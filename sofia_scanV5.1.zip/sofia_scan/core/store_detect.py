"""STAGE 2c: lọc "cửa hàng THẬT" (storefront đang mở bán) theo PLATFORM.

fingerprint (2a/2a-woo) chỉ xác nhận "có Magento/WooCommerce" — nhưng nhiều URL
thoả fingerprint không phải cửa hàng thật:
  - cài mới chưa setup (trang mặc định, không giỏ hàng/khách),
  - maintenance mode / "coming soon" / "under construction",
  - dùng làm blog/CMS/landing không có storefront bán hàng,
  - trang chết/403/404 (đã đổi domain, chỉ còn REST/API mở),
  - WAF/CDN chặn (429), trang CHALLENGE WAF, hoặc homepage không phải HTML.

Stage này probe đặc tính storefront đang bán và chấm điểm — PLATFORM-AWARE:
`run(..., platform)` = "magento" | "woocommerce", path giỏ/login/api đổi theo
platform (PLATFORM_PATHS):
  magento      cart=/checkout/cart/  login=/customer/account/login/
  woocommerce  cart=/cart/           login=/my-account/
               api =/wp-json/wc/store/v1/products?per_page=1

    +3  trang chủ 200 + marker bán hàng (catalog/minicart/giỏ/tìm kiếm...)
    +3  trang giỏ 200 + NỘI DUNG giỏ khớp platform  (verify_content)
    +1  trang giỏ 200 nhưng nội dung không khớp / redirect
    +2  trang login/tài khoản 200 + nội dung khớp platform
    +1  trang login 200 nhưng nội dung không khớp
    +4  (Woo) Store API products trả JSON 200 — bằng chứng mạnh nhất:
        cửa hàng đang có sản phẩm thật công khai, không cần auth
    +2  (Woo) Store API trả JSON lỗi "woocommerce_rest" (API bị khóa nhưng
        server vẫn là Woo thật)
    -8  trang chủ không phải 2xx (403/404/5xx — site chết/chặn; vẫn probe tiếp)
    LOẠI NGAY: 503 maintenance / "coming soon / under construction" / TRANG
      CHALLENGE WAF ("Just a moment", "Checking your browser", ddos-guard,
      incapsula, datadome… — waf_detect) — chỉ tìm trong ~6KB đầu + <title>
      tránh false positive; 429 = đang bị chặn tốc độ.

Tổng đạt `store_detect.min_score` (mặc định 3) → "cửa hàng thật".
Short-circuit: đủ điểm thì dừng probe sớm.

Cấu hình (block store_detect trong config.yaml):
  enabled         bật/tắt cả stage (true)
  min_score       ngưỡng điểm (3)
  check_cart      probe trang giỏ theo platform (true)
  check_login     probe trang login/tài khoản theo platform (true)
  waf_detect      nhận diện trang challenge WAF → loại "waf-challenge" (true)
  verify_content  xác minh nội dung cart/login khớp platform (true)
  check_products  (Woo) probe Store API products (true)
  threads         số worker RIÊNG của stage (20) — không tranh với fingerprint
  retries         số lần thử lại lỗi mạng tạm thời (1)
  jitter_min/max  ngủ ngẫu nhiên (giây) TRƯỚC mỗi URL — giãn nhịp, chống chặn
  head_limit      số byte đầu body để tìm dấu hiệu "chưa mở bán" (6144)

Output:
    Magento:    output/stores.txt + stores_scored.txt + stores_reasons.txt (giữ nguyên)
    WooCommerce: output/stores.txt (gộp chung) + stores_scored_woo.txt
                 + stores_reasons_woo.txt — tách riêng để dễ soi
Contract: run(urls, workdir, global_stores, cfg, platform="magento") → list URL
 cửa hàng thật.
"""
import concurrent.futures
import os
import random
import re
import time

import requests
import urllib3

from utils import file_io, http
from utils.logger import info, warn

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

USER_AGENT = "Mozilla/5.0 (compatible; SofiaScan/1.0)"
BODY_LIMIT = 200000  # giới hạn body đọc <title> (tránh tốn RAM trang lớn)
HEAD_LIMIT = 6 * 1024  # số byte đầu dùng tìm dấu hiệu "chưa mở bán"

DEFAULT_MIN_SCORE = 3
DEFAULT_THREADS = 20
DEFAULT_RETRIES = 1
DEFAULT_JITTER_MIN = 0.0
DEFAULT_JITTER_MAX = 0.2
REDIRECT_CAP = 5  # session.max_redirects — không đuổi theo redirect dây chuyền

# Marker một STOREFRONT đang bán xuất hiện trong HTML — dùng chung cho Magento
# VÀ WooCommerce (catalog sản phẩm / nút thêm giỏ / giỏ hàng / tìm kiếm / tài khoản).
STORE_MARKERS = re.compile(
    r"(?:"
    # Magento / Adobe Commerce
    r"data-product-id|product-item|product\.name|price-box|price-wrapper|"
    r"add-to-cart|addtocart|tocart\b|action\.tocart|swatch-opt|"
    r"product-info-price|products-grid|product-list|product-list-container|"
    r"minicart|minicart-wrapper|block-minicart|showcart\b|action\.showcart|"
    r"block-search|catalogsearch|search-mini|"
    r"customer/account/login|checkout/cart|checkout/onepage|"
    r"category-products|products\.wrapper|ol\.products|"
    # WooCommerce (loop sản phẩm / nút add-to-cart / khối checkout)
    r"woocommerce-loop-product|woocommerce-notices-wrapper|"
    r"woocommerce-result-count|woocommerce-products-header|"
    r"add_to_cart_button|wp-block-woocommerce|wc-block-|"
    r"woocommerce-checkout|woocommerce-cart|wc_ajax|added_to_cart|"
    # MARKER MỞ RỘNG — dùng chung cả 2 platform (theme tùy biến không luôn
    # dùng class chuẩn, thêm đặc tính storefront phổ biến khác):
    r"product-card|product-grid|product-item-link|product-photo|"
    r"price[-_]?amount|regular-price|special-price|old-price|"
    r"mini-cart|cart-icon|cart-count|cart_count|cart-contents|"
    r"shopping-cart|checkout-button|proceed-to-checkout|"
    r"onpage-checkout|checkout-step|payment-method|"
    r"add-to-wishlist|add-to-compare|qty-input|quantity-input|"
    r"data-bind=.scope.?[:=].?['\"](?:minicart|cartItems)"
    r")",
    re.I,
)

# Marker riêng theo PLATFORM (chấm thêm điểm storefront khi marker chung không
# bắt được — theme tùy biến thường còn để lại dấu hiệu framework này):
PLATFORM_MARKERS = {
    "magento": re.compile(
        r"(?:"
        r"data-mage-init|Mage\.Cookies|mage/translate|requirejs-config|"
        r"magento-version|Magento_Theme|Magento_Catalog|"
        r"checkout-index-index|customer-data|section-data|"
        r"static/version\d|pub/static|"
        r"magento\\.(?:js|ui|theme)|x-magento-init"
        r")",
        re.I),
    "woocommerce": re.compile(
        r"(?:"
        r"woocommerce-store-notice|woocommerce-page|site-header-cart|"
        r"woocommerce-mini-cart|wc-add-to-cart-js|woocommerce-tabs|"
        r"woocommerce-info|woocommerce-message|woocommerce-price|"
        r"wc_price|woocommerce-billing-fields|woocommerce-form-coupon|"
        r"wp-block-woocommerce-|yith-wcwl|is-added-to-cart|"
        r"woocommerce-no-js|wp-woocommerce|storefront-(?:theme|handheld)"
        r")",
        re.I),
}

# Dấu hiệu site CHƯA mở bán / đang bảo trì → loại ngay.
# Chỉ áp dụng cho phần ĐẦU trang (HEAD_LIMIT byte) + nội dung <title> — nếu
# quét toàn bộ body dễ false positive (promo/blog nhắc "coming soon").
NOT_STORE_RE = re.compile(
    r"(?:"
    r"Service Temporarily Unavailable|under construction|"
    r"coming soon|is under maintenance|maintenance mode|"
    r"we[’']?ll be back|site is offline|currently unavailable"
    r")",
    re.I,
)
TITLE_RE = re.compile(r"<title[^>]*>(.*?)</title>", re.I | re.S)

# Content-Type rõ ràng KHÔNG phải HTML — không thể chấm marker storefront
# trên đó (JSON/ảnh/PDF có thể chứa từ "product" ngẫu nhiên → false positive).
NON_HTML_RE = re.compile(
    r"^(?:image/|video/|audio/|application/pdf|application/json|"
    r"application/octet-stream|text/plain|application/xml|font/)",
    re.I,
)

REDIRECT_STATUSES = (301, 302, 303, 307, 308)
TOO_MANY = 429  # đang bị giới hạn tốc độ — KHÔNG nên quấy thêm
# Path cũ (giữ cho tương thích import/test cũ) — mã mới dùng PLATFORM_PATHS.
CART_PATH = "/checkout/cart/"
LOGIN_PATH = "/customer/account/login/"

# Path theo PLATFORM — storefront thật phải có giỏ hàng + luồng tài khoản.
PLATFORM_PATHS = {
    "magento": {
        "cart": "/checkout/cart/",
        "login": "/customer/account/login/",
        "products_api": None,
    },
    "woocommerce": {
        "cart": "/cart/",
        "login": "/my-account/",
        # Store API công khai: trả danh sách sản phẩm thật KHÔNG cần auth.
        "products_api": "/wp-json/wc/store/v1/products?per_page=1",
    },
}

# Trang CHALLENGE của WAF/CDN (Cloudflare/Ddos-Guard/Incapsula-Imperva/
# DataDome/Sucuri/PerimeterX/Radware…) — nội dung trả về KHÔNG phải storefront
# thật, chấm điểm trên đó sẽ cho kết quả sai. Chỉ tìm trong phần đầu trang
# + <title> (cùng nguyên tắc với NOT_STORE_RE).
WAF_CHALLENGE_RE = re.compile(
    r"(?:"
    r"just a moment|checking your browser|attention required|one more step|"
    r"cf-browser-verification|cf_chl_|challenge-platform|cdn-cgi/challenge|"
    r"ddos-guard|ddos protection|incapsula|imperva|sucuri|datadome|"
    r"perimeterx|distil networks|captcha-delivery|radware|"
    r"enable javascript and cookies|verify you are human|"
    r"ray id\b|request unsuccessful|"
    r"access to this (?:page|service) has been denied"
    r")",
    re.I,
)

# Nội dung đặc trưng của trang GIỎ HÀNG theo platform — xác minh URL 200 này
# THẬT SỰ là trang giỏ (không phải catch-all 404 mềm/redirect về home).
CART_CONTENT_RE = {
    "magento": re.compile(
        r"(?:checkout/cart|cart-item-block|cart-container|cart-wrapper|"
        r"minicart|cart-empty|summary item|checkout\.cart)",
        re.I),
    "woocommerce": re.compile(
        r"(?:woocommerce-cart|cart-empty|return-to-shop|"
        r"woocommerce-notices-wrapper|woocommerce-checkout|your cart|"
        r"shopping cart)",
        re.I),
}

# Nội dung đặc trưng của trang ĐĂNG NHẬP/TÀI KHOẢN theo platform.
LOGIN_CONTENT_RE = {
    "magento": re.compile(
        r"(?:customer/account/login|login-container|block-login|"
        r"data-role=\"email\"|signin-tooltip|sign[ -]?in)",
        re.I),
    "woocommerce": re.compile(
        r"(?:woocommerce-MyAccount|woocommerce-form-login|myaccount|"
        r"lost your password|remember me|username or email address)",
        re.I),
}


def _cfg_values(cfg):
    sd = cfg.get("store_detect") or {}
    return {
        "min_score": int(sd.get("min_score", DEFAULT_MIN_SCORE)),
        "check_cart": bool(sd.get("check_cart", True)),
        "check_login": bool(sd.get("check_login", True)),
        "threads": max(1, int(sd.get("threads", DEFAULT_THREADS))),
        "retries": max(0, int(sd.get("retries", DEFAULT_RETRIES))),
        "waf_detect": bool(sd.get("waf_detect", True)),
        "verify_content": bool(sd.get("verify_content", True)),
        "check_products": bool(sd.get("check_products", True)),
        "jitter_min": float(sd.get("jitter_min", DEFAULT_JITTER_MIN)),
        "jitter_max": float(sd.get("jitter_max", DEFAULT_JITTER_MAX)),
        "head_limit": max(512, int(sd.get("head_limit", HEAD_LIMIT))),
    }


ACCEPT_HTML = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"


def _new_session():
    """Session DÙNG CHUNG thread-local (utils/http.py) — tái dùng keep-alive/pool.

    Trước đây mỗi URL tạo 1 requests.Session() mới → ở quy mô lớn sinh hàng trăm
    nghìn session/handshake (tốn CPU + rủi ro cạn FD). Nay lấy session thread-local
    đã cấu hình pool/retry; chỉ chỉnh verify/redirect cap cho nhất quán.
    """
    session = http.get_session()
    session.verify = False
    try:
        session.max_redirects = int(getattr(session, "max_redirects", None)
                                    or REDIRECT_CAP)
    except (TypeError, ValueError):
        session.max_redirects = REDIRECT_CAP
    session.headers.setdefault("User-Agent", USER_AGENT)
    session.headers.setdefault("Accept", ACCEPT_HTML)
    return session


def _http_get(session, url, timeout, retries, allow_redirects=True):
    """GET có thử lại tối đa `retries` lần cho LỖI MẠNG (RequestException).

    Chỉ retry lỗi mạng tạm thời — KHÔNG retry theo HTTP status (503/429 là
    tín hiệu của máy chủ, retry chỉ làm tình hình tệ hơn). Trả response hoặc
    None khi cạn lượt thử."""
    attempt = 0
    while True:
        try:
            return session.get(url, timeout=timeout, allow_redirects=allow_redirects)
        except requests.RequestException as exc:
            attempt += 1
            if attempt > retries:
                return None
            # backoff ngắn + jitter trước khi thử lại
            time.sleep(0.5 + random.random() * 1.5)


def _is_html(resp):
    """Content-Type có vẻ HTML (thiếu header → mặc định HTML như server cũ)."""
    ctype = (resp.headers.get("Content-Type") or "").lower()
    if not ctype:
        return True
    if "html" in ctype or ctype.startswith("text/"):
        return True
    return not NON_HTML_RE.match(ctype)


def _head_and_title(resp, head_limit):
    """(đầu trang, nội dung <title>) để tìm dấu hiệu chưa mở bán — KHÔNG quét
    toàn bộ body (tránh false positive từ nội dung quảng cáo/blog)."""
    text = resp.text or ""
    head = text[:head_limit]
    title_match = TITLE_RE.search(text[:BODY_LIMIT])
    title = title_match.group(1) if title_match else ""
    return head + "\n" + title[:head_limit]


def _store_markers(platform):
    """Regex marker bán hàng cho platform: marker CHUNG + marker RIÊNG platform
    (marker mở rộng — theme tùy biến thường vẫn để lại dấu hiệu framework)."""
    extra = PLATFORM_MARKERS.get(platform)
    if extra is None:
        return STORE_MARKERS
    return re.compile("(?:" + STORE_MARKERS.pattern + "|" + extra.pattern + ")",
                      STORE_MARKERS.flags)


def _waf_challenge(resp, head_limit):
    """True khi body/<title> (phần ĐẦU trang) chứa dấu hiệu trang CHALLENGE WAF."""
    return bool(WAF_CHALLENGE_RE.search(_head_and_title(resp, head_limit)))


def _looks_like_json(resp):
    """Response có vẻ JSON (theo Content-Type hoặc body bắt đầu bằng {/[)."""
    ctype = (resp.headers.get("Content-Type") or "").lower()
    if "json" in ctype:
        return True
    body = (resp.text or "").lstrip()
    return bool(body) and body[0] in "{["


def _probe(url, timeout, opts, platform="magento"):
    """Probe 1 URL theo PLATFORM → (url, is_store, score, evidence). Không raise.

    Trang chủ đọc qua PageCache dùng chung (nếu fingerprint đã tải thì không GET
    lại) → tiết kiệm request đáng kể khi cả pipeline chạy trên cùng host.
    """
    paths = PLATFORM_PATHS.get(platform) or PLATFORM_PATHS["magento"]
    session = _new_session()
    min_score = opts["min_score"]
    retries = opts["retries"]
    waf_detect = opts["waf_detect"]
    verify_content = opts["verify_content"]
    markers = _store_markers(platform)

    total = 0
    evidence = []

    def add(points, why):
        nonlocal total
        total += points
        evidence.append(why)

    # Jitter giãn nhịp giữa các URL — chống burst request dễ bị WAF chặn.
    jitter = opts["jitter_max"] - opts["jitter_min"]
    if jitter > 0:
        time.sleep(opts["jitter_min"] + random.random() * jitter)

    # 1) Trang chủ — phải là storefront, không được maintenance/coming-soon/WAF
    resp = http.fetch(url, timeout=timeout, retries=retries, allow_redirects=True,
                      cache=http.get_page_cache())
    if resp is None:
        return url, False, total, ["err:connect"]

    status = resp.status_code
    if status == TOO_MANY:
        return url, False, total, ["home:429"]
    if status == 503:
        return url, False, total, ["home:503-maintenance"]
    if NOT_STORE_RE.search(_head_and_title(resp, opts["head_limit"])):
        return url, False, total, ["home:not-store"]
    if waf_detect and _waf_challenge(resp, opts["head_limit"]):
        return url, False, total, ["home:waf-challenge"]

    if not _is_html(resp):
        add(0, "home:not-html")  # không chấm được marker — chờ giỏ/tài khoản
    elif status not in (200, 201, 202, 204):
        add(-8, f"home:{status}")
    elif markers.search((resp.text or "")[:BODY_LIMIT]):
        add(3, "home:store-markers")
        if total >= min_score:
            return url, True, total, evidence

    # 2) Trang GIỎ theo platform — giỏ hoạt động = bằng chứng mạnh của storefront.
    # verify_content: 200 mà nội dung KHÔNG khớp trang giỏ platform (catch-all
    # 404 mềm/redirect về home) chỉ được +1 thay vì +3.
    if opts["check_cart"]:
        resp = _http_get(session, url.rstrip("/") + paths["cart"], timeout,
                         retries, allow_redirects=False)
        if resp is not None:
            if resp.status_code == TOO_MANY:
                add(0, "cart:429")
            elif resp.status_code == 503:
                return url, False, total, evidence + ["cart:503-maintenance"]
            elif NOT_STORE_RE.search(_head_and_title(resp, opts["head_limit"])):
                return url, False, total, evidence + ["cart:not-store"]
            elif waf_detect and _waf_challenge(resp, opts["head_limit"]):
                return url, False, total, evidence + ["cart:waf-challenge"]
            elif resp.status_code == 200 and _is_html(resp):
                if verify_content and not CART_CONTENT_RE.get(
                        platform, CART_CONTENT_RE["magento"]).search(
                        (resp.text or "")[:BODY_LIMIT]):
                    add(1, "cart:200-no-content")
                else:
                    add(3, "cart:200")
                    if total >= min_score:
                        return url, True, total, evidence
            elif resp.status_code in REDIRECT_STATUSES:
                add(1, "cart:redirect")

    # 3) Trang LOGIN/TÀI KHOẢN theo platform — cửa hàng có luồng đăng nhập khách.
    if opts["check_login"]:
        resp = _http_get(session, url.rstrip("/") + paths["login"], timeout,
                         retries, allow_redirects=False)
        if resp is not None:
            if resp.status_code == TOO_MANY:
                add(0, "login:429")
            elif resp.status_code == 503:
                return url, False, total, evidence + ["login:503-maintenance"]
            elif NOT_STORE_RE.search(_head_and_title(resp, opts["head_limit"])):
                return url, False, total, evidence + ["login:not-store"]
            elif waf_detect and _waf_challenge(resp, opts["head_limit"]):
                return url, False, total, evidence + ["login:waf-challenge"]
            elif resp.status_code == 200 and _is_html(resp):
                if verify_content and not LOGIN_CONTENT_RE.get(
                        platform, LOGIN_CONTENT_RE["magento"]).search(
                        (resp.text or "")[:BODY_LIMIT]):
                    add(1, "login:200-no-content")
                else:
                    add(2, "login:200")
                    if total >= min_score:
                        return url, True, total, evidence

    # 4) (Woo) Store API products — bằng chứng mạnh nhất: JSON 200 có sản phẩm
    # thật công khai (không cần auth); JSON lỗi "woocommerce_rest" = API bị khóa
    # nhưng server vẫn là Woo thật → +2. Chỉ chạy khi trang chủ không đủ điểm.
    if platform == "woocommerce" and opts["check_products"] and paths["products_api"]:
        resp = _http_get(session, url.rstrip("/") + paths["products_api"],
                         timeout, retries, allow_redirects=False)
        if resp is not None and resp.status_code == 200 and _looks_like_json(resp):
            body = (resp.text or "")[:BODY_LIMIT]
            if "woocommerce_rest" in body:
                add(2, "products:rest-error")  # API khóa — vẫn là Woo thật
            elif body.lstrip().startswith("[") or '"id"' in body:
                add(4, "products:api-json")

    return url, total >= min_score, total, evidence


def probe(url, timeout, min_score=DEFAULT_MIN_SCORE, check_cart=True,
          check_login=True, retries=DEFAULT_RETRIES, platform="magento"):
    """Contract nhẹ cho test/tích hợp: chỉ cần 1 URL (+ platform tùy chọn).

    Trả (is_store, score) — 2 phần tử giữa của kết quả _probe.
    """
    opts = {
        "min_score": min_score, "check_cart": check_cart,
        "check_login": check_login, "threads": 1, "retries": retries,
        "jitter_min": 0.0, "jitter_max": 0.0, "head_limit": HEAD_LIMIT,
        "waf_detect": True, "verify_content": True, "check_products": True,
    }
    return _probe(url, timeout, opts, platform=platform)[1:3]


def _reject_reason(evidence):
    """Lý do "không phải cửa hàng" để gom vào bảng đếm — lấy mốc loại đầu tiên."""
    if not evidence:
        return "score-thap"
    first = evidence[0]
    for prefix in ("err:", "home:429", "home:503", "home:not-store",
                   "home:waf-challenge",
                   "cart:503", "cart:not-store", "cart:waf-challenge",
                   "login:503", "login:not-store", "login:waf-challenge"):
        if first.startswith(prefix):
            return prefix
    if first.startswith("home:"):
        return "home-khong-2xx"  # 403/404/5xx...
    return first.split(":")[0]


# Hậu tố file debug theo platform — Woo tách riêng để dễ soi (docstring phía trên).
_DEBUG_SUFFIX = {"magento": "", "woocommerce": "_woo"}


def run(urls, workdir, global_stores, cfg, platform="magento"):
    """urls: list URL theo platform → list URL là CỬA HÀNG THẬT; append stores.txt.

    Ghi debug ra output/work/<slug>/stores_scored[.ext] + bảng lý do loại ra
    stores_reasons[.ext] (Woo dùng hậu tố _woo), trả list cửa hàng thật để
    pipeline chỉ đẩy target này xuống stage 2b-4.
    """
    if not urls:
        return []
    opts = _cfg_values(cfg)
    timeout = cfg.get("timeout", 15)
    suffix = _DEBUG_SUFFIX.get(platform, f"_{platform}")
    label = platform.capitalize()

    found = set()
    scored = []
    reasons = {}
    with concurrent.futures.ThreadPoolExecutor(
            max_workers=min(opts["threads"], max(1, len(urls)))) as pool:
        futures = [pool.submit(_probe, u, timeout, opts, platform) for u in urls]
        for future in concurrent.futures.as_completed(futures):
            url, is_store, score, evidence = future.result()
            scored.append(f"{url} {score} {' '.join(evidence)}".strip())
            if is_store:
                found.add(url)
            else:
                reason = _reject_reason(evidence)
                reasons[reason] = reasons.get(reason, 0) + 1

    stores = file_io.dedupe_sort(found)
    file_io.append_lines(global_stores, stores)

    scored_file = os.path.join(workdir, f"stores_scored{suffix}.txt")
    file_io.write_lines(scored_file, file_io.dedupe_sort(scored))
    reasons_file = os.path.join(workdir, f"stores_reasons{suffix}.txt")
    if reasons:
        file_io.write_lines(reasons_file, file_io.dedupe_sort(
            [f"{count} {reason}" for reason, count in sorted(
                reasons.items(), key=lambda kv: (-kv[1], kv[0]))]))

    info(f"stage2c: {len(stores)}/{len(urls)} {label} là cửa hàng THẬT "
         f"(min_score={opts['min_score']}, cart={'bật' if opts['check_cart'] else 'tắt'}, "
         f"login={'bật' if opts['check_login'] else 'tắt'}, "
         f"waf={'bật' if opts['waf_detect'] else 'tắt'}, "
         f"products={'bật' if opts['check_products'] else 'tắt'}, "
         f"threads={opts['threads']})")
    if reasons:
        top = ", ".join(f"{r}={c}" for r, c in sorted(
            reasons.items(), key=lambda kv: -kv[1])[:5])
        info(f"stage2c: lý do loại (top) — {top} "
             f"(chi tiết: {os.path.relpath(reasons_file, os.getcwd())})")
    if urls and not stores:
        warn(f"stage2c: 0/{len(urls)} {label} thoả điều kiện cửa hàng thật — "
             f"không có target cho stage 2b-4 trong dải này")
    return stores

