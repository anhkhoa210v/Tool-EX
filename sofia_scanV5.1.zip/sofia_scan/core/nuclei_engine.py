"""Nuclei engine dùng chung — chạy nuclei cho CẢ nhánh Magento & WooCommerce.

Trước đây logic gọi nuclei nằm rải trong core/cve_scan.py (_nuclei_help/
_nuclei_supports/_nuclei_flags/_run_nuclei...) và core/woo_cve_scan.py gọi
mượn qua cve_scan. Nay gom vào MỘT engine, nâng cấp thêm:

  * template update  — cve.nuclei.update_templates=true → tự chạy
    `nuclei -update-templates` MỘT lần mỗi tiến trình trước lượt quét đầu
    (nuclei tự cache ở ~/nuclei-templates, không lặp lại mỗi stage).
  * auto community discovery — cve.nuclei.auto_discovery=true → tự DÒ
    template cộng đồng cho từng CVE trong thư mục templates_dir (mặc định
    ~/nuclei-templates, cấu trúc http/cves/<năm>/CVE-*.yaml) thay vì chỉ
    phỏng đoán qua `-id`: CVE có file → chạy thẳng qua `-t <path>` (chính
    xác hơn, không phụ thuộc `nuclei -tl`); CVE không tìm thấy → fallback
    `-id` và được kiểm tra tồn tại qua `nuclei -tl` như cũ.
  * JSONL output — cve.nuclei.json_output=true → nuclei chạy với `-j`
    (JSONL), engine parse từng dòng JSON thành dòng finding đọc được
    (`<url> [cve:CVE-ID] [severity] name`), có matcher-status=true mới giữ;
    JSON hỏng/dòng lạ → fallback dòng thô (không mất finding). Tắt cờ →
    output text như bản cũ.
  * chunking — cve.nuclei.chunk_size=N > 0 → chia targets thành các phần N
    URL, chạy từng lượt nuclei riêng: timeout một chunk không vứt kết quả
    các chunk khác (trước đây 1 lượt quá giờ → phần sau bị mất).
  * retry — cve.nuclei.max_retries=N → lượt nuclei lỗi (rc≠0, KHÔNG tính
    timeout rc=124) được thử lại tối đa N lần, nghỉ retry_delay giây giữa
    2 lần; timeout không retry (chỉ càng tốn giờ, tăng max_seconds thay vào).
  * new flags — engine tự phát hiện cờ qua `nuclei -help` (chống lệch bản):
    thêm `-duc` (disable-update-check) khi nuclei hỗ trợ — nuclei không tự
    check update mỗi lượt (chậm + gọi ra internet không cần thiết).
  * parallel sources — cve.nuclei.parallel_sources=true → chạy các NGUỒN
    template (local / community) SONG SONG bằng thread pool thay vì tuần tự.

API chính:
  nuclei_config(cfg)             chuẩn hóa block cve.nuclei (dict an toàn)
  ensure_templates_updated(cfg)  tự cập nhật templates (cache mỗi tiến trình)
  discover_community_templates(ids, templates_dir) → {CVE: [đường dẫn]}
  community_ids_available(ids)   lọc CVE có template qua `nuclei -tl`
  run_scan(targets_file, out, extra, cfg, label) → (lines, ok, n_failed)
  run_sources(tasks, cfg)        chạy nhiều nguồn (song song/tuần tự)

Hàm nào cũng không raise (an toàn pipeline) — lỗi binary/I/O thành cảnh
báo + trả kết quả rỗng/partial.
"""
import json
import os
import re
import shutil
import subprocess
import threading
import time
import traceback
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urlparse

from utils import file_io, runner
from utils.logger import debug, info, warn

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# CVE-ID (dùng cho discovery + JSONL parse) — cùng mẫu với cve_scan.CVE_RE.
CVE_RE = re.compile(r"CVE-\d{4}-\d{4,7}", re.IGNORECASE)

DEFAULT_NUCLEI_MAX_SECONDS = 7200
DEFAULT_TEMPLATES_DIR = os.path.join(os.path.expanduser("~"), "nuclei-templates")

# ── Cache dùng chung tiến trình ─────────────────────────────────────────
_FLAG_CACHE = {"help": None}          # text `nuclei -help` (đọc 1 lần)
_TL_CACHE = {"text": None}            # text `nuclei -tl -silent` (đọc 1 lần)
_UPDATE_LOCK = threading.Lock()
_UPDATED = {"done": False}            # -update-templates chỉ chạy 1 lần
_DISCOVERY_CACHE = {}                 # (templates_dir, ids frozenset) → kết quả
_DISCOVERY_LOCK = threading.Lock()


def nuclei_config(cfg):
    """Chuẩn hóa block cve.nuclei — điền default, trả dict an toàn.

    Giữ nguyên các khóa cũ (enabled/concurrency/…/severity) và thêm khóa
    mới của engine: update_templates, templates_dir, auto_discovery,
    json_output, chunk_size, max_retries, retry_delay, parallel_sources.
    """
    nuc = (cfg.get("cve") or {}).get("nuclei") or {}
    templates_dir = str(nuc.get("templates_dir") or "").strip() or DEFAULT_TEMPLATES_DIR
    if not os.path.isabs(templates_dir):
        templates_dir = os.path.join(BASE_DIR, templates_dir)
    return {
        # ── khóa cũ (giữ nguyên ngữ nghĩa) ──
        "enabled": bool(nuc.get("enabled", True)),
        "concurrency": int(nuc.get("concurrency") or 0),
        "rate_limit": int(nuc.get("rate_limit") or 0),
        "timeout": int(nuc.get("timeout") or cfg.get("timeout") or 15),
        "retries": int(nuc.get("retries") or 2),
        "follow_redirects": bool(nuc.get("follow_redirects", False)),
        "max_seconds": int(nuc.get("max_seconds") or DEFAULT_NUCLEI_MAX_SECONDS),
        "local_templates": bool(nuc.get("local_templates", True)),
        "community": bool(nuc.get("community", True)),
        "severity": str(nuc.get("severity") or "").strip(),
        # ── khóa mới (nâng cấp engine) ──
        # Tự `nuclei -update-templates` trước lượt quét đầu mỗi tiến trình.
        "update_templates": bool(nuc.get("update_templates", False)),
        # Thư mục nuclei-templates để dò template cộng đồng (auto discovery).
        "templates_dir": templates_dir,
        # Tự dò file template cộng đồng cho từng CVE (chạy qua -t chính xác
        # hơn -id; CVE không dò được mới fallback -id + kiểm tra -tl).
        "auto_discovery": bool(nuc.get("auto_discovery", True)),
        # Output JSONL (-j) — finding đầy đủ hơn (severity, name, matched-at).
        "json_output": bool(nuc.get("json_output", True)),
        # Số URL mỗi lượt nuclei (0 = cả list một lượt như bản cũ).
        "chunk_size": int(nuc.get("chunk_size") or 0),
        # Số lần thử lại LỖI (rc≠0, không tính timeout) của 1 lượt nuclei.
        "max_retries": int(nuc.get("max_retries") or 0),
        # Giây nghỉ giữa 2 lần thử lại.
        "retry_delay": float(nuc.get("retry_delay") or 5),
        # Chạy các nguồn template (local/community) SONG SONG.
        "parallel_sources": bool(nuc.get("parallel_sources", True)),
    }


# ── Phát hiện cờ nuclei (đọc -help 1 lần) ───────────────────────────────

def _nuclei_help():
    """Toàn bộ -help của nuclei (cache) hoặc '' nếu đọc thất bại."""
    if _FLAG_CACHE["help"] is None:
        try:
            proc = runner.run(["nuclei", "-help"], timeout=60)
            _FLAG_CACHE["help"] = (proc.stdout or "") + "\n" + (proc.stderr or "")
        except (OSError, subprocess.SubprocessError) as exc:
            warn(f"nuclei -help thất bại: {exc.__class__.__name__}: {exc} | "
                 + traceback.format_exc().rstrip())
            _FLAG_CACHE["help"] = ""
    return _FLAG_CACHE["help"]


def _nuclei_supports(*tokens):
    """True nếu nuclei -help có chứa bất kỳ token nào (vd "-follow-redirects")."""
    help_text = _nuclei_help()
    return any(re.search(re.escape(token), help_text, re.I) for token in tokens)


def _nuclei_flags(ncfg):
    """cfg nuclei → cờ CLI. Chỉ thêm cờ nuclei bản đang chạy hỗ trợ."""
    flags = []
    if ncfg["concurrency"] > 0 and _nuclei_supports("-concurrency", " -c ", "concurrency"):
        flags += ["-c", str(ncfg["concurrency"])]
    if ncfg["rate_limit"] > 0 and _nuclei_supports("-rate-limit", "-rl"):
        flags += ["-rl", str(ncfg["rate_limit"])]
    if ncfg["retries"] > 0:
        flags += ["-retries", str(ncfg["retries"])]
    if ncfg["timeout"] > 0:
        flags += ["-timeout", str(ncfg["timeout"])]
    if ncfg["follow_redirects"] and _nuclei_supports("-follow-redirects", "-fr"):
        flags += ["-follow-redirects"]
    if ncfg["severity"] and _nuclei_supports("-severity"):
        flags += ["-severity", ncfg["severity"]]
    # Engine tự quản templates (update_templates) → tắt self-update-check
    # của nuclei cho đỡ chậm/không cần gọi ra internet mỗi lượt.
    if _nuclei_supports("-disable-update-check", "-duc"):
        flags += ["-disable-update-check"]
    return flags


def _jsonl_flags(ncfg):
    """Cờ output JSONL nếu bật và nuclei hỗ trợ (vd `-j, -jsonl`)."""
    if not ncfg["json_output"]:
        return []
    if _nuclei_supports("-jsonl", "-j "):
        # Chọn cờ dài "-jsonl" khi có (rõ nghĩa), fallback "-j" ở bản cũ.
        if "-jsonl" in _nuclei_help():
            return ["-jsonl"]
        return ["-j"]
    debug("nuclei không hỗ trợ output JSONL — chạy output text")
    return []


# ── Template update ─────────────────────────────────────────────────────

def ensure_templates_updated(cfg, force=False):
    """Chạy `nuclei -update-templates` MỘT lần mỗi tiến trình (nếu bật).

    Trả True nếu bộ template đã sẵn sàng (đã update thành công HOẶC không
    bật update HOẶC đã update từ trước). Không raise.
    """
    ncfg = nuclei_config(cfg)
    if not ncfg["update_templates"]:
        return True
    with _UPDATE_LOCK:
        if _UPDATED["done"] and not force:
            return True
        info("[nuclei] cập nhật templates (nuclei -update-templates)...")
        proc = runner.run(["nuclei", "-update-templates", "-silent"], timeout=600)
        if proc.returncode == 0:
            info("[nuclei] templates đã cập nhật xong")
            _UPDATED["done"] = True
            return True
        warn(f"[nuclei] nuclei -update-templates exit {proc.returncode}: "
             f"{(proc.stderr or '').strip()[-300:]} — chạy tiếp với bộ template "
             f"hiện có (tắt cve.nuclei.update_templates nếu không muốn tự cập nhật)")
        return False


# ── Auto community discovery ────────────────────────────────────────────

def discover_community_templates(ids, templates_dir=None):
    """Tự DÒ file template cộng đồng cho từng CVE trong `templates_dir`.

    Duyệt cây thư mục (mặc định ~/nuclei-templates), chỉ quan tâm file
    *.yaml/*.yml có TÊN FILE chứa CVE-ID (quy ước nuclei-templates:
    http/cves/<năm>/CVE-YYYY-NNNN-<slug>.yaml); file trúng tên được đọc để
    xác minh `id:` trong nội dung khớp CVE (tránh gán nhầm kết quả).
    Trả {CVE-ID: [đường dẫn]} — chỉ CVE tìm thấy mới có khóa.
    Không raise; thư mục không tồn tại → {} kèm cảnh báo (1 lần mỗi dir).
    """
    ids = sorted({str(c).strip().upper() for c in (ids or []) if str(c).strip()})
    if not ids:
        return {}
    templates_dir = os.path.abspath(templates_dir or DEFAULT_TEMPLATES_DIR)
    cache_key = (templates_dir, frozenset(ids))
    with _DISCOVERY_LOCK:
        cached = _DISCOVERY_CACHE.get(cache_key)
    if cached is not None:
        return {k: list(v) for k, v in cached.items()}
    if not os.path.isdir(templates_dir):
        warn(f"[nuclei] templates_dir không tồn tại: {templates_dir} — "
             f"bỏ qua auto community discovery (kết quả sẽ chạy qua -id "
             f"và được kiểm tra bằng nuclei -tl)")
        return {}

    id_set = set(ids)
    found = {cve: [] for cve in ids}
    scanned = 0
    try:
        for root, dirs, files in os.walk(templates_dir):
            # Bỏ qua rác .git (nuclei-templates tải bằng git có thể kèm).
            dirs[:] = [d for d in dirs if d != ".git"]
            for fname in files:
                if not fname.lower().endswith((".yaml", ".yml")):
                    continue
                # Tên file chứa CVE — phần lớn template cộng đồng đặt tên
                # trùng id; lọc theo tên trước khi đọc nội dung (nhanh).
                hits = {m.group(0).upper() for m in CVE_RE.finditer(fname)}
                if not (hits & id_set):
                    continue
                path = os.path.join(root, fname)
                try:
                    with open(path, encoding="utf-8", errors="replace") as fh:
                        head = fh.read(65536)
                except OSError as exc:
                    debug(f"[nuclei] không đọc được template {path}: {exc}")
                    continue
                content_ids = {m.group(0).upper() for m in CVE_RE.finditer(head)}
                for cve in (hits & id_set):
                    if cve in content_ids:
                        found[cve].append(path)
                scanned += 1
    except OSError as exc:
        warn(f"[nuclei] dò templates_dir {templates_dir} lỗi: {exc} — "
             f"kết quả discovery có thể thiếu")
    result = {cve: paths for cve, paths in found.items() if paths}
    n_paths = sum(len(v) for v in result.values())
    info(f"[nuclei] auto discovery: {len(result)}/{len(ids)} CVE có template "
         f"cộng đồng trong {templates_dir} ({n_paths} file, đã soát "
         f"{scanned} file khớp tên)")
    with _DISCOVERY_LOCK:
        _DISCOVERY_CACHE[cache_key] = {k: list(v) for k, v in result.items()}
    return result


_TL_CACHE = {"text": None}


def _nuclei_template_list():
    """Output của `nuclei -tl -silent` (cache 1 lần) — '' nếu lấy thất bại.

    Dùng để kiểm tra template cộng đồng CÓ TỒN TẠI trong bộ template nuclei
    đã cài TRƯỚC khi chạy (chưa `-update-templates` → nuclei không tìm thấy
    template, lượt chạy tốn giờ mà không ra finding nào).
    """
    if not _nuclei_supports("-template-list", "-tl"):
        return ""
    if _TL_CACHE["text"] is None:
        proc = runner.run(["nuclei", "-tl", "-silent"], timeout=600)
        if proc.returncode != 0:
            warn(f"[nuclei] nuclei -tl exit {proc.returncode}: "
                 f"{(proc.stderr or '').strip()[-300:]} — coi như không có "
                 f"danh sách template")
            _TL_CACHE["text"] = ""
        else:
            _TL_CACHE["text"] = proc.stdout or ""
            if not _TL_CACHE["text"].strip():
                warn("[nuclei] `nuclei -tl` không trả template nào — bộ template "
                     "cộng đồng trống? Chạy `nuclei -update-templates`")
    return _TL_CACHE["text"]


def community_ids_available(ids):
    """Lọc các CVE cộng đồng CÓ template trong bộ nuclei đã cài; warn id thiếu.

    Không kiểm tra được (thiếu cờ -tl / -tl lỗi) → trả nguyên `ids` kèm cảnh
    báo (không chặn lượt chạy vì thông tin chưa chắc chắn).
    """
    ids = [str(cve).strip().upper() for cve in ids or [] if str(cve).strip()]
    if not ids:
        return []
    text = _nuclei_template_list()
    if not text.strip():
        warn("[nuclei] không kiểm tra được template cộng đồng có tồn tại — "
             "chạy nguyên trạng (nếu thiếu template, lượt nuclei sẽ không ra finding)")
        return ids
    installed = {m.group(0).upper() for m in CVE_RE.finditer(text)}
    have, missing = [], []
    for cve in ids:
        (have if cve in installed else missing).append(cve)
    for cve in missing:
        warn(f"[nuclei] template cộng đồng {cve} không có trong bộ template nuclei "
             f"— bỏ qua (chạy `nuclei -update-templates` để tải thêm)")
    return have


# ── JSONL parse ─────────────────────────────────────────────────────────

def _jsonl_line_to_finding(raw):
    """1 dòng JSONL của nuclei → dòng finding đọc được, hoặc None.

    Format dòng ra giữ KHỐI thả `[cve:CVE-ID]` để dedupe theo (CVE, host)
    ở tầng caller (cve_scan.dedupe_against) vẫn hoạt động như bản text:
        <matched-at|url|host> [cve:<template-id>] [<severity>] <name>
    Chỉ giữ dòng matcher-status=true (nuclei JSONL ghi cả event không khớp
    khi có -verbose; -silent thì phần lớn là match nhưng vẫn chặn lọc).
    JSON hỏng → trả None (caller fallback dùng dòng thô).
    """
    try:
        data = json.loads(raw)
    except (json.JSONDecodeError, ValueError):
        return None
    if not isinstance(data, dict):
        return None
    if data.get("matcher-status") is False:
        return None
    info_block = data.get("info") or {}
    template_id = str(data.get("template-id") or data.get("id") or "").strip()
    url = (str(data.get("matched-at") or "").strip()
           or str(data.get("url") or "").strip()
           or str(data.get("host") or "").strip())
    if not url or not template_id:
        return None
    sev = str(info_block.get("severity") or "unknown").strip().lower()
    name = str(info_block.get("name") or "").strip()
    cve_m = CVE_RE.search(template_id)
    cve_token = f"cve:{cve_m.group(0).upper()}" if cve_m else template_id
    # Giữ URL dạng host gốc của nuclei (không rewrite — tầng caller lo).
    line = f"{url} [{cve_token}] [{sev}]"
    if name:
        line += f" {name}"
    return line


def _read_findings(path, ncfg):
    """Đọc file output nuclei → list dòng finding (JSONL hoặc text).

    JSONL: mỗi dòng parse được → dòng finding đẹp; dòng KHÔNG parse được
    (output text trộn vào, nuclei in cảnh báo…) → giữ dòng thô để không
    mất thông tin debug. File không tồn tại → [].
    """
    if not path or not os.path.exists(path):
        return []
    raw_lines = file_io.read_lines(path, strip_comments=False)
    if not ncfg["json_output"]:
        return raw_lines
    out, n_json, n_raw = [], 0, 0
    for raw in raw_lines:
        finding = _jsonl_line_to_finding(raw)
        if finding is not None:
            out.append(finding)
            n_json += 1
        elif raw.strip():
            out.append(raw)
            n_raw += 1
    if n_json or n_raw:
        debug(f"[nuclei] đọc {path}: {n_json} finding JSONL + {n_raw} dòng thô")
    return out


# ── Chunking + retry + chạy 1 nguồn ─────────────────────────────────────

def _split_chunks(items, chunk_size):
    """Chia list thành các phần ≤ chunk_size; chunk_size ≤ 0 → 1 phần."""
    size = int(chunk_size or 0)
    if size <= 0 or len(items) <= size:
        return [items] if items else []
    return [items[i:i + size] for i in range(0, len(items), size)]


def _one_attempt(targets_file, out, extra, ncfg):
    """MỘT lượt nuclei trên targets_file → (lines, returncode).

    Timeout (rc=124) giữ phần output đã ghi — nuclei `-o` ghi liên tục.
    """
    cmd = ["nuclei", "-l", targets_file]
    cmd += list(extra)
    cmd += ["-silent", "-nc", "-no-color", "-o", out]
    cmd += _jsonl_flags(ncfg)
    cmd += _nuclei_flags(ncfg)
    proc = runner.run(cmd, timeout=ncfg["max_seconds"])
    if proc.returncode == 124:
        n_lines = len(file_io.read_lines(out, strip_comments=False)) \
            if os.path.exists(out) else 0
        warn(f"[nuclei] TIMEOUT sau {ncfg['max_seconds']}s (rc=124) — bị kill: "
             f"giữ được {n_lines} finding một phần trong {out}; finding xuất "
             f"hiện sau thời điểm kill bị MẤT — tăng cve.nuclei.max_seconds "
             f"hoặc bật chunk_size để chia nhỏ lượt quét")
    elif proc.returncode != 0 and proc.stderr:
        warn(f"[nuclei] exit {proc.returncode}: {proc.stderr.strip()[-300:]}")
    lines = _read_findings(out, ncfg)
    return lines, proc.returncode


def run_scan(targets_file, out, extra, cfg, label="nuclei"):
    """Chạy MỘT NGUỒN template qua engine: chunking + retry + tổng hợp.

    targets_file: file chứa URL (1 URL/dòng); out: file output CUỐI (engine
    tự ghi dòng tổng hợp vào đây — caller chỉ cần đọc/đếm); extra: cờ chọn
    template ("-t path" / ["-id", "..."]) đã chuẩn bị trước; cfg: config
    toàn cục; label: nhãn log ("local"/"community"/...).

    Trả (lines, ok, n_failed_chunks):
      lines — dòng finding (đã parse JSONL nếu bật);
      ok    — True nếu MỌI chunk chạy trọn vẹn rc=0 (điều kiện cộng bộ đếm);
      n_failed_chunks — số chunk lỗi (timeout/không retry được) — 0 = trọn vẹn.
    Không bao giờ raise.
    """
    ncfg = nuclei_config(cfg)
    if shutil.which("nuclei") is None:
        warn("[nuclei] không tìm thấy binary nuclei trong PATH — bỏ qua nguồn "
             f"{label} (cài nuclei hoặc tắt cve.nuclei.enabled)")
        return [], False, 0
    try:
        urls = file_io.read_lines(targets_file)
    except OSError as exc:
        warn(f"[nuclei] không đọc được targets {targets_file}: {exc} — "
             f"bỏ qua nguồn {label}")
        return [], False, 0
    if not urls:
        debug(f"[nuclei] nguồn {label}: targets rỗng — bỏ qua")
        return [], True, 0

    chunks = _split_chunks(urls, ncfg["chunk_size"])
    all_lines, n_failed, ok_chunks = [], 0, 0
    for i, chunk in enumerate(chunks, 1):
        chunk_file = f"{out}.chunk{i}"
        chunk_out = f"{out}.part{i}"
        try:
            file_io.atomic_write(chunk_file, "".join(u + "\n" for u in chunk))
        except OSError as exc:
            warn(f"[nuclei] không ghi được chunk {chunk_file}: {exc} — "
                 f"bỏ qua chunk {i}/{len(chunks)} của nguồn {label}")
            n_failed += 1
            continue
        tag = f"{label}[{i}/{len(chunks)}]" if len(chunks) > 1 else label
        attempts = 0
        lines, rc = [], 0
        while True:
            attempts += 1
            if len(chunks) > 1:
                debug(f"[nuclei] nguồn {tag}: {len(chunk)} URL (lần {attempts})")
            lines, rc = _one_attempt(chunk_file, chunk_out, extra, ncfg)
            if rc == 0:
                break
            if rc == 124:
                # Timeout KHÔNG retry — chỉ càng tốn giờ; người dùng tăng
                # max_seconds hoặc bật chunk_size nhỏ hơn.
                n_failed += 1
                break
            if attempts > ncfg["max_retries"]:
                warn(f"[nuclei] nguồn {tag} lỗi rc={rc} sau {attempts} lần thử "
                     f"— bỏ chunk này (tăng cve.nuclei.max_retries nếu cần)")
                n_failed += 1
                break
            warn(f"[nuclei] nguồn {tag} lỗi rc={rc} — thử lại sau "
                 f"{ncfg['retry_delay']}s (lần {attempts}/{ncfg['max_retries'] + 1})")
            time.sleep(max(0.0, ncfg["retry_delay"]))
        if rc == 0:
            ok_chunks += 1
        all_lines += lines
        # Dọn file trung gian sau khi đã gom kết quả.
        for tmp in (chunk_file, chunk_out):
            try:
                if os.path.exists(tmp):
                    os.remove(tmp)
            except OSError as exc:
                debug(f"[nuclei] không xóa được file tạm {tmp}: {exc}")

    # Ghi dòng tổng hợp vào `out` để caller/debug đọc được như bản cũ.
    try:
        if all_lines:
            file_io.atomic_write(out, "".join(l + "\n" for l in all_lines))
    except OSError as exc:
        warn(f"[nuclei] không ghi được output tổng hợp {out}: {exc} — "
             f"findings vẫn trả về caller trong bộ nhớ")
    ok = (n_failed == 0) and (ok_chunks == len(chunks)) and bool(chunks)
    return all_lines, ok, n_failed


def run_sources(tasks, cfg):
    """Chạy NHIỀU NGUỒN template (local/community/…) — song song nếu bật.

    tasks: list dict {label, targets_file, out, extra} (label duy nhất).
    Trả {label: {"lines": [...], "ok": bool, "failed": int}} — mọi nguồn
    đều có khóa kể cả khi lỗi, caller không cần kiểm tra KeyError.
    parallel_sources=true → ThreadPoolExecutor (max_workers = số nguồn);
    false → tuần tự như bản cũ (tránh tăng tải khi bị target chặn).
    Không raise; lỗi 1 nguồn không ảnh hưởng nguồn khác.
    """
    ncfg = nuclei_config(cfg)
    results = {t["label"]: {"lines": [], "ok": False, "failed": 0}
               for t in tasks or []}
    if not tasks:
        return results

    def _run(task):
        label = task["label"]
        lines, ok, failed = run_scan(task["targets_file"], task["out"],
                                     task.get("extra") or [], cfg, label=label)
        return label, {"lines": lines, "ok": ok, "failed": failed}

    if ncfg["parallel_sources"] and len(tasks) > 1:
        info(f"[nuclei] chạy {len(tasks)} nguồn template SONG SONG: "
             f"{', '.join(t['label'] for t in tasks)}")
        with ThreadPoolExecutor(max_workers=len(tasks)) as pool:
            futures = [pool.submit(_run, t) for t in tasks]
            for fut in futures:
                try:
                    label, res = fut.result()
                    results[label] = res
                except Exception as exc:  # an toàn pipeline — không chết stage
                    warn(f"[nuclei] nguồn chạy song song lỗi: "
                         f"{exc.__class__.__name__}: {exc} | "
                         + traceback.format_exc().rstrip())
    else:
        for t in tasks:
            label, res = _run(t)
            results[label] = res
    return results


def extract_hosts_from_lines(lines):
    """Hostname từ list dòng finding (dedupe, sort) — tiện dùng chung.

    Caller (cve_scan/woo_cve_scan) có rewrite URL riêng; helper này chỉ
    trích hostname thô từ URL trong dòng.
    """
    hosts = set()
    url_re = re.compile(r"https?://[^\s]+", re.IGNORECASE)
    for line in lines or []:
        m = url_re.search(str(line))
        if not m:
            continue
        try:
            host = (urlparse(m.group(0)).hostname or "").lower()
        except ValueError:
            continue
        if host:
            hosts.add(host)
    return sorted(hosts)