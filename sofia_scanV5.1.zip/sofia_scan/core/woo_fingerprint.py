"""STAGE 2a-woo: phát hiện WordPress và WooCommerce — probe ĐA ENDPOINT + chấm điểm.

Song song với core/fingerprint.py (Magento). Mỗi host được probe thêm endpoint
đặc trưng (cấu hình `woocommerce.endpoints`, mặc định):
    /wp-login.php                    → trang đăng nhập WordPress
    /wp-json/                        → WP REST API (JSON, có "routes"/"namespaces")
    /wp-json/wc/store/v1/products    → WooCommerce Store API (JSON) — DẤU HIỆU WOO
    /readme.html                     → readme mặc định WordPress
    /cart/  /shop/                   → trang giỏ hàng / cửa hàng WooCommerce

Chấm điểm tin cậy (confidence scoring):
    header x-powered-by: WordPress                          +3
    header Link chứa wp-json                                +3
    cookie wordpress_*/wp-settings*/wp_lang/wp_test_cookie   +3
    cookie woocommerce_*/wp_woocommerce_session             +3 (WOO)
    body chữ ký WordPress (wp-content/wp-includes/wp-json/wp-emoji/wp-block-library) +3
    body <meta generator> WordPress                        +2
    body chữ ký WOOCOMMERCE (plugins/woocommerce/, wc-…)    +3   ← woo-specific
    /wp-json/ trả JSON (routes/namespaces)                  +3
    /wp-json/ body chứa namespace wc/store hoặc wc/v3       +3   ← woo-specific
    /wp-json/wc/store/ trả JSON                             +3   ← woo-specific
    /wp-login.php 200 + wp-login trong body                 +2
    /readme.html 200 + "WordPress"                          +2
    /cart/ 200   /shop/ 200                                 +2 mỗi cái

Tổng đạt `woocommerce.min_score` (mặc định 3) → kết luận WordPress. Kết luận
WooCommerce khi có ≥1 BẰNG CHỨNG WOO RIÊNG (asset plugin woocommerce, Store API
JSON, cookie woo, marker `wc-…`) VÀ tổng điểm đạt ngưỡng.

Short-circuit: đủ ngưỡng + đã có bằng chứng woo → dừng probe sớm cho woo.

NÂNG CẤP: trang chủ GET qua lớp HTTP chung (utils/http.py) + PageCache → tái
dùng kết quả giữa các stage; retry transport; pool thread-local an toàn chạy dài.

NÂNG CẤP 2 (không bỏ sót target — recall + chính xác hơn):
  * FALLBACK HTTPS: homepage http:// chết hẳn → thử đúng 1 lần https:// cùng
    host:port (`woocommerce.scheme_fallback`) — site nói TLS trên port lạ
    (8080/8443…) trước đây bị mất oan vì luôn probe http.
  * httpx -tech-detect (WordPress/WooCommerce) chạy SONG SONG với probe nội bộ
    (`woocommerce.httpx_detect`, mặc định true) — lưới bắt thêm target mà probe
    nội bộ bỏ sót; kết quả httpx chỉ nhận URL nằm trong danh sách đã probe.
  * Endpoint mới mặc định: /robots.txt, /my-account/. Endpoint sâu mới:
    /wp-json/wc/store/cart, /wp-json/wc/store/products (Store API đời đầu dùng
    namespace không version), /xmlrpc.php, /wp-links-opml.php.
  * Scoring mới: robots.txt kiểu WP (+3), xmlrpc.php 405/200 XML-RPC (+3),
    wp-links-opml.php OPML 200 (+3), /wp-json/ 401/403 JSON lỗi WP
    (rest_cannot_access/rest_forbidden) (+3), Store API JSON lỗi
    "woocommerce_rest" (+3 WOO — server Woo thật bị khóa API vẫn lọt).
  * Marker WP mới: xmlrpc.php?rsd, wp-sitemap, admin-ajax.php, wp-links-opml.

Output:
    output/wordpress.txt       — 1 URL WordPress mỗi dòng
    output/woocommerce.txt     — 1 URL WooCommerce mỗi dòng (tập con WordPress)
    output/work/<slug>/woo_scored.txt — "url score bằng_chứng" (debug)
Contract: run(hosts, workdir, global_wp, global_woo, cfg) → list URL WooCommerce.
"""
import concurrent.futures
import os
import shutil

import requests
import urllib3

from utils import file_io, http, runner, stats
from utils.logger import info, warn

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

USER_AGENT = "Mozilla/5.0 (compatible; SofiaScan/1.0)"
BODY_LIMIT = 200000

DEFAULT_ENDPOINTS = (
    "/wp-login.php", "/wp-json/", "/wp-json/wc/store/v1/products",
    "/readme.html", "/cart/", "/shop/",
    # robots mặc định của WP chặn /wp-admin/ + allow admin-ajax — sig rẻ, bền
    "/robots.txt",
    "/my-account/",                          # trang tài khoản chỉ Woo có mặc định
)
# Endpoint nặng bằng chứng WOOCOMMERCE (đặc trưng plugin, không phải WP chung).
WOO_DEEP_ENDPOINTS = (
    "/wp-json/wc/store/v1/cart",            # Store API cart → JSON (không cần auth)
    "/wp-content/plugins/woocommerce/readme.txt",  # plugin CÓ MẶT (kể cả khi asset bị gộp)
    # Store API đời đầu dùng namespace KHÔNG version (wc/store/cart, wc/store/
    # products) — site Woo cũ/tắt rewrite permastruct vẫn còn hai path này.
    "/wp-json/wc/store/cart",
    "/wp-json/wc/store/products",
    # xmlrpc.php chỉ tồn tại trên WordPress (405 cho GET / 200 XML-RPC).
    "/xmlrpc.php",
    # wp-links-opml.php trả OPML 200 không cần auth — chỉ WP có.
    "/wp-links-opml.php",
)
DEFAULT_MIN_SCORE = 3

JSON_TYPES = "application/json"
HTML_TYPES = "text/html"


def _hdrs(headers):
    return {str(k).lower(): str(v) for k, v in (headers or {}).items()}


# --- Bằng chứng WordPress (chung) -------------------------------------------
WP_BODY_MARKERS = (
    "/wp-content/", "wp-content/", "/wp-includes/", "wp-includes/",
    "wp-emoji", "wp-emoji-release", "/wp-json", "wp-block-", "wp-block-library",
    "wp-embed", "wpadminbar", "wordpress",
    # site gộp asset qua CDN mà vẫn còn các path đặc trưng WP:
    "xmlrpc.php?rsd",                        # RSD link trong <head>
    "wp-sitemap",                            # sitemap mặc định WP 5.5+
    "admin-ajax.php",                        # admin-ajax được expose ở frontend
    "wp-links-opml",                         # link OPML
)

# --- Bằng chứng WOOCOMMERCE (riêng) -----------------------------------------
# Xuất hiện khi site thật sự chạy plugin WooCommerce (asset/marker/class).
WOO_BODY_MARKERS = (
    "/wp-content/plugins/woocommerce/",
    "wp-content/plugins/woocommerce/",
    "woocommerce-page", "woocommerce-info", "woocommerce-message",
    "wc-block-", "wc-blocks", "wc-block-components", "wc-item-meta",
    "wp-block-woocommerce", "wc-ajax", "wc_add_to_cart", "wc_get_cart_url",
    "wc-store", "wc-store-api", "add_to_cart_button", "woocommerce-cart",
    "woocommerce-checkout", "class=\"woocommerce", "wc-forward",
    "cart-fragments", "wc_cart_hash", "wc_cart_fragments_params",
    "woocommerce_assets_url", "data-block-name=\"woocommerce/",
    "woocommerce-Reviews", "wc-single-product",
)
WOO_COOKIE_RE = "woocommerce_"
WOO_SESSION_COOKIE = "wp_woocommerce_session"
WOO_STORE_API_PATH = "/wp-json/wc/store/"
# namespace WooCommerce trong REST index body
WOO_REST_NS_RE = ("wc/store", "wc/v3", "wc/v2")


def score_response(status, headers, body, endpoint=None, store_api=None):
    """Chấm điểm 1 response.

    Trả về (score, woo_points, [bằng_chứng]) — woo_points>0 nghĩa là có bằng
    chứng WOOCOMMERCE riêng (dùng để phân biệt woo với WordPress thường)."""
    hdrs = _hdrs(headers)
    score = 0
    woo = 0
    evidence = []

    powered = hdrs.get("x-powered-by", "")
    if "wordpress" in powered.lower():
        score += 3
        evidence.append("header:x-powered-by")

    link = hdrs.get("link", "")
    if "wp-json" in link.lower():
        score += 3
        evidence.append("header:link-wp-json")

    for header in ("set-cookie", "cookie"):
        value = hdrs.get(header, "")
        if not value:
            continue
        low = value.lower()
        if ("wordpress_" in low or "wp-settings" in low
                or "wp_lang" in low or "wp_test_cookie" in low):
            score += 3
            evidence.append("cookie:wordpress")
        if WOO_SESSION_COOKIE in low:
            score += 3
            woo += 3
            evidence.append("cookie:woo-session")
        elif WOO_COOKIE_RE in low:
            score += 3
            woo += 3
            evidence.append("cookie:woo")

    body = body or ""
    low_body = body.lower()
    if any(m in low_body for m in WP_BODY_MARKERS):
        score += 3
        evidence.append("body:wordpress")
    if "name=\"generator\"" in low_body and "wordpress" in low_body:
        score += 2
        evidence.append("body:generator")
    if any(m in low_body for m in WOO_BODY_MARKERS):
        score += 3
        woo += 3
        evidence.append("body:woocommerce")

    if endpoint:
        ctype = hdrs.get("content-type", "").lower()
        is_json = JSON_TYPES in ctype
        if endpoint.startswith("/wp-json/"):
            is_store_api = endpoint.startswith(store_api)
            if status == 200 and is_json and (
                    "routes" in body or "namespaces" in body or is_store_api):
                score += 3
                evidence.append("endpoint:wp-rest")
            # namespace WooCommerce lộ ngay trong REST index (/wp-json/)
            if status == 200 and is_json and any(ns in low_body for ns in WOO_REST_NS_RE):
                score += 3
                woo += 3
                evidence.append("endpoint:woo-rest-ns")
            if is_store_api and status == 200 and is_json:
                score += 3
                woo += 3
                evidence.append("endpoint:woo-store-api")
            # REST index trả 401/403 dạng JSON lỗi WP (rest_cannot_access /
            # rest_forbidden / rest_no_route) → catch-all HTML 401 của web
            # server không lọt vào đây.
            if status in (401, 403) and is_json and (
                    "rest_cannot_access" in low_body
                    or "rest_forbidden" in low_body
                    or "rest_no_route" in low_body):
                score += 3
                evidence.append(f"endpoint:wp-rest-{status}")
            # Store API trả JSON lỗi "woocommerce_rest_*" — server Woo thật
            # bị khóa API (auth/bảo trì) vẫn nhận diện được.
            if is_store_api and status in (400, 401, 403, 404) and is_json \
                    and "woocommerce_rest" in low_body:
                score += 3
                woo += 3
                evidence.append("endpoint:woo-store-api-error")
        elif endpoint == "/wp-login.php":
            if status == 200 and "wp-login" in low_body:
                score += 2
                evidence.append("endpoint:wp-login")
        elif endpoint == "/readme.html":
            if status == 200 and "wordpress" in low_body:
                score += 2
                evidence.append("endpoint:readme")
        elif endpoint in ("/cart/", "/shop/", "/my-account/"):
            if status == 200:
                score += 2
                evidence.append(f"endpoint:{endpoint.strip('/')}")
        elif endpoint == "/robots.txt":
            # robots.txt mặc định của WP: Disallow /wp-admin/ + Allow
            # admin-ajax.php + Sitemap wp-sitemap.xml — site bị WAF che toàn bộ
            # marker HTML vẫn còn lộ qua robots.
            rules = 0
            if "wp-admin/" in low_body:
                rules += 1
            if "admin-ajax.php" in low_body:
                rules += 1
            if "wp-sitemap" in low_body or "sitemap_index.xml" in low_body:
                rules += 1
            if "wp-content" in low_body or "wp-includes" in low_body:
                rules += 1
            if rules >= 2:
                score += 3
                evidence.append("endpoint:robots-wp")
            elif rules == 1:
                score += 2
                evidence.append("endpoint:robots-wp-weak")
        elif endpoint == "/xmlrpc.php":
            # WP chặn GET /xmlrpc.php bằng 405 ("XML-RPC server accepts only
            # POST requests") — endpoint này hầu như chỉ tồn tại trên WP.
            if status == 200 and "xml-rpc" in low_body:
                score += 3
                evidence.append("endpoint:xmlrpc")
            elif status == 405:
                score += 2
                evidence.append("endpoint:xmlrpc-405")
            elif status in (401, 403):
                score += 1
                evidence.append("endpoint:xmlrpc-protected")
        elif endpoint.endswith("wp-links-opml.php"):
            # wp-links-opml.php trả OPML 200 KHÔNG cần auth — chỉ WP có.
            if status == 200 and "opml" in low_body:
                score += 3
                evidence.append("endpoint:wp-links-opml")
        elif endpoint.endswith("readme.txt"):
            # readme.txt của plugin WooCommerce: chứng minh plugin CÓ MẶT kể cả khi
            # asset bị gộp/minify không lộ đường dẫn ("Stable tag" còn cho version).
            if status == 200 and "woocommerce" in low_body:
                score += 3
                woo += 3
                evidence.append("endpoint:woo-readme")
            elif status == 200 and ("wordpress" in low_body or "stable tag" in low_body):
                score += 2
                evidence.append("endpoint:plugin-readme")

    return score, woo, evidence


def check_woocommerce(status, headers, body, min_score=DEFAULT_MIN_SCORE):
    """True nếu response đơn lẻ đủ điểm WordPress (tương thích test)."""
    score, _woo, _ev = score_response(status, headers, body)
    return score >= min_score


def _endpoints_from_cfg(cfg):
    wc = cfg.get("woocommerce") or {}
    endpoints = wc.get("endpoints")
    return tuple(endpoints) if endpoints else DEFAULT_ENDPOINTS


def _min_score_from_cfg(cfg):
    wc = cfg.get("woocommerce") or {}
    return int(wc.get("min_score", DEFAULT_MIN_SCORE))


def _store_api_from_cfg(cfg):
    wc = cfg.get("woocommerce") or {}
    return str(wc.get("store_api", WOO_STORE_API_PATH))


def _alt_scheme(url):
    """Scheme đối xứng: http→https, https→http (None nếu không đổi được)."""
    if url.startswith("http://"):
        return "https://" + url[len("http://"):]
    if url.startswith("https://"):
        return "http://" + url[len("https://"):]
    return None


def _probe(url, timeout, endpoints, min_score, store_api, deep=True,
           scheme_fallback=True):
    """Probe chi tiết → (url, is_wordpress, is_woocommerce, score, woo, evidence).

    Giữ ĐÚNG chữ ký 5 tham số (test cũ monkeypatch hàm này); `deep` và
    `scheme_fallback` là tham số thêm CÓ DEFAULT nên không phá vỡ contract cũ.

    Trang chủ + endpoint dùng http.fetch_limited (trần byte, cache trang chủ).
    `deep` bật probe "chứng cứ Woo" (Store API cart/products,
    /wp-content/plugins/woocommerce/readme.txt, /xmlrpc.php,
    /wp-links-opml.php) khi chưa kết luận Woo — chỉ chạy khi host đã có tín
    hiệu WordPress nên không nạp thêm host lạ.

    `scheme_fallback`: homepage http:// chết hẳn → thử đúng 1 lần https:// cùng
    host:port (và ngược lại) trước khi kết luận host chết — bắt site nói TLS
    trên port lạ (8080/8443…) mà trước đây bị mất oan vì luôn probe http.
    """
    cache = http.get_page_cache()

    total = 0
    woo_total = 0
    evidence = []

    def visit(path, use_cache=False):
        nonlocal total, woo_total, evidence
        resp = http.fetch_limited(path, timeout=timeout, limit=BODY_LIMIT,
                                  cache=cache if use_cache else None)
        if resp is None:
            return None
        ep = None if path == url else path[len(url):]
        score, woo, ev = score_response(
            resp.status_code, dict(resp.headers), resp.text[:BODY_LIMIT],
            endpoint=ep, store_api=store_api,
        )
        total += score
        woo_total += woo
        evidence.extend(ev)
        return resp

    try:
        resp = visit(url, use_cache=True)
        # FALLBACK SCHEME: homepage không phản hồi gì → thử scheme đối xứng
        # đúng 1 lần trước khi kết luận (chỉ khi homepage chết hẳn — không
        # đốt request cho host đã trả nội dung).
        if resp is None and scheme_fallback:
            alt = _alt_scheme(url)
            if alt:
                resp = visit(alt)
                if resp is not None:
                    url = alt  # probe tiếp các endpoint trên scheme sống
        if total >= min_score and woo_total > 0:
            return url, True, True, total, woo_total, evidence
        for ep in tuple(endpoints):
            visit(url + ep)
            if total >= min_score and woo_total > 0:
                return url, True, True, total, woo_total, evidence
        # Chưa đủ kết luận Woo nhưng host CÓ vẻ WordPress → tìm chứng cứ Woo
        # đặc trưng (plugin readme / Store API cart) trước khi loại.
        if deep and total > 0 and woo_total == 0:
            for ep in WOO_DEEP_ENDPOINTS:
                visit(url + ep)
                if total >= min_score and woo_total > 0:
                    break
        return url, total >= min_score, total >= min_score and woo_total > 0, \
            total, woo_total, evidence
    except requests.RequestException:
        return url, False, False, total, woo_total, evidence


def probe(url, timeout, endpoints=DEFAULT_ENDPOINTS, min_score=DEFAULT_MIN_SCORE,
          store_api=WOO_STORE_API_PATH):
    """Contract nhẹ: trả (url, is_wordpress, is_woocommerce)."""
    result = _probe(url, timeout, endpoints, min_score, store_api)
    return result[0], result[1], result[2]


def _scheme_for(host_port):
    return "https" if host_port.endswith(":443") else "http"


def _scheme_fallback_from_cfg(cfg):
    """`woocommerce.scheme_fallback` (mặc định true) — thử scheme đối xứng khi
    homepage chết hẳn (site TLS trên port lạ mà trước đây chỉ probe http)."""
    wc = cfg.get("woocommerce") or {}
    return bool(wc.get("scheme_fallback", True))


def _httpx_enabled(cfg):
    """`woocommerce.httpx_detect` (mặc định true) — tắt để bỏ hẳn tiến trình ngoài."""
    wc = cfg.get("woocommerce") or {}
    return bool(wc.get("httpx_detect", True))


def httpx_detect(live_file, timeout):
    """httpx -tech-detect → (set WordPress, set WooCommerce).

    httpx nhận tech "WordPress:x.y" và "WooCommerce:x.y" trong output. Lỗi
    binary/timeout KHÔNG raise (runner.run nuốt) — chỉ warn; probe nội bộ vẫn
    là nguồn kết quả chính, httpx chỉ là lưới bắt thêm.
    """
    if shutil.which("httpx") is None:
        return set(), set()
    proc = runner.run(
        ["httpx", "-l", live_file, "-tech-detect", "-status-code", "-silent",
         "-no-color", "-timeout", str(timeout)],
        timeout=max(600, timeout * 60),
    )
    if proc.returncode == 124:
        warn(f"[httpx-woo] timeout {max(600, timeout * 60)}s (rc=124) — bị kill, "
             f"chỉ giữ được kết quả một phần")
    elif proc.returncode != 0:
        warn(f"[httpx-woo] exit {proc.returncode}: "
             f"{(proc.stderr or '').strip()[-300:] or '(không có stderr)'}")
    wp, woo = set(), set()
    for line in (proc.stdout or "").splitlines():
        parts = line.split()
        if not parts:
            continue
        low = line.lower()
        if "wordpress" in low or "woocommerce" in low:
            wp.add(parts[0].strip())
            if "woocommerce" in low:
                woo.add(parts[0].strip())
    return wp, woo


def run(hosts, workdir, global_wp, global_woo, cfg):
    """hosts: list 'ip:port' → list URL WooCommerce; append wordpress.txt/woocommerce.txt.

    Trả về (wordpress_urls, woocommerce_urls) — woo là tập con của wordpress.

    `httpx -tech-detect` (nếu bật) chạy SONG SONG với probe nội bộ như stage 2a
    Magento: thời gian stage ≈ max(hai phần); lỗi httpx không ảnh hưởng probe.
    """
    timeout = cfg.get("timeout", 15)
    endpoints = _endpoints_from_cfg(cfg)
    min_score = _min_score_from_cfg(cfg)
    store_api = _store_api_from_cfg(cfg)
    scheme_fallback = _scheme_fallback_from_cfg(cfg)
    urls = [f"{_scheme_for(h)}://{h}" for h in hosts]
    if not urls:
        info("stage2a-woo: 0 host — bỏ qua")
        return set(), set()

    # live.txt phải có TRƯỚC khi httpx_detect chạy → ghi sớm (rẻ, 1 lần/CIDR).
    live_file = os.path.join(workdir, "live.txt")
    file_io.write_lines(live_file, hosts)

    wp_found = set()
    woo_found = set()
    scored = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=cfg.get("threads", 50)) as pool:
        httpx_future = pool.submit(httpx_detect, live_file, timeout) \
            if _httpx_enabled(cfg) else None
        futures = [
            pool.submit(_probe, u, timeout, endpoints, min_score, store_api,
                        True, scheme_fallback)
            for u in urls
        ]
        for future in concurrent.futures.as_completed(futures):
            url, is_wp, is_woo, score, woo, evidence = future.result()
            scored.append(f"{url} {score} woo:{woo} {' '.join(evidence)}".strip())
            if is_wp:
                wp_found.add(url)
            if is_woo:
                woo_found.add(url)
        if httpx_future is not None:
            # httpx chỉ là lưới bắt thêm: chỉ nhận URL thuộc danh sách đã probe
            # (tránh URL lạ từ output binary ngoài làm nhiễu kết quả).
            url_set = set(urls)
            httpx_wp, httpx_woo = httpx_future.result()
            wp_found |= {u for u in httpx_wp if u in url_set}
            woo_found |= {u for u in httpx_woo if u in url_set}

    wp_found = file_io.dedupe_sort(wp_found)
    woo_found = file_io.dedupe_sort(woo_found)
    # Bộ đếm cộng dồn: target đã kiểm tra là WooCommerce (utils/stats.py)
    stats.add_store(woocommerce=len(woo_found))
    file_io.append_lines(global_wp, wp_found)
    file_io.append_lines(global_woo, woo_found)

    scored_file = os.path.join(workdir, "woo_scored.txt")
    file_io.write_lines(scored_file, file_io.dedupe_sort(scored))
    info(f"stage2a-woo: {len(wp_found)}/{len(urls)} WordPress, "
         f"{len(woo_found)} WooCommerce (min_score={min_score}, "
         f"endpoints={','.join(endpoints) or '-'})")
    return wp_found, woo_found
