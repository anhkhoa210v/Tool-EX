"""STAGE 2c-P2S: phát hiện PHP2Shell (CVE-2026-109618/109619) — NON-DESTRUCTIVE.

Chạy NGAY SAU stage 2c store_detect (lọc cửa hàng THẬT) — chỉ các URL đã được
xác nhận là storefront thật mới được probe (giảm request, giảm rủi ro block).

Bọc `sofia/tools/php2shell/lib/detect.py` (toolkit vendored php2shell):
  - đọc version PHP từ header/body (X-Powered-By, Server, body lỗi…),
  - so với fix-floor từng branch (8.2→8.2.35, 8.3→8.3.36, 8.4→8.4.27, 8.5→8.5.12),
  - verdict: vulnerable | patched | eol | unknown,
  - probe phụ: session.upload_progress (POST multipart ~1KB) + display_errors
    (path 404 + route PHP). KHÔNG chạy lệnh, KHÔNG upload file, KHÔNG khai thác.

URL dính (verdict vulnerable/eol, tuỳ include_eol) được ghi:
  - output/php2shell.txt (global, appends) — 1 dòng / target,
  - nếu write_vuln (mặc định BẬT): CÙNG dòng ghim CVE append vào
    output/vuln.txt theo định dạng dòng ghim của sofia.py
    (`<url> [CVE-2026-109619] <info>` — discovery/target_line.py nhận diện
    tự động) → hook exploit (core/exploit_runner.py) chạy `sofia/sofia.py`
    sau batch và worker `exploit/php2shell.py` khai thác target này.
    Mỗi dòng dính cũng được cộng vào findings (webhook đếm đúng).
  - debug trong output/work/<slug>/:
      php2shell_scored.txt  — mọi kết quả (verdict + version + reason + signals)
      php2shell_targets.txt — chỉ target dính
      php2shell_audit.jsonl — audit request (tùy audit: true)

Chỉ DÙNG cho mục đích kiểm thử bảo mật được ủy quyền.
"""
from __future__ import annotations

import concurrent.futures
import importlib.util
import os
import random
import sys
import threading
import time

from utils import file_io
from utils.logger import debug, info, warn

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_LIB_DIR = os.path.join(BASE_DIR, "sofia", "tools", "php2shell", "lib")

# CVE ghim vào dòng target — exploit/php2shell.py dùng key chung
# "CVE-2026-109619/109618" (discovery/target_line.py._MAGENTO_CVE_ALIAS tự quy đổi
# cả 109618 lẫn 109619 về key đó).
PIN_CVE = "CVE-2026-109619"

DEFAULTS = {
    "enabled": True,
    "threads": 10,          # worker RIÊNG của stage — không tranh thread stage khác
    "delay": 0.0,           # delay Transport giữa 2 request CÙNG URL (giây, 0 = tắt)
    "timeout": 15,          # timeout HTTP mỗi request
    "ja3": "chrome",        # profile TLS của transport (chrome/safari/firefox/…)
    "proxy": "",            # proxy cho transport (rỗng = dùng trực tiếp)
    "retries": 1,           # retry lỗi mạng tạm thời (5xx/kết nối) trong transport
    "check_upload_progress": True,   # probe session.upload_progress (POST ~1KB)
    "check_display_errors": True,    # probe display_errors (404 + route PHP)
    "include_eol": True,    # branch EOL (không bao giờ được vá) tính là dính
    "include_bypassable": False,     # patched-but-bypassable cũng ghi (mặc định tắt)
    "output": "php2shell.txt",       # file global trong output_dir
    "write_vuln": True,     # append dòng ghim CVE vào vuln.txt (cho exploit hook)
    "audit": False,         # true = ghi audit JSONL từng request vào workdir
    "jitter_min": 0.0,      # ngủ ngẫu nhiên TRƯỚC mỗi URL — giãn nhịp chống chặn
    "jitter_max": 0.2,
}

# Lưu module detect nạp 1 lần (import có khoá — an toàn đa luồng).
_DETECT_MOD = None
_LOAD_LOCK = threading.Lock()
_LOAD_ERROR = ""


def _load_detect():
    """Nạp lib.detect từ toolkit vendored dưới TÊN RIÊNG (sofia_p2s_lib).

    Không chèn "lib" vào sys.path (dễ đè module tên chung của thư viện khác):
    nạp package bằng spec_from_file_location với tên duy nhất, nhờ đó các
    import tương đối bên trong lib (from .transport import …) vẫn hoạt động.
    """
    global _DETECT_MOD, _LOAD_ERROR
    if _DETECT_MOD is not None:
        return _DETECT_MOD
    with _LOAD_LOCK:
        if _DETECT_MOD is not None:
            return _DETECT_MOD
        init = os.path.join(_LIB_DIR, "__init__.py")
        if not os.path.isfile(init):
            _LOAD_ERROR = f"không tìm thấy {init}"
            raise ImportError(_LOAD_ERROR)
        name = "sofia_p2s_lib"
        spec = importlib.util.spec_from_file_location(
            name, init, submodule_search_locations=[_LIB_DIR])
        if spec is None or spec.loader is None:
            _LOAD_ERROR = f"nạp package lib thất bại ({_LIB_DIR})"
            raise ImportError(_LOAD_ERROR)
        pkg = importlib.util.module_from_spec(spec)
        sys.modules[name] = pkg
        try:
            spec.loader.exec_module(pkg)
            _DETECT_MOD = importlib.import_module(f"{name}.detect")
        except Exception as exc:  # noqa: BLE001 — lib lỗi không được chết pipeline
            sys.modules.pop(name, None)
            _LOAD_ERROR = f"{type(exc).__name__}: {exc}"
            raise
    return _DETECT_MOD


def _cfg_values(cfg):
    merged = dict(DEFAULTS)
    user = (cfg.get("php2shell_detect") or {}) if isinstance(cfg, dict) else {}
    for key, value in user.items():
        if value is not None:
            merged[key] = value
    return merged


def _make_transport(timeout, opts, workdir):
    """Transport RIÊNG cho 1 URL (không dùng chung thread — throttle cục bộ)."""
    detect = _load_detect()
    audit_log = None
    if opts["audit"] and workdir:
        audit_log = os.path.join(workdir, "php2shell_audit.jsonl")
    return detect.Transport(
        profile=opts["ja3"], delay=float(opts["delay"] or 0.0),
        timeout=int(timeout), proxy=(opts["proxy"] or None),
        audit_log=audit_log, retries=int(opts["retries"] or 0))


def _pinned_line(url, d):
    """Dòng ghim CVE cho vuln.txt — sofia.py nhận diện tự động (format 1)."""
    ver = f"PHP/{d.php_version}" if d.php_version else (
        f"PHP branch {d.branch}" if d.branch else "PHP/unknown")
    parts = [f"{ver}", d.verdict]
    if d.fix_floor:
        parts.append(f"fix-floor={d.fix_floor}")
    parts.append(f"upload_progress={d.upload_progress}")
    parts.append(f"display_errors={d.display_errors}")
    return f"{url} [{PIN_CVE}] PHP2Shell {' '.join(parts)}"


def _is_hit(d, opts):
    """True nếu target đủ điều kiện ghi vào file target (dính/tiếp cận được)."""
    if d.verdict == "vulnerable":
        return True
    if d.verdict == "eol" and opts["include_eol"]:
        return True
    if (d.verdict == "patched" and d.patched_but_bypassable
            and opts["include_bypassable"]):
        return True
    return False


def _probe(url, timeout, opts, workdir):
    """detect() 1 URL → (Detection, pinned_line hoặc None). Không raise."""
    jitter = opts["jitter_max"] - opts["jitter_min"]
    if jitter > 0:
        time.sleep(opts["jitter_min"] + random.random() * jitter)
    detect = _load_detect()
    t = _make_transport(timeout, opts, workdir)
    try:
        d = detect.detect(
            url, transport=t,
            check_upload_progress=opts["check_upload_progress"],
            check_display_errors=opts["check_display_errors"])
    except Exception as exc:  # noqa: BLE001 — 1 URL lỗi không chết stage
        debug(f"php2shell_detect: {url} lỗi: {type(exc).__name__}: {exc}")
        d = detect.Detection(url=url, verdict="unknown",
                             error=f"{type(exc).__name__}: {exc}")
        return d, None
    finally:
        try:
            t.close()
        except Exception:  # noqa: BLE001
            pass
    return d, (_pinned_line(url, d) if _is_hit(d, opts) else None)


def run(urls, workdir, global_out, cfg):
    """urls (cửa hàng THẬT sau stage 2c) → list dòng ghim CVE đã ghi ra file.

    Ghi output/php2shell.txt (global) + nếu write_vuln → append cùng dòng vào
    output/vuln.txt để hook exploit nạp. Trả list dòng dính (cho findings).
    """
    urls = [u for u in (urls or []) if u]
    if not urls:
        return []
    opts = _cfg_values(cfg)
    timeout = (cfg.get("timeout", 15) if isinstance(cfg, dict) else 15)

    hits = []
    scored = []
    n_vuln = n_eol = 0
    with concurrent.futures.ThreadPoolExecutor(
            max_workers=max(1, int(opts["threads"]))) as pool:
        futures = [pool.submit(_probe, u, timeout, opts, workdir) for u in urls]
        for future in concurrent.futures.as_completed(futures):
            try:
                d, line = future.result()
            except Exception as exc:  # noqa: BLE001 — không chết stage
                warn(f"php2shell_detect: worker lỗi: {type(exc).__name__}: {exc}")
                continue
            scored.append(
                f"{d.url} {d.verdict} php={d.php_version or '-'} "
                f"branch={d.branch or '-'} up={d.upload_progress} "
                f"disp={d.display_errors}"
                + (f" :: {d.reason}" if d.reason else "")
                + (f" [{d.error}]" if d.error else ""))
            if d.verdict == "vulnerable":
                n_vuln += 1
            elif d.verdict == "eol":
                n_eol += 1
            if line:
                hits.append(line)

    if not scored:
        return []
    try:
        file_io.write_lines(
            os.path.join(workdir, "php2shell_scored.txt"),
            file_io.dedupe_sort(scored))
    except Exception as exc:  # noqa: BLE001 — debug file lỗi không mất finding
        warn(f"php2shell_detect: không ghi được php2shell_scored.txt: {exc}")
    if hits:
        try:
            file_io.write_lines(
                os.path.join(workdir, "php2shell_targets.txt"),
                file_io.dedupe_sort(hits))
            file_io.append_lines(global_out, file_io.dedupe_sort(hits))
            if opts["write_vuln"]:
                vuln = (cfg.get("paths", {}).get("output_dir")
                        if isinstance(cfg, dict) else None)
                if not vuln:
                    vuln = os.path.join(BASE_DIR, "output")
                file_io.append_lines(
                    os.path.join(str(vuln), "vuln.txt"), file_io.dedupe_sort(hits))
        except Exception as exc:  # noqa: BLE001
            warn(f"php2shell_detect: không ghi được file target: {exc}")

    info(f"stage2c-p2s: PHP2Shell probe {len(scored)} cửa hàng — "
         f"dính vulnerable={n_vuln}, eol={n_eol}"
         + (f", đã ghi {len(hits)} dòng ghim CVE-2026-109619" if hits else ""))
    return file_io.dedupe_sort(hits)