"""STAGE 3: phát hiện CVE Magento — 2 lớp độc lập:

  A. OFFLINE (version match + KIỂM DUYỆT template offline) — luôn chạy, không
     cần nuclei:
     version từ stage 2b → khớp cves/version_map.yaml (core/cve_map.py) →
     dòng "[version] url ver — khả năng CVE-... [severity] name (khoảng dính)".
     Không gửi request thêm; nếu URL không có version thì không có dòng này.
     Template local trong cves/<CVE>.yaml được KIỂM DUYỆT offline TRƯỚC khi
     chạy nuclei (offline_template_validation): id khớp tên file + cấu trúc
     template hợp lệ (info.name/severity, khối thực thi http, request có
     matchers) — template hỏng bị loại + cảnh báo, không chờ nuclei lỗi.

  B. ONLINE (nuclei qua core/nuclei_engine.py dùng chung cho cả Woo) —
     CÓ THỂ TẮT qua cve.nuclei.enabled:
     1) template local trong cves/<CVE>.yaml qua -t; id trong template PHẢI
        khớp tên file (chống gán nhầm CVE cho kết quả) — lệch là bỏ qua;
     2) template cộng đồng: auto discovery dò file template trong
        cve.nuclei.templates_dir cho từng CVE → chạy qua -t chính xác; CVE
        không dò được mới fallback -id (cve.community_ids) và kiểm tra tồn
        tại qua `nuclei -tl`. Nguồn local + community chạy SONG SONG
        (cve.nuclei.parallel_sources); có chunking + retry + JSONL output
        + tự `nuclei -update-templates` (xem nuclei_engine.py).
     Một CVE vừa có template local vừa có trong community_ids → CHỈ chạy
     bản local (tránh quét trùng 2 lần cùng 1 CVE).

Cờ điều khiển mức độ ăn to (chống block/đỡ tốn băng thông) ở cve.nuclei:
  concurrency (-c), rate_limit (-rl), timeout (-timeout), retries (-retries),
  follow_redirects (trước đây code cứng "-fr" — thực chất là follow-redirects,
  KHÔNG phải "giảm false positive" như chú thích cũ), max_seconds (chặn mềm
  mỗi lượt nuclei), local_templates / community (bật tắt từng nguồn),
  severity (chỉ giữ finding mức này trở lên; rỗng = tất cả).

Kết quả: A (dòng [version]) vào output/vuln_version.txt; B (nuclei) vào
output/vuln.txt — mỗi dòng đúng 1 lần (B chỉ append phần nuclei CHƯA có ở A,
dedupe theo cặp (CVE-ID, host) thay vì so cả dòng). vuln_version.txt LUÔN
được tạo kể cả khi không có version match. Mọi lần ghi file có GHI DỰ PHÒNG:
global fail → bản tạm trong workdir (hoặc log) giữ finding — không mất dữ
liệu khi ổ cứng/quyền lỗi; _append_vul_hosts không bao giờ raise. Riêng A còn
ghi output/work/<slug>/cve_version.txt. Template cộng đồng được kiểm tra tồn
tại (nuclei -tl) trước khi chạy; timeout/template lệch được log rõ ràng. Mọi
URL dạng ip:port trong dòng finding được rewrite sang domain
(core.resolver.to_domain_url — https ưu tiên TLS SAN, http dùng PTR; giữ
nguyên URL nếu không phân giải được). Hàm nào cũng không raise (an toàn
pipeline).
"""
import os
import re
import shutil
from urllib.parse import urlparse

import yaml

from core import cve_map, nuclei_engine, resolver
from utils import file_io, stats
from utils.logger import debug, info, warn

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CVE_DIR = os.path.join(BASE_DIR, "cves")

# Trích URL từ dòng finding (version match + nuclei đều bắt đầu bằng URL)
# Escaped `\"` — chuỗ ra là raw string, backslash giữ → class chỉ literal `\"`
URL_RE = re.compile(r"""https?://[^\s]+[^\s.,;:)\]}'"]""", re.IGNORECASE)

# CVE-ID trong dòng finding (version: "khả năng CVE-..."; nuclei: [cve:ID] hoặc
# [CVE-...]) — dùng cho dedupe theo (CVE-ID, host) thay vì so cả dòng.
CVE_RE = re.compile(r"CVE-\d{4}-\d{4,7}", re.IGNORECASE)

# File riêng cho findings khớp version — tách khỏi vuln.txt (chỉ nuclei).
VERSION_FILENAME = "vuln_version.txt"

DEFAULT_NUCLEI_MAX_SECONDS = 7200


def version_file(global_vuln):
    """Đường dẫn output/vuln.txt → output/vuln_version.txt (cùng thư mục)."""
    return os.path.join(os.path.dirname(global_vuln) or ".", VERSION_FILENAME)


def rewrite_line(line, ptr_timeout=5, tls_timeout=10):
    """Đổi URL ip:port trong dòng finding sang domain; giữ line nếu thất bại.

    Dòng không chứa URL, hoặc URL không phân giải ra domain (PTR/TLS SAN) đều
    được trả về nguyên trạng. Không raise.
    """
    try:
        match = URL_RE.search(str(line))
        if not match:
            return line
        old_url = match.group(0)
        new_url = resolver.to_domain_url(old_url, ptr_timeout, tls_timeout)
        if new_url == old_url:
            return line
        return str(line).replace(old_url, new_url, 1)
    except (OSError, ValueError) as exc:
        # PTR/TLS phân giải thất bại là chuyện bình thường — giữ nguyên dòng;
        # chỉ bắt lỗi I/O/giá trị có thể thấy từ to_domain_url, lỗi khác phải
        # lộ ra caller thay vì bị nuốt im lặng.
        debug(f"rewrite_line giữ nguyên dòng ({exc.__class__.__name__}: {exc})")
        return line

def nuclei_config(cfg):
    """Chuẩn hóa block cve.nuclei — chuyển sang core/nuclei_engine.py.

    Engine chuẩn hóa CẢ khóa cũ (enabled/concurrency/…) LẪN khóa mới
    (update_templates/templates_dir/auto_discovery/json_output/chunk_size/
    max_retries/retry_delay/parallel_sources). Giữ hàm bọc tại đây để
    caller cũ gọi cve_scan.nuclei_config không bị gãy.
    """
    return nuclei_engine.nuclei_config(cfg)


def _local_template_paths(cfg):
    """Đường dẫn template local cho CVE khai trong cves: (chỉ file tồn tại)."""
    out = []
    for cve in cfg.get("cves") or []:
        path = os.path.join(CVE_DIR, f"{cve}.yaml")
        if os.path.exists(path):
            out.append(path)
        else:
            warn(f"[nuclei] không tìm thấy template local {cve} → {path} (bỏ qua)")
    return out


# Mức severity hợp lệ trong khối info của template nuclei.
_TEMPLATE_SEVERITIES = {"info", "low", "medium", "high", "critical", "unknown"}

# Các khối thực thi hợp lệ của template (đủ 1 trong các khối này là chạy được).
_TEMPLATE_EXEC_BLOCKS = ("http", "network", "dns", "workflow", "code",
                         "ssl", "file", "headless")


def _load_template_yaml(path):
    """yaml.safe_load → (data, None) hoặc (None, lý do lỗi). Không raise."""
    try:
        with open(path, encoding="utf-8") as fh:
            data = yaml.safe_load(fh)
    except (yaml.YAMLError, OSError) as exc:
        return None, str(exc)
    if not isinstance(data, dict):
        return None, "không phải mapping YAML"
    return data, None


def validate_template(path):
    """KIỂM DUYỆT OFFLINE template nuclei (không chạy nuclei) → list lý do.

    Trả list RỖNG = hợp lệ. Kiểm tra:
      * đọc được YAML mapping;
      * `id` là CVE-ID hợp lệ VÀ khớp TÊN FILE (chống gán nhầm kết quả);
      * `info.name` không trống + `info.severity` hợp lệ;
      * có ít nhất 1 khối thực thi (http/network/dns/workflow/…);
      * khối http: mỗi request phải có raw/path VÀ matchers — template
        "viết mù" không matchers sẽ không bao giờ ra finding nhưng vẫn tốn
        cả lượt nuclei → loại trước.
    Không raise; file lỗi → list lý do (caller cảnh báo + loại).
    """
    problems = []
    data, err = _load_template_yaml(path)
    if data is None:
        return [f"không đọc được YAML: {err}"]
    template_id = str(data.get("id") or "").strip().upper()
    filename_cve = os.path.basename(path).rsplit(".", 1)[0].upper()
    if not cve_map._valid_cve(template_id):
        problems.append(f"id={template_id!r} không phải CVE-ID (chống gán nhầm kết quả)")
    elif template_id != filename_cve:
        problems.append(f"id {template_id} KHÁC tên file {filename_cve}")
    info_block = data.get("info")
    if not isinstance(info_block, dict):
        problems.append("thiếu khối info")
    else:
        if not str(info_block.get("name") or "").strip():
            problems.append("info.name trống")
        sev = str(info_block.get("severity") or "").strip().lower()
        if sev not in _TEMPLATE_SEVERITIES:
            problems.append(f"info.severity={sev!r} không hợp lệ "
                            f"(một trong: {','.join(sorted(_TEMPLATE_SEVERITIES))})")
    exec_blocks = [k for k in _TEMPLATE_EXEC_BLOCKS if k in data]
    if not exec_blocks:
        problems.append("không có khối thực thi (http/network/dns/...)")
    elif "http" in data:
        requests = data.get("http") or []
        if not isinstance(requests, list) or not requests:
            problems.append("khối http rỗng / không phải list")
        else:
            for i, req in enumerate(requests, 1):
                if not isinstance(req, dict):
                    problems.append(f"http[{i}] không phải mapping")
                    continue
                if not (req.get("raw") or req.get("path")):
                    problems.append(f"http[{i}] thiếu raw/path")
                matchers = req.get("matchers")
                if not (isinstance(matchers, list) and matchers):
                    problems.append(f"http[{i}] thiếu matchers")
    return problems


def local_templates(cfg):
    """Template local hợp lệ → [(path, CVE-ID chuẩn)].

    KIỂM DUYỆT OFFLINE 2 tầng qua validate_template (id khớp tên file +
    cấu trúc template) TRƯỚC khi chạy nuclei — template hỏng bị loại kèm
    cảnh báo lý do cụ thể (trước đây chỉ phát hiện khi nuclei báo lỗi giữa
    chừng, tốn cả lượt quét).
    """
    valid = []
    for path in _local_template_paths(cfg):
        data, err = _load_template_yaml(path)
        if data is None:
            warn(f"[nuclei] template {os.path.basename(path)} không đọc được: "
                 f"{err} — bỏ qua (không gán được CVE)")
            continue
        problems = validate_template(path)
        if problems:
            warn(f"[nuclei] template {os.path.basename(path)} không hợp lệ "
                 f"(kiểm duyệt offline): {'; '.join(problems)} — bỏ qua")
            continue
        valid.append((path, str(data.get("id") or "").strip().upper()))
    return valid


def _template_flags(pairs):
    """[(path, _)] → cờ '-t path' phẳng (mỗi template một -t)."""
    flags = []
    for path, _ in pairs or []:
        flags += ["-t", path]
    return flags


def _community_tasks(community_ids, targets_file, workdir, ncfg, prefix="nuclei_community"):
    """Dựng tasks nguồn CỘNG ĐỒNG: auto discovery (-t) + fallback -id.

    auto_discovery=true → dò file template trong templates_dir cho từng
    CVE: tìm thấy → chạy qua -t (chính xác hơn, không phụ thuộc `nuclei
    -tl`); CVE không dò được → fallback `-id` và được kiểm tra tồn tại qua
    `nuclei -tl` như cũ. Mỗi task một file out RIÊNG (engine tự ghi dòng
    tổng hợp vào out — 2 task chung 1 out sẽ ghi đè nhau). `prefix` đặt tên
    file out (mặc định "nuclei_community" của Magento; Woo truyền
    "woo_nuclei_community" để không ghi đè file của nhánh Magento khi 2
    stage dùng chung workdir).
    Trả list task cho nuclei_engine.run_sources.
    """
    tasks = []
    remaining = [str(c).strip().upper() for c in community_ids or [] if str(c).strip()]
    if ncfg["auto_discovery"] and remaining:
        discovered = nuclei_engine.discover_community_templates(
            remaining, ncfg["templates_dir"])
        paths = [p for cve in remaining for p in discovered.get(cve, [])]
        if paths:
            remaining = [cve for cve in remaining if not discovered.get(cve)]
            tasks.append({
                "label": "community-discovered",
                "targets_file": targets_file,
                "out": os.path.join(workdir, f"{prefix}_discovered.txt"),
                "extra": _template_flags([(p, "") for p in paths]),
            })
            info(f"[nuclei] auto discovery: {len(paths)} template cộng đồng "
                 f"chạy qua -t ({len(remaining)} CVE fallback -id)")
    if remaining:
        # Kiểm tra template cộng đồng TỒN TẠI trước khi chạy (chưa
        # -update-templates → lượt nuclei tốn giờ mà không ra finding).
        available = nuclei_engine.community_ids_available(remaining)
        if available:
            tasks.append({
                "label": "community",
                "targets_file": targets_file,
                "out": os.path.join(workdir, f"{prefix}.txt"),
                "extra": ["-id", ",".join(available)],
            })
    return tasks


def community_template_ids(cfg):
    """CVE cộng đồng khai trong cve.community_ids (chưa lọc trùng local)."""
    return [cve for cve in (cfg.get("cve", {}).get("community_ids") or []) if cve]


def community_ids_available(ids):
    """Lọc CVE cộng đồng CÓ template — chuyển sang core/nuclei_engine.py.

    Giữ hàm bọc tại đây cho caller cũ (log/cảnh báo giữ nguyên ngữ nghĩa).
    """
    return nuclei_engine.community_ids_available(ids)


def extract_hosts(findings):
    """URL trong từng dòng finding → hostname (dedupe, sort) — dữ liệu cho vul.txt.

    Mỗi dòng finding (version match: `[version] <url> ...` hoặc nuclei:
    `<url> [CVE-...]`) chứa URL của cửa hàng dính lỗi. Trích part hostname
    (bỏ scheme/path) để ra "domain dính vuln" sạch, khớp kiểu t.txt.
    """
    hosts = set()
    for line in findings or []:
        match = URL_RE.search(str(line))
        if not match:
            continue
        host = urlparse(match.group(0)).hostname
        if host:
            hosts.add(host.lower())
    return sorted(hosts)


def _try_append(path, lines):
    """append_lines phiên bản không raise: True nếu ghi thành công, False nếu lỗi."""
    try:
        file_io.append_lines(path, lines)
        return True
    except OSError as exc:
        warn(f"[file] không ghi được {path}: {exc}")
        return False


def _log_lost_lines(path, lines):
    """Backup bằng log: in các dòng finding KHÔNG ghi được vào file nào ra log

    (cắt preview để log không phình to) — finding không bị mất vô trace.
    """
    preview = " | ".join(str(l) for l in lines[:3])
    if len(lines) > 3:
        preview += f" ... (+{len(lines) - 3} dòng nữa)"
    warn(f"[file] {len(lines)} dòng finding KHÔNG ghi được vào file nào "
         f"(backup qua log): {preview}")


def _append_ok(path, lines, fallback=None):
    """append_lines phiên bản không raise + GHI DỰ PHÒNG.

    Ghi `path` lỗi (OSError) → thử `fallback` (file tạm chứa cùng finding);
    fallback cũng lỗi → backup bằng log (_log_lost_lines) thay vì làm chết
    stage hay mất finding vô trace. Trả về True nếu finding đã ghi vào BẤT
    KỲ file nào (path hoặc fallback) — đây là điều kiện cộng bộ đếm
    (utils/stats.py): chỉ đếm target khi kết quả đã ghi ra file thành công.
    """
    if _try_append(path, lines):
        return True
    if fallback and fallback != path and _try_append(fallback, lines):
        warn(f"[file] đã ghi dự phòng {len(lines)} dòng finding vào {fallback} "
             f"({path} ghi thất bại)")
        return True
    _log_lost_lines(path, lines)
    return False


def ensure_version_file(global_vuln):
    """Tạo (nếu chưa có) output/vuln_version.txt — KỂ CẢ khi không có version

    match nào. Trước đây file chỉ được tạo khi có finding → người dùng tưởng
    bước quét version không chạy dù đã chạy mà không ra kết quả. Không raise.
    """
    path = version_file(global_vuln)
    try:
        if not os.path.exists(path):
            file_io.atomic_write(path, "")
    except OSError as exc:
        warn(f"[file] không tạo được {path}: {exc}")


def _urls_in_lines(lines):
    """Tập URL xuất hiện trong các dòng finding (dedupe) — dùng để đếm target."""
    urls = set()
    for line in lines or []:
        match = URL_RE.search(str(line))
        if match:
            urls.add(match.group(0))
    return urls


def _finding_key(line):
    """(CVE-ID, host) từ dòng finding — None nếu thiếu một trong hai.

    Dùng cho dedupe GIỮA version match và nuclei: trước đây so cả dòng nên
    `[version] url ver — khả năng CVE-...` không bao giờ khớp
    `<url> [cve:ID] ...` → cùng 1 lỗi xuất hiện 2 lần (vuln_version.txt +
    vuln.txt). Dedupe theo cặp (CVE-ID, host) là đủ để nhận trùng.
    """
    text = str(line)
    cve_m = CVE_RE.search(text)
    if not cve_m:
        return None
    url_m = URL_RE.search(text)
    if not url_m:
        return None
    try:
        host = (urlparse(url_m.group(0)).hostname or "").lower()
    except ValueError:
        return None
    if not host:
        return None
    return (cve_m.group(0).upper(), host)


def dedupe_against(nuclei_lines, known_lines):
    """Dedupe nuclei theo (CVE-ID, host): bỏ dòng nuclei trùng với `known_lines`

    (version match) — tức cùng 1 CVE trên cùng 1 host đã có ở bước A. Dòng
    nuclei không trích được (CVE, host) → GIỮ (không chứng minh được trùng).
    Output đã dedupe_sort (giữ nguyên hành vi cũ).
    """
    known = {key for key in (_finding_key(l) for l in known_lines or []) if key}
    out = []
    for line in file_io.dedupe_sort(nuclei_lines or []):
        key = _finding_key(line)
        if key and key in known:
            continue
        out.append(line)
    return out


def _append_vul_hosts(findings, global_vuln):
    """Ghi danh sách domain dính vuln (từ findings) vào output/vul.txt.

    KHÔNG BAO GIỜ raise (lỗi ghi chỉ là warn + backup log) — trước đây
    append_lines để trần, OSError (ổ cứng/quyền) làm sập toàn pipeline.
    """
    hosts = extract_hosts(findings)
    if not hosts:
        return
    global_vul = os.path.join(os.path.dirname(global_vuln), "vul.txt")
    if _try_append(global_vul, hosts):
        info(f"stage3: {len(hosts)} domain dính vuln → {global_vul}")
    else:
        _log_lost_lines(global_vul, hosts)


def version_candidates(urls, versions, cfg):
    """url + version → dòng '[version] ...' cho từng CVE khả năng dính lỗi.

    Mỗi dòng mang CVE, severity, tên lỗi và khoảng version dính lỗi (lý do
    khớp) để người đọc vuln.txt tự đối chiếu, không phải đoán.
    """
    if not versions:
        return []
    map_path = cfg.get("cve", {}).get("version_map")
    if map_path and not os.path.isabs(map_path):
        map_path = os.path.join(BASE_DIR, map_path)
    version_map = cve_map.load_map(map_path)
    if not version_map:
        return []

    lines = []
    for url in urls:
        version = versions.get(url)
        if not version:
            continue
        for hit in cve_map.match_detail(version, version_map):
            sev = hit["severity"].upper() if hit["severity"] != "n/a" else "n/a"
            name = f" ({hit['name']})" if hit["name"] else ""
            lines.append(
                f"[version] {url} {version} — khả năng {hit['cve']} "
                f"[{sev}]{name} — dính trong {hit['label']}"
            )
    return lines


def run(urls, workdir, global_vuln, cfg, versions=None):
    """urls: list URL Magento → findings (version match + nuclei); append vuln.txt.

    Không bao giờ raise: mọi lỗi nuclei/đọc file đều thành cảnh báo. Trả list
    dòng finding (version + nuclei) cho pipeline đếm.
    """
    if not urls:
        return []
    findings = []

    # vuln_version.txt luôn được TẠO (kể cả rỗng) — không có version match
    # ≠ bước quét version không chạy.
    ensure_version_file(global_vuln)

    # A) offline version match — chạy trước, có kết quả kể cả khi thiếu nuclei.
    # Dòng [version] vào vuln_version.txt (tách khỏi vuln.txt của nuclei) và
    # được rewrite URL ip:port → domain trước khi ghi. Ghi 2 file ĐỘC LẬP:
    # global fail thì workdir (cve_version.txt) còn giữ bản — finding không mất.
    version_lines_raw = version_candidates(urls, versions or {}, cfg)
    version_lines = [rewrite_line(l) for l in version_lines_raw]
    work_version_file = os.path.join(workdir, "cve_version.txt")
    version_written = False
    if version_lines:
        ok_global = _try_append(version_file(global_vuln), version_lines)
        ok_work = _try_append(work_version_file, version_lines)
        if not ok_global and ok_work:
            warn(f"[file] findings version chỉ còn ở bản dự phòng "
                 f"{work_version_file} ({version_file(global_vuln)} ghi thất bại)")
        elif not ok_global and not ok_work:
            _log_lost_lines(version_file(global_vuln), version_lines)
        version_written = ok_global and ok_work
        findings += version_lines
        if version_written:
            # Bộ đếm cộng dồn: target đã kiểm tra version KHỚP
            # cves/version_map.yaml VÀ đã ghi kết quả ra file thành công
            # (utils/stats.py). Target có version nhưng không khớp CVE nào,
            # hoặc ghi file thất bại thì KHÔNG tính.
            stats.add_version_checked(
                matched=len(_urls_in_lines(version_lines_raw)),
                found=sum(1 for u in urls if (versions or {}).get(u)))

    ncfg = nuclei_config(cfg)
    if not ncfg["enabled"]:
        info(f"stage3: {len(findings)} findings offline "
             f"(nuclei tắt trong cve.nuclei.enabled=true — vuln.txt sẽ "
             f"KHÔNG có dòng nuclei, chỉ có findings version match)")
        _append_vul_hosts(findings, global_vuln)
        return findings
    if shutil.which("nuclei") is None:
        warn("[nuclei] không tìm thấy binary nuclei trong PATH — bỏ qua toàn bộ "
             "lượt quét nuclei; vuln.txt sẽ không có thêm dòng nào (cài nuclei "
             "hoặc bật lại để quét)")
        info(f"stage3: {len(findings)} findings offline (không có nuclei)")
        _append_vul_hosts(findings, global_vuln)
        return findings

    # Tự cập nhật templates nếu bật (nuclei -update-templates — 1 lần mỗi
    # tiến trình, engine tự cache; tắt qua cve.nuclei.update_templates).
    nuclei_engine.ensure_templates_updated(cfg)

    targets_file = os.path.join(workdir, "magento.txt")
    file_io.atomic_write(targets_file, "".join(u + "\n" for u in urls))

    # Chuẩn bị 2 nguồn + dedupe: CVE có template local → bỏ khỏi community_ids
    local = local_templates(cfg) if ncfg["local_templates"] else []
    local_cves = {cve for _, cve in local}
    configured_local = [str(c).strip().upper() for c in (cfg.get("cves") or [])
                        if str(c).strip()] if ncfg["local_templates"] else []
    skipped_local = [cve for cve in configured_local if cve not in local_cves]
    if skipped_local:
        # Log rõ: CVE bị bỏ qua (file thiếu / id lệch tên file / template hỏng)
        # sẽ KHÔNG được quét bằng nuclei → vuln.txt thiếu finding của CVE này.
        warn(f"[nuclei] {len(skipped_local)} template local bị bỏ qua: "
             f"{', '.join(skipped_local)} — các CVE này sẽ KHÔNG được quét "
             f"bằng nuclei (sửa id trong template cho khớp tên file hoặc thêm "
             f"file cves/<CVE>.yaml)")
    community_ids = [cve for cve in community_template_ids(cfg)
                     if cve and cve.upper() not in local_cves] \
        if ncfg["community"] else []
    if not local and not community_ids:
        reason = ("template local không hợp lệ " if ncfg["local_templates"] else "tắt local") \
            if not community_ids else ""
        warn(f"[nuclei] không có nguồn nào để chạy ({reason or 'cả local và community đều tắt/trống'}) "
             f"— giữ {len(findings)} findings offline")
        _append_vul_hosts(findings, global_vuln)
        return findings

    # B) dựng các NGUỒN template rồi chạy qua engine dùng chung (chunking +
    # retry + JSONL + chạy song song): local qua -t; community qua auto
    # discovery (-t, chính xác hơn) + fallback -id — _community_tasks tự lọc
    # CVE còn template (nuclei -tl) trước khi chạy.
    tasks = []
    if local:
        tasks.append({
            "label": "local",
            "targets_file": targets_file,
            "out": os.path.join(workdir, "nuclei.txt"),
            "extra": _template_flags(local),
        })
    if community_ids and os.path.isdir(CVE_DIR):
        tasks += _community_tasks(community_ids, targets_file, workdir, ncfg)
    if not tasks:
        warn("[nuclei] không còn nguồn nào khả dụng sau khi lọc (template "
             "cộng đồng không tồn tại) — giữ "
             f"{len(findings)} findings offline")
        _append_vul_hosts(findings, global_vuln)
        return findings

    results = nuclei_engine.run_sources(tasks, cfg)
    nuclei_lines = []
    for label, res in results.items():
        nuclei_lines += res["lines"]
        if res["failed"]:
            warn(f"[nuclei] nguồn {label}: {res['failed']} chunk lỗi/timeout — "
                 f"finding từ các chunk này CÓ THỂ thiếu")
    # Bộ đếm chỉ cộng SAU khi findings đã ghi ra file thành công (bên dưới).
    local_done = bool(local) and results.get("local", {}).get("ok", False)
    if local and not local_done:
        warn(f"[nuclei] lượt template local dừng sớm/không trọn vẹn — "
             f"không tính {len(urls)} target vào bộ đếm nuclei local")

    # Rewrite URL ip:port → domain cho findings nuclei trước khi dedupe/ghi.
    nuclei_lines = [rewrite_line(l) for l in nuclei_lines]
    findings = file_io.dedupe_sort(version_lines + nuclei_lines)
    # Append CHỈ phần nuclei chưa có ở bước A — version_lines đã append vào
    # vuln_version.txt ở bước A rồi; append cả findings sẽ ghi trùng dòng
    # [version] lần 2. Dedupe theo (CVE-ID, host) thay vì so cả dòng: trước
    # đây dòng version `[version] url ... CVE-X ...` không bao giờ trùng dòng
    # nuclei `url [cve:X] ...` → cùng 1 lỗi bị ghi 2 lần (vuln_version + vuln).
    new_lines = dedupe_against(nuclei_lines, version_lines)
    # Ghi dự phòng: global fail → bản tạm workdir/vuln_fallback.txt giữ finding.
    vuln_written = _append_ok(global_vuln, new_lines,
                              fallback=os.path.join(workdir, "vuln_fallback.txt"))
    if local_done:
        if vuln_written:
            # Bộ đếm cộng dồn: target đã kiểm tra bằng nuclei template local
            # VÀ findings đã ghi ra file thành công (utils/stats.py).
            stats.add_nuclei_local_done(targets=len(urls), runs=1)
        else:
            warn(f"[nuclei] không ghi được findings vào {global_vuln} — "
                 f"không tính {len(urls)} target vào bộ đếm nuclei local")
    _append_vul_hosts(findings, global_vuln)
    info(f"stage3: {len(findings)} findings "
         f"(offline {len(version_lines)} + nuclei mới {len(new_lines)})")
    return findings



