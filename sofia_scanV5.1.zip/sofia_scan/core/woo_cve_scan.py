"""STAGE 3-woo: phát hiện CVE WooCommerce/WordPress — 2 lớp (giống cve_scan.py):

  A. OFFLINE (version match) — luôn chạy, không cần nuclei:
     version TỪNG PLUGIN (stage 3-woo) → khớp cves/woo_version_map.yaml
     (core/woo_cve_map.py) → dòng
     "[version] <url> <slug> <version> — khả năng CVE-... [SEV] (name) — dính trong <label>".
     Không gửi request thêm; plugin không rõ version thì không có dòng này.

  B. ONLINE (nuclei qua core/nuclei_engine.py — dùng chung engine với Magento)
     — CÓ THỂ TẮT qua cve.nuclei.enabled:
     1) template LOCAL trong cves/<CVE>.yaml qua -t (woocommerce.cves) — chỉ
        CVE đã xác minh qua research (cves/research/), tránh template viết mù;
        id trong template PHẢI khớp tên file (dùng lại cve_scan.local_templates
        — kiểm duyệt offline cấu trúc template TRƯỚC khi chạy nuclei);
     2) template CỘNG ĐỒNG (woocommerce.community_ids; nếu để trống thì lấy
        toàn bộ CVE có trong woo_version_map.yaml): auto discovery dò file
        template trong cve.nuclei.templates_dir cho từng CVE → chạy qua -t
        (chính xác hơn); CVE không dò được mới fallback -id (kiểm tra tồn
        tại qua `nuclei -tl`).
     Nguồn local + community chạy SONG SONG (cve.nuclei.parallel_sources); có
     chunking + retry + JSONL output + tự `nuclei -update-templates`
     (cve.nuclei.update_templates — xem nuclei_engine.py).
     Một CVE vừa có template local vừa có trong community_ids → CHỈ chạy bản
     local (như nhánh Magento). Dùng chung cờ nuclei với Magento
     (cve.nuclei: concurrency/rate_limit/…).

Dùng lại helper của core/cve_scan.py (nuclei_config/local_templates/
_append_vul_hosts/community_template_ids/_community_tasks/_append_ok/
_urls_in_lines) và engine dùng chung core/nuclei_engine.py (run_sources) để
2 nhánh Magento & Woo hành xử nhất quán.
Findings: offline (dòng [version]) vào output/vuln_version.txt (LUÔN được tạo,
kể cả khi không có version match), nuclei vào output/vuln.txt (mỗi dòng đúng
1 lần — nuclei chỉ append phần CHƯA có ở A, dedupe theo cặp (CVE-ID, host));
host dính ghi vào output/vul.txt (không bao giờ raise); riêng offline ghi
work/<slug>/woo_cve_version.txt, nuclei local ghi work/<slug>/woo_nuclei.txt,
cộng đồng ghi woo_nuclei_community.txt (kèm woo_nuclei_community_discovered.txt
khi auto discovery dò được file template). Mọi lần ghi file có GHI DỰ PHÒNG:
global fail → bản tạm trong workdir (hoặc log) giữ finding.
URL ip:port trong finding được rewrite
sang domain (cve_scan.rewrite_line; giữ nguyên nếu không phân giải được).
Hàm nào cũng không raise (an toàn pipeline).
Contract: run(urls, versions, workdir, global_vuln, cfg) → list dòng finding.
"""
import os
import shutil

from core import cve_scan, nuclei_engine, woo_cve_map
from utils import file_io, stats
from utils.logger import info, warn

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _map_path(cfg):
    """Đường dẫn woo_version_map (cfg.woocommerce.version_map, tương đối → BASE_DIR)."""
    path = (cfg.get("woocommerce") or {}).get("version_map")
    if path and not os.path.isabs(path):
        path = os.path.join(BASE_DIR, path)
    return path


def version_candidates(urls, versions, cfg):
    """(url, {slug: version}) → dòng '[version] ...' cho mỗi plugin dính lỗi."""
    if not versions:
        return []
    plugin_map = woo_cve_map.load_map(_map_path(cfg))
    if not plugin_map:
        return []

    lines = []
    for url in urls:
        host_plugins = versions.get(url) or {}
        for slug, version in host_plugins.items():
            for hit in woo_cve_map.match(slug, version, plugin_map):
                sev = hit["severity"].upper() if hit["severity"] != "n/a" else "n/a"
                name = f" ({hit['name']})" if hit["name"] else ""
                lines.append(
                    f"[version] {url} {slug} {version} — khả năng {hit['cve']} "
                    f"[{sev}]{name} — dính trong {hit['label']}"
                )
    return file_io.dedupe_sort(lines)


def local_templates(cfg):
    """Template local Woo (cfg.woocommerce.cves) → [(path, CVE-ID chuẩn)].

    Dùng lại cve_scan.local_templates (kiểm tra id khớp tên file, chỉ file
    tồn tại) với danh sách CVE khai trong woocommerce.cves.
    """
    ids = (cfg.get("woocommerce") or {}).get("cves") or []
    return cve_scan.local_templates({"cves": ids})


def community_ids(cfg):
    """CVE cộng đồng cho Woo: cfg.woocommerce.community_ids, trống → toàn bộ map."""
    ids = [str(cve).strip().upper()
           for cve in ((cfg.get("woocommerce") or {}).get("community_ids") or [])
           if str(cve).strip()]
    if ids:
        return ids
    return sorted(woo_cve_map.all_cves(woo_cve_map.load_map(_map_path(cfg))))


def run(urls, versions, workdir, global_vuln, cfg):
    """urls: list URL WooCommerce; versions: {url: {slug: version}}.

    Trả list dòng finding (offline + nuclei); offline → vuln_version.txt,
    nuclei → vuln.txt, host → vul.txt; URL ip:port được rewrite sang domain.
    """
    if not urls:
        return []
    findings = []

    # vuln_version.txt luôn được TẠO (kể cả rỗng) — không có version match
    # ≠ bước quét version không chạy (khớp hành vi cve_scan.run).
    cve_scan.ensure_version_file(global_vuln)

    # A) offline version match — chạy trước, có kết quả kể cả khi thiếu nuclei.
    # Dòng [version] vào vuln_version.txt (tách khỏi vuln.txt của nuclei) và
    # được rewrite URL ip:port → domain trước khi ghi. Ghi 2 file ĐỘC LẬP:
    # global fail thì workdir (woo_cve_version.txt) còn giữ bản dự phòng.
    version_lines_raw = version_candidates(urls, versions or {}, cfg)
    version_lines = [cve_scan.rewrite_line(l) for l in version_lines_raw]
    work_version_file = os.path.join(workdir, "woo_cve_version.txt")
    version_written = False
    if version_lines:
        ok_global = cve_scan._try_append(cve_scan.version_file(global_vuln),
                                         version_lines)
        ok_work = cve_scan._try_append(work_version_file, version_lines)
        if not ok_global and ok_work:
            warn(f"[file] findings version (woo) chỉ còn ở bản dự phòng "
                 f"{work_version_file} ({cve_scan.version_file(global_vuln)} "
                 f"ghi thất bại)")
        elif not ok_global and not ok_work:
            cve_scan._log_lost_lines(cve_scan.version_file(global_vuln),
                                     version_lines)
        version_written = ok_global and ok_work
        findings += version_lines
        if version_written:
            # Bộ đếm cộng dồn: target Woo đã kiểm tra version plugin KHỚP
            # cves/woo_version_map.yaml VÀ đã ghi kết quả ra file thành công
            # (utils/stats.py). Host có version plugin nhưng không khớp CVE
            # nào, hoặc ghi file thất bại thì KHÔNG tính.
            stats.add_version_checked(
                matched=len(cve_scan._urls_in_lines(version_lines_raw)),
                found=sum(1 for v in (versions or {}).values() if v))

    ncfg = cve_scan.nuclei_config(cfg)
    if not ncfg["enabled"]:
        info(f"stage3-woo: {len(findings)} findings offline "
             f"(nuclei tắt trong cve.nuclei.enabled)")
        cve_scan._append_vul_hosts(findings, global_vuln)
        return findings
    if shutil.which("nuclei") is None:
        warn("[nuclei] không tìm thấy nuclei — giữ nguyên kết quả version match (woo)")
        info(f"stage3-woo: {len(findings)} findings offline (không có nuclei)")
        cve_scan._append_vul_hosts(findings, global_vuln)
        return findings

    # Tự cập nhật templates nếu bật (nuclei -update-templates — 1 lần mỗi
    # tiến trình, engine tự cache; tắt qua cve.nuclei.update_templates).
    nuclei_engine.ensure_templates_updated(cfg)

    targets_file = os.path.join(workdir, "woocommerce.txt")
    file_io.atomic_write(targets_file, "".join(u + "\n" for u in urls))

    # Chuẩn bị 2 nguồn + dedupe: CVE có template local → bỏ khỏi community_ids
    # (mô phỏng đúng nhánh Magento — xem cve_scan.run).
    local = local_templates(cfg) if ncfg["local_templates"] else []
    local_cves = {cve for _, cve in local}
    configured_local = [str(c).strip().upper() for c in ((cfg.get("woocommerce")
                          or {}).get("cves") or []) if str(c).strip()] \
        if ncfg["local_templates"] else []
    skipped_local = [cve for cve in configured_local if cve not in local_cves]
    if skipped_local:
        # Log rõ tổng hợp: các CVE này sẽ KHÔNG được quét bằng nuclei (woo).
        warn(f"[nuclei] {len(skipped_local)} template local bị bỏ qua (woo): "
             f"{', '.join(skipped_local)} — các CVE này sẽ KHÔNG được quét "
             f"bằng nuclei (sửa id cho khớp tên file hoặc thêm file)")
    ids = [cve for cve in community_ids(cfg) if cve not in local_cves] \
        if ncfg["community"] else []
    if not local and not ids:
        warn("[nuclei] không có nguồn nào để chạy (woo) — "
             "giữ nguyên kết quả version match (woo)")
        cve_scan._append_vul_hosts(findings, global_vuln)
        return findings

    # B) dựng các NGUỒN template rồi chạy qua engine dùng chung (chunking +
    # retry + JSONL + chạy song song): local qua -t; community qua auto
    # discovery (-t, chính xác hơn) + fallback -id — _community_tasks tự lọc
    # CVE còn template (nuclei -tl) trước khi chạy. prefix riêng để không
    # ghi đè file community của nhánh Magento khi 2 stage chung workdir.
    tasks = []
    if local:
        tasks.append({
            "label": "local",
            "targets_file": targets_file,
            "out": os.path.join(workdir, "woo_nuclei.txt"),
            "extra": cve_scan._template_flags(local),
        })
    if ids:
        tasks += cve_scan._community_tasks(
            ids, targets_file, workdir, ncfg,
            prefix="woo_nuclei_community")
    if not tasks:
        warn("[nuclei] không còn nguồn nào khả dụng sau khi lọc (woo) — "
             "giữ nguyên kết quả version match (woo)")
        cve_scan._append_vul_hosts(findings, global_vuln)
        return findings

    results = nuclei_engine.run_sources(tasks, cfg)
    nuclei_lines = []
    for label, res in results.items():
        nuclei_lines += res["lines"]
        if res["failed"]:
            warn(f"[nuclei] nguồn {label}: {res['failed']} chunk lỗi/timeout — "
                 f"finding từ các chunk này CÓ THỂ thiếu (woo)")
    # Bộ đếm chỉ cộng SAU khi findings đã ghi ra file thành công (bên dưới).
    local_done = bool(local) and results.get("local", {}).get("ok", False)
    if local and not local_done:
        warn(f"[nuclei] lượt template local dừng sớm/không trọn vẹn (woo) — "
             f"không tính {len(urls)} target vào bộ đếm nuclei local")

    # Rewrite URL ip:port → domain cho findings nuclei trước khi dedupe/ghi.
    nuclei_lines = [cve_scan.rewrite_line(l) for l in nuclei_lines]
    findings = file_io.dedupe_sort(version_lines + nuclei_lines)
    # Append CHỈ phần nuclei chưa có ở bước A — version_lines đã append vào
    # vuln_version.txt ở bước A rồi; append cả findings sẽ ghi trùng dòng
    # [version] lần 2. Dedupe theo (CVE-ID, host) thay vì so cả dòng
    # (khớp cve_scan.run — trước đây 2 dạng dòng không bao giờ khớp nên
    # cùng 1 lỗi bị ghi 2 lần: vuln_version.txt + vuln.txt).
    new_lines = cve_scan.dedupe_against(nuclei_lines, version_lines)
    # Ghi dự phòng: global fail → bản tạm workdir/vuln_fallback.txt giữ finding.
    vuln_written = cve_scan._append_ok(
        global_vuln, new_lines,
        fallback=os.path.join(workdir, "vuln_fallback.txt"))
    if local_done:
        if vuln_written:
            # Bộ đếm cộng dồn: target đã kiểm tra bằng nuclei template local
            # VÀ findings đã ghi ra file thành công (utils/stats.py).
            stats.add_nuclei_local_done(targets=len(urls), runs=1)
        else:
            warn(f"[nuclei] không ghi được findings vào {global_vuln} — "
                 f"không tính {len(urls)} target vào bộ đếm nuclei local (woo)")
    cve_scan._append_vul_hosts(findings, global_vuln)
    info(f"stage3-woo: {len(findings)} findings "
         f"(offline {len(version_lines)} + nuclei mới {len(new_lines)}, "
         f"local {len(local)} + community {len(ids)} template)")
    return findings
