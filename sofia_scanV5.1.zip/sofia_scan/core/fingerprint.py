"""STAGE 2a: phát hiện Magento — probe ĐA ENDPOINT + chấm điểm tin cậy.

Thay vì chỉ GET trang chủ, mỗi host được probe thêm các endpoint đặc trưng
(cấu hình `fingerprint.endpoints`, mặc định):
    /rest/V1/          → REST API (JSON)
    /graphql           → GraphQL API (JSON)
    /static/version/   → static content version (Magento 2)
    /magento_version   → lộ version nếu cấu hình lỏng

Mỗi bằng chứng cộng điểm (confidence scoring):
    header x-magento*/x-mage*            +3
    cookie mage-*/private_content_version/x-magento-vary/section_data_ids/form_key  +3
    cookie frontend=                      +2
    body chữ ký MẠNH (Magento_*, data-mage-init, mage/*, static/frontend/...)     +3
    body chữ ký TRUNG BÌNH (branding)     +2
    >=3 từ "magento" trong body           +1
    /rest/V1/ trả JSON                    +3
    /graphql trả JSON                     +3
    /static/version/ HTTP 200             +2
    /magento_version trả version          +3

Tổng đạt `fingerprint.min_score` (mặc định 3) → kết luận là Magento.
Short-circuit: đạt ngưỡng thì dừng probe sớm (tiết kiệm request).

NÂNG CẤP độ nhận diện:
  * Trang chủ GET qua lớp HTTP chung (utils/http.py) + PageCache → tái dùng kết
    quả khi stage 2c/2b cũng đọc trang chủ (giảm request, nhanh hơn).
  * Endpoint sâu (deep): khi trang chủ cho tín hiệu MỀM (0 < điểm < ngưỡng) thì
    probe thêm /rest/V1/store/storeConfigs và /customer/section/load/?sections=cart
    — hai endpoint đặc trưng Magento mà site đổi theme/asset vẫn còn. CHỈ probe
    khi đã có tín hiệu (không nạp thêm host không phải Magento).
  * Bổ sung nhiều marker mạnh (static/frontend/, form_key, mage/cookies...).

NÂNG CẤP 2 (nhận diện chính xác hơn + nhanh hơn):
  * GET có TRẦN byte (http.fetch_limited) → không kéo cả trang nặng chỉ để chấm
    điểm; kết nối đóng ngay.
  * PROBE REST CÔNG KHAI: /rest/V1/directory/countries trả JSON array 200 KHÔNG
    cần auth — dấu hiệu rất khó giả và ít endpoint khác có.
  * REST trả 401/403 dạng JSON lỗi Magento ("consumer isn't authorized",
    "vendor/magento/") → +3: catch-all HTML 401 của web server không lọt.
  * PROBE GraphQL BẰNG POST (`{storeConfig{base_currency_code}}`) — site headless/
    đổi theme vẫn trả JSON GraphQL; GET /graphql không đủ nhận diện.
  * Thêm marker Magento 1 (varien/js, /js/prototype, Mage.*) và 2.4+.
  * httpx_detect (binary ngoài) chạy SONG SONG với probe và bật/tắt qua
    `fingerprint.httpx_detect` (mặc định true) — không chặn stage 2a nữa.

NÂNG CẤP 3 (không bỏ sót target — recall):
  * FALLBACK HTTPS: host chỉ nói TLS trên port lạ (8080/8000...) mà probe http://
    kết nối lỗi → thử lại đúng 1 lần https:// cùng host:port (site này trước đây
    bị mất oan vì luôn probe http). Cấu hình `fingerprint.scheme_fallback`.
  * RE-PROBE SAU REDIRECT: homepage 301/302 sang thư mục con (/shop/, /magento/)
    hay sang domain thật (ip → www) → probe tiếp HOMEPAGE + REST/GraphQL ngay tại
    URL cuối (cài Magento trong thư mục con trước đây bị bỏ sót vì chỉ probe
    endpoint ở gốc). Cấu hình `fingerprint.redirect_probe`.
  * REST QUA /index.php: nginx/Apache không rewrite /rest/ trực tiếp vẫn phục vụ
    /index.php/rest/V1/ → thêm endpoint mặc định (rule REST áp cho MỌI đường
    dẫn chứa /rest/).
  * ROBOTS.TXT: robots mặc định của Magento chặn đặc trưng (checkout,
    catalogsearch, customer/account, rest, downloader, cron.php...) — site bị WAF
    che toàn bộ marker HTML vẫn còn lộ qua robots (≥4 quy tắc +3, ≥2 +2, 1 +1).
  * ADMIN + STATIC PUB (endpoint sâu, chỉ probe khi đã có tín hiệu mềm):
    /admin, /index.php/admin (login admin chứa static/adminhtml/),
    /pub/static/version/ (docroot trỏ webroot — cấu hình sai phổ biến),
    /downloader/ (Magento 1 Connect Manager).
  * MARKER MỚI: static/adminhtml/, media/catalog/product, requirejs-config.js,
    customer/section/load — bắt site gộp asset qua CDN mà còn đường dẫn đặc trưng.
  * HEADER Fastly: `Fastly-Module-Enabled` (CDN mặc định Adobe Commerce Cloud) +2.
  * httpx nhận thêm "Adobe Commerce" bên cạnh "Magento".

Output:
    magento.txt            — 1 URL Magento mỗi dòng (contract cũ, giữ nguyên)
    output/work/<slug>/magento_scored.txt — "url score bằng_chứng" (debug)
Contract giữ nguyên: probe → (url, bool); run → list URL Magento.
"""
import concurrent.futures
import os
import re
import shutil

import requests
import urllib3

from utils import file_io, http, runner, stats
from utils.logger import info, warn

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

USER_AGENT = "Mozilla/5.0 (compatible; SofiaScan/1.0)"
BODY_LIMIT = 200000  # giới hạn body đọc signature (tránh tốn RAM trên trang lớn)

DEFAULT_ENDPOINTS = (
    "/rest/V1/", "/rest/V1/directory/countries", "/graphql",
    "/static/version/", "/magento_version",
    # REST phục vụ qua front controller (nginx không rewrite /rest/ trực tiếp)
    "/index.php/rest/V1/",
    # robots mặc định của Magento liệt kê path đặc trưng — sig rẻ và bền
    "/robots.txt",
)
# Endpoint sâu — chỉ probe khi đã có tín hiệu mềm (0 < điểm < ngưỡng).
DEEP_ENDPOINTS = (
    "/rest/V1/store/storeConfigs", "/customer/section/load/?sections=cart",
    # admin login (default frontname) — body chứa static/adminhtml/ (marker mạnh)
    "/admin", "/index.php/admin",
    # docroot trỏ sai vào webroot → static nằm dưới /pub/
    "/pub/static/version/",
    # Magento 1 Connect Manager — còn sống ở nhiều store M1
    "/downloader/",
)
# Endpoint probe lại tại URL CUỐI khi homepage redirect sang base khác (thư mục
# con / domain thật) — bộ nhỏ, đủ bằng chứng, không đốt request.
REDIRECT_REPROBE_ENDPOINTS = ("/rest/V1/directory/countries", "/graphql")
DEFAULT_MIN_SCORE = 3
# REST công khai, không cần auth — trả JSON array (endpoint đặc trưng Magento).
PUBLIC_REST_PATH = "/rest/V1/directory/countries"
# GraphQL POST body tối thiểu: Magento trả {"data":{"storeConfig":{...}}}
GRAPHQL_QUERY = {"query": "{storeConfig{base_currency_code store_name}}"}
GRAPHQL_BODY_MARKERS = ("storeConfig", "base_currency_code", "graphql", "GraphQL")
# Lỗi REST của Magento (JSON) — dùng để nhận diện 401/403 thật của Magento.
REST_ERROR_RE = re.compile(
    r"consumer\s+isn'?t\s+authorized|vendor[/\\]magento[/\\]|"
    r"Magento\\\\Framework|magento[\"']?\s*,\s*[\"']?trace", re.I)

# --- Headers ----------------------------------------------------------------
HEADER_PREFIXES = ("x-magento", "mage-", "x-mage")

# Tên cookie do Magento đặt (kiểm tra trên Set-Cookie và Cookie)
COOKIE_NAMES = re.compile(
    r"(?:^|[;\s=])(?:mage-[a-z0-9_-]+|private_content_version|x-magento-vary"
    r"|section_data_ids|form_key)[\s;=]", re.I,
)
FRONTEND_COOKIE = re.compile(r"frontend=", re.I)

# --- Body: chữ ký MẠNH (đặc trưng riêng của Magento) -------------------------
STRONG_BODY = (
    # Magento 2: widget/component JS — "Magento_Theme/js/view/...", Magento_Ui
    re.compile(r"Magento_[A-Za-z0-9_]+"),
    # Magento 2: data-mage-init / x-magento-init (requirejs bootstrap inline)
    re.compile(r"data-mage-init"),
    re.compile(r"x-magento-init"),
    # Magento 2: lib web mage — /lib/web/mage/requirejs/..., mage/cookies.js
    re.compile(r"/lib/web/mage/"),
    # Magento 2: theme path — frontend/Magento/luma, frontend/Magento/blank
    re.compile(r"frontend/Magento/(?:luma|blank)\b"),
    re.compile(r"frontend/Magento/"),
    # Magento 2: requirejs config / mage/* script paths
    re.compile(r"mage/(?:requirejs|cookies|url|translate|validation|apply|storage|cache)"),
    re.compile(r"js/mage/"),
    re.compile(r"requirejs-magento"),
    # Magento 2: static versioned assets — /static/version1699999999/frontend/...
    re.compile(r"static/version\d{6,}/"),
    # Magento 2: static content dir
    re.compile(r"static/frontend/"),
    # Magento 2: form key (CSRF token chỉ Magento dùng tên này phổ biến)
    re.compile(r"form_key", re.I),
    re.compile(r"pub/static/"),
    # Magento 2: REST API path trong HTML
    re.compile(r"/rest/V[12]/"),
    # Magento 1 & 2
    re.compile(r"skin/frontend/"),
    # Magento 1: varien JS library, VarienForm, js/prototype (chỉ M1 dùng)
    re.compile(r"varien/[a-z0-9_]+", re.I),
    re.compile(r"VarienForm"),
    re.compile(r"(?:js/)?prototype(?:\.js)?[\"'?]"),
    re.compile(r"js/calendar/calendar\.js"),
    re.compile(r"skin/adminhtml/"),
    # Magento 1: Mage object / Mage.Cookies, Mage.cache, Mage.app, Mage.baseURL
    re.compile(r"Mage\.(?:Cookies|cache|app|baseURL)\b"),
    # Magento 1 Connect downloader
    re.compile(r"/downloader/\?url="),
    # <meta name="generator" content="Magento ...">
    re.compile(r"<meta[^>]+name=[\"']generator[\"'][^>]+content=[\"'][^>]*magento", re.I),
    re.compile(r"<meta[^>]+content=[\"'][^>]*magento[^>]*name=[\"']generator[\"']", re.I),
    # HTML attribute trỏ tới path/asset Magento
    re.compile(r"""(?:href|src)\s*=\s*["'][^"']*magento""", re.I),
    # V5.3: asset admin (backend vẫn dùng theme luma kể cả khi frontend đổi)
    re.compile(r"static/adminhtml/"),
    # V5.3: ảnh sản phẩm (storefront thật/landing có catalog còn sót)
    re.compile(r"media/catalog/product"),
    re.compile(r"requirejs-config\.js"),
    # V5.3: customer-data section (mọi theme Magento 2 đều giữ tên path này)
    re.compile(r"customer/section/load"),
)

# --- Body: chữ ký TRUNG BÌNH (tên thương mại — 1 hit là xác nhận) -----------
MEDIUM_BODY = (
    re.compile(r"powered\s+by\s+magento", re.I),
    re.compile(r"Magento\s+Commerce", re.I),
    re.compile(r"Adobe\s+Commerce", re.I),
)

# --- Body: chữ ký YẾU (từ "magento" thường trong text) -----------------------
WEAK_WORD = re.compile(r"\bmagento\b", re.I)
WEAK_MIN_OCCURRENCES = 3

# --- robots.txt: quy tắc Disallow đặc trưng của Magento -----------------------
# Sét riêng Magento (không trùng Shopify/WooCommerce): checkout/ CÓ slash,
# catalogsearch, customer/account, rest, sendfriend, downloader, api.php,
# cron.php, lib/, review/, media/, static/.
MAGENTO_ROBOTS_RE = re.compile(
    r"disallow:\s*/(checkout|catalogsearch|customer/account|rest|sendfriend|"
    r"downloader|api\.php|cron\.php|lib|review|media|static)", re.I)

# --- /magento_version --------------------------------------------------------
# Cho phép hậu tố ngày kiểu "-2026-aug" (bản 2026 dùng build date) bên cạnh -pN.
VERSION_RE = re.compile(
    r"^\s*(Magento/\d+\.\d+(?:\.\d+)?(?:-p\d+)?(?:-\d{4}-[a-z]{3})?"
    r"(?:\s*\([^)]*\))?)", re.I,
)
HTML_TYPES = re.compile(r"text/html", re.I)
JSON_TYPES = re.compile(r"application/json", re.I)


def _hdrs(headers):
    return {str(k).lower(): str(v) for k, v in (headers or {}).items()}


def score_response(status, headers, body, endpoint=None):
    """Chấm điểm 1 response HTTP. Trả về (score, [bằng_chứng]).

    Bằng chứng dạng "header:x-magento-*", "cookie:mage", "body:strong", ...
    """
    hdrs = _hdrs(headers)
    score = 0
    evidence = []

    for header, value in hdrs.items():
        if header.startswith(HEADER_PREFIXES):
            score += 3
            evidence.append(f"header:{header}")
            break
    # Fastly là CDN mặc định của Adobe Commerce Cloud — module Fastly-Caching
    # của Magento tự thêm header này (đặc trưng, không phải CDN nào cũng có).
    if "fastly-module-enabled" in hdrs:
        score += 2
        evidence.append("header:fastly-module-enabled")
    for header, value in hdrs.items():
        if header in ("set-cookie", "cookie"):
            if COOKIE_NAMES.search(value):
                score += 3
                evidence.append("cookie:mage")
            elif FRONTEND_COOKIE.search(value):
                score += 2
                evidence.append("cookie:frontend")

    body = body or ""
    if any(p.search(body) for p in STRONG_BODY):
        score += 3
        evidence.append("body:strong")
    if any(p.search(body) for p in MEDIUM_BODY):
        score += 2
        evidence.append("body:medium")
    hits = len(WEAK_WORD.findall(body))
    if hits >= WEAK_MIN_OCCURRENCES:
        score += 1
        evidence.append(f"body:weak x{hits}")

    if endpoint:
        if endpoint == "/magento_version":
            ok, _version = check_magento_version_response(status, headers, body)
            if ok:
                score += 3
                evidence.append("endpoint:magento_version")
        elif endpoint.startswith("/rest/"):
            is_json = bool(JSON_TYPES.search(hdrs.get("content-type", "")))
            if status == 200 and is_json:
                score += 3
                evidence.append("endpoint:rest")
                # REST công khai của Magento trả JSON array/object — tín hiệu chắc.
                if endpoint.startswith(PUBLIC_REST_PATH) and body.lstrip()[:1] in "[{":
                    score += 2
                    evidence.append("endpoint:rest-public")
            elif status in (400, 401, 403) and is_json and REST_ERROR_RE.search(body):
                # 401/403 JSON đúng định dạng lỗi Magento → catch-all của web
                # server (HTML 401) không lọt vào đây.
                score += 3
                evidence.append(f"endpoint:rest-{status}")
        elif endpoint == "/graphql" or endpoint == "/graphql/":
            is_json = bool(JSON_TYPES.search(hdrs.get("content-type", "")))
            if is_json and status in (200, 400):
                if any(m in body for m in GRAPHQL_BODY_MARKERS):
                    # POST GraphQL trả data/errors của Magento (mạnh hơn GET 200 JSON)
                    score += 3
                    evidence.append("endpoint:graphql")
                elif status == 200:
                    score += 2
                    evidence.append("endpoint:graphql-weak")
        elif endpoint == "/static/version/":
            if status == 200:
                score += 2
                evidence.append("endpoint:static_version")
        elif endpoint.startswith("/customer/section/load"):
            # sections=cart trả JSON ở store thật; HTML/redirect bị bỏ qua
            if status == 200 and JSON_TYPES.search(hdrs.get("content-type", "")):
                score += 2
                evidence.append("endpoint:section-load")

    return score, evidence


def check_magento(status, headers, body, min_score=DEFAULT_MIN_SCORE):
    """Signature check (contract cũ): True nếu response đạt ngưỡng điểm."""
    score, _evidence = score_response(status, headers, body)
    return score >= min_score


def check_magento_version_response(status, headers, body):
    """Response của GET /magento_version.

    Chặt hơn: yêu cầu HTTP 200 + content-type KHÔNG phải text/html (tránh
    catch-all rewrite trả về trang HTML chứa text "Magento/2.x").
    Trả về (bool, version) — version rò rỉ để log.
    """
    if status != 200:
        return False, None
    ctype = _hdrs(headers).get("content-type", "")
    if HTML_TYPES.search(ctype):
        return False, None
    body = (body or "")[:200].strip()
    match = VERSION_RE.match(body)
    if not match:
        return False, None
    return True, match.group(1)


def _endpoints_from_cfg(cfg):
    """Đọc fingerprint.endpoints; fallback legacy probe_magento_version."""
    fp = cfg.get("fingerprint") or {}
    endpoints = fp.get("endpoints")
    if endpoints:
        return tuple(endpoints)
    # Legacy: chỉ probe /magento_version nếu bật (bản cũ)
    if cfg.get("probe_magento_version", True):
        return ("/magento_version",)
    return ()


def _min_score_from_cfg(cfg):
    fp = cfg.get("fingerprint") or {}
    return int(fp.get("min_score", DEFAULT_MIN_SCORE))


def _deep_from_cfg(cfg):
    """Endpoint sâu tuỳ chỉnh (rỗng = mặc định). None nếu tắt hẳn."""
    fp = cfg.get("fingerprint") or {}
    if fp.get("deep_probe", True) is False:
        return ()
    deep = fp.get("deep_endpoints")
    return tuple(deep) if deep else DEEP_ENDPOINTS


def _alt_scheme(url):
    """Scheme đối xứng: http→https, https→http (None nếu không đổi được)."""
    if url.startswith("http://"):
        return "https://" + url[len("http://"):]
    if url.startswith("https://"):
        return "http://" + url[len("https://"):]
    return None


def _final_url(resp):
    """URL cuối sau redirect (http/https, đã gọt trailing '/') hoặc ''."""
    final = str(getattr(resp, "url", "") or "").strip()
    if not final.startswith(("http://", "https://")):
        return ""
    return final.rstrip("/")


def _probe(url, timeout, endpoints, min_score, deep=None, graphql_post=True,
           scheme_fallback=True, redirect_probe=True):
    """Probe chi tiết → (url, is_magento, score, evidence). Không bao giờ raise.

    Trang chủ GET qua PageCache (nếu pipeline đã đặt cache); endpoint con không
    cache. `deep` là các endpoint sâu probe khi có tín hiệu mềm (default
    DEEP_ENDPOINTS) — căn chỉnh với contract 4 tham số của các test cũ.

    `graphql_post`: gửi POST /graphql (truy vấn storeConfig) khi tín hiệu còn
    mềm — bắt được store headless/theme tuỳ biến mà GET không lộ dấu hiệu.

    `scheme_fallback`: homepage http:// kết nối lỗi → thử đúng 1 lần https://
    cùng host:port (và ngược lại) trước khi kết luận host chết — bắt site nói
    TLS trên port lạ (8080/8443…) mà trước đây bị mất oan vì luôn probe http.
    `redirect_probe`: homepage 301/302 sang base khác (thư mục con /shop/,
    /magento/, hay ip→www) → probe lại HOMEPAGE + REST/GraphQL ngay tại URL
    cuối — cài Magento trong thư mục con trước đây bị bỏ sót vì chỉ probe gốc.
    """
    if deep is None:
        deep = DEEP_ENDPOINTS
    cache = http.get_page_cache()

    total = 0
    evidence = []

    def visit(path, use_cache=False, method="GET", payload=None):
        """GET có trần byte (hoặc POST JSON) → chấm điểm. Trả response/None."""
        nonlocal total, evidence
        if method == "POST":
            resp = http.post_json(path, payload, timeout=timeout)
        else:
            resp = http.fetch_limited(
                path, timeout=timeout, limit=BODY_LIMIT,
                cache=cache if use_cache else None)
        if resp is None:
            return None
        score, ev = score_response(
            resp.status_code, dict(resp.headers), resp.text[:BODY_LIMIT],
            endpoint=None if path == url else path[len(url):],
        )
        total += score
        evidence.extend(ev)
        return resp

    def is_graphql(path):
        return path.split("?")[0].rstrip("/").endswith("/graphql")

    try:
        resp = visit(url, use_cache=True)
        # FALLBACK SCHEME: homepage không phản hồi gì → thử scheme đối xứng
        # đúng 1 lần trước khi kết luận (chỉ khi homepage chết hẳn — không
        # đốt request cho host đã trả nội dung).
        if resp is None and scheme_fallback:
            alt = _alt_scheme(url)
            if alt:
                resp = visit(alt)
                if resp is not None:
                    url = alt  # probe tiếp các endpoint trên scheme sống
        # RE-PROBE SAU REDIRECT: 301/302 sang base khác → probe lại homepage
        # + REST/GraphQL ngay tại URL cuối (fetch_limited trả resp.url = URL
        # CUỐI sau redirect). Bounded: 1 homepage + 2 endpoint.
        if resp is not None and redirect_probe and total < min_score:
            final = _final_url(resp)
            if final and final != url.rstrip("/"):
                url = final
                visit(url)
                for ep in REDIRECT_REPROBE_ENDPOINTS:
                    if total >= min_score:
                        break
                    visit(url + ep)
        if total >= min_score:
            return url, True, total, evidence
        soft = 0 < total < min_score
        gql_done = False
        for ep in tuple(endpoints) + (tuple(deep) if soft else ()):
            if graphql_post and is_graphql(ep):
                visit(url + ep, method="POST", payload=GRAPHQL_QUERY)
                gql_done = True
            else:
                visit(url + ep)
            if total >= min_score:
                return url, True, total, evidence
        # Trang chủ im lặng hoàn toàn → KHÔNG probe GraphQL (tránh nạp host lạ).
        if soft and graphql_post and not gql_done and total < min_score:
            visit(url + "/graphql", method="POST", payload=GRAPHQL_QUERY)
        return url, total >= min_score, total, evidence
    except requests.RequestException:
        return url, False, total, evidence


def probe(url, timeout, endpoints=DEFAULT_ENDPOINTS, min_score=DEFAULT_MIN_SCORE,
          deep=None):
    """Contract cũ: GET các endpoint; trả về (url, is_magento)."""
    return _probe(url, timeout, endpoints, min_score, deep)[:2]


def _scheme_for(host_port):
    return "https" if host_port.endswith(":443") else "http"


def httpx_detect(live_file, timeout):
    """Dùng httpx -tech-detect nếu binary có sẵn; trả về set URL có Magento.

    runner.run không bao giờ raise: timeout → rc=124, thiếu binary → rc=127.
    Kiểm tra returncode và log rõ khi httpx thất bại — lỗi của tool ngoài
    không được nuốt im lặng (vì kết quả probe vẫn chạy, dễ tưởng là không có
    target nào phát hiện được qua httpx).
    """
    if shutil.which("httpx") is None:
        return set()
    proc = runner.run(
        ["httpx", "-l", live_file, "-tech-detect", "-status-code", "-silent",
         "-no-color", "-timeout", str(timeout)],
        timeout=max(600, timeout * 60),
    )
    if proc.returncode == 124:
        warn(f"[httpx] timeout {max(600, timeout * 60)}s (rc=124) — bị kill, "
             f"chỉ giữ được kết quả một phần")
    elif proc.returncode != 0:
        warn(f"[httpx] exit {proc.returncode}: "
             f"{(proc.stderr or '').strip()[-300:] or '(không có stderr)'}")
    out = set()
    for line in (proc.stdout or "").splitlines():
        parts = line.split()
        if parts and "magento" in line.lower():
            out.add(parts[0].strip())
    return out


def _httpx_enabled(cfg):
    """`fingerprint.httpx_detect` (mặc định true) — tắt để bỏ hẳn tiến trình ngoài."""
    fp = cfg.get("fingerprint") or {}
    return bool(fp.get("httpx_detect", True))


def _graphql_post_from_cfg(cfg):
    """`fingerprint.graphql_post` (mặc định true) — POST /graphql khi tín hiệu mềm."""
    fp = cfg.get("fingerprint") or {}
    return bool(fp.get("graphql_post", True))


def _scheme_fallback_from_cfg(cfg):
    """`fingerprint.scheme_fallback` (mặc định true) — thử scheme đối xứng khi
    homepage chết hẳn (site TLS trên port lạ mà trước đây chỉ probe http)."""
    fp = cfg.get("fingerprint") or {}
    return bool(fp.get("scheme_fallback", True))


def _redirect_probe_from_cfg(cfg):
    """`fingerprint.redirect_probe` (mặc định true) — re-probe tại URL cuối sau
    redirect (cài Magento trong thư mục con / domain thật)."""
    fp = cfg.get("fingerprint") or {}
    return bool(fp.get("redirect_probe", True))


def run(hosts, workdir, global_magento, cfg):
    """hosts: list 'ip:port' → list URL Magento; append vào global_magento.

    `httpx -tech-detect` (nếu bật) chạy SONG SONG với probe nội bộ: trước đây nó
    chạy SAU khi probe xong nên thời gian stage 2a = probe + httpx; giờ chỉ còn
    ≈ max(hai phần). Lỗi httpx không ảnh hưởng kết quả probe.
    """
    timeout = cfg.get("timeout", 15)
    endpoints = _endpoints_from_cfg(cfg)
    min_score = _min_score_from_cfg(cfg)
    deep = _deep_from_cfg(cfg)
    graphql_post = _graphql_post_from_cfg(cfg)
    scheme_fallback = _scheme_fallback_from_cfg(cfg)
    redirect_probe = _redirect_probe_from_cfg(cfg)
    urls = [f"{_scheme_for(h)}://{h}" for h in hosts]
    if not urls:
        info("stage2a: 0 host — bỏ qua")
        return []

    # live.txt phải có TRƯỚC khi httpx_detect chạy → ghi sớm (rẻ, 1 lần/CIDR).
    live_file = os.path.join(workdir, "live.txt")
    file_io.write_lines(live_file, hosts)

    found = set()
    scored = []
    workers = max(1, int(cfg.get("threads", 50)))
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
        httpx_future = pool.submit(httpx_detect, live_file, timeout) \
            if _httpx_enabled(cfg) else None
        futures = [
            pool.submit(_probe, u, timeout, endpoints, min_score, deep,
                        graphql_post, scheme_fallback, redirect_probe)
            for u in urls
        ]
        for future in concurrent.futures.as_completed(futures):
            url, is_magento, score, evidence = future.result()
            scored.append(f"{url} {score} {' '.join(evidence)}".strip())
            if is_magento:
                found.add(url)
        if httpx_future is not None:
            # httpx_detect không raise (runner.run nuốt subprocess + parsing
            # đã phòng IndexError) — lỗi thật vẫn để lộ ra caller.
            url_set = set(urls)
            found |= {u for u in httpx_future.result() if u in url_set}

    found = file_io.dedupe_sort(found)
    # Bộ đếm cộng dồn: target đã kiểm tra là Magento (utils/stats.py)
    stats.add_store(magento=len(found))
    file_io.append_lines(global_magento, found)

    scored_file = os.path.join(workdir, "magento_scored.txt")
    file_io.write_lines(scored_file, file_io.dedupe_sort(scored))
    info(f"stage2a: {len(found)}/{len(urls)} URL là Magento "
         f"(min_score={min_score}, endpoints={','.join(endpoints) or '-'}, "
         f"threads={workers})")
    return found
