#!/usr/bin/env bash
# setup.sh — Cài đặt toàn bộ thư viện & công cụ cho Sofia Scan (Debian/Ubuntu)
# Chạy:        bash setup.sh
# Ép cài lại:  FORCE=1 bash setup.sh   (cài lại binary ProjectDiscovery đã có)

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

log()  { echo -e "\033[1;34m[+]\033[0m $*"; }
ok()   { echo -e "\033[1;32m[OK]\033[0m $*"; }
warn() { echo -e "\033[1;33m[!]\033[0m $*"; }
die()  { echo -e "\033[1;31m[FATAL]\033[0m $*"; exit 1; }

FORCE="${FORCE:-0}"

# ─── 0. sudo / root ──────────────────────────────────────────
# Container chạy bằng root (Docker, Codespaces...) không có sudo → chạy trực
# tiếp; có sudo thì bọc sudo; thiếu cả hai → cảnh báo và thử trực tiếp.
if [ "$(id -u)" -eq 0 ]; then
    SUDO=""
elif command -v sudo >/dev/null 2>&1; then
    SUDO="sudo"
else
    warn "Không có sudo và không chạy dưới root — lệnh hệ thống có thể thất bại"
    SUDO=""
fi

as_root() {
    if [ -n "$SUDO" ]; then $SUDO "$@"; else "$@"; fi
}

# ─── 1. Hệ thống ─────────────────────────────────────────────
log "Cập nhật apt cache..."
as_root apt-get update -qq

log "Cài package hệ thống: python3/pip3, masscan, zmap, bind9-dnsutils (dig), openssl, curl, git, unzip, build-essential, lsb-release..."
as_root apt-get install -y -qq python3 python3-pip python3-venv python3-dev \
    masscan zmap bind9-dnsutils openssl curl git unzip build-essential \
    libpcap0.8 libpcap-dev lsb-release ca-certificates

# ─── Zmap (engine stage 1 — thay thế masscan) ──────────────────────
# Đã thử cài chung ở trên; nếu repo không có zmap (vd. distro lạ),
# thử cài riêng rồi kiểm tra lại:
if ! command -v zmap >/dev/null 2>&1; then
    log "zmap chưa có — thử cài riêng..."
    as_root apt-get install -y -qq zmap \
        || warn "Không cài được zmap qua apt — scanner sẽ tự dùng masscan (engine auto)"
fi
if command -v zmap >/dev/null 2>&1; then
    ok "zmap: $(command -v zmap)"
else
    warn "zmap THIẾU — stage 1 sẽ fallback về masscan (scanner.engine: auto)"
fi
if command -v masscan >/dev/null 2>&1; then
    ok "masscan: $(command -v masscan)"
else
    warn "masscan THIẾU — engine auto sẽ dùng zmap; không có cả hai thì stage 1 không chạy"
fi

# NodeJS + npx: NodeSource nodejs đã chứa sẵn npm+npx, cài thêm gói 'npm'
# của Ubuntu sẽ xung đột → thử cả hai, lỗi thì chỉ cài nodejs.
if command -v node >/dev/null 2>&1 && command -v npx >/dev/null 2>&1; then
    ok "NodeJS đã có: $(node -v) (npx: $(command -v npx))"
else
    log "Cài NodeJS + npm (npx)..."
    as_root apt-get install -y -qq nodejs npm || as_root apt-get install -y -qq nodejs
fi

# ─── 2. Python libraries ─────────────────────────────────────
# Chọn cách gọi pip: pip3, hoặc 'python3 -m pip' nếu pip3 không có trên PATH
PIP_CMD="pip3"
if ! command -v pip3 >/dev/null 2>&1; then
    if python3 -m pip --version >/dev/null 2>&1; then
        PIP_CMD="python3 -m pip"
        warn "pip3 không có trên PATH — dùng '$PIP_CMD' thay thế"
    else
        log "pip3 chưa có — cài python3-pip qua apt..."
        as_root apt-get install -y -qq python3-pip || warn "Không cài được python3-pip qua apt"
        PIP_CMD="pip3"
    fi
fi

# Fallback --break-system-packages cho Ubuntu/Debian mới (PEP 668).
# KHÔNG nuốt stderr — khi thất bại in 15 dòng cuối của lỗi gốc ra log
# (trước đây 2>/dev/null khiến lỗi thật bị ẩn, chỉ còn dòng warn chung).
pip_install() {
    local errlog
    errlog="$(mktemp /tmp/sofia_pip_err.XXXXXX)"
    # 1) pip user hiện tại (không cần sudo — tránh lỗi 'sudo: pip3: command not found'
    #    khi pip được cài ở ~/.local/bin hay conda không nằm trong PATH của root)
    if $PIP_CMD install "$@" >"$errlog" 2>&1; then rm -f "$errlog"; return 0; fi
    # 2) sudo pip (system-wide)
    if [ -n "$SUDO" ] && $SUDO $PIP_CMD install "$@" >>"$errlog" 2>&1; then rm -f "$errlog"; return 0; fi
    # 3) sudo pip --break-system-packages (PEP 668)
    if [ -n "$SUDO" ] && $SUDO $PIP_CMD install --break-system-packages "$@" >>"$errlog" 2>&1; then rm -f "$errlog"; return 0; fi
    # 4) pip --user --break-system-packages (không có sudo, distro chặn install global)
    if $PIP_CMD install --user --break-system-packages "$@" >>"$errlog" 2>&1; then rm -f "$errlog"; return 0; fi
    warn "pip3 install thất bại: $*"
    warn "Chi tiết lỗi (15 dòng cuối):"
    tail -n 15 "$errlog" | sed 's/^/    /' >&2
    rm -f "$errlog"
    return 1
}
log "Cài Python dependencies (requirements.txt): requests, pyyaml, rich, sh, pytricia..."
pip_install -r requirements.txt

# Deps riêng của SofiaTool (sofia/requirements.txt): requests, urllib3, httpx
if [ -f sofia/requirements.txt ]; then
    log "Cài Python dependencies cho SofiaTool (sofia/requirements.txt)..."
    pip_install -r sofia/requirements.txt
else
    warn "Không thấy sofia/requirements.txt — cài trực tiếp requests/urllib3/httpx..."
    pip_install requests urllib3 httpx
fi

# pytest chỉ cần cho tests — thiếu không chặn pipeline
if ! python3 -c "import pytest" >/dev/null 2>&1; then
    log "Cài pytest (cho tests)..."
    pip_install pytest || warn "pytest chưa cài được — chỉ ảnh hưởng khi chạy tests/"
fi

# ─── 3. Công cụ ProjectDiscovery: httpx & nuclei (GitHub Releases) ───
# Tải binary prebuilt từ GitHub Releases — không cần Go.
PD_BIN_DIR="/usr/local/bin"
# Pin nuclei — chỉ dùng khi không lấy được tag mới nhất từ GitHub API.
# Nâng cấp: đổi biến này rồi chạy lại setup.sh (engine cve.nuclei.update_templates
# tự kéo templates mới mỗi lần chạy pipeline).
NUCLEI_VERSION="v3.11.1"
case "$(uname -m)" in
    x86_64)  PD_ARCH="amd64" ;;
    aarch64) PD_ARCH="arm64" ;;
    *)       warn "Kiến trúc không hỗ trợ: $(uname -m)"; exit 1 ;;
esac

pd_latest_tag() {
    curl -fsSL "https://api.github.com/repos/projectdiscovery/$1/releases/latest" \
        | grep -oP '"tag_name":\s*"\K[^"]+' | head -n1
}

pd_install() {
    local repo="$1" bin="$2" ver_fallback="$3" tag ver url
    if [ "$FORCE" != "1" ] && command -v "$bin" >/dev/null 2>&1; then
        ok "$bin đã có: $(command -v "$bin") (FORCE=1 để cài lại bản mới)"
        return 0
    fi
    tag="$(pd_latest_tag "$repo" || true)"
    [ -n "$tag" ] || { warn "Không lấy được bản mới nhất của $bin từ GitHub API — dùng bản ${ver_fallback}"; tag="$ver_fallback"; }
    ver="${tag#v}"
    url="https://github.com/projectdiscovery/${repo}/releases/download/${tag}/${bin}_${ver}_linux_${PD_ARCH}.zip"
    log "Cài $bin ${tag} từ GitHub Releases..."
    curl -fsSL -o "/tmp/${bin}.zip" "$url"
    as_root unzip -o -j "/tmp/${bin}.zip" "$bin" -d "/tmp/${bin}_pd"
    as_root mv "/tmp/${bin}_pd/$bin" "$PD_BIN_DIR/$bin"
    as_root chmod +x "$PD_BIN_DIR/$bin"
    rm -rf "/tmp/${bin}.zip" "/tmp/${bin}_pd"
    ok "$bin ${tag} đã cài ($("$bin" -version 2>&1 | grep -i 'version' | tail -1))"
}

pd_install "httpx"  "httpx"  "v1.11.0"
pd_install "nuclei" "nuclei" "$NUCLEI_VERSION"

# ─── 4. Nuclei templates ─────────────────────────────────────
# Tải bộ template cộng đồng (http/cves/<năm>/CVE-*.yaml) — engine
# (core/nuclei_engine.py) DÒ template theo từng CVE trong thư mục này
# (cve.nuclei.auto_discovery) và có thể tự cập nhật lại mỗi lần quét khi bật
# cve.nuclei.update_templates=true (nuclei -update-templates, 1 lần mỗi tiến trình).
log "Cập nhật nuclei templates..."
nuclei -update-templates -silent 2>/dev/null || warn "Không tải được templates, nuclei sẽ tự tải khi chạy lần đầu"
if [ -d "$HOME/nuclei-templates/http/cves" ]; then
    N_TPL=$(find "$HOME/nuclei-templates/http/cves" -name '*.yaml' 2>/dev/null | wc -l)
    ok "nuclei templates: $N_TPL file CVE trong ~/nuclei-templates/http/cves"
else
    warn "Chưa thấy ~/nuclei-templates/http/cves — kiểm tra lại bằng: nuclei -update-templates"
fi

# ─── 4b. Kiểm duyệt template LOCAL trong cves/ ────────────────
# Template local là tài nguyên quan trọng (scanner chạy qua -t theo tên file
# CVE-ID) — validate bằng nuclei TRƯỚC khi dùng; file hỏng bị cảnh báo ngay
# lúc setup thay vì bị bỏ qua âm thầm giữa lượt quét.
if command -v nuclei >/dev/null 2>&1; then
    log "Kiểm duyệt template local cves/CVE-*.yaml bằng nuclei -validate..."
    TPL_BAD=0
    for f in cves/CVE-*.yaml; do
        [ -f "$f" ] || continue
        # version_map/*.community.yaml không phải template — chỉ validate CVE-*.yaml đúng tên
        out="$(nuclei -validate -t "$f" 2>&1 | grep -E 'FTL|ERR' | head -2 || true)"
        if [ -n "$out" ]; then
            warn "template $f KHÔNG hợp lệ: $out"
            TPL_BAD=$((TPL_BAD + 1))
        fi
    done
    if [ "$TPL_BAD" -eq 0 ]; then
        ok "Tất cả template local trong cves/ hợp lệ"
    else
        warn "$TPL_BAD template local lỗi — scanner sẽ BỎ QUA chúng lúc quét (xem log phía trên)"
    fi
fi

# ─── 4c. Thư mục/tài nguyên dự án ─────────────────────────────
# output/ là paths.output_dir mặc định trong config (rir_cache, live.txt...).
mkdir -p output
[ -f config/config.yaml ] || warn "Thiếu config/config.yaml — chạy pipeline sẽ không có cấu hình"
[ -f config/exclude.txt ] || warn "Thiếu config/exclude.txt — masscan/zmap không loại trừ được dải nhạy cảm"

# ─── 5. Cloudflare Tunnel (cloudflared) ──────────────────────
# Dùng cho quick tunnel (webhook/tunnel URL). Tải binary prebuilt từ GitHub
# Releases; nếu thất bại thì fallback sang apt repo chính thức pkg.cloudflare.com.
if command -v cloudflared >/dev/null 2>&1; then
    ok "cloudflared đã có: $(cloudflared --version 2>&1 | head -1)"
else
    log "Cài cloudflared (Cloudflare Tunnel)..."
    case "$(uname -m)" in
        x86_64|amd64)  CF_ARCH="amd64" ;;
        aarch64|arm64) CF_ARCH="arm64" ;;
        *)             CF_ARCH="" ; warn "Kiến trúc không hỗ trợ: $(uname -m) — thử apt repo" ;;
    esac
    CF_OK=0
    if [ -n "$CF_ARCH" ]; then
        CF_URL="https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-${CF_ARCH}"
        CF_TMP="$(mktemp)"
        log "Tải cloudflared: ${CF_URL}"
        if curl -fsSL --retry 3 -o "$CF_TMP" "$CF_URL" && [ -s "$CF_TMP" ]; then
            chmod +x "$CF_TMP"
            if as_root install -m 0755 "$CF_TMP" /usr/local/bin/cloudflared; then
                CF_OK=1
            elif mkdir -p "$HOME/.local/bin" \
                 && install -m 0755 "$CF_TMP" "$HOME/.local/bin/cloudflared"; then
                export PATH="$HOME/.local/bin:$PATH"
                CF_OK=1
            fi
        else
            warn "Tải binary cloudflared thất bại — thử apt repo pkg.cloudflare.com"
        fi
        rm -f "$CF_TMP"
    fi
    if [ "$CF_OK" -eq 1 ]; then
        ok "cloudflared đã cài: $(cloudflared --version 2>&1 | head -1)"
    else
        # apt repo chính thức của Cloudflare
        log "Cài cloudflared qua apt repo: pkg.cloudflare.com..."
        as_root mkdir -p --mode=0755 /usr/share/keyrings
        curl -fsSL https://pkg.cloudflare.com/cloudflare-main.gpg \
            | as_root tee /usr/share/keyrings/cloudflare-main.gpg >/dev/null \
            || warn "Không lấy được khoá Cloudflare GPG"
        echo "deb [signed-by=/usr/share/keyrings/cloudflare-main.gpg] https://pkg.cloudflare.com/cloudflared $(lsb_release -cs 2>/dev/null || echo any) main" \
            | as_root tee /etc/apt/sources.list.d/cloudflared.list >/dev/null
        if as_root apt-get update -qq \
           && as_root apt-get install -y -qq cloudflared; then
            ok "cloudflared đã cài (apt): $(cloudflared --version 2>&1 | head -1)"
        else
            warn "cloudflared CHƯA cài được — tunnel Cloudflare sẽ không khả dụng"
        fi
    fi
fi

# ─── 6. Webhook.site CLI (whcli) ─────────────────────────────
# Tunnel ƯU TIÊN của SofiaTool (tunnel auto → webhook.site trước, cloudflare
# dự phòng) — xem sofia/core/tunnel.py: `whcli forward --token=... --target=...`.
# Cài qua npm global (NodeJS/npm đã cài ở phần trên). Free user không cần API
# key; tài khoản trả phí set env WEBHOOKSITE_API_KEY khi chạy.
export PATH="$HOME/.local/bin:$PATH"
if command -v whcli >/dev/null 2>&1; then
    ok "whcli đã có: $(command -v whcli)"
else
    if ! command -v npm >/dev/null 2>&1; then
        warn "npm không có — không cài được whcli (tunnel webhook.site sẽ không khả dụng)"
    else
        log "Cài whcli (@webhooksite/cli) qua npm global..."
        if as_root npm install -g --no-audit --no-fund @webhooksite/cli \
           || npm install -g --no-audit --no-fund @webhooksite/cli; then
            ok "whcli đã cài: $(command -v whcli || echo 'không thấy trong PATH — kiểm tra npm prefix')"
        else
            # npm global bị khoá (EACCES/prefix không ghi được) → cài vào ~/.local
            log "npm global thất bại — thử cài whcli vào ~/.local..."
            NPM_USER_PREFIX="$HOME/.local"
            mkdir -p "$NPM_USER_PREFIX"
            if npm install -g --prefix "$NPM_USER_PREFIX" --no-audit --no-fund @webhooksite/cli; then
                export PATH="$NPM_USER_PREFIX/bin:$PATH"
                ok "whcli đã cài (user): $(command -v whcli || echo "$NPM_USER_PREFIX/bin/whcli")"
                warn "Lưu ý: thêm '$NPM_USER_PREFIX/bin' vào PATH khi chạy sofia.py, hoặc set WHCLI_BIN"
            else
                warn "whcli CHƯA cài được — tunnel webhook.site không khả dụng (cloudflared dự phòng)"
            fi
        fi
    fi
fi

# ─── 7. Kiểm tra tổng hợp ────────────────────────────────────
echo ""
log "Kiểm tra tất cả công cụ cần thiết:"
MISSING=0
for b in python3 pip3 node npx masscan zmap httpx nuclei cloudflared whcli dig openssl curl git; do
    if command -v "$b" >/dev/null 2>&1; then
        ok "$b: $(command -v "$b")"
    else
        warn "$b: THIẾU"
        MISSING=1
    fi
done
for m in requests yaml rich sh pytricia httpx urllib3; do
    if python3 -c "import $m" >/dev/null 2>&1; then
        ok "python module '$m': OK"
    else
        warn "python module '$m': THIẾU"
        MISSING=1
    fi
done
# pytest chỉ dùng cho tests — thiếu chỉ cảnh báo, không tính là thiếu pipeline
if python3 -c "import pytest" >/dev/null 2>&1; then
    ok "python module 'pytest': OK"
else
    warn "python module 'pytest': THIẾU (chỉ cần cho tests/)"
fi

echo ""
if [ "$MISSING" -eq 0 ]; then
    ok "✅ Đầy đủ! Chạy: sudo python3 main.py --countries SG"
else
    warn "⚠ Một số thành phần còn thiếu — xem log phía trên"
    exit 1
fi
