"""Tự sinh dải IPv4 để quét stage 1 — thay vì lấy CIDR từ RIR.

Bật bằng `scanner.generate_ipv4.enabled: true` hoặc CLI `--generate-ipv4`.
Các chunk sinh ra được đẩy vào pipeline như CIDR bình thường (webhook +
resume theo từng chunk) và quét đúng `scanner.ports` (mặc định 80,443,8080).

─── V5: SINH CHUNK KÍCH THƯỚC NGẪU NHIÊN (thông minh hơn) ────────────────
Trước đây chunk luôn cố định /N (`split_to`) → 0.0.0.0/0 ra đúng 65.536
chunk /16, kích thước đều đặn máy móc. V5 chia ĐỆ QUY theo kiểu ngẫu nhiên:
mỗi dải đang chờ chia được chọn 1 prefix ngẫu nhiên trong khoảng
[`prefix_min`, `prefix_max`] (nghiêng theo `size_bias`) rồi tách thành các
subnet /p — mỗi subnet tiếp tục được rút thăm chia tiếp hay giữ nguyên.

Kết quả: các chunk LỚN NHẤT đúng giới hạn /`prefix_min` (mặc định /16 —
không bao giờ có chunk to hơn /16), nhỏ nhất tới /`prefix_max` (mặc định
/20), kích thước TRỘN LẪN NGẪU NHIÊN giữa các chunk:
  - Mẫu quét không đều đặn → khó bị nhận diện là scanner theo kích thước.
  - Dải nhỏ quét nhanh xong → pipeline chuyển sang chunk kế sớm hơn,
    kết hợp `scanner.politeness.adaptive` (nghỉ ngắn hơn cho dải nhỏ)
    → tăng thông lượng tổng mà không tăng lưu lượng đỉnh.

Các lựa chọn (block `scanner.generate_ipv4`):
  - cidr         : dải gốc, mặc định "0.0.0.0/0" (toàn bộ IPv4)
  - random_sizes : true (V5 mặc định) = kích thước chunk ngẫu nhiên;
                   false = chế độ cũ — chia đều `split_to`
  - split_to     : (chế độ cũ) chia thành chunk /N cố định — mặc định 16
  - prefix_min   : prefix NHỎ NHẤT được rút thăm = chunk LỚN NHẤT /prefix_min
                   (mặc định 16 → chunk to nhất là /16)
  - prefix_max   : prefix LỚN NHẤT được rút thăm = chunk NHỎ NHẤT /prefix_max
                   (mặc định 20). Lưu ý: dải gốc đã nhỏ hơn /prefix_min hoặc
                   prefix ở giữa khoảng vẫn được giữ nguyên (chỉ giới hạn
                   KÍCH THƯỚC TỐI ĐA của chunk, không ghép dải nhỏ lại).
  - size_bias    : 0.0 = nghi về chunk LỚN (gần /prefix_min); 1.0 = nghi về
                   chunk NHỎ (gần /prefix_max); 0.5 = đều (mặc định)
  - shuffle      : xáo thứ tự chunk (mặc định true) — tránh quét cụm 1 vùng
  - seed         : 0 = ngẫu nhiên mỗi lần; >0 = tái lập toàn bộ (kích thước
                   + thứ tự xáo)
  - max_chunks   : 0 = tất cả; >0 = giới hạn số chunk (test/chạy thử)
Lọc `paths.exclude` (gov/mil...) giống RIR — dùng chung ExcludeIndex.
"""
import ipaddress
import random

from utils import file_io, rir
from utils.logger import info

DEFAULT_GENERATE = {
    "cidr": "0.0.0.0/0",
    "split_to": 16,      # chế độ cũ (random_sizes=false) — chunk /N cố định
    "random_sizes": True,  # V5: kích thước chunk NGẪU NHIÊN (tối đa /prefix_min)
    "prefix_min": 16,    # chunk LỚN NHẤT /16 (prefix nhỏ nhất được rút thăm)
    "prefix_max": 20,    # chunk NHỎ NHẤT /20 (prefix lớn nhất được rút thăm)
    "size_bias": 0.5,    # 0 = nghi chunk lớn, 1 = nghi chunk nhỏ, 0.5 = đều
    "seed": 0,           # 0 = ngẫu nhiên; >0 = tái lập kích thước + thứ tự xáo
    "shuffle": True,
    "max_chunks": 0,     # 0 = tất cả
}


def gen_config(cfg):
    """Chuẩn hóa block `scanner.generate_ipv4` (điền default + hợp lệ hóa)."""
    gen = dict(DEFAULT_GENERATE)
    gen.update(cfg.get("scanner", {}).get("generate_ipv4") or {})
    gen["random_sizes"] = bool(gen.get("random_sizes"))
    if gen["random_sizes"]:
        lo = int(gen.get("prefix_min") or 16)
        hi = int(gen.get("prefix_max") or lo)
        if lo > hi:
            lo, hi = hi, lo  # người dùng khai ngược — tự hoán đổi
        lo = max(1, min(32, lo))
        hi = max(1, min(32, hi))
        gen["prefix_min"], gen["prefix_max"] = lo, hi
        bias = float(gen.get("size_bias") or 0.0)
        gen["size_bias"] = max(0.0, min(1.0, bias))
    return gen


def _pick_prefix(lo, hi, bias, rng):
    """Rút thăm prefix p trong [lo, hi] theo `size_bias`.

    Trọng số tuyến tính: bias → 0 nghi về p nhỏ (chunk LỚN), bias → 1 nghi
    về p lớn (chunk NHỎ), 0.5 = đều. Trả int p.
    """
    if hi <= lo:
        return lo
    weights = [(hi - p + 1) * (1.0 - bias) + (p - lo + 1) * bias
               for p in range(lo, hi + 1)]
    return rng.choices(range(lo, hi + 1), weights=weights, k=1)[0]


def _split_variable(net, gen, rng):
    """Chia `net` ĐỆ QUY thành các chunk kích thước NGẪU NHIÊN.

    Mỗi dải chưa đạt mức "chunk lớn nhất cho phép" (prefixlen < prefix_min)
    được rút thăm 1 prefix trong [prefixlen+1, prefix_max] rồi tách thành các
    subnet /p; subnet nào còn lớn hơn /prefix_min thì tiếp tục được rút thăm.
    Dải đã ≤ /prefix_min (hoặc đã nhỏ hơn cả mức chia nhỏ nhất) giữ nguyên.

    Trả list ip_network các lá (chunk cuối).
    """
    prefix_min = int(gen["prefix_min"])   # chunk LỚN NHẤT /prefix_min
    prefix_max = int(gen["prefix_max"])   # mức chia nhỏ nhất được rút thăm
    bias = float(gen.get("size_bias") or 0.0)
    leaves = []
    stack = [net]
    while stack:
        cur = stack.pop()
        if cur.prefixlen >= prefix_min:
            # Đã ≤ /prefix_min (chunk tối đa cho phép) — giữ nguyên làm chunk.
            leaves.append(cur)
            continue
        lo = cur.prefixlen + 1  # không thể chọn prefix nhỏ hơn mức này
        hi = max(prefix_max, lo)
        p = _pick_prefix(lo, hi, bias, rng)
        stack.extend(cur.subnets(new_prefix=p))
    return leaves


def _split_fixed(net, gen):
    """Chế độ cũ: chia ĐỀU thành chunk /split_to (tương thích ngược)."""
    split_to = int(gen["split_to"])
    if split_to < net.prefixlen:
        split_to = net.prefixlen  # không chia nhỏ hơn dải gốc
    try:
        return list(net.subnets(new_prefix=split_to)), split_to
    except ValueError:
        return [net], net.prefixlen


def generate_chunks(cfg):
    """Sinh list CIDR str sau lọc exclude + giới hạn max_chunks."""
    gen = gen_config(cfg)
    try:
        net = ipaddress.ip_network(gen["cidr"], strict=False)
    except ValueError as exc:
        raise ValueError(f"generate_ipv4.cidr không hợp lệ: {gen['cidr']} ({exc})")

    rng = random.Random(int(gen.get("seed") or 0) or None)
    if gen["random_sizes"]:
        subnets = _split_variable(net, gen, rng)
        p_lo = min(s.prefixlen for s in subnets)
        p_hi = max(s.prefixlen for s in subnets)
        desc = (f"{len(subnets)} chunk ngẫu nhiên "
                f"/{p_lo}–/{p_hi} (tối đa /{gen['prefix_min']}, "
                f"size_bias={gen['size_bias']})")
    else:
        subnets, split_to = _split_fixed(net, gen)
        desc = f"{len(subnets)} chunk /{split_to}"

    exclude_index = rir.ExcludeIndex(cfg["paths"].get("exclude"))
    chunks = [str(s) for s in subnets if not exclude_index.contains(s)]

    if gen.get("shuffle", True):
        rng.shuffle(chunks)

    max_chunks = int(gen.get("max_chunks") or 0)
    if max_chunks > 0:
        chunks = chunks[:max_chunks]

    info(f"[ipgen] {net} → {desc}; "
         f"sau lọc exclude: {len(chunks)}"
         + (f" (giới hạn {max_chunks})" if max_chunks else ""))
    return chunks


def build_targets(cfg):
    """Ghi targets.txt (CIDR|GEN|IP4) từ generate_chunks; trả (số, generator)."""
    chunks = generate_chunks(cfg)
    targets_path = cfg["paths"]["targets"]
    file_io.write_lines(targets_path, [f"{c}|GEN|IP4" for c in chunks])
    return len(chunks), rir.read_targets(targets_path)