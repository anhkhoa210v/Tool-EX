# Sofia Scan

QuétMagento hàng loạt theo dải IP tự sinh từ **5 RIR** (APNIC, RIPE, ARIN, LACNIC, AFRINIC),
chạy nhiều stage theo từng CIDR, **lọc ra cửa hàng thật** rồi quét CVE và thông báo
qua **webhook** (Discord/Slack).

```
main.py ─▶ utils/rir.py ─▶ targets.txt (CIDR|rir|quốc_gia)
        └▶ config/targets_extra.txt  hotspot CIDR ưu tiên quét TRƯỚC RIR
        └▶ core/pipeline.py — với MỖI CIDR:
             webhook "🔎 Đang Quét <CIDR> (<quốc gia>)"
             STAGE 1  scanner.py      masscan|-iL|-p80,443,8080|-oL  → output/live.txt
             (engine stage 1: masscan | zmap | auto — xem `scanner.engine`)
             CIDR lớn chia chunk /16, resume từng chunk, retry/backoff,
             politeness giữa các CIDR (pipeline) — xem `scanner.*` bên dưới
             STAGE 2a fingerprint.py  probe đa endpoint + điểm tin cậy → output/magento.txt
                 /rest/V1/ /graphql /static/version/ /magento_version (+httpx tech-detect)
                 ngưỡng fingerprint.min_score (mặc định 3), debug ra work/<slug>/magento_scored.txt
             STAGE 2a-woo woo_fingerprint.py  phát hiện WordPress/WooCommerce
                 probe /wp-login.php /wp-json/ /wp-json/wc/store/v1/products
                 /readme.html /cart/ /shop/ → output/wordpress.txt + output/woocommerce.txt
                 ngưỡng woocommerce.min_score (mặc định 3), debug work/<slug>/woo_scored.txt
             STAGE 2b/3-woo woo_versioning.py → woo_cve_scan.py
                 dò version TỪNG PLUGIN (asset ?ver=… / readme.txt) → khớp
                 cves/woo_version_map.yaml (OFFLINE) + nuclei local
                 (cves/<CVE>.yaml — woocommerce.cves) + cộng đồng
                 (woocommerce.community_ids) → gộp output/vuln_version.txt (dòng
                 [version]) / output/vuln.txt (nuclei) / vul.txt
             STAGE 2c store_detect.py  probe storefront → chỉ giữ "cửa hàng THẬT"
                 trang chủ marker bán hàng / /checkout/cart/ /customer/account/login/
                 retry lỗi mạng + jitter + threads riêng + đếm lý do loại
                 → output/stores.txt (global) + work/<slug>/stores_scored.txt
                   + work/<slug>/stores_reasons.txt (bảng đếm — điều chỉnh ngưỡng)
                 ngưỡng store_detect.min_score (mặc định 3)
             STAGE 2b versioning.py   /magento_version → /static/version/ JSON → magento_versions.txt
                 — chỉ chạy trên các URL là CỬA HÀNG THẬT (output của 2c)
             STAGE 3  cve_scan.py     offline version→CVE (cves/version_map.yaml,
                                      ranges + eol_older_than) — luôn chạy
                                      + nuclei (bật tắt qua cve.nuclei.enabled):
                                      template local (-t, id khớp tên file) +
                                      community (-id, trừ CVE đã chạy local)
                                      → output/vuln.txt (chỉ findings nuclei)
             STAGE 4  resolver.py     dig PTR + openssl SAN/CN → output/t.txt
                 (t.txt = domain cửa hàng THẬT — loại maintenance/coming-soon/blog);
                 cùng bộ hàm phân giải này (to_domain_url) tự rewrite URL
                 "https://ip:port" trong vuln.txt/vuln_version.txt sang domain —
                 không phân giải được thì giữ nguyên IP
             finally: webhook "✅ Đã Ghi Vào File t.txt <N> domain — dải ... hoàn tất"

        Ngoài ra: upload_live.py — daemon upload output/t.txt + output/vul.txt
        lên GoFile định kỳ (khi số dòng đổi + đủ `upload.interval`) và gửi link
        về webhook — MỖI FILE 1 TIN NHẮN kèm tên file + `upload.title` (tên scan)
        (mở trong main.py, xem cấu hình `upload`).
        Cleanup tự động: `cleanup` — sofia.log + backups > `log_total_mb` → tự xoá,
        output/live.txt > `live_txt_max_mb` → giữ chỉ `live_txt_keep_lines` dòng cuối.
```

## Cài đặt

```bash
pip install -r requirements.txt
pip install pytest          # chỉ để chạy tests

# binary ngoài (nếu thiếu):
#   masscan, zmap, httpx (projectdiscovery), nuclei (projectdiscovery), dig (bind9-dnsutils), openssl
sudo apt install masscan zmap bind9-dnsutils openssl
```

## Sử dụng

```bash
# Sinh targets.txt từ tất cả RIR, lọc exclude, rồi quét toàn bộ
sudo python3 main.py

# Chỉ sinh targets.txt (lọc Việt Nam + Thái Lan) rồi thoát
python3 main.py --countries VN,TH --targets-only

# Ghi đè rate/thread, tắt resume
sudo python3 main.py --rate 20000 --threads 100 --no-resume

# Bắt buộc dùng zmap cho stage 1 (mặc định auto: masscan nếu có, ngược lại zmap)
sudo python3 main.py --countries SG --engine zmap

# Tự sinh IPv4 — quét toàn bộ internet bằng zmap (80/443/8080), không cần RIR
sudo python3 main.py --generate-ipv4 --engine zmap
# Thử nhanh: chỉ 2 chunk /24 trong 1.0.0.0/8, không quét thật
python3 main.py --generate-ipv4 --gen-cidr 1.0.0.0/8 --split-to 24 --max-chunks 2 --targets-only
```

> `masscan` cần quyền root (`sudo`). Stage fingerprint/versioning chạy bằng Python threads.

## Vòng lặp quét ↔ khai thác (exploit hook — NÂNG CẤP)

Bản này đã COPY framework khai thác `sofia/` vào trong `sofia_scan/sofia/` và nối
thành vòng lặp TỰ ĐỘNG (xem `core/exploit_runner.py`):

```
batch CIDR n  →  stage 1-4 quét (append output/vuln.txt + output/vuln_version.txt)
              →  sofia/sofia.py -t output/vuln.txt        (ĐỢI chạy xong)
              →  sofia/sofia.py -t output/vuln_version.txt (rồi mới tới file kế)
              →  batch CIDR n+1 → ... (lặp lại tới hết targets)
```

* `vuln.txt` (findings nuclei) và `vuln_version.txt` (findings khớp version, dòng
  `[version]`) chứa "dòng ghim CVE" đúng định dạng PHA 1 của sofia.py nhận diện
  (`discovery/target_line.py`) → sofia chọn LUÔN CVE ghi trong từng dòng thay vì dò lại.
* URL trong cả hai file đã ở dạng DOMAIN (rewrite tự động từ "https://ip:port" qua
  PTR + TLS SAN — `core/resolver.to_domain_url`); IP chỉ giữ lại khi không phân giải được.
* sofia.py tự bỏ qua target đã khai thác qua sổ `ran_target.json` (`--skip-ran` bật
  mặc định) → nạp lại cả file mỗi batch KHÔNG khai thác lại target cũ.
* Chỉ khởi động sofia.py trên file có dòng MỚI kể từ lần chạy thành công gần nhất của
  CHÍNH FILE đó (mốc RIÊNG từng file, lưu `output/exploit_state.json`); chạy
  THẤT BẠI/timeout → giữ mốc file đó, batch kế nạp lại phần chưa xong.
* stdout/stderr của sofia.py: `output/sofia_exploit.log`; bật/tắt bằng `exploit.enabled`.
* Webhook nhận tin "⚔️ exploit — bắt đầu" / "✅ xong" / "⚠️ thoát rc≠0" mỗi lượt.

Cấu hình (khối `exploit:` trong `config/config.yaml`):

```yaml
exploit:
  enabled: true                 # false = tắt hook, chạy như bản cũ (chỉ quét)
  script: sofia/sofia.py        # tương đối với thư mục sofia_scan
  targets_file:                 # list file (tương đối với output_dir) — chạy LẦN LƯỢT;
    - vuln.txt                  # vẫn chấp nhận dạng string cũ (1 file) của config trước
    - vuln_version.txt
  args: []                      # tham số thêm cho sofia.py, vd: ["--threads", "10"]
  timeout: 0                    # giây chờ tối đa mỗi lần chạy (0 = không giới hạn)
  min_new_lines: 1              # chỉ chạy khi có ≥ N dòng MỚI (0 = luôn chạy mỗi batch)
  log_file: sofia_exploit.log   # tương đối output_dir — nơi ghi output sofia.py
```

## Cấu hình — `config/config.yaml`

| Khóa | Ý nghĩa |
|---|---|
| `scanner.engine` | engine stage 1: `masscan` / `zmap` / `auto` (auto = masscan nếu có, ngược lại zmap) |
| `scanner.ports` | danh sách cổng quét, ví dụ `80,443,8080` |
| `scanner.masscan.rate` / `.wait` | tốc độ masscan (gói/giây) / giây chờ sau khi quét |
| `scanner.masscan.seed` | seed cố định `--seed` cho masscan (0 = ngẫu nhiên — tái lập để so sánh) |
| `scanner.masscan.source_port` / `.source_ip` / `.interface` | source port / IP nguồn / giao diện `-e` (đổi nguồn khi bị chặn) |
| `scanner.chunk_max_hosts` | host tối đa mỗi chunk khi CIDR lớn (mặc định 262144 = /16) — quyết định prefix mặc định |
| `scanner.chunk_prefix` | prefix mỗi chunk (0 = tự suy từ `chunk_max_hosts`, floor /16; >0 = cố định) |
| `scanner.retries` / `.retry_backoff_base` | thử lại engine khi 1 chunk lỗi, ngủ `base*2^(n-1)` + jitter giữa các lần thử |
| `scanner.retry_rate_scale` | khi retry (lần n>1), nhân rate với `scale^(n-1)` (mặc định 0.5) — bị throttle thì lùi tốc độ |
| `scanner.parallel_ports` | `true` (mặc định) = chạy SONG SONG 1 tiến trình zmap mỗi cổng, rate tổng chia đều — nhanh gấp n lần, tổng pps không đổi |
| `scanner.warmup_chunks` / `.warmup_start_frac` | khởi động mềm: n chunk đầu chạy `frac` rate rồi tăng dần lên 100% (mặc định 2 chunk, 50%) — tránh spew tốc độ tối đa ngay từ đầu |
| `scanner.max_scan_seconds` | 0 = chặn mềm 3600s/lần engine; >0 = truyền `--max-time` cho masscan + timeout runner |
| `scanner.chunk_sleep_min` / `.chunk_sleep_max` | politeness giữa các CHUNK cùng CIDR (0/0 = tắt) |
| `scanner.politeness.sleep_min` / `.sleep_max` | pipeline ngủ ngẫu nhiên GIỮA các CIDR (0/0 = tắt) — chống block nguồn quét |
| `scanner.zmap.rate` / `.bandwidth` | tốc độ zmap (gói/giây) / bandwidth ví dụ `100M` (ghi đè rate) |
| `scanner.zmap.cooldown` | giây chờ gói trả về sau khi zmap scan xong |
| `scanner.zmap.seed` | seed ngẫu nhiên hóa thứ tự quét (0 = ngẫu nhiên) |
| `scanner.zmap.source_port` | source port (ví dụ `40000` hoặc `40000-41000`); khi quét song song, dải được CHIA RỜI RẠCH cho từng instance / dịch offset nếu là port đơn |
| `scanner.zmap.source_port_range` | dải port nguồn xoay THEO TỪNG GÓI, vd `40000-60000` (mặc định) — mỗi instance nhận 1 dải con riêng; cần zmap hỗ trợ `--source-port=port|range` (tự detect) |
| `scanner.zmap.sender_threads` | số sender thread mỗi tiến trình zmap (`--sender-threads`, 0 = mặc định zmap) |
| `scanner.zmap.min_hitrate` | dừng sớm chunk khi hit-rate dưới ngưỡng (`--min-hitrate`, 0 = tắt) |
| `scanner.zmap.exclude_file` | file CIDR loại trừ tùy chọn cho zmap |
| `scanner.zmap.exclude_default` | `true` (mặc định) = khi `exclude_file` trống, tự dùng `config/exclude.txt` (bogon/DoD) qua `--blacklist-file` |
| `scanner.zmap.quiet` | tắt status updates của zmap |
| `scanner.zmap.dryrun` | `true` = chỉ validate config, không gửi gói (test) — zmap 2.x có bug assertion khi dryrun với CIDR >1 IP, chỉ dùng cho 1 IP |
| `scanner.generate_ipv4.enabled` | `true` = tự sinh chunk IPv4 từ `cidr`, bỏ qua RIR (không cần targets.txt) |
| `scanner.generate_ipv4.cidr` | dải gốc, mặc định `0.0.0.0/0` (toàn bộ IPv4) |
| `scanner.generate_ipv4.split_to` | chia thành chunk /N, mặc định 16 → 65.536 chunk |
| `scanner.generate_ipv4.shuffle` / `.seed` | xáo thứ tự chunk / seed tái lập thứ tự |
| `scanner.generate_ipv4.max_chunks` | `0` = tất cả; `>0` = giới hạn số chunk (test) |
| `scanner.ports` | cổng quét (mặc định `80,443,8080`) — dùng chung cho tự sinh |
| `rate` | tốc độ quét (gói/giây) — fallback khi `scanner.*.rate` trống |
| `threads` | số thread fingerprint/versioning |
| `timeout` | timeout HTTP |
| `cves` | danh sách CVE có template local trong `cves/` (đưa vào nuclei `-t`) |
| `fingerprint.endpoints` | endpoint probe thêm ngoài trang chủ (mặc định `/rest/V1/`, `/graphql`, `/static/version/`, `/magento_version`) |
| `fingerprint.min_score` | ngưỡng điểm tin cậy để kết luận Magento (mặc định 3) |
| `store_detect.enabled` | `true` = bật stage 2c lọc cửa hàng thật; `false` = chạy như bản cũ (mọi URL Magento đi tiếp) |
| `store_detect.min_score` | ngưỡng điểm cửa hàng thật (mặc định 3) |
| `store_detect.check_cart` / `.check_login` | probe `/checkout/cart/` (giỏ hàng) và `/customer/account/login/` (đăng nhập khách) — bật mặc định |
| `store_detect.threads` | số worker RIÊNG của stage (mặc định 20 — không tranh fingerprint) |
| `store_detect.retries` | thử lại LỖI MẠNG tạm thời (mặc định 1; không retry 429/503) |
| `store_detect.jitter_min` / `.jitter_max` | ngủ ngẫu nhiên (giây) TRƯỚC mỗi URL — giãn nhịp chống WAF chặn |
| `store_detect.head_limit` | byte đầu body + `<title>` để tìm dấu hiệu "chưa mở bán" (mặc định 6144) |
| `cve.version_map` | `cves/version_map.yaml` — khớp version (stage 2b) → CVE offline, không cần nuclei |
| `cve.nuclei.enabled` | `false` = chỉ khớp version offline, không gọi nuclei |
| `cve.nuclei.concurrency` / `.rate_limit` / `.timeout` / `.retries` | cờ nuclei `-c` / `-rl` / `-timeout` / `-retries` (0/trống = để nuclei tự chọn hoặc mặc định) |
| `cve.nuclei.follow_redirects` | `true` = nuclei theo redirect (mặc định tắt — tránh quét lạc; lưu ý đây là follow-redirects, KHÔNG phải "giảm false positive") |
| `cve.nuclei.max_seconds` | chặn mềm 1 lượt nuclei — quá giờ giữ kết quả một phần (mặc định 7200) |
| `cve.nuclei.local_templates` / `.community` | bật/tắt từng nguồn template (local trong `cves/` / cộng đồng qua `-id`) |
| `cve.nuclei.severity` | chỉ giữ finding mức này trở lên, vd `high` (rỗng = tất cả) |
| `cve.community_ids` | CVE chạy qua nuclei `-id` từ nuclei-templates cộng đồng (cần đã cài templates) |
| `paths.targets_extra` | `config/targets_extra.txt` — hotspot CIDR ưu tiên quét trước RIR (mỗi dòng `CIDR` hoặc `CIDR|EXTRA|COUNTRY`) |
| `rir.countries` | rỗng = mọi quốc gia; ví dụ `[VN, TH]` |
| `rir.min_prefix` / `max_prefix` | giới hạn prefix CIDR được chấp nhận |
| `rir.split_to` | chia allocation lớn xuống /N (mặc định 24) |
| `upload.enabled` | bật daemon upload `output/t.txt` + `output/vul.txt` lên GoFile định kỳ (mặc định true) |
| `upload.title` | tên scan — hiển thị trên đỉnh tin webhook để "biết bị" (mặc định `SofiaScan`) |
| `upload.files` | tên file trong output/ → mô tả hiển thị trên webhook (mặc định `{t.txt: "domain cửa hàng thật", vul.txt: "domain dính vuln"}`) |
| `upload.interval` | điều kiện 2 — thời gian TỐI THIỂU giữa 2 lần upload, giây (mặc định 900 = 15 phút) |
| `upload.poll_interval` | tần suất kiểm tra file, giây (mặc định 60) — bắt đổi số dòng nhanh |
| `upload.count_changed` | điều kiện 1 — `true` = chỉ upload khi SỐ dòng file thay đổi (mặc định true; `false` = upload theo chu kỳ như bản cũ) |
| `cleanup.enabled` | bật/tắt tự động dọn output/ (mặc định true) |
| `cleanup.log_total_mb` | TỔNG dung lượng sofia.log + backups; vượt → tự xoá backup cũ / truncate file chính (0 = tắt; mặc định 120MB) |
| `cleanup.live_txt_max_mb` | output/live.txt vượt → tự cắt, giữ chỉ `live_txt_keep_lines` dòng cuối (0 = tắt; mặc định 512MB) |
| `cleanup.live_txt_keep_lines` | số dòng live.txt giữ khi cắt (mặc định 500000) |
| `webhook.enabled/type/url` | bật webhook `discord` / `slack` / `generic` |

Dải loại trừ (gov/mil/CDN/bogon...) khai báo trong `config/exclude.txt` (một CIDR mỗi
dòng) — zmap tự nạp qua `--blacklist-file` khi `scanner.zmap.exclude_default: true`.

### Chống block IP khi quét lớn (zmap)

- **Warmup**: 2 chunk đầu chạy 50% rate rồi tăng dần — không spew tốc độ tối đa ngay.
- **Jitter ±15%** mỗi chunk + **politeness sleep** giữa chunk/CIDR — nhịp không đều.
- **Port nguồn xoay theo gói** từ dải 40000-60000, chia rời rạch cho từng instance
  song song — giả vờ như nhiều host khác nhau, tránh tạo pattern port nguồn lặp lại.
- **Retry lùi rate** ×0.5 mỗi lần thử lại — bị throttle thì giảm tốc, không cày tiếp.
- **Exclude mặc định** bogon/RFC1918/DoD — không gửi gói tới dải không nên quét.
- **`--max-runtime` + cooldown**: zmap tự dừng đúng giờ, runner chờ đủ cooldown
  (timeout = `max_runtime + cooldown + 60s`) — không giết zmap giữa lúc gói còn về.
- **Rate lớn**: quét toàn internet (0.0.0.0/0) thường cần 100k–350k pps; đặt kèm
  `bandwidth` (vd `100M`) để cap băng thông nếu đường yếu. Chunk /16 chia nhỏ từng
  bước, xong chunk nào ghi ngay (resume per-chunk) nên block giữa chừng không mất
  toàn bộ tiến độ.

## Resume

Mỗi CIDR hoàn tất tạo marker `output/work/<slug>/.complete` — chạy lại `main.py` sẽ
**bỏ qua** các CIDR đó; dùng `--no-resume` để quét lại từ đầu.

Resume còn ở mức **chunk** (stage 1): CIDR lớn chia chunk, chunk nào xong ghi ngay
`output/work/<slug>/scan_chunks_done.txt` + gộp kết quả vào `live_chunks.txt`.
Crash/block giữa CIDR → lần chạy sau chỉ quét lại các chunk còn dang dở.

## Phát hiện CVE — 2 lớp

1. **Offline (version match)** — không cần nuclei, không gửi thêm request:
   version lấy từ stage 2b khớp `cves/version_map.yaml` → ghi `[version] <url> <ver> — khả năng <CVE>`
   vào `output/vuln_version.txt` (file riêng cho findings khớp version — TÁCH KHỎI
   `vuln.txt`) và `output/work/<slug>/cve_version.txt`.

   Nuclei chỉ ghi vào `output/vuln.txt`, và chỉ phần findings CHƯA có ở lớp offline
   (dedupe theo nguyên dòng, đã rewrite domain).
2. **Online (nuclei)** — trên các cửa hàng thật (URL từ stage 2c), bật/tắt qua
   `cve.nuclei.enabled`:
   - template local: `cves/<CVE>.yaml` qua `-t` — `id` trong template PHẢI khớp
     tên file (lệch là bỏ qua, chống gán nhầm CVE cho kết quả);
   - template cộng đồng: `cve.community_ids` qua `-id` (cần `nuclei-templates` đã
     cài: `nuclei -update-templates`). CVE vừa có template local vừa trong
     `community_ids` → chỉ chạy bản local (tránh quét trùng 1 CVE 2 lần).
   - Mức độ ăn to điều khiển qua `cve.nuclei.*` (concurrency/rate_limit/timeout/
     retries/follow_redirects/max_seconds/severity — xem bảng cấu hình).
     Lưu ý: `follow_redirects` (cờ `-fr` của nuclei) là theo redirect, KHÔNG phải
     "giảm false positive" như chú thích bản cũ.

CVE có template local hiện tại:
- Magento: `cves/CVE-2022-24086.yaml`, `cves/CVE-2024-34102.yaml`, `cves/CVE-2025-54236.yaml`
  (nhận diện, version thủ công).
- WooCommerce: `cves/CVE-2025-6440.yaml` (Designer Pro — upload file, PoC đã xác minh),
  `cves/CVE-2025-5746.yaml` (Drag&Drop Upload Pro — upload file, response chưa xác minh),
  `cves/CVE-2024-3957.yaml` (Booster — chỉ fingerprint version qua readme.txt),
  `cves/CVE-2023-28121.yaml` (WooPayments — auth bypass, GET-only không tạo user).
  Chi tiết: `cves/research/cve_woocommerce_4cve_nuclei_research.md`.
Nếu nuclei không tìm thấy template community cho CVE nào thì chỉ cần chạy
`nuclei -update-templates`.

## Nhánh WooCommerce / WordPress

Cùng danh sách host của stage 1, pipeline chạy thêm nhánh WooCommerce (bật/tắt qua
`woocommerce.enabled`, mặc định bật) — độc lập với nhánh Magento:

1. **Phát hiện** (`core/woo_fingerprint.py`) — probe đa endpoint + chấm điểm tin cậy:
   header `x-powered-by: WordPress`, cookie `wordpress_*`/`woocommerce_*`,
   body chữ ký WP (`/wp-content/`, `wp-json`…), `/wp-json/` trả JSON. Bằng chứng
   **WooCommerce riêng** (để phân biệt với WordPress thường): asset
   `/wp-content/plugins/woocommerce/`, cookie `wp_woocommerce_session`/`woocommerce_*`,
   marker `wc-*`/`woocommerce-*`, và **Store API** `/wp-json/wc/store/` trả JSON.
   Kết luận WordPress khi tổng điểm ≥ `woocommerce.min_score` (mặc định 3); kết luận
   **WooCommerce** khi có ≥1 bằng chứng Woo riêng và đủ ngưỡng. Kết quả ra
   `output/wordpress.txt` (mọi WP) + `output/woocommerce.txt` (chỉ Woo).
2. **Dò version plugin** (`core/woo_versioning.py`) — trích version TỪNG PLUGIN từ
   asset tĩnh `/wp-content/plugins/<slug>/…?ver=<version>`; nếu thiếu `?ver` thì thử
   `readme.txt` (dòng `Stable tag:`, tắt qua `woocommerce.fetch_readme`). Giới hạn
   `woocommerce.max_plugins` slug/host. Debug: `work/<slug>/woo_plugins.txt`.
3. **Khớp CVE** (`core/woo_cve_scan.py`) — offline (không cần nuclei) khớp cặp
   (slug, version) với `cves/woo_version_map.yaml`, ghi dòng
   `[version] <url> <slug> <version> — khả năng <CVE> [SEV] (tên) — dính trong <khoảng>`;
   cộng thêm nuclei 2 nguồn giống nhánh Magento: template local `cves/<CVE>.yaml`
   qua `-t` (`woocommerce.cves` — chỉ CVE đã xác minh qua `cves/research/`, id khớp
   tên file) và template cộng đồng qua `-id` (`woocommerce.community_ids`, để trống
   thì lấy toàn bộ CVE trong map; CVE có template local bị bỏ khỏi danh sách
   cộng đồng — không quét trùng). Dùng chung cờ nuclei với Magento (`cve.nuclei.*`).
   Debug: `work/<slug>/woo_cve_version.txt`, `work/<slug>/woo_nuclei.txt` (local),
   `work/<slug>/woo_nuclei_community.txt` (cộng đồng).

Kết quả gộp chung: `output/vuln_version.txt` (dòng `[version]` offline) +
`output/vuln.txt` (findings nuclei) + `output/vul.txt` (domain dính); URL Woo cũng
được đưa vào resolver để ra domain trong `output/t.txt`. URL ip:port trong dòng
finding được rewrite sang domain như nhánh Magento.

### Bản đồ plugin → CVE — `cves/woo_version_map.yaml`

Khác `version_map.yaml` (Magento: 1 sản phẩm, nhiều dòng version), file này khóa theo
**SLUG PLUGIN** — một site có thể dính nhiều plugin khác nhau cùng lúc. Mỗi plugin khai
`aliases` (slug khác cùng plugin: bản free/pro, đổi tên) và `cves`; mỗi CVE khai khoảng
bằng 1 trong 2 cách (kết hợp được):

```yaml
plugins:
  woocommerce-payments:
    name: "WooCommerce Payments (WooPayments)"
    aliases: ["woocommerce-payments", "woopayments"]
    cves:
      CVE-2023-28121:
        severity: critical
        ranges:                      # các khoảng ĐÓNG [lo, hi] dính lỗi
          - ["4.8.0", "4.8.1"]
          - ["5.0.0", "5.0.3"]
  woocommerce-upload-files:
    cves:
      CVE-2024-10820:
        severity: critical
        below: "84.4"               # dính khi version < 84.4 (bản đã vá)
```

- **`below: "X.Y.Z"`** — dùng khi vendor chỉ công bố *bản đã vá*: mọi version nhỏ hơn
  X.Y.Z coi như dính.
- **`ranges: [[lo, hi], …]`** — dùng khi cần loại trừ nhánh đã được backport (tránh false
  positive ở các bản trung gian đã vá, như WooCommerce Payments vá từng nhánh).

Parser version plugin nhận dạng số tối đa 4 thành phần `X.Y[.Z[.W]]` (pad 0 khi thiếu) —
khớp version thật của WordPress (`3.15.0.3`, `84.3`, `4.9.40`). CVE đã đối chiếu gồm:
CVE-2026-47100 (FunnelKit), CVE-2023-28121 (WooCommerce Payments), CVE-2023-3169
(tagDiv Composer), CVE-2024-10820 (WooCommerce Upload Files), CVE-2024-13342 +
CVE-2024-3957 (Booster for WooCommerce), CVE-2024-13359 (Product Input Fields),
CVE-2024-8425 (Ultimate Gift Card), CVE-2023-33318 (AutomateWoo), CVE-2025-5746
(Drag&Drop File Upload Pro), CVE-2025-6440 (WooCommerce Designer Pro), CVE-2024-9289 +
CVE-2026-32558 (Affiliate Program/Pro).

### Khớp version offline — `cves/version_map.yaml`

Mỗi CVE khai **`ranges`**: danh sách khoảng ĐÓNG `[lo, hi]` (lo/hi phải cùng family
major.minor, parser tự loại nếu lệch). Version dính lỗi khi NẰM TRONG ≥1 khoảng:

```yaml
CVE-2022-24086:
  ranges:
    - ["2.4.0", "2.4.3-p1"]     # 2.4.0..2.4.3-p1 đều dính
    - ["2.3.3-p1", "2.3.7-p2"]
```

**`eol_older_than`** khai dòng release cũ nhất còn được vendor vá — mọi version cùng
family major.minor NHỎ HƠN dòng đó thuộc nhánh EOL, không bao giờ nhận bản vá nên coi
như vẫn dính lỗi (chỉ khai khi chắc chắn nhánh đó không được backport):

```yaml
CVE-2024-34102:
  eol_older_than: "2.4.4"      # → 2.4.0..2.4.3 (mọi pnum) vẫn dính
  ranges:
    - ["2.4.4", "2.4.4-p8"]
    - ["2.4.5", "2.4.5-p7"]
```

Parser version chặt: chỉ nhận token `X.Y[.Z][-pN]` sạch (có boundary, chặn hậu tố mơ hồ
như `-rc1`/`.1`/`-p3x`) — giảm false positive từ chuỗi lạ. Key cũ `max_vulnerable` vẫn
được đọc (mỗi mục = khoảng đóng trên ĐÚNG nhánh X.Y.Z, không suy diễn sang nhánh EOL).

## Lọc "cửa hàng THẬT" (stage 2c)

`fingerprint` chỉ xác nhận **có Magento** — nhưng nhiều URL thoả fingerprint không phải cửa
hàng đang bán: maintenance mode, "coming soon", cài mới chưa setup, Magento làm
blog/CMS/landing, hay trang chết chỉ còn REST mở.

Stage 2c (`core/store_detect.py`) probe thêm đặc tính storefront và chấm điểm:

| Bằng chứng | Điểm |
|---|---|
| Trang chủ 200 + marker bán hàng (catalog/giỏ/tìm kiếm/tài khoản) | +3 |
| `/checkout/cart/` trả 200 — giỏ hàng hoạt động | +3 |
| `/checkout/cart/` redirect | +1 |
| `/customer/account/login/` trả 200 — có tài khoản khách | +2 |
| Trang chủ không phải 2xx (403/404/5xx) | −8 (vẫn probe tiếp) |
| 503 "Service Temporarily Unavailable" / body "coming soon / under construction..." | loại ngay |

Tổng `>= store_detect.min_score` (mặc định 3) → cửa hàng THẬT. Chỉ các URL này được đưa
xuống stage 2b-4; toàn bộ URL Magento vẫn nằm trong `output/magento.txt`.

Output:

| File | Nội dung |
|---|---|
| `output/stores.txt` | 1 URL cửa hàng thật mỗi dòng (global, mọi CIDR) |
| `output/work/<slug>/stores_scored.txt` | `url <điểm> <bằng chứng>` (debug từng CIDR) |
| `output/work/<slug>/stores_reasons.txt` | `số_lần <lý do loại>` — bảng đếm để điều chỉnh ngưỡng (vd quá nhiều `home:503-maintenance` = nhiều site bảo trì) |

Dấu hiệu "chưa mở bán" chỉ tìm trong `store_detect.head_limit` byte đầu + `<title>`
(không quét cả body — tránh false positive từ quảng cáo/blog nhắc "coming soon").
429/503/connect-lỗi không retry (retry chỉ áp dụng cho lỗi mạng tạm thời).

## Upload t.txt + vul.txt lên GoFile định kỳ (`upload_live.py`)

`t.txt` = danh sách **domain cửa hàng thật** (kết quả cuối pipeline), `vul.txt` =
danh sách **domain dính vuln** (extract tự động từ findings của stage 3 — xem
[Phát hiện CVE](#phát-hiện-cve--2-lớp)). `upload_live.py` upload cả hai (theo `upload.files`)
lên GoFile rồi gửi link về webhook — **MỖI FILE 1 TIN NHẮN RIÊNG** kèm tên file
+ `upload.title` (tên scan) để người nhận "biết bị" đây là file nào, từ scan nào:

```
📁 SofiaScan — t.txt (domain cửa hàng thật)
• 1,234 dòng, 45.6 KB
• Tải: https://gofile.io/d/xxxx
🚨 SofiaScan — vul.txt (domain dính vuln)
• 12 dòng, 0.8 KB
• Tải: https://gofile.io/d/yyyy
```

(`vul.txt` tự nhận bằng 🚨 trên Discord; file khác 📁.)

**CHỈ upload khi ĐỦ 2 ĐIỀU KIỆN:**

1. **Số dòng thay đổi** — số dòng (≥ 1 file trong `upload.files`) khác lần upload
   thành công gần nhất (thêm/bớt domain nhưng cùng số lượng → không upload).
   Lần đầu tiên luôn upload. Trong 1 đợt chỉ các file thay đổi được upload.
2. **Đủ thời gian** — đã trôi qua ≥ `upload.interval` giây (mặc định 900 = 15 phút)
   kể từ lần upload thành công gần nhất.

Trạng thái mỗi file (số dòng + mốc thời gian) lưu trong `output/upload_state.json`
(cấu trúc `{"files": {"t.txt": {...}, "vul.txt": {...}}}`; state cũ quy về t.txt tự) —
khởi động lại daemon không gây upload vội. Trước khi upload tự loại dòng trùng
(t.txt/vul.txt append theo CIDR — chạy lại sẽ trùng). Nếu upload mid-round lỗi, file
đã xong sẽ re-upload chu kỳ sau (state chỉ ghi khi toàn đợt hoàn) — đồng hợp quyết.

- **Tích hợp `main.py`**: khởi động daemon background qua `upload_live.start_daemon(cfg)`
  (khi `upload.enabled=true`), kiểm tra file mỗi `upload.poll_interval` giây (mặc định 60).
- **Chạy riêng**: `python3 upload_live.py [--once] [--interval 900] [--poll-interval 60]`
  `[--title SofiaScan]` (`--no-count-changed` = upload theo chu kỳ như bản cũ).
  Legacy 1 file: `python3 upload_live.py --file output/vul.txt --desc "domain dính vuln"`.
  Webhook URL: `config/config.yaml` (`webhook.url`) hoặc env `SOFIA_WEBHOOK_URL`.

Tin nhắn webhook kèm tên file, mô tả, số dòng, dung lượng và link tải. Nếu GoFile/webhook
lỗi sẽ báo 1 lần khi chuyển trạng thái OK → lỗi (chống spam) và thử lại chu kỳ sau.


## Nâng tỉ lệ tìm Magento

- **Hotspot**: điền dải hosting/cloud hay dựng Magento vào `config/targets_extra.txt`
  (`CIDR|EXTRA|COUNTRY`), chúng được quét trước toàn bộ RIR.
- **Tăng nhận diện**: probe đa endpoint nên bắt được cả site đổi theme nhưng còn REST/GraphQL;
  muốn an toàn hơn tăng `fingerprint.min_score`, muốn nhạy hơn giảm còn 2 (kèm false positive).
- **Tăng trúng CVE**: `cve.version_map` tận dụng cả version không cần nuclei; thêm CVE mới vào
  `cve.community_ids` + kéo template bằng `nuclei -update-templates`.
- **Tăng nhận diện WooCommerce**: `woocommerce.endpoints` thêm endpoint đặc trưng của site
  cần tìm; `woocommerce.min_score` tăng (an toàn) hoặc giảm còn 2 (nhạy hơn, kèm false positive);
  thêm plugin/CVE mới vào `cves/woo_version_map.yaml` + `woocommerce.community_ids`;
  CVE đã xác minh PoC thì viết template local `cves/<CVE>.yaml` (id khớp tên file)
  và khai vào `woocommerce.cves` — ưu tiên hơn template cộng đồng.

## Tests

```bash
cd sofia_scan && python3 -m pytest tests/ -v
```

Phủ: parse/delegated → CIDR (`test_rir.py`), format tin nhắn webhook (`test_webhook.py`),
signature Magento 1/2 (`test_fingerprint.py`), mock dig + SAN (`test_resolver.py`),
thứ tự stage + webhook trong `finally` + resume (`test_pipeline.py`),
nâng cấp zmap song song/warmup/chia dải port nguồn (`test_scanner.py`).
Nhánh WooCommerce: parse version plugin + khớp map offline (`test_woo_cve_map.py`),
chấm điểm/parse WP-Woo (`test_woo_fingerprint.py`), trích version plugin từ HTML/readme
(`test_woo_versioning.py`).














