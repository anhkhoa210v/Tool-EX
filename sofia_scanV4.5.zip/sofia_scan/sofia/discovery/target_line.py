# -*- coding: utf-8 -*-
"""SofiaTool v2 — PHA 1: parser dòng target có GỢI Ý CVE (pinned CVE).

Ngoài host/URL trần (1 dòng / target), file `-t` có thể chứa dòng ĐÃ BIẾT CVE
do bước trinh sát (SofiaScan / người dùng tổng hợp) sinh ra. Với các dòng đó
Sofia CHỌN LUÔN CVE ghi trong dòng với URL target để khai thác (định tuyến
pipeline theo chính CVE đó), thay vì tự dò lại nền tảng/version — đúng câu
"chọn luôn CVE-id đó với url target để exploit".

Ba định dạng được nhận diện (tự động, không cần cờ):

  1) <url> [<CVE-id>] <thông tin>
     vd: https://shop.tld [CVE-2024-34102] CosmicSting

  2) [version] <url> <version> — khả năng <CVE> [<SEV>](<tên lỗi>) — dính trong <label>
     (nhánh Magento của SofiaScan — version_match trên version_map.yaml)
     <version> có thể là token trơn ("2.4.6-p3") hoặc mang prefix "Magento/"
     ("Magento/2.4" — SofiaScan ghi chuỗi trả về từ core/versioning.py nguyên vẹn);
     parser bóc prefix để ra version thuần, và KHÔNG nhầm token đó làm slug.

  3) [version] <url> <slug> <version> — khả năng <CVE> [<SEV>](<tên lỗi>) — dính trong <khoảng>
     (nhánh WooCommerce của SofiaScan — version_match trên woo_version_map.yaml)

Dòng KHÔNG chứa CVE (host/URL trần) trả về `cves = []` -> Sofia xử lý như cũ:
nhận diện nền tảng (PHA 1b) rồi chọn CVE theo version.

Hàm thuần (pure), KHÔNG I/O mạng -> test offline dễ.

CHỈ DÙNG CHO MỤC ĐÍCH KIỂM THỬ BẢO MẬT ĐƯỢC UỶ QUYỀN.
"""
import re

from discovery.target_queue import normalize

# CVE-YYYY-NNNN (>=4 chữ số phần cuối để tránh khớp rác)
_CVE_RE = re.compile(r"CVE-\d{4}-\d{4,}", re.I)
# URL http(s) — dừng ở khoảng trắng / ký tự bao quanh phổ biến
_URL_RE = re.compile(r"https?://[^\s\]\)>\"'`]+", re.I)
# token version: X.Y[.Z[.W]] (tuỳ chọn -pN/-alphaN/-betaN/-rcN) — Magento + WP
_VER_RE = re.compile(r"^\d+(?:\.\d+){1,3}(?:-(?:p|alpha|beta|rc)\d+)?$", re.I)
# token version Magento có prefix platform — SofiaScan ghi nguyên chuỗi
# "Magento/2.4" / "Magento/2.4.6-p3" từ core/versioning.py vào dòng [version]
_MAGENTO_VER_RE = re.compile(r"^Magento/?\s*v?(.+)$", re.I)
_IPV4_RE = re.compile(r"^\d{1,3}(?:\.\d{1,3}){3}$")
# dấu gạch dài (em/en dash) phân tách phần "— khả năng ... — dính trong ..."
_DASH_RE = re.compile(r"\s*[—–]\s*")

# Magento 24086 & 24087 dùng CHUNG một worker `cve_2022_24086` (key nội bộ
# "CVE-2022-24086/24087") -> quy đổi CVE lẻ về key đó.
_MAGENTO_CVE_ALIAS = {
    "CVE-2022-24086": "CVE-2022-24086/24087",
    "CVE-2022-24087": "CVE-2022-24086/24087",
}


def _strip_wrap(tok):
    """Bỏ ký tự bao/đuôi câu khỏi 1 token ('[x]', '(x)', 'x,', 'x.')."""
    return (tok or "").strip().strip("[]()<>\"'`,.;")


def extract_cves(line):
    """Trả list CVE trong dòng (UPPER, đã quy đổi Magento, khử trùng, giữ thứ tự)."""
    out, seen = [], set()
    for m in _CVE_RE.findall(line or ""):
        cve = _MAGENTO_CVE_ALIAS.get(m.upper(), m.upper())
        if cve in seen:
            continue
        seen.add(cve)
        out.append(cve)
    return out


def _looks_like_host(tok):
    """True nếu token đủ giống host/URL để dùng làm target (không phải rác/CVE)."""
    t = _strip_wrap(tok)
    if not t or _CVE_RE.search(t) or "—" in t or "–" in t:
        return False
    if "://" in t:
        return True
    host = t.split("/", 1)[0]
    if _IPV4_RE.match(host.split(":", 1)[0]):
        return True
    # domain: phải có dấu chấm và không bắt đầu bằng dấu chấm
    return "." in host and not host.startswith(".")


def extract_url(line):
    """Trả URL target đã chuẩn hoá (scheme://host) hoặc None.

    Ưu tiên URL http(s) đầy đủ; nếu không có, thử token đầu tiên trông giống
    host (domain trần / IP[:port]) — vd dòng '[version] shop.tld 2.4.6 ...'.
    """
    m = _URL_RE.search(line or "")
    if m:
        url = m.group(0).rstrip(".,;)]}\"'`")
        return normalize(url) or url
    for tok in (line or "").split():
        if _looks_like_host(tok):
            return normalize(tok)
    return None


def _version_token(tok):
    """Token → chuỗi version thuần (đã bóc prefix 'Magento/'), hoặc None.

    Chấp nhận cả "2.4.6-p3" (token trơn) lẫn "Magento/2.4.6-p3" (SofiaScan ghi
    nguyên chuỗi versioning). Phần sau prefix phải khớp _VER_RE mới tính là
    version — 'Magento/unknown' không thành version.
    """
    t = _strip_wrap(tok)
    m = _MAGENTO_VER_RE.match(t)
    if m:
        cand = m.group(1).strip()
        return cand if _VER_RE.match(cand) else None
    return t if _VER_RE.match(t) else None


def _is_magento_token(tok):
    """True nếu token mang prefix 'Magento/' (version hoặc rác) — không làm slug."""
    return bool(_MAGENTO_VER_RE.match(_strip_wrap(tok)))


def _parse_version_line(line):
    """Tách (version, slug) từ dòng bắt đầu bằng '[version]'. (None, None) nếu thiếu.

    Nhánh Magento: 1 token version — trơn ("2.4.6-p3") hoặc có prefix
    ("Magento/2.4") → version được bóc prefix; token 'Magento/…' KHÔNG BAO GIỜ
    làm slug (tránh nhầm platform). Nhánh Woo: token 1 = slug plugin,
    token 2 = version trơn.
    """
    body = re.sub(r"^\s*\[version\]\s*", "", line, flags=re.I)
    body = _URL_RE.sub(" ", body)          # bỏ URL, chỉ còn '<ver>' hoặc '<slug> <ver>'
    head = _DASH_RE.split(body, 1)[0]      # cắt ở '— khả năng ...'
    tokens = [t for t in head.split() if t]
    version = next((v for v in (_version_token(t) for t in tokens) if v), None)
    slug = next((t for t in tokens
                 if not t.startswith("[") and not _is_magento_token(t)
                 and _version_token(t) is None), None)
    return (version,
            _strip_wrap(slug) if slug else None)


def parse_line(line):
    """Dòng target -> dict {'url','cves','version','slug','platform','is_version_line','raw'}
    hoặc None nếu dòng trống / không tìm thấy URL.

    - cves rỗng  -> dòng host/URL trần: Sofia nhận diện nền tảng như cũ.
    - cves có    -> GỢI Ý CVE (pinned): Sofia chọn luôn CVE đó (xem resolve_pinned).
    """
    raw = (line or "").rstrip("\n")
    s = raw.strip()
    if not s or s.startswith("#"):
        return None

    url = extract_url(s)
    if not url:
        return None

    cves = extract_cves(s)
    is_ver_line = bool(re.match(r"^\s*\[version\]", s, re.I))

    version, slug = (None, None)
    if is_ver_line:
        version, slug = _parse_version_line(s)

    platform = None
    if slug:
        platform = "woocommerce"
    elif is_ver_line:
        platform = "magento"

    return {"url": url, "cves": cves, "version": version, "slug": slug,
            "platform": platform, "is_version_line": is_ver_line, "raw": raw}


def _engine_of(cve):
    """Pipeline có worker cho CVE: 'magento' | 'wordpress' | None."""
    cve = _MAGENTO_CVE_ALIAS.get((cve or "").upper(), (cve or "").upper())
    from discovery import version as _version
    if cve in set(_version.ALL_CVES):
        return "magento"
    try:  # KB WooCommerce (13 CVE plugin) — import lazy, tránh vòng lặp import
        from exploit_wo import kb as _kb
        if cve in _kb.BY_CVE:
            return "wordpress"
    except Exception:  # noqa: BLE001 — thiếu KB vẫn chạy phần Magento
        pass
    return None


def resolve_pinned(rec):
    """dict parse_line -> (engine, platform, cves, dropped).

    Chỉ giữ CVE có WORKER (chạy được); engine suy theo CVE trước, rồi theo slug/
    hint của dòng. `dropped` = CVE bị loại (không worker / khác pipeline).
    cves rỗng -> caller nên fallback về nhận diện nền tảng như cũ.
    """
    cves = list(rec.get("cves") or [])
    slug = rec.get("slug")
    hint = rec.get("platform")

    engine = None
    for c in cves:
        e = _engine_of(c)
        if e:
            engine = e
            break
    if engine is None and slug:
        engine = "wordpress"
    if engine is None and hint:
        engine = {"woocommerce": "wordpress", "magento": "magento"}.get(hint)
    if engine is None and cves:
        engine = "magento"     # mặc định pipeline Magento cho CVE lạ không slug

    resolved, dropped = [], []
    for c in cves:
        (resolved if _engine_of(c) == engine else dropped).append(c)

    platform = "woocommerce" if engine == "wordpress" else "magento"
    return engine, platform, resolved, dropped
