# SofiaTool v2

Công cụ kiểm thử bảo mật **đa nền tảng** (Magento / Adobe Commerce / WooCommerce) — khai thác các lỗ hổng **đã công bố** trên các instance **được phép kiểm thử**. Chỉ dùng cho mục đích đánh giá an ninh được ủy quyền / huấn luyện blue team.

> Các payload đều là PoC công khai (public disclosure). Toàn bộ logic khai thác nằm trong `exploit/` (Magento/Adobe) và `exploit_wo/` (WooCommerce).

## Tự động nhận diện nền tảng & định tuyến

PHA 1b (`discovery/platform.py`) tự nhận diện **từng** target rồi định tuyến pipeline:

| Nền tảng phát hiện | Pipeline | Chọn CVE |
|--------------------|----------|----------|
| `magento` (Open Source) / `adobe_commerce` (Enterprise) | `exploit/` | `discovery/version.py` — dò version rồi chọn theo ngưỡng vá (`CVE_RULES`) |
| `woocommerce` | `exploit_wo/` | `discovery/wo_select.py` — dò plugin/version rồi chỉ chạy CVE PHÙ HỢP |
| `unknown` | bỏ qua | — |

Danh sách target có thể **xen kẽ** Magento / Adobe Commerce / WooCommerce: mỗi target đi đúng engine của nó, không cần tách file. Chọn `--platform {auto,magento,adobe_commerce,woocommerce}` để lọc/ép pipeline (`auto` = tự nhận diện, mặc định).

## File target & dòng ghim CVE (pinned)

Ngoài host/URL trần (1 dòng / target, `#` = chú thích), file `-t` nhận thêm **dòng GHIM CVE (pinned)** — dòng đã kèm sẵn CVE do bước trinh sát (SofiaScan) hoặc bạn tự tổng hợp. Khi `--pin` bật (mặc định), Sofia **chọn LUÔN CVE ghi trong dòng** với URL target để khai thác và **bỏ qua dò nền tảng/version** (PHA 1b) cho dòng đó.

Ba định dạng nhận diện **tự động**, không cần cờ riêng (parser: `discovery/target_line.py`):

```text
# 1) <url> [<CVE-id>] <thông tin>
https://shop.tld [CVE-2024-34102] CosmicSting

# 2) [version] <url> <version> — khả năng <CVE> [<SEV>](<tên lỗi>) — dính trong <label>
#    (nhánh Magento của SofiaScan — version_match trên version_map.yaml)
[version] https://shop.tld 2.4.6 — khả năng CVE-2024-34102 (CRITICAL)(CosmicSting) — dính trong 2.3.0 - 2.4.6-p2
#    <version> cũng chấp nhận dạng có prefix platform (SofiaScan ghi nguyên chuỗi
#    từ core/versioning.py): "Magento/2.4", "Magento/2.4.6-p3" — parser bóc prefix
#    để ra version thuần và KHÔNG nhầm token đó làm slug.

# 3) [version] <url> <slug> <version> — khả năng <CVE> [<SEV>](<tên lỗi>) — dính trong <khoảng>
#    (nhánh WooCommerce của SofiaScan — version_match trên woo_version_map.yaml)
[version] https://shop.tld product-slider 1.2.3 — khả năng CVE-2023-28121 (HIGH)(SVG) — dính trong 1.0 - 1.4
```

Quy tắc định tuyến dòng pinned:

- `target_line.resolve_pinned()` chỉ giữ CVE **có worker**: Magento/Adobe → `exploit/`, WooCommerce → `exploit_wo/`; dòng xen kẽ vẫn đi đúng pipeline. `CVE-2022-24086`/`24087` tự quy về key worker chung `CVE-2022-24086/24087`.
- Dòng ghim vẫn qua `--scope`, sổ `ran_target.json` (`--skip-ran`) và lọc `--platform` như target thường.
- CVE ghim **không có worker** (CVE lạ/không hỗ trợ) → target fallback về nhận diện nền tảng như cũ, log rõ lý do.
- Dòng host/URL trần (không CVE) hoặc chạy với `--no-pin` → đi PHA 1b tự nhận diện như cũ.
- Dòng `[version]` mang thêm `version`/`slug` vào target — log và evidence dễ đọc hơn.

| Cờ | Ý nghĩa |
|----|---------|
| `--pin` / `--no-pin` | ghim CVE ghi trong dòng target (3 định dạng trên); mặc định **bật**; `--no-pin` = coi mọi dòng là host trần, tự nhận diện lại |

## Cài đặt (tự động)

```bash
cd sofia
bash setup.sh
```

`setup.sh` tự động (idempotent — chạy lại an toàn, không ghi đè cấu hình):

1. Cài công cụ base qua apt nếu thiếu (curl, unzip, ca-certificates, gnupg, python3-pip, node/npm).
2. Cài **whcli** (Webhook.site CLI — `npm i -g @webhooksite/cli`) — tunnel chính cho OOB callback.
3. Cài **cloudflared** (quick tunnel) — tunnel dự phòng khi webhook.site không khả dụng.
4. Cài pip deps từ `requirements.txt` (requests / urllib3 / httpx).
5. Nâng cấp `sofia.py` lên bản **multi-target** (`tools/upgrade_multitarget.py`, idempotent — nếu đã nâng cấp thì bỏ qua).
6. Tạo `targets.txt` mẫu nếu chưa có.

Kiểm tra cuối: `whcli --version`, `cloudflared --version`, `python3 sofia.py --help` (phải thấy `--batch-size`, `--resume`, `--platform` và `--classify-threads`).

## Multi-target

`sofia.py` xử lý nhiều target từ file `-t` với đầy đủ kiểm soát quy mô:

| Cờ | Ý nghĩa |
|----|---------|
| `-t FILE` | file danh sách target (1 host/URL mỗi dòng, `#` = chú thích) |
| `--threads N` | số luồng exploit song song (mặc định 20) |
| `--batch-size N` | xử lý theo nhóm N target — giới hạn tokens/state, log tiến độ `batch k/n`; `0` = tất cả cùng lúc (mặc định) |
| `--resume` | bỏ qua JOB (CVE, host) đã có kết quả trong `report/report.json` — tiếp tục lần chạy bị dừng giữa chừng |
| `--skip-ran` / `--no-skip-ran` | mỗi target chạy xong tự ghi vào `ran_target.json` rồi **bỏ qua target đó ở lần chạy sau** (mặc định: bật) |
| `--ran-file FILE` | đổi đường dẫn sổ target đã kiểm tra (mặc định `ran_target.json` ở thư mục sofia) |
| `--classify-threads N` | số luồng SONG SONG cho PHA 1b (nhận diện nền tảng + dò version/plugin); mặc định tự chọn (4–32) |
| `--no-classify-cache` | TẮT cache phân loại — luôn dò lại nền tảng/version/plugin cho mọi host |
| `--classify-ttl SEC` | thời gian sống của cache phân loại (giây; mặc định 86400 = 24h; `0` = không hết hạn) |
| `--platform P` | `auto` (mặc định) \| `magento` \| `adobe_commerce` \| `woocommerce` — lọc target theo pipeline |
| `--pin` / `--no-pin` | dòng target kèm CVE (pinned) được chọn LUÔN CVE đó, bỏ dò nền tảng/version — xem mục «File target & dòng ghim CVE» |

Cách phối hợp cho danh sách lớn:

```bash
python3 sofia.py -t targets.txt --threads 20 --batch-size 50 --resume
python3 sofia.py -t interleaved.txt --classify-threads 32 --batch-size 100 --resume
```

- Kiểu batch: mỗi batch N target chạy song song với `--threads` luồng; xong mới sang batch kế; mỗi batch log rõ số job Magento/Adobe vs WooCommerce và hit mới.
- `--resume` đọc `report/report.json`: job `(CVE, host)` có entry ghi `time`/`hit`/`error` (hit lẫn miss) được xem là *đã xử lý* và bị bỏ qua — bạn có thể Ctrl-C giữa chừng rồi chạy lại y nguyên lệnh.

### Sổ target đã kiểm tra (`ran_target.json`)

Mỗi khi một target chạy **xong** (mọi job CVE của nó đã có kết quả hit/miss/lỗi, hoặc target không có CVE nào phù hợp), target đó được ghi vào `ran_target.json` ở thư mục `sofia`. Ở **lần chạy sau**, các target trong sổ được **bỏ qua ngay từ PHA 1b** — không nhận diện nền tảng, không dò version/plugin, không khai thác lại:

```json
{
  "generated": "2026-09-30T16:00:00+07:00",
  "updated":   "2026-09-30T16:05:12+07:00",
  "count": 2,
  "targets": ["https://a.example.com", "https://b.example.com"]
}
```

- Ghi **atomic** (tmp → `os.replace`), an toàn đa luồng; ghi theo lô sau mỗi batch nên Ctrl-C vẫn giữ được các target đã xong.
- So khớp theo URL đã chuẩn hoá: `example.com`, `http://example.com/path`, `https://example.com` là một.
- Tắt hẳn: `--no-skip-ran` (hoặc `SOFIA_SKIP_RAN=0`). Đổi file: `--ran-file FILE` / `SOFIA_RAN_FILE`.
- Muốn **chạy lại** một target đã bỏ qua: xoá dòng URL của nó khỏi `ran_target.json` (hoặc xoá cả file).
- Khác với `--resume` (bỏ qua theo JOB trong `report.json`), `--skip-ran` bỏ qua theo TARGET và áp ngay ở bước nhận diện.

### Cache phân loại (PHA 1b) — tối ưu danh sách lớn

PHA 1b là phần **chạm mạng nhiều nhất** (mỗi host 1–6 request chỉ để classify). Sofia lưu **sự thật nhận diện** (nền tảng/engine/edition/version/plugin) xuống `report/classify_cache.json`:

- Chạy lại / `--resume` / nhiều phiên trên cùng danh sách lớn: host đã có cache (còn hạn TTL) được dùng lại **ngay, KHÔNG chạm mạng**.
- Danh sách CVE **luôn được tính lại offline** từ `discovery/version.py` / `discovery/wo_select.choose_cves()` khi đọc cache — nên khi ngưỡng CVE trong KB thay đổi, cache cũ không sinh quyết định sai.
- Host trùng trong danh sách được dedup trước khi dò mạng; ghi cache atomic + an toàn đa luồng.
- TTL qua `--classify-ttl` hoặc biến môi trường `SOFIA_CLASSIFY_TTL`; tắt hẳn bằng `--no-classify-cache`.

## CVE được hỗ trợ

| CVE | Tên | Điều kiện version | Chức năng |
|-----|-----|-------------------|-----------|
| CVE-2024-34102 | CosmicSting (XXE qua REST) | ≤ 2.4.6-p1 / 2.4.5-p4 / 2.4.4-p6 | đọc `app/etc/env.php`, OOB exfil, SSRF |
| CVE-2025-54236 | SessionReaper | ≤ 2.4.9-alpha2 / 2.4.8-p2 / 2.4.7-p7 | chiếm session admin |
| CVE-2022-24086/24087 | template-filter RCE | 2.3.3-p1 – 2.3.7-p2 ; 2.4.0 – 2.4.3-p1 | SQLi/RCE qua số lượng |
| CVE-2026-75650 | StyleSmuggler (unauth SSTI→RCE) | 2.4.4 – 2.4.9 (mọi mức patch tới hotfix APSB26-146) | poison log → GraphQL cart → SSTI trigger → chạy `id`, báo webhook `CVE \| domain \| bằng chứng` |

Quy tắc chọn CVE theo version nằm trong `discovery/version.py` (`CVE_RULES`); target không rõ version sẽ quét toàn bộ.

### WooCommerce (`exploit_wo/`)

Với target WooCommerce, `discovery/wo_select.py` dò plugin/version đang cài rồi chọn CVE **phù hợp** từ KB `exploit_wo/kb.py` (13 CVE plugin WP/Woo, ví dụ `woocommerce-jetpack`, `woocommerce` core…). Có các mode:

- `targeted` — thấy plugin trong KB → chỉ chạy đúng CVE của plugin đó.
- `none-vuln` / `none` — không thấy plugin dính → không chạy (hoặc fallback theo `--wo-fallback`).
- `fallback-all` — không dò được plugin → chạy toàn bộ KB.

`choose_cves()` là hàm thuần offline (dùng chung cho cả dò live lẫn đọc cache) — đổi/thêm CVE trong KB thì cache cũ vẫn tự tính lại đúng.

## Sử dụng

```bash
# 1) Discovery: quét engine tìm Magento 2 + fingerprint version
python3 sofia.py --discover --seeds example.com --scope example.com

# 2) File target đã có (tự nhận diện Magento/Adobe/Woo, danh sách xen kẽ OK)
python3 sofia.py -t targets.txt

# 3) Multi-target quy mô lớn (batch + resume + cache phân loại)
python3 sofia.py -t targets.txt --threads 20 --batch-size 50 --resume \
    --webhook https://discord.com/api/webhooks/...

# 4) Chỉ xử lý Adobe Commerce (bỏ qua Magento community & Woo)
python3 sofia.py -t targets.txt --platform adobe_commerce

# 5) Ép dò lại phân loại (bỏ cache) cho một phiên
python3 sofia.py -t targets.txt --no-classify-cache

# 6) Bỏ qua tunnel manager nếu đã có tunnel URL sẵn
python3 sofia.py -t targets.txt --tunnel-url https://xxxx.webhook.site

# 7) File target có dòng ghim CVE (pinned) — chọn luôn CVE, không dò lại nền tảng
#    (kết hợp --no-pin nếu muốn Sofia tự nhận diện lại toàn bộ)
python3 sofia.py -t pinned.txt --pin
```

Cờ hữu ích khác: `--wait N` (timeout OOB callback, mặc định 30s), `--timeout N` (HTTP timeout, mặc định 15s), `--max-targets N` (giới hạn số target thực tế bị exploit), `--scope DOMAIN` (lọc target theo scope), `--tunnel auto|webhook.site|cloudflare`.

## Kết quả

- `report/report.json` — chi tiết từng target/CVE (hit, miss, lỗi, evidence_dir)
- `report/hits.csv` — danh sách target trúng
- `report/evidence/` — bằng chứng từng hit (snippet, cookies, webroot…)
- `report/classify_cache.json` — cache phân loại PHA 1b (nền tảng/version/plugin)
- `ran_target.json` — sổ target đã kiểm tra xong (bỏ qua ở lần chạy sau)
- Log tiến độ: `report/sofia.log`

## Cấu trúc

```
sofia/
├── setup.sh                # cài whcli + cloudflared + deps + upgrade multi-target
├── targets.txt             # danh sách target mẫu
├── sofia.py                # entrypoint CLI (--batch-size / --resume)
├── core/                   # config, logger, listener OOB, tunnel (whcli/cloudflared)
├── discovery/              # platform (nhận diện), version (CVE Magento), wo_select +
│                           #   exploit_wo/kb (CVE Woo), cache (classify_cache.json),
│                           #   engines, target_queue, target_line (parser dòng ghim
│                           #   CVE/pinned), fingerprint, scope_guard
├── exploit/                # env_hunter (34102), session_reaper (54236), cve_2022_24086,
│                           #   cve_2026_75650 (Magento/Adobe)
├── exploit_wo/             # pipeline WooCommerce (kb 13 CVE plugin WP/Woo, run_one/run_all)
├── waf/                    # phát hiện WAF + evasion
├── webroot/                # webroot PoC phục vụ qua listener
├── tools/upgrade_multitarget.py  # nâng cấp sofia.py lên bản multi-target (idempotent)
└── requirements.txt
```