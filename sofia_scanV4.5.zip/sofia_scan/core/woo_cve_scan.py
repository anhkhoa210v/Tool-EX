"""STAGE 3-woo: phát hiện CVE WooCommerce/WordPress — 2 lớp (giống cve_scan.py):

  A. OFFLINE (version match) — luôn chạy, không cần nuclei:
     version TỪNG PLUGIN (stage 3-woo) → khớp cves/woo_version_map.yaml
     (core/woo_cve_map.py) → dòng
     "[version] <url> <slug> <version> — khả năng CVE-... [SEV] (name) — dính trong <label>".
     Không gửi request thêm; plugin không rõ version thì không có dòng này.

  B. ONLINE (nuclei) — CÓ THỂ TẮT qua cve.nuclei.enabled:
     1) template LOCAL trong cves/<CVE>.yaml qua -t (woocommerce.cves) — chỉ
        CVE đã xác minh qua research (cves/research/), tránh template viết mù;
        id trong template PHẢI khớp tên file (dùng lại cve_scan.local_templates);
     2) template CỘNG ĐỒNG qua -id (woocommerce.community_ids; nếu để trống thì
        lấy toàn bộ CVE có trong woo_version_map.yaml).
     Một CVE vừa có template local vừa có trong community_ids → CHỈ chạy bản
     local (như nhánh Magento). Dùng chung cờ nuclei với Magento
     (cve.nuclei: concurrency/rate_limit/…).

Dùng lại helper của core/cve_scan.py (nuclei_config/_run_nuclei/_append_vul_hosts/
community_template_ids/_nuclei_flags) để 2 nhánh Magento & Woo hành xử nhất quán.
Findings: offline (dòng [version]) vào output/vuln_version.txt, nuclei vào
output/vuln.txt (mỗi dòng đúng 1 lần — nuclei chỉ append phần CHƯA có ở A),
host dính ghi vào output/vul.txt; riêng offline ghi work/<slug>/woo_cve_version.txt,
nuclei local ghi work/<slug>/woo_nuclei.txt, cộng đồng ghi woo_nuclei_community.txt.
URL ip:port trong finding được rewrite
sang domain (cve_scan.rewrite_line; giữ nguyên nếu không phân giải được).
Hàm nào cũng không raise (an toàn pipeline).
Contract: run(urls, versions, workdir, global_vuln, cfg) → list dòng finding.
"""
import os
import shutil

from core import cve_scan, woo_cve_map
from utils import file_io
from utils.logger import info, warn

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _map_path(cfg):
    """Đường dẫn woo_version_map (cfg.woocommerce.version_map, tương đối → BASE_DIR)."""
    path = (cfg.get("woocommerce") or {}).get("version_map")
    if path and not os.path.isabs(path):
        path = os.path.join(BASE_DIR, path)
    return path


def version_candidates(urls, versions, cfg):
    """(url, {slug: version}) → dòng '[version] ...' cho mỗi plugin dính lỗi."""
    if not versions:
        return []
    plugin_map = woo_cve_map.load_map(_map_path(cfg))
    if not plugin_map:
        return []

    lines = []
    for url in urls:
        host_plugins = versions.get(url) or {}
        for slug, version in host_plugins.items():
            for hit in woo_cve_map.match(slug, version, plugin_map):
                sev = hit["severity"].upper() if hit["severity"] != "n/a" else "n/a"
                name = f" ({hit['name']})" if hit["name"] else ""
                lines.append(
                    f"[version] {url} {slug} {version} — khả năng {hit['cve']} "
                    f"[{sev}]{name} — dính trong {hit['label']}"
                )
    return file_io.dedupe_sort(lines)


def local_templates(cfg):
    """Template local Woo (cfg.woocommerce.cves) → [(path, CVE-ID chuẩn)].

    Dùng lại cve_scan.local_templates (kiểm tra id khớp tên file, chỉ file
    tồn tại) với danh sách CVE khai trong woocommerce.cves.
    """
    ids = (cfg.get("woocommerce") or {}).get("cves") or []
    return cve_scan.local_templates({"cves": ids})


def community_ids(cfg):
    """CVE cộng đồng cho Woo: cfg.woocommerce.community_ids, trống → toàn bộ map."""
    ids = [str(cve).strip().upper()
           for cve in ((cfg.get("woocommerce") or {}).get("community_ids") or [])
           if str(cve).strip()]
    if ids:
        return ids
    return sorted(woo_cve_map.all_cves(woo_cve_map.load_map(_map_path(cfg))))


def run(urls, versions, workdir, global_vuln, cfg):
    """urls: list URL WooCommerce; versions: {url: {slug: version}}.

    Trả list dòng finding (offline + nuclei); offline → vuln_version.txt,
    nuclei → vuln.txt, host → vul.txt; URL ip:port được rewrite sang domain.
    """
    if not urls:
        return []
    findings = []

    # A) offline version match — chạy trước, có kết quả kể cả khi thiếu nuclei.
    # Dòng [version] vào vuln_version.txt (tách khỏi vuln.txt của nuclei) và
    # được rewrite URL ip:port → domain trước khi ghi.
    version_lines = [cve_scan.rewrite_line(l)
                     for l in version_candidates(urls, versions or {}, cfg)]
    if version_lines:
        file_io.append_lines(cve_scan.version_file(global_vuln), version_lines)
        file_io.append_lines(os.path.join(workdir, "woo_cve_version.txt"), version_lines)
        findings += version_lines

    ncfg = cve_scan.nuclei_config(cfg)
    if not ncfg["enabled"]:
        info(f"stage3-woo: {len(findings)} findings offline "
             f"(nuclei tắt trong cve.nuclei.enabled)")
        cve_scan._append_vul_hosts(findings, global_vuln)
        return findings
    if shutil.which("nuclei") is None:
        warn("[nuclei] không tìm thấy nuclei — giữ nguyên kết quả version match (woo)")
        info(f"stage3-woo: {len(findings)} findings offline (không có nuclei)")
        cve_scan._append_vul_hosts(findings, global_vuln)
        return findings

    targets_file = os.path.join(workdir, "woocommerce.txt")
    file_io.atomic_write(targets_file, "".join(u + "\n" for u in urls))

    # Chuẩn bị 2 nguồn + dedupe: CVE có template local → bỏ khỏi community_ids
    # (mô phỏng đúng nhánh Magento — xem cve_scan.run).
    local = local_templates(cfg) if ncfg["local_templates"] else []
    local_cves = {cve for _, cve in local}
    ids = [cve for cve in community_ids(cfg) if cve not in local_cves] \
        if ncfg["community"] else []
    if not local and not ids:
        warn("[nuclei] không có nguồn nào để chạy (woo) — "
             "giữ nguyên kết quả version match (woo)")
        cve_scan._append_vul_hosts(findings, global_vuln)
        return findings

    # B1) template local đã kiểm tra id qua -t (mỗi template một -t)
    nuclei_lines = []
    if local:
        out = os.path.join(workdir, "woo_nuclei.txt")
        extra = []
        for path, _ in local:
            extra += ["-t", path]
        nuclei_lines += cve_scan._run_nuclei(targets_file, out, extra, cfg)

    # B2) template cộng đồng qua -id (không trùng CVE đã chạy local)
    if ids:
        out = os.path.join(workdir, "woo_nuclei_community.txt")
        nuclei_lines += cve_scan._run_nuclei(targets_file, out,
                                             ["-id", ",".join(ids)], cfg)

    # Rewrite URL ip:port → domain cho findings nuclei trước khi dedupe/ghi.
    nuclei_lines = [cve_scan.rewrite_line(l) for l in nuclei_lines]
    findings = file_io.dedupe_sort(version_lines + nuclei_lines)
    # Append CHỈ phần nuclei chưa có ở bước A — version_lines đã append vào
    # vuln_version.txt ở bước A rồi; append cả findings sẽ ghi trùng dòng
    # [version] lần 2 (append_lines ghi mù, không tự dedupe theo nội dung file).
    seen = set(version_lines)
    new_lines = [l for l in file_io.dedupe_sort(nuclei_lines) if l not in seen]
    file_io.append_lines(global_vuln, new_lines)
    cve_scan._append_vul_hosts(findings, global_vuln)
    info(f"stage3-woo: {len(findings)} findings "
         f"(offline {len(version_lines)} + nuclei mới {len(new_lines)}, "
         f"local {len(local)} + community {len(ids)} template)")
    return findings
