"""STAGE 2c: lọc "cửa hàng THẬT" (storefront đang mở bán) trong URL Magento.

fingerprint (2a) chỉ xác nhận "có Magento" — nhưng nhiều URL thoả fingerprint
không phải cửa hàng thật:
  - cài mới chưa setup (trang mặc định, không giỏ hàng/khách),
  - maintenance mode / "coming soon" / "under construction",
  - Magento dùng làm blog/CMS/landing không có storefront bán hàng,
  - trang chết/403/404 (đã đổi domain, chỉ còn REST mở),
  - WAF/CDN chặn (429) hoặc homepage trả nội dung không phải HTML.

Stage này probe đặc tính storefront đang bán và chấm điểm:

    +3  trang chủ 200 + marker bán hàng (catalog/minicart/giỏ/tìm kiếm...)
    +3  /checkout/cart/ trả 200            (giỏ hàng hoạt động)
    +1  /checkout/cart/ redirect           (đang chuyển hướng, yếu hơn)
    +2  /customer/account/login/ trả 200   (có tài khoản khách)
    -8  trang chủ không phải 2xx (403/404/5xx — site chết/chặn; vẫn probe tiếp)
    LOẠI NGAY: 503 maintenance / body "coming soon / under construction..."
      (CHỈ tìm trong ~6KB đầu + <title> — tránh false positive từ quảng cáo
      hay bài viết nằm sâu trong trang); 429 = đang bị chặn tốc độ.

Tổng đạt `store_detect.min_score` (mặc định 3) → "cửa hàng thật".
Short-circuit: đủ điểm thì dừng probe sớm.

Cấu hình (block store_detect trong config.yaml):
  enabled        bật/tắt cả stage (true)
  min_score      ngưỡng điểm (3)
  check_cart     probe /checkout/cart/ (true)
  check_login    probe /customer/account/login/ (true)
  threads        số worker RIÊNG của stage (20) — không tranh với fingerprint
  retries        số lần thử lại lỗi mạng tạm thời (1)
  jitter_min/max ngủ ngẫu nhiên (giây) TRƯỚC mỗi URL — giãn nhịp, chống chặn
  head_limit     số byte đầu body để tìm dấu hiệu "chưa mở bán" (6144)

Output:
    output/stores.txt                      — 1 URL cửa hàng thật mỗi dòng
    output/work/<slug>/stores_scored.txt   — "url score bằng_chứng" (debug)
    output/work/<slug>/stores_reasons.txt  — đếm lý do loại (điều chỉnh ngưỡng)
Contract: run(urls, workdir, global_stores, cfg) → list URL cửa hàng thật.
"""
import concurrent.futures
import os
import random
import re
import time

import requests
import urllib3

from utils import file_io
from utils.logger import info, warn

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

USER_AGENT = "Mozilla/5.0 (compatible; SofiaScan/1.0)"
BODY_LIMIT = 200000  # giới hạn body đọc <title> (tránh tốn RAM trang lớn)
HEAD_LIMIT = 6 * 1024  # số byte đầu dùng tìm dấu hiệu "chưa mở bán"

DEFAULT_MIN_SCORE = 3
DEFAULT_THREADS = 20
DEFAULT_RETRIES = 1
DEFAULT_JITTER_MIN = 0.0
DEFAULT_JITTER_MAX = 0.2
REDIRECT_CAP = 5  # session.max_redirects — không đuổi theo redirect dây chuyền

# Marker một STOREFRONT đang bán xuất hiện trong HTML Magento
# (catalog sản phẩm / nút thêm giỏ / giỏ hàng / tìm kiếm / tài khoản).
STORE_MARKERS = re.compile(
    r"(?:"
    r"data-product-id|product-item|product\.name|price-box|price-wrapper|"
    r"add-to-cart|addtocart|tocart\b|action\.tocart|swatch-opt|"
    r"product-info-price|products-grid|product-list|product-list-container|"
    r"minicart|minicart-wrapper|block-minicart|showcart\b|action\.showcart|"
    r"block-search|catalogsearch|search-mini|"
    r"customer/account/login|checkout/cart|checkout/onepage|"
    r"category-products|products\.wrapper|ol\.products"
    r")",
    re.I,
)

# Dấu hiệu site CHƯA mở bán / đang bảo trì → loại ngay.
# Chỉ áp dụng cho phần ĐẦU trang (HEAD_LIMIT byte) + nội dung <title> — nếu
# quét toàn bộ body dễ false positive (promo/blog nhắc "coming soon").
NOT_STORE_RE = re.compile(
    r"(?:"
    r"Service Temporarily Unavailable|under construction|"
    r"coming soon|is under maintenance|maintenance mode|"
    r"we[’']?ll be back|site is offline|currently unavailable"
    r")",
    re.I,
)
TITLE_RE = re.compile(r"<title[^>]*>(.*?)</title>", re.I | re.S)

# Content-Type rõ ràng KHÔNG phải HTML — không thể chấm marker storefront
# trên đó (JSON/ảnh/PDF có thể chứa từ "product" ngẫu nhiên → false positive).
NON_HTML_RE = re.compile(
    r"^(?:image/|video/|audio/|application/pdf|application/json|"
    r"application/octet-stream|text/plain|application/xml|font/)",
    re.I,
)

REDIRECT_STATUSES = (301, 302, 303, 307, 308)
TOO_MANY = 429  # đang bị giới hạn tốc độ — KHÔNG nên quấy thêm
CART_PATH = "/checkout/cart/"
LOGIN_PATH = "/customer/account/login/"


def _cfg_values(cfg):
    sd = cfg.get("store_detect") or {}
    return {
        "min_score": int(sd.get("min_score", DEFAULT_MIN_SCORE)),
        "check_cart": bool(sd.get("check_cart", True)),
        "check_login": bool(sd.get("check_login", True)),
        "threads": max(1, int(sd.get("threads", DEFAULT_THREADS))),
        "retries": max(0, int(sd.get("retries", DEFAULT_RETRIES))),
        "jitter_min": float(sd.get("jitter_min", DEFAULT_JITTER_MIN)),
        "jitter_max": float(sd.get("jitter_max", DEFAULT_JITTER_MAX)),
        "head_limit": max(512, int(sd.get("head_limit", HEAD_LIMIT))),
    }


def _new_session():
    """Session với redirect cap + header hợp lý (verify=False: chấp nhận TLS lạ)."""
    session = requests.Session()
    session.verify = False
    session.max_redirects = REDIRECT_CAP
    session.headers["User-Agent"] = USER_AGENT
    session.headers["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
    return session


def _http_get(session, url, timeout, retries, allow_redirects=True):
    """GET có thử lại tối đa `retries` lần cho LỖI MẠNG (RequestException).

    Chỉ retry lỗi mạng tạm thời — KHÔNG retry theo HTTP status (503/429 là
    tín hiệu của máy chủ, retry chỉ làm tình hình tệ hơn). Trả response hoặc
    None khi cạn lượt thử."""
    attempt = 0
    while True:
        try:
            return session.get(url, timeout=timeout, allow_redirects=allow_redirects)
        except requests.RequestException as exc:
            attempt += 1
            if attempt > retries:
                return None
            # backoff ngắn + jitter trước khi thử lại
            time.sleep(0.5 + random.random() * 1.5)


def _is_html(resp):
    """Content-Type có vẻ HTML (thiếu header → mặc định HTML như server cũ)."""
    ctype = (resp.headers.get("Content-Type") or "").lower()
    if not ctype:
        return True
    if "html" in ctype or ctype.startswith("text/"):
        return True
    return not NON_HTML_RE.match(ctype)


def _head_and_title(resp, head_limit):
    """(đầu trang, nội dung <title>) để tìm dấu hiệu chưa mở bán — KHÔNG quét
    toàn bộ body (tránh false positive từ nội dung quảng cáo/blog)."""
    text = resp.text or ""
    head = text[:head_limit]
    title_match = TITLE_RE.search(text[:BODY_LIMIT])
    title = title_match.group(1) if title_match else ""
    return head + "\n" + title[:head_limit]


def _probe(url, timeout, opts):
    """Probe 1 URL → (url, is_store, score, evidence). Không bao giờ raise."""
    session = _new_session()
    min_score = opts["min_score"]
    retries = opts["retries"]

    total = 0
    evidence = []

    def add(points, why):
        nonlocal total
        total += points
        evidence.append(why)

    # Jitter giãn nhịp giữa các URL — chống burst request dễ bị WAF chặn.
    jitter = opts["jitter_max"] - opts["jitter_min"]
    if jitter > 0:
        time.sleep(opts["jitter_min"] + random.random() * jitter)

    # 1) Trang chủ — phải là storefront, không được maintenance/coming-soon
    resp = _http_get(session, url, timeout, retries, allow_redirects=True)
    if resp is None:
        return url, False, total, ["err:connect"]

    status = resp.status_code
    if status == TOO_MANY:
        return url, False, total, ["home:429"]
    if status == 503:
        return url, False, total, ["home:503-maintenance"]
    if NOT_STORE_RE.search(_head_and_title(resp, opts["head_limit"])):
        return url, False, total, ["home:not-store"]

    if not _is_html(resp):
        add(0, "home:not-html")  # không chấm được marker — chờ giỏ/tài khoản
    elif status not in (200, 201, 202, 204):
        add(-8, f"home:{status}")
    elif STORE_MARKERS.search((resp.text or "")[:BODY_LIMIT]):
        add(3, "home:store-markers")
        if total >= min_score:
            return url, True, total, evidence

    # 2) /checkout/cart/ — giỏ hàng hoạt động = bằng chứng mạnh của storefront
    if opts["check_cart"]:
        resp = _http_get(session, url.rstrip("/") + CART_PATH, timeout,
                         retries, allow_redirects=False)
        if resp is not None:
            if resp.status_code == TOO_MANY:
                add(0, "cart:429")
            elif resp.status_code == 503:
                return url, False, total, evidence + ["cart:503-maintenance"]
            elif NOT_STORE_RE.search(_head_and_title(resp, opts["head_limit"])):
                return url, False, total, evidence + ["cart:not-store"]
            elif resp.status_code == 200 and _is_html(resp):
                add(3, "cart:200")
                if total >= min_score:
                    return url, True, total, evidence
            elif resp.status_code in REDIRECT_STATUSES:
                add(1, "cart:redirect")

    # 3) /customer/account/login/ — cửa hàng có luồng đăng nhập khách
    if opts["check_login"]:
        resp = _http_get(session, url.rstrip("/") + LOGIN_PATH, timeout,
                         retries, allow_redirects=False)
        if resp is not None:
            if resp.status_code == TOO_MANY:
                add(0, "login:429")
            elif resp.status_code == 503:
                return url, False, total, evidence + ["login:503-maintenance"]
            elif NOT_STORE_RE.search(_head_and_title(resp, opts["head_limit"])):
                return url, False, total, evidence + ["login:not-store"]
            elif resp.status_code == 200 and _is_html(resp):
                add(2, "login:200")

    return url, total >= min_score, total, evidence


def probe(url, timeout, min_score=DEFAULT_MIN_SCORE, check_cart=True,
          check_login=True, retries=DEFAULT_RETRIES):
    """Contract nhẹ cho test/tích hợp: chỉ cần 1 URL."""
    opts = {
        "min_score": min_score, "check_cart": check_cart,
        "check_login": check_login, "threads": 1, "retries": retries,
        "jitter_min": 0.0, "jitter_max": 0.0, "head_limit": HEAD_LIMIT,
    }
    return _probe(url, timeout, opts)[:2]


def _reject_reason(evidence):
    """Lý do "không phải cửa hàng" để gom vào bảng đếm — lấy mốc loại đầu tiên."""
    if not evidence:
        return "score-thap"
    first = evidence[0]
    for prefix in ("err:", "home:429", "home:503", "home:not-store",
                   "cart:503", "cart:not-store", "login:503", "login:not-store"):
        if first.startswith(prefix):
            return prefix
    if first.startswith("home:"):
        return "home-khong-2xx"  # 403/404/5xx...
    return first.split(":")[0]


def run(urls, workdir, global_stores, cfg):
    """urls: list URL Magento → list URL là CỬA HÀNG THẬT; append vào stores.txt.

    Ghi debug ra output/work/<slug>/stores_scored.txt + bảng lý do loại ra
    stores_reasons.txt, trả list cửa hàng thật để pipeline chỉ đẩy target này
    xuống stage 2b-4.
    """
    if not urls:
        return []
    opts = _cfg_values(cfg)
    timeout = cfg.get("timeout", 15)

    found = set()
    scored = []
    reasons = {}
    with concurrent.futures.ThreadPoolExecutor(
            max_workers=min(opts["threads"], max(1, len(urls)))) as pool:
        futures = [pool.submit(_probe, u, timeout, opts) for u in urls]
        for future in concurrent.futures.as_completed(futures):
            url, is_store, score, evidence = future.result()
            scored.append(f"{url} {score} {' '.join(evidence)}".strip())
            if is_store:
                found.add(url)
            else:
                reason = _reject_reason(evidence)
                reasons[reason] = reasons.get(reason, 0) + 1

    stores = file_io.dedupe_sort(found)
    file_io.append_lines(global_stores, stores)

    scored_file = os.path.join(workdir, "stores_scored.txt")
    file_io.write_lines(scored_file, file_io.dedupe_sort(scored))
    reasons_file = os.path.join(workdir, "stores_reasons.txt")
    if reasons:
        file_io.write_lines(reasons_file, file_io.dedupe_sort(
            [f"{count} {reason}" for reason, count in sorted(
                reasons.items(), key=lambda kv: (-kv[1], kv[0]))]))

    info(f"stage2c: {len(stores)}/{len(urls)} Magento là cửa hàng THẬT "
         f"(min_score={opts['min_score']}, cart={'bật' if opts['check_cart'] else 'tắt'}, "
         f"login={'bật' if opts['check_login'] else 'tắt'}, threads={opts['threads']})")
    if reasons:
        top = ", ".join(f"{r}={c}" for r, c in sorted(
            reasons.items(), key=lambda kv: -kv[1])[:5])
        info(f"stage2c: lý do loại (top) — {top} "
             f"(chi tiết: {os.path.relpath(reasons_file, os.getcwd())})")
    if urls and not stores:
        warn(f"stage2c: 0/{len(urls)} URL thoả điều kiện cửa hàng thật — "
             f"không có target cho stage 2b-4 trong dải này")
    return stores

