"""Pipeline: tuần tự 4 stage theo từng CIDR + resume + webhook (batch).

Với MỖI CIDR:
  stage1 scanner → stage2a fingerprint → stage2b versioning
  → stage3 cve_scan → stage4 resolver (đếm domain)
  → webhook.scan_done (buffer, gửi gộp chống spam — xem webhook.py)

stage 2c store_detect (xem core/store_detect.py) lọc các URL Magento thành
"cửa hàng THẬT" (storefront đang bán); chỉ các cửa hàng thật mới được đẩy
xuống stage 2b→4 (nên t.txt chỉ chứa domain cửa hàng thật).
Bật/tắt + ngưỡng ở `store_detect` trong config.yaml (tắt = chạy như cũ).

CIDR đã có marker .complete trong output/work/<slug>/ sẽ được bỏ qua (resume).
"""
import os
import random
import time

import webhook
from core import cve_scan, fingerprint, resolver, scanner, store_detect, versioning
from utils import cleanup, file_io
from utils.logger import error, info, success, warn


class Pipeline:
    def __init__(self, cfg):
        self.cfg = cfg
        self.output_dir = cfg["paths"]["output_dir"]
        self.work_dir = os.path.join(self.output_dir, "work")
        webhook.configure(cfg.get("webhook"))

    def _global(self, name):
        return os.path.join(self.output_dir, name)

    def _cleanup_live(self):
        """Cắt output/live.txt nếu vượt cleanup.live_txt_max_mb (giữ dòng cuối).

        Gọi sau stage 1 mỗi CIDR — kiểm tra chỉ tốn 1 lần get size; file dưới
        trần thì không có thao tác nào khác.
        """
        try:
            if cleanup.enforce_live(self._global("live.txt"), cfg=self.cfg):
                info(f"[{self._global('live.txt')}] đã cắt bớt (trần "
                     f"{self.cfg.get('cleanup', {}).get('live_txt_max_mb', 0)}MB)")
        except Exception as exc:
            warn(f"cleanup live.txt lỗi: {exc}")

    def _politeness_sleep(self, done, total):
        """Ngủ ngẫu nhiên GIỮA các CIDR (scanner.politeness) — quét dài ngày
        với nhịp đều, không phun liên tục nhiều dải cạnh nhau dễ bị nhà mạng
        / WAF chặn nguồn quét. Không ngủ sau CIDR cuối (tránh trễ kết thúc)."""
        pol = (self.cfg.get("scanner") or {}).get("politeness") or {}
        lo = float(pol.get("sleep_min") or 0.0)
        hi = float(pol.get("sleep_max") or 0.0)
        if hi <= 0 or hi < lo:
            return
        if total is not None and done >= total:
            return
        seconds = random.uniform(lo, hi)
        info(f"politeness: ngủ {seconds:.1f}s giữa các CIDR "
             f"({lo:.0f}-{hi:.0f}s) — chống block nguồn quét")
        time.sleep(seconds)

    def run(self, targets, resume=True, total=None):
        total_domains = 0
        done = 0
        # lookahead 1 phần tử: biết khi nào là CIDR cuối (để không ngủ thừa
        # sau CIDR cuối khi total không xác định — targets có thể là generator)
        it = iter(targets)
        item = next(it, None)
        while item is not None:
            cidr, rir, country = item
            done += 1
            info(f"=== [{done}/{total if total is not None else '?'}] "
                 f"{cidr} ({rir}, {country}) ===")
            total_domains += self.run_cidr(cidr, rir, country, resume=resume)
            item = next(it, None)
            if item is not None:
                self._politeness_sleep(done, total)
        success(f"Hoàn tất {done} CIDR — tổng {total_domains} domain trong t.txt")

    def run_cidr(self, cidr, rir, country, resume=True):
        """Chạy 1 CIDR; trả về số domain ghi vào t.txt cho dải này."""
        workdir = os.path.join(self.work_dir, file_io.slugify(cidr))
        done_marker = os.path.join(workdir, ".complete")
        if resume and os.path.exists(done_marker):
            info(f"[{cidr}] đã hoàn tất trước đó — bỏ qua (resume)")
            return 0
        os.makedirs(workdir, exist_ok=True)

        domains = []
        findings = []
        ok = False
        try:
            hosts = scanner.scan(cidr, workdir, self._global("live.txt"), self.cfg)
            self._cleanup_live()  # live.txt quá nặng → cắt bớt, giữ dòng mới nhất
            magento = fingerprint.run(hosts, workdir, self._global("magento.txt"), self.cfg)
            # stage 2c — lọc cửa hàng THẬT; các stage sau chỉ nhận cửa hàng thật
            sd_cfg = self.cfg.get("store_detect") or {}
            urls = magento
            if sd_cfg.get("enabled", True):
                urls = store_detect.run(magento, workdir,
                                        self._global("stores.txt"), self.cfg)
                if magento and not urls:
                    warn(f"[{cidr}] không có cửa hàng thật trong "
                         f"{len(magento)} Magento — bỏ qua stage 2b-4")
            versions = versioning.run(urls, workdir, self._global("magento_versions.txt"), self.cfg)
            findings = cve_scan.run(urls, workdir, self._global("vuln.txt"), self.cfg, versions=versions)
            domains = resolver.run(urls, workdir, self._global("t.txt"), self.cfg)
            file_io.append_lines(self._global("t.txt"), domains)
            ok = True
        except Exception as exc:
            error(f"[{cidr}] lỗi trong pipeline: {exc}")
        finally:
            webhook.scan_done(cidr, country, len(domains), n_findings=len(findings))

        if ok:
            file_io.atomic_write(done_marker, "ok\n")
        info(f"[{cidr}] xong — {len(domains)} domain")
        return len(domains)










