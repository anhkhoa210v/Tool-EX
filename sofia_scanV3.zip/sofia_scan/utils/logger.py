"""Logging màu (rich) + ghi log ra file (xoay vòng — giới hạn kích thước)."""
import glob
import logging
import os

from logging.handlers import RotatingFileHandler

from rich.logging import RichHandler

# Mặc định: mỗi file tối đa 10MB, giữ 2 backup (sofia.log + 2 backup ≈ 30MB)
DEFAULT_MAX_BYTES = 10 * 1024 * 1024
DEFAULT_BACKUP_COUNT = 2

_log = None


class CappedRotatingFileHandler(RotatingFileHandler):
    """RotatingFileHandler + TRẦN TỔNG DUNG LƯỢNG (chống phình output).

    Ngoài việc xoay vòng theo max_bytes/backup_count như handler gốc, handler
    này còn xoá các backup CŨ NHẤT khi tổng kích thước sofia.log + backups
    vượt `total_cap_bytes` — "tự động xoá file log khi quá nặng". Nếu bản
    thân file log chính vẫn vượt cap (vd cap nhỏ hơn max_bytes) → truncate
    ngay trên stream đang mở (không tạo lỗ hổng sparse trong file).
    """

    def __init__(self, filename, maxBytes=0, backupCount=0, encoding=None,
                 total_cap_bytes=None):
        super().__init__(filename, maxBytes=max(maxBytes, 0),
                         backupCount=max(backupCount, 0), encoding=encoding)
        self.total_cap_bytes = total_cap_bytes
        self._enforcing = False  # chống viết status lặng vào bản handler
        if self.total_cap_bytes:
            self._enforce_total_cap()

    def emit(self, record):
        """Cap giữ tại mọi thời điểm — không chỉ khi xoay vòng."""
        super().emit(record)
        if (self._enforcing or not self.total_cap_bytes
                or self._log_total_size() <= self.total_cap_bytes):
            return
        self._enforce_total_cap()

    def doRollover(self):
        super().doRollover()
        if self.total_cap_bytes:
            self._enforce_total_cap()

    def _log_total_size(self):
        """Tổng dung lượng các file log của baseFilename (sofia.log + .1, .2...)."""
        total = 0
        for name in glob.glob(self.baseFilename + "*"):
            try:
                total += os.path.getsize(name)
            except OSError:
                pass
        return total

    def _enforce_total_cap(self):
        """Xoá backup cũ nhất cho tới khi tổng ≤ cap; truncate file chính nếu cần."""
        if self._enforcing:
            return
        self._enforcing = True
        try:
            self._enforce_total_cap_inner()
        finally:
            self._enforcing = False

    def _enforce_total_cap_inner(self):
        base_abs = os.path.abspath(self.baseFilename)
        backups = sorted(
            (name for name in glob.glob(self.baseFilename + ".*")
             if os.path.abspath(name) != base_abs),
            key=lambda n: (os.path.getmtime(n), n),
        )
        total = self._log_total_size()
        removed = 0
        # backup mtime cũ nhất (số hậu tố lớn nhất) bị xoá trước
        while backups and total > self.total_cap_bytes:
            oldest = backups.pop(0)
            try:
                total -= os.path.getsize(oldest)
                os.remove(oldest)
                removed += 1
            except OSError:
                break
        if total > self.total_cap_bytes:
            # file chính vẫn quá cap — truncate ngay trên stream đang mở
            try:
                if self.stream is not None:
                    self.stream.seek(0)
                    self.stream.truncate()
                    self.stream.flush()
                    removed += 1
                else:
                    with open(self.baseFilename, "w", encoding="utf-8"):
                        pass
                    removed += 1
            except OSError:
                pass
        if removed:
            logging.getLogger("sofia").info(
                f"log: tổng log vượt trần — đã dọn {removed} file "
                f"(giữ tổng ≤ {self.total_cap_bytes / (1024 * 1024):.0f}MB)")



def get_logger():
    global _log
    if _log is None:
        _log = logging.getLogger("sofia")
        _log.setLevel(logging.DEBUG)
        _log.propagate = False
        handler = RichHandler(rich_tracebacks=True, show_path=False, markup=True)
        handler.setLevel(logging.INFO)
        _log.addHandler(handler)
    return _log


def setup_file_logging(log_path, max_bytes=DEFAULT_MAX_BYTES,
                        backup_count=DEFAULT_BACKUP_COUNT, total_cap_bytes=None):
    """Ghi log ra file xoay vòng: quá max_bytes → xoay sofia.log.1, .2...

    Giữ tổng dung lượng log bị chặn ≈ max_bytes * (backup_count + 1)
    thay vì tăng trưởng vô hạn khi chạy lâu. Truyền `total_cap_bytes`
    (block `cleanup.log_total_mb` trong config) để handler TỰ XOÁ backup cũ
    / truncate file chính khi TỔNG log vượt trần — "xoá file log khi quá nặng".
    """
    os.makedirs(os.path.dirname(log_path) or ".", exist_ok=True)
    try:
        handler = CappedRotatingFileHandler(
            log_path, maxBytes=max(1024, max_bytes),
            backupCount=max(0, backup_count), encoding="utf-8",
            total_cap_bytes=total_cap_bytes,
        )
    except (OSError, ValueError):
        # Nơi đọc-ghi không xoay được (FS lạ) → fallback file thường
        handler = logging.FileHandler(log_path, encoding="utf-8")
    handler.setLevel(logging.DEBUG)
    handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
    get_logger().addHandler(handler)


def log():
    return get_logger()


def debug(msg):
    log().debug(msg)


def info(msg):
    log().info(msg)


def success(msg):
    log().info(f"[green]{msg}[/green]")


def warn(msg):
    log().warning(msg)


def error(msg):
    log().error(f"[red]{msg}[/red]")






