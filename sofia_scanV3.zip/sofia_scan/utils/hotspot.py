
"""Tự sinh config/targets_extra.txt — dải CIDR hotspot ưu tiên quét trước RIR.2 nguồn chính (có thể kết hợp):
  1. IP Magento đã dính (output/magento.txt) → gom theo /N
     (mặc định /24, chỉ giữ dải có >= N IP trúng) — "tự nuôi" từ chính
     kết quả quét: thấy 1 site Magento là quét luôn cả dải quanh nó.
  2. ASN nhà hosting/cloud → kéo announced prefixes qua RIPEstat API
     (miễn phí, không key) rồi nạp thẳng vào targets_extra.
Lọc tự động:
  - dải private/loopback/multicast/link-local, prefix là subnet của dải
    trong config/exclude.txt (gov/mil/CDN...)
  - CIDR đã tồn tại trong config/targets_extra.txt (không ghi trùng)
Ví dụ:
  # IP dính Magento trong output/magento.txt → /24 có >= 2 IP → ghi thêm
  python3 utils/hotspot.py
  # Chỉ xem kết quả, không ghi file
  python3 utils/hotspot.py --dry-run --min-hits 1
  # Kéo prefix các ASN hosting + gom từ magento.txt, tag quốc gia DE
  python3 utils/hotspot.py --asn 16276,24940,51167 --country DE
  # Gom theo /16 (quét dải lớn quanh cụm) thay vì /24
  python3 utils/hotspot.py --prefix 16 --min-hits 1 --dry-run
"""
import argparse
import ipaddress
import os
import re
import sys
from collections import Counter
import requests
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)
from utils import file_io  # noqa: E402
from utils.logger import error, info, warn  # noqa: E402
DEFAULT_IP_FILE = os.path.join(BASE_DIR, "output", "magento.txt")
DEFAULT_EXCLUDE = os.path.join(BASE_DIR, "config", "exclude.txt")
DEFAULT_OUTPUT = os.path.join(BASE_DIR, "config", "targets_extra.txt")
RIPE_STAT = "https://stat.ripe.net/data/announced-prefixes/data.json?resource=AS{asn}"
# "http://1.2.3.4/", "1.2.3.4:443", "1.2.3.4", "https://[..]:port/.."
IP_TOKEN_RE = re.compile(r"\b(\d{1,3}(?:\.\d{1,3}){3})\b")
def parse_ip_line(line):
    """Trích IPv4 từ dòng bất kỳ (IP trần / ip:port / URL). Trả về str hoặc None."""
    if not line:
        return None
    for token in IP_TOKEN_RE.findall(line):
        try:
            return str(ipaddress.ip_address(token))
        except ValueError:
            continue
    return None
def read_ip_file(path):
    """Đọc file → set IPv4 hợp lệ. Chấp nhận IP trần, ip:port, URL."""
    ips = set()
    for line in file_io.read_lines(path, strip_comments=True):
        ip = parse_ip_line(line)
        if ip:
            ips.add(ip)
    return ips
def group_to_prefixes(ips, prefix):
    """set IPv4 → Counter[network] số IP trúng trong dải đó."""
    counts = Counter()
    for ip in ips:
        net = ipaddress.ip_network(f"{ip}/{prefix}", strict=False)
        counts[net.network_address] += 1
    return counts
def _usable(network):
    """Dải có thể quét? Loại private/loopback/multicast/link-local/unspecified."""
    return not (
        network.is_private or network.is_loopback or network.is_multicast
        or network.is_link_local or network.is_unspecified
    )
def load_excludes(path):
    """File CIDR loại trừ → list IPv4Network (rỗng nếu không có file)."""
    nets = []
    for line in file_io.read_lines(path, strip_comments=True):
        try:
            nets.append(ipaddress.ip_network(line, strict=False))
        except ValueError:
            continue
    return nets
def excluded(network, excludes):
    """network nằm trong (là subnet của) một dải loại trừ nào đó?"""
    return any(network.subnet_of(ex) for ex in excludes)
def fetch_asn_prefixes(asns, excludes, max_prefix=24):
    """RIPEstat announced prefixes cho từng ASN → list CIDR (đã lọc).
    Không raise: lỗi mạng/ASN sai chỉ warn rồi bỏ qua. max_prefix loại các
    host-route (/25..) ít khi là block hosting.
    """
    out = []
    for asn in asns:
        try:
            resp = requests.get(RIPE_STAT.format(asn=asn), timeout=30)
            resp.raise_for_status()
            prefixes = (resp.json().get("data") or {}).get("prefixes") or []
        except (requests.RequestException, ValueError) as exc:
            warn(f"[hotspot] lấy prefix AS{asn} thất bại: {exc}")
            continue
        before = len(out)
        for item in prefixes:
            cidr = (item or {}).get("prefix")
            try:
                network = ipaddress.ip_network(cidr, strict=False)
            except (TypeError, ValueError):
                continue
            if not _usable(network):
                continue
            if network.prefixlen > max_prefix:
                continue
            if excluded(network, excludes):
                continue
            out.append(cidr)
        info(f"[hotspot] AS{asn}: {len(out) - before} prefix hợp lệ")
    return out
def existing_cidrs(path):
    """CIDR đã có trong targets_extra (field đầu mỗi dòng) → set."""
    out = set()
    for line in file_io.read_lines(path, strip_comments=True):
        cidr = line.split("|")[0].strip()
        try:
            ipaddress.ip_network(cidr, strict=False)
            out.add(cidr)
        except ValueError:
            continue
    return out
def render_lines(entries, country):
    """entries: dict CIDR → số IP trúng → list dòng 'CIDR|EXTRA|COUNTRY'."""
    rows = []
    for cidr in sorted(entries, key=lambda c: ipaddress.ip_network(c)):
        rows.append(f"{cidr}|EXTRA|{country}")
    return rows
def build_hotspots(args):
    """Tổng hợp mọi nguồn → dict {cidr: hits} đã lọc trùng/exclude."""
    excludes = load_excludes(args.exclude_file)
    existing = existing_cidrs(args.output)
    hotspots = {}
    def add(cidr, hits):
        try:
            network = ipaddress.ip_network(cidr, strict=False)
        except ValueError:
            warn(f"[hotspot] bỏ CIDR không hợp lệ: {cidr}")
            return
        if not _usable(network):
            return
        if excluded(network, excludes):
            return
        if network.with_prefixlen in existing:
            return
        key = network.with_prefixlen
        hotspots[key] = max(hotspots.get(key, 0), hits)
    # Nguồn 1 — IP Magento đã dính, gom theo prefix
    ips = read_ip_file(args.ip_file)
    if ips:
        counts = group_to_prefixes(ips, args.prefix)
        info(f"[hotspot] {len(ips)} IP từ {args.ip_file}, gom /{args.prefix}: "
             f"{len(counts)} dải, giữ dải >= {args.min_hits} IP trúng")
        for network_addr, hits in counts.most_common():
            if hits < args.min_hits:
                continue
            add(f"{network_addr}/{args.prefix}", hits)
    else:
        warn(f"[hotspot] không có IP nào trong {args.ip_file} — bỏ nguồn magento")
    # Nguồn 2 — ASN hosting
    if args.asn:
        for cidr in fetch_asn_prefixes(args.asn, excludes, args.max_asn_prefix):
            add(cidr, 0)
    # Nguồn 3 — CIDR chỉ định trực tiếp
    for cidr in args.cidr or []:
        add(cidr, 0)
    return hotspots, existing
def run(args):
    hotspots, existing = build_hotspots(args)
    if not hotspots:
        info("[hotspot] không có CIDR mới — targets_extra giữ nguyên")
        return
    lines = render_lines(hotspots, args.country)
    if args.dry_run:
        for line in lines:
            print(line)
        info(f"[hotspot] DRY-RUN: {len(lines)} CIDR mới (chưa ghi file)")
        return
    file_io.append_lines(args.output, lines)
    info(f"[hotspot] ghi {len(lines)} CIDR mới vào {args.output} "
         f"(đã loại {len(existing)} CIDR trùng)")
    # Top dải theo số IP trúng — gợi ý nguồn tiếp theo để quét rộng hơn
    top = sorted(
        ((cidr, hits) for cidr, hits in hotspots.items() if hits > 0),
        key=lambda item: -item[1],
    )[:10]
    if top:
        info("[hotspot] TOP dải dày nhất (cân nhắc --prefix lớn hơn để mở rộng):")
        for cidr, hits in top:
            info(f"    {cidr}  ({hits} IP trúng)")
def parse_args():
    ap = argparse.ArgumentParser(
        description="Sinh config/targets_extra.txt từ IP Magento dính + ASN hosting")
    ap.add_argument("--ip-file", default=DEFAULT_IP_FILE,
                    help=f"File IP/URL Magento đã dính (mặc định: {DEFAULT_IP_FILE})")
    ap.add_argument("--prefix", type=int, default=24,
                    help="Kích thước prefix gom IP (mặc định 24)")
    ap.add_argument("--min-hits", type=int, default=2,
                    help="Chỉ giữ dải có >= N IP trúng (mặc định 2; 1 = thêm cả dải 1 IP)")
    ap.add_argument("--asn", default="",
                    help="Danh sách ASN hosting, ví dụ '16276,24940,51167' (RIPEstat)")
    ap.add_argument("--max-asn-prefix", type=int, default=24,
                    help="Prefix tối đa giữ từ ASN (mặc định 24; loại host-route)")
    ap.add_argument("--cidr", default="",
                    help="CIDR thêm trực tiếp, ví dụ '45.130.140.0/22,1.2.3.0/24'")
    ap.add_argument("--country", default="XX",
                    help="Tag quốc gia cho dòng ghi (mặc định XX)")
    ap.add_argument("--exclude-file", default=DEFAULT_EXCLUDE,
                    help=f"File CIDR loại trừ (mặc định: {DEFAULT_EXCLUDE})")
    ap.add_argument("--output", default=DEFAULT_OUTPUT,
                    help=f"File ghi (mặc định: {DEFAULT_OUTPUT})")
    ap.add_argument("--dry-run", action="store_true",
                    help="Chỉ in ra stdout, không ghi file")
    return ap.parse_args()
def main():
    args = parse_args()
    asns = [a.strip() for a in args.asn.split(",") if a.strip().isdigit()]
    if args.asn and not asns:
        error(f"[hotspot] --asn không hợp lệ: {args.asn!r} (cần số ASN, ví dụ 16276)")
        sys.exit(2)
    cidrs = [c.strip() for c in args.cidr.split(",") if c.strip()]
    if not (asns or cidrs or os.path.exists(args.ip_file)):
        error(f"[hotspot] không có nguồn nào: {args.ip_file} không tồn tại, "
              f"--asn rỗng, --cidr rỗng")
        sys.exit(2)
    if args.prefix < 8 or args.prefix > 28:
        error("[hotspot] --prefix nên trong 8..28")
        sys.exit(2)
    args.asn = asns
    args.cidr = cidrs
    run(args)
if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        error("Dừng bởi người dùng (Ctrl+C)")