"""Tải & parse delegated-*-latest của 5 RIR → targets.txt (CIDR + rir + quốc gia).

Chuỗi xử lý: download (cache output/rir_cache/) → parse() → iter_cidrs()
→ lọc exclude.txt → build_targets() ghi targets.txt (stream, tối ưu RAM —
split_to=24 có thể sinh hàng chục triệu CIDR).
"""
import array
import glob
import heapq
import ipaddress
import os
import tempfile
import time

import requests

try:
    import pytricia
    _HAS_PYTRICIA = True
except ImportError:  # fallback sang ipaddress nếu thiếu pytricia
    pytricia = None
    _HAS_PYTRICIA = False

from utils import file_io
from utils.logger import error, info, warn

CACHE_MAX_AGE = 86400  # giây — tải lại delegated file sau 1 ngày


def cache_path(cache_dir, rir):
    return os.path.join(cache_dir, f"delegated-{rir}-extended-latest")


def download(rir, url, cache_dir, max_age=CACHE_MAX_AGE):
    """Tải delegated file nếu cache quá hạn; trả về đường dẫn cache."""
    path = cache_path(cache_dir, rir)
    if os.path.exists(path) and (time.time() - os.path.getmtime(path)) < max_age:
        info(f"[RIR] {rir}: dùng cache {path}")
        return path
    os.makedirs(cache_dir, exist_ok=True)
    info(f"[RIR] {rir}: đang tải {url}")
    fd, tmp = tempfile.mkstemp(dir=cache_dir, prefix=".dl_")
    try:
        with requests.get(url, stream=True, timeout=180) as resp:
            resp.raise_for_status()
            with os.fdopen(fd, "wb") as fh:
                for chunk in resp.iter_content(1 << 16):
                    fh.write(chunk)
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.remove(tmp)
    return path


def parse_file(path):
    """Parse delegated file → list (rir, country, 'ipv4'|'ipv6', start, value).

    Ví dụ dòng: apnic|VN|ipv4|1.52.0.0|16384|20110414|allocated
    """
    records = []
    with open(path, encoding="utf-8", errors="ignore") as fh:
        for raw in fh:
            line = raw.strip()
            if not line or line.startswith("#") or "|" not in line:
                continue
            parts = line.split("|")
            if len(parts) < 5:
                continue
            rir, country, rtype, start = parts[0], parts[1], parts[2], parts[3]
            if rtype not in ("ipv4", "ipv6"):
                continue
            try:
                value = int(parts[4])
            except ValueError:
                continue
            records.append((rir, country, rtype, start, value))
    return records


def _split_subnet(net, split_to):
    """Chia allocation lớn xuống split_to (tối đa 2^16 subnet mỗi bước)."""
    if net.version == 6 or not split_to or net.prefixlen >= split_to:
        return [net]
    if net.prefixlen < 4:
        return [net]
    new_prefix = min(split_to, net.prefixlen + 16)
    try:
        return list(net.subnets(new_prefix=new_prefix))
    except ValueError:
        return [net]


def iter_cidrs(records, countries=None, min_prefix=8, max_prefix=24, split_to=24):
    """Generator: records → (ip_network, rir, country) sau lọc quốc gia + prefix."""
    cset = {c.strip().upper() for c in countries if c} if countries else None
    for rir, country, rtype, start, value in records:
        if cset and country.upper() not in cset:
            continue
        try:
            if rtype == "ipv4":
                if value <= 0 or value & (value - 1):
                    continue  # số host phải là lũy thừa của 2
                prefix = 33 - value.bit_length()
                net = ipaddress.ip_network(f"{start}/{prefix}", strict=False)
            else:
                if not 0 < value <= 128:
                    continue
                net = ipaddress.ip_network(f"{start}/{value}", strict=False)
        except ValueError:
            continue
        for sub in _split_subnet(net, split_to):
            if not min_prefix <= sub.prefixlen <= max_prefix:
                continue
            yield sub, rir, country.upper()


def to_cidrs(records, countries=None, min_prefix=8, max_prefix=24, split_to=24):
    """Như iter_cidrs nhưng trả về list (dùng cho test/dữ liệu nhỏ)."""
    return list(iter_cidrs(records, countries, min_prefix, max_prefix, split_to))


class ExcludeIndex:
    """Chỉ mục dải loại trừ; dùng pytricia nếu có, fallback ipaddress."""

    def __init__(self, path):
        self.nets = []
        self.tree = pytricia.PyTricia(32) if _HAS_PYTRICIA else None
        for line in file_io.read_lines(path):
            try:
                net = ipaddress.ip_network(line, strict=False)
            except ValueError:
                warn(f"[exclude] CIDR không hợp lệ: {line}")
                continue
            self.nets.append(net)
            if self.tree is not None:
                self.tree[str(net)] = True

    def contains(self, net):
        if not self.nets:
            return False
        if self.tree is not None:
            return bool(self.tree.get(str(net.network_address))) or bool(
                self.tree.get(str(net.broadcast_address))
            )
        for ex in self.nets:
            if net.subnet_of(ex) or ex.subnet_of(net):
                return True
        return False


def read_targets(path):
    """Stream targets.txt (định dạng CIDR|rir|country) → generator tuple."""
    for line in file_io.read_lines(path):
        parts = line.split("|")
        if len(parts) != 3:
            continue
        try:
            ipaddress.ip_network(parts[0], strict=False)
        except ValueError:
            continue
        yield parts[0], parts[1], parts[2]


def _encode_v4_key(net, rir_i, country_i):
    """(ip, prefix, rir, country) → int để sort gọn trong RAM (64-bit)."""
    return ((((int(net.network_address) << 5) | net.prefixlen) << 5) | rir_i) << 16 | country_i


def _decode_v4_key(key, rir_names, country_names):
    ip = ipaddress.IPv4Address(key >> 26)
    prefix = (key >> 21) & 31
    rir = rir_names[(key >> 16) & 31]
    country = country_names[key & 65535]
    return int(ip), prefix, rir, country


def build_targets(cfg):
    """Chuỗi đầy đủ: download → parse → iter_cidrs → lọc exclude → targets.txt.

    Ghi stream (sorted theo IP, dedupe) để chịu được hàng chục triệu CIDR.
    Trả về (số_CIDR, generator (cidr, rir, country)).
    """
    rir_cfg = cfg.get("rir", {})
    sources = rir_cfg.get("sources", {})
    cache_dir = os.path.join(cfg["paths"]["output_dir"], "rir_cache")

    records = []
    for rir_name, url in sources.items():
        try:
            path = download(rir_name, url, cache_dir)
            records.extend(parse_file(path))
        except Exception as exc:  # một RIR lỗi không chặn các RIR khác
            error(f"[RIR] {rir_name}: {exc}")

    exclude_index = ExcludeIndex(cfg["paths"].get("exclude"))

    # Mã hóa rir/quốc gia thành index để pack vào key 64-bit
    rir_names = sorted(sources)[:31]
    rir_index = {name: i for i, name in enumerate(rir_names)}
    country_names = []

    v4 = array.array("q")  # sort theo IP rồi prefix rồi rir rồi country
    v6 = []  # (int_ip, prefix, rir, country) — số lượng nhỏ
    for net, rir_name, country in iter_cidrs(
        records,
        countries=rir_cfg.get("countries") or None,
        min_prefix=rir_cfg.get("min_prefix", 8),
        max_prefix=rir_cfg.get("max_prefix", 24),
        split_to=rir_cfg.get("split_to", 24),
    ):
        if exclude_index.contains(net):
            continue
        if country not in country_names:
            if len(country_names) >= 65535:
                raise RuntimeError("Quá 65535 mã quốc gia — không thể pack key")
            country_names.append(country)
        if net.version == 4 and rir_name in rir_index:
            v4.append(_encode_v4_key(net, rir_index[rir_name],
                                     country_names.index(country)))
        else:
            v6.append((int(net.network_address), net.prefixlen, rir_name, country))

    v4_sorted = sorted(v4)
    v6_sorted = sorted(v6)
    del v4, records

    targets_path = cfg["paths"]["targets"]
    count = 0
    fd, tmp = tempfile.mkstemp(dir=os.path.dirname(targets_path) or ".",
                               prefix=".targets_")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            v4_iter = (_decode_v4_key(k, rir_names, country_names)
                       for k in v4_sorted)
            merged = heapq.merge(v4_iter, v6_sorted, key=lambda t: (t[0], t[1]))
            prev = None
            for int_ip, prefix, rir_name, country in merged:
                if (int_ip, prefix, rir_name, country) == prev:
                    continue  # dedupe khi sort đã gom trùng nhau
                prev = (int_ip, prefix, rir_name, country)
                cidr = f"{ipaddress.ip_address(int_ip)}/{prefix}"
                fh.write(f"{cidr}|{rir_name}|{country}\n")
                count += 1
        os.replace(tmp, targets_path)
    finally:
        if os.path.exists(tmp):
            os.remove(tmp)

    return count, read_targets(targets_path)


def find_cached(cache_dir):
    return sorted(glob.glob(os.path.join(cache_dir, "delegated-*-extended-latest")))

