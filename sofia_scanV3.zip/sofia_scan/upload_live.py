#!/usr/bin/env python3
"""Upload định kỳ output/t.txt (domain cửa hàng thật) + output/vul.txt
(domain dính vuln) lên GoFile → gửi link về WEBHOOK, MỖI FILE 1 TIN NHẮN
KÈM TÊN FILE + TÊN SCAN (`upload.title`, vd tên chiến dịch) để biết tin nào
là file nào (kèm theo tên biết bị).

NÂNG CẤP — CHỈ upload khi ĐỦ 2 ĐIỀU KIỆN cho ĐỢT upload:
  1. CÓ ÍT NHẤT 1 file có SỐ DÒNG thay đổi so với lần upload thành công gần nhất
     (so theo SỐ LƯỢNG dòng — thêm/bớt nhưng cùng số lượng → coi như không đổi).
  2. ĐÃ ĐỦ thời gian tối thiểu `interval` (mặc định 900s = 15 phút) kể từ
     lần upload thành công gần nhất.
  Trong một đợt, chỉ các file thay đổi mới được upload; mỗi file gửi 1 tin
  webhook riêng kèm tên file.

Trạng thái (số dòng từng file + mốc thời gian) lưu vào <output_dir>/upload_state.json
(cấu trúc {"files": {"t.txt": {"count":..., "last_upload_ts":...}, "vul.txt": {...}}};
state dạng cũ {"last_count", "last_upload_ts"} vẫn đọc được — tự chuyển sang t.txt) —
khởi động lại daemon không gây upload vội (vẫn tôn trọng 2 điều kiện).

Hai cách dùng:
  1. Tích hợp trong main.py (khuyến nghị):
       import upload_live
       upload_live.start_daemon(cfg)   # background thread, kiểm tra mỗi poll_interval giây
     Webhook lấy từ cfg['webhook'] (config.yaml, ghi đè bằng env SOFIA_WEBHOOK_URL),
     danh sách file upload lấy từ cfg['upload']['files'] (mặc định t.txt + vul.txt).
     placeholder trên webhook.
     placeholder trên webhook.
     placeholder trên webhook.

  2. Chạy riêng: python3 upload_live.py [--once] [--file ...] [--interval ...]
                 [--poll-interval ...] [--no-count-changed] [--title ...] [--desc ...]
     Nếu không truyền --file → upload t.txt + vul.txt theo config/config.yaml.
"""
import argparse
import json
import os
import sys
import threading
import time

import requests
import yaml

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)

from utils import file_io
from utils.logger import error, info, success, warn

INTERVAL_DEFAULT = 15 * 60   # điều kiện 2: thời gian TỐI THIỂU giữa 2 đợt upload (giây)
POLL_DEFAULT = 60            # tần suất kiểm tra file (giây)
STATE_FILENAME = "upload_state.json"
T_DEFAULT = os.path.join(BASE_DIR, "output", "t.txt")
CONFIG_PATH = os.path.join(BASE_DIR, "config", "config.yaml")
DEFAULT_TITLE = "SofiaScan"
# Tên file trong output_dir → mô tả hiển thị trên webhook (có thể ghi đè trong config)
DEFAULT_FILES = {
    "t.txt": "domain cửa hàng thật",
    "vul.txt": "domain dính vuln",
}


def load_webhook_config():
    """Trả về (url, type) — ưu tiên env SOFIA_WEBHOOK_URL > config.yaml."""
    url, kind = "", "generic"
    try:
        with open(CONFIG_PATH, encoding="utf-8") as fh:
            wh = (yaml.safe_load(fh) or {}).get("webhook") or {}
        kind = wh.get("type", "generic")
        url = wh.get("url") or ""
    except OSError:
        pass
    url = os.environ.get("SOFIA_WEBHOOK_URL") or url
    return url, kind


def gofile_servers():
    r = requests.get("https://api.gofile.io/servers", timeout=30)
    r.raise_for_status()
    data = (r.json() or {}).get("data") or {}
    servers = data.get("servers") or ([{"name": data["server"]}] if data.get("server") else [])
    return [s["name"] if isinstance(s, dict) else str(s) for s in servers]


def gofile_upload(path):
    """Upload anonymous lên GoFile, trả về link downloadPage. Thử lần lượt các server."""
    last_err = None
    for name in gofile_servers():
        try:
            with open(path, "rb") as fh:
                r = requests.post(
                    f"https://{name}.gofile.io/contents/uploadfile",
                    files={"file": fh},
                    timeout=600,
                )
            r.raise_for_status()
            body = r.json() or {}
            if body.get("status") == "ok":
                page = (body.get("data") or {}).get("downloadPage")
                if page:
                    return page
            last_err = RuntimeError(f"GoFile/{name}: phản hồi {body}")
        except requests.RequestException as exc:
            last_err = exc
    raise last_err or RuntimeError("GoFile: không có server khả dụng")


def send_webhook(url, kind, text):
    if kind == "discord":
        payload = {"content": text[:2000], "username": "SofiaScan"}
    else:  # slack | generic
        payload = {"text": text[:39000]}
    r = requests.post(url, json=payload, timeout=15)
    if r.status_code == 429:  # tôn trọng Retry-After (giống webhook.py)
        wait = min(float(r.headers.get("Retry-After", 5) or 5), 60)
        warn(f"webhook 429 — chờ {wait}s rồi thử lại")
        time.sleep(wait)
        r = requests.post(url, json=payload, timeout=15)
    r.raise_for_status()


def human_size(n):
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024 or unit == "GB":
            return f"{n:,.0f} {unit}" if unit == "B" else f"{n:,.1f} {unit}"
        n /= 1024.0


# ─────────────────────────── Trạng thái (state) ──────────────────────
# state mới: {"files": {"<tên file>": {"count": int, "last_upload_ts": float}}}
# state cũ:  {"last_count": int, "last_upload_ts": float} → tự quy về "t.txt"

def _load_state(path):
    """Đọc trạng thái từng file — {} nếu chưa có / lỗi / không hợp lệ."""
    try:
        with open(path, encoding="utf-8") as fh:
            data = json.load(fh)
    except (OSError, ValueError):
        return {}
    files = data.get("files") if isinstance(data, dict) else None
    if not isinstance(files, dict):
        files = {}
        # legacy: state cũ chỉ theo dõi t.txt
        if isinstance(data.get("last_count"), int):
            files["t.txt"] = {"count": data["last_count"],
                              "last_upload_ts": data.get("last_upload_ts")}
    out = {}
    for name, item in files.items():
        if not isinstance(item, dict) or not isinstance(item.get("count"), int):
            continue
        entry = {"count": item["count"]}
        if isinstance(item.get("last_upload_ts"), (int, float)):
            entry["last_upload_ts"] = item["last_upload_ts"]
        out[name] = entry
    return out


def _save_state(path, state):
    payload = {"files": state}
    try:
        file_io.atomic_write(path, json.dumps(payload, ensure_ascii=False, indent=2) + "\n")
    except OSError as exc:
        warn(f"upload_live: không ghi được state {path}: {exc}")


# ─────────────────────────── Logic upload ────────────────────────────

def _read_count(path):
    """Số dòng KHÔNG RỖNG trong file. None nếu file thiếu/rỗng."""
    try:
        if not os.path.exists(path) or os.path.getsize(path) == 0:
            return None
        with open(path, encoding="utf-8", errors="ignore") as fh:
            return sum(1 for ln in fh if ln.strip())
    except OSError:
        return None


def _dedupe_stable(path):
    """Loại dòng trùng trong file (giữ thứ tự).

    t.txt/vul.txt được pipeline append theo từng CIDR — chạy lại (--no-resume)
    sinh dòng trùng; dọn trước khi upload để file trên GoFile luôn sạch.
    Trả về True nếu đã ghi lại file.
    """
    try:
        with open(path, encoding="utf-8", errors="ignore") as fh:
            lines = [ln.rstrip("\n") for ln in fh]
    except OSError:
        return False
    seen, out = set(), []
    for line in lines:
        if line and line not in seen:
            seen.add(line)
            out.append(line)
    if len(out) == len(lines):
        return False
    try:
        file_io.atomic_write(path, "".join(o + "\n" for o in out))
        return True
    except OSError:
        return False


def _check_and_upload(files_map, url, kind, title, state, min_interval, count_changed):
    """Kiểm tra ĐỦ 2 ĐIỀU KIỆN rồi upload cả ĐỢT.

    files_map: dict TÊN FILE → (đường dẫn, mô tả) — thứ tự dict quyết định
    thứ tự upload. Điều kiện 1 áp dụng riêng từng file (số dòng thay đổi so
    với lần upload thành công gần nhất — lần đầu luôn coi là đổi); điều kiện 2
    áp dụng cho CẢ ĐỢT (≥ min_interval giây kể từ lần upload thành công gần nhất).

    Trả về (outcome, state_mới); outcome ∈ {'uploaded','skip_missing',
    'skip_count','skip_time'}. Raise nếu upload THỰC SỰ lỗi để worker báo
    webhook và thử lại chu kỳ sau.
    """
    now = time.time()
    changed, missing = [], []

    for name, (path, desc) in files_map.items():
        count = _read_count(path)
        if count is None:
            missing.append(name)
            info(f"upload_live: chưa có/rỗng {name} — bỏ qua file này")
            continue
        if _dedupe_stable(path):
            info(f"upload_live: đã loại dòng trùng trong {name}")
            count = _read_count(path) or 0
        prev = state.get(name) or {}
        last_count = prev.get("count")
        if count_changed and last_count is not None and count == last_count:
            info(f"upload_live: {name} số dòng không đổi ({count:,}) — "
                 f"chờ thay đổi (điều kiện 1)")
            continue
        changed.append((name, path, desc, count))

    if not changed:
        if missing and not state:
            return "skip_missing", state
        return "skip_count", state

    # Điều kiện 2 — đủ thời gian tối thiểu kể từ lần upload thành công gần nhất
    last_ts = max((entry.get("last_upload_ts") for entry in state.values()
                   if entry.get("last_upload_ts") is not None), default=None)
    if last_ts is not None and now - last_ts < min_interval:
        remain = int(min_interval - (now - last_ts))
        info(f"upload_live: chưa đủ {min_interval}s kể từ đợt upload trước "
             f"(còn ~{remain}s) — chờ (điều kiện 2)")
        return "skip_time", state

    # Đủ 2 điều kiện → upload từng file thay đổi + gửi 1 tin webhook/file
    uploaded_at = time.time()
    new_state = dict(state)
    for name, path, desc, count in changed:
        size = os.path.getsize(path)
        link = gofile_upload(path)
        success(f"upload_live: đã upload {name} → {link}")

        if url:
            emoji = "🚨" if "vul" in name.lower() else "📁"
            text = (f"{emoji} {title} — {name} ({desc})\n"
                    f"• {count:,} dòng, {human_size(size)}\n"
                    f"• Tải: {link}")
            try:
                send_webhook(url, kind, text)
                success(f"upload_live: đã gửi {name} về webhook")
            except Exception as exc:
                error(f"upload_live: gửi webhook {name} lỗi: {exc}")
        else:
            warn(f"upload_live: chưa cấu hình webhook — xem link {name} ở log")

        new_state[name] = {"count": count, "last_upload_ts": uploaded_at}
    return "uploaded", new_state


# ─────────────────────────── Daemon cho main.py ──────────────────────

def _worker(files_map, url, kind, title, state_path, min_interval,
            count_changed, poll_interval):
    state = _load_state(state_path)
    if state:
        info(f"upload_live: khôi phục state — {len(state)} file: "
             + ", ".join(f"{n}={v['count']:,}" for n, v in sorted(state.items())))
    state_ok = True  # chống spam: chỉ báo lỗi qua webhook khi chuyển OK → lỗi
    while True:
        try:
            outcome, state = _check_and_upload(
                files_map, url, kind, title, state, min_interval, count_changed)
            if outcome == "uploaded":
                _save_state(state_path, state)
            state_ok = True
        except Exception as exc:
            error(f"upload_live: {exc}")
            if state_ok:
                try:
                    send_webhook(url, kind,
                                 f"⚠️ {title} — upload lên GoFile THẤT BẠI "
                                 "(t.txt/vul.txt — sẽ thử lại chu kỳ sau)")
                except Exception:
                    pass
            state_ok = False
        time.sleep(poll_interval)


def _build_files_map(upload_cfg, output_dir):
    """files config → {tên file: (đường dẫn tuyệt đối, mô tả)}.

    Mặc định t.txt + vul.txt; người dùng có thể ghi đè/hạn chế qua
    `upload.files` (dict tên file → mô tả hiển thị trên webhook).
    """
    files_raw = (upload_cfg or {}).get("files") or DEFAULT_FILES
    out = {}
    for name, desc in files_raw.items():
        if not name or not isinstance(name, str):
            continue
        path = os.path.join(output_dir, name)
        out[name] = (path, str(desc) if desc else name)
    return out


def start_daemon(cfg):
    """Khởi động background thread upload t.txt + vul.txt (tích hợp main.py).

    CHỈ upload khi ĐỦ 2 ĐIỀU KIỆN:
      1. có ≥1 file trong `upload.files` thay đổi SỐ DÒNG so với lần upload thành công;
      2. đã đủ cfg['upload']['interval'] giây kể từ lần upload thành công gần nhất.

    cfg: dict config đã merge (DEFAULT_CONFIG + config.yaml):
      - cfg['webhook']['url'] / ['type']  — SOFIA_WEBHOOK_URL ghi đè
      - cfg['paths']['output_dir']        — nơi chứa t.txt/vul.txt + upload_state.json
      - cfg['upload']['enabled'/'title'/'interval'/'poll_interval'/'count_changed'/'files']
        (legacy 'only_changed' — so hash — được chuyển thành count_changed)
    Trả về Thread (daemon) hoặc None nếu bị tắt / thiếu webhook.
    """
    upload_cfg = cfg.get("upload") or {}
    if not upload_cfg.get("enabled", True):
        info("upload_live: bị tắt (upload.enabled=false)")
        return None

    wh = cfg.get("webhook") or {}
    url = os.environ.get("SOFIA_WEBHOOK_URL") or wh.get("url") or ""
    kind = wh.get("type", "generic")
    if not url:
        warn("upload_live: chưa có webhook.url trong config — không khởi động uploader")
        return None

    title = str(upload_cfg.get("title") or DEFAULT_TITLE)
    min_interval = max(60, int(upload_cfg.get("interval", INTERVAL_DEFAULT)))
    poll_interval = max(10, int(upload_cfg.get("poll_interval", POLL_DEFAULT)))
    count_changed = upload_cfg.get("count_changed", True)
    if "count_changed" not in upload_cfg and "only_changed" in upload_cfg:
        count_changed = bool(upload_cfg["only_changed"])  # legacy → count
    count_changed = bool(count_changed)
    output_dir = cfg["paths"]["output_dir"]
    files_map = _build_files_map(upload_cfg, output_dir)
    state_path = os.path.join(output_dir, STATE_FILENAME)

    t = threading.Thread(
        target=_worker, name="upload-live", daemon=True,
        args=(files_map, url, kind, title, state_path, min_interval,
              count_changed, poll_interval),
    )
    t.start()
    info(f"upload_live: daemon khởi động — files={', '.join(files_map)}; "
         f"tối thiểu {min_interval}s/đợt, kiểm tra mỗi {poll_interval}s, "
         f"chỉ upload khi số dòng đổi={count_changed}, title={title!r}, "
         f"webhook type={kind}")
    return t


# ─────────────────────────── Chạy độc lập (CLI) ──────────────────────

def parse_args():
    ap = argparse.ArgumentParser(
        description="Upload t.txt (domain cửa hàng thật) + vul.txt (domain dính vuln) "
                    "lên GoFile — CHỈ khi ĐỦ 2 điều kiện: số dòng thay đổi + đã đủ "
                    "thời gian tối thiểu")
    ap.add_argument("--file", default="",
                    help="đường dẫn file upload (mặc định: t.txt + vul.txt trong "
                         "output/ theo config/config.yaml)")
    ap.add_argument("--desc", default="",
                    help="mô tả file khi dùng --file (hiển thị trên webhook)")
    ap.add_argument("--title", default=DEFAULT_TITLE,
                    help="tên scan hiển thị trên webhook (mặc định SofiaScan)")
    ap.add_argument("--interval", type=int, default=INTERVAL_DEFAULT,
                    help="điều kiện 2 — thời gian TỐI THIỂU (giây) giữa 2 đợt upload "
                         "(mặc định 900 = 15 phút)")
    ap.add_argument("--poll-interval", type=int, default=POLL_DEFAULT,
                    help="tần suất kiểm tra file (giây, mặc định 60)")
    ap.add_argument("--count-changed", action=argparse.BooleanOptionalAction, default=True,
                    help="điều kiện 1 — chỉ upload khi SỐ dòng thay đổi (mặc định bật; "
                         "--no-count-changed = upload theo chu kỳ như bản cũ)")
    ap.add_argument("--webhook-url", default="", help="ghi đè URL webhook")
    ap.add_argument("--once", action="store_true",
                    help="chạy 1 lần rồi thoát (vẫn kiểm tra 2 điều kiện)")
    return ap.parse_args()


def main():
    args = parse_args()
    url = args.webhook_url
    kind = "generic"
    if not url:
        url, kind = load_webhook_config()

    if args.file:  # chế độ 1 file (legacy CLI)
        desc = args.desc or os.path.basename(args.file)
        files_map = {os.path.basename(args.file): (args.file, desc)}
        output_dir = os.path.dirname(args.file) or "."
    else:          # chế độ mặc định — t.txt + vul.txt theo config
        output_dir = os.path.join(BASE_DIR, "output")
        try:
            with open(CONFIG_PATH, encoding="utf-8") as fh:
                up = (yaml.safe_load(fh) or {}).get("upload") or {}
        except OSError:
            up = {}
        title = str(up.get("title") or args.title)
        files_map = _build_files_map(up, output_dir)
        info(f"upload_live: files={', '.join(files_map)} title={title!r}")

    state_path = os.path.join(output_dir, STATE_FILENAME)
    info(f"upload_live: files={', '.join(files_map)} tối thiểu={args.interval}s "
         f"kiểm tra={args.poll_interval}s count_changed={args.count_changed} "
         f"webhook={'bật' if url else 'tắt'} type={kind} title={args.title!r}")

    state = _load_state(state_path)
    while True:
        try:
            outcome, state = _check_and_upload(
                files_map, url, kind, args.title, state, args.interval,
                args.count_changed)
            if outcome == "uploaded":
                _save_state(state_path, state)
        except KeyboardInterrupt:
            raise
        except Exception as exc:
            error(f"upload_live: {exc}")
        if args.once:
            return 0
        time.sleep(args.poll_interval)


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        error("upload_live: dừng bởi người dùng (Ctrl+C)")
        sys.exit(130)
