# -*- coding: utf-8 -*-
"""
rate_limiter.py — Bộ điều tiết tốc độ quét THÍCH ỨNG (anti-block) cho Sofia-iot.

Mục tiêu của module: cho phép quét SỐ LƯỢNG LỚN dải IP mà HẠN CHẾ bị chặn
(fail2ban / IPS / rate-limit ở biên mạng / firewall thiết bị) bằng cách:

  * Điều tiết pps theo phản hồi thực tế (AIMD — additive-increase /
    multiplicative-decrease):
        - batch quét "sạch" (có mục tiêu, không lỗi) → tăng pps dần.
        - nhiều batch liên tiếp 0 kết quả, hoặc zmap/masscan stderr có
          dấu hiệu bị chặn → giảm mạnh pps + cooldown luỹ tiến (backoff).
  * Xoay IP nguồn (SourceRotator) — zmap `-S` / masscan `--source-ip`.
  * Hỗ trợ chia shard để nhiều máy cùng quét một kế hoạch lớn
    (zmap `--shards/--shard`, masscan `--shard x/N`).
  * Cung cấp jitter + thứ tự cổng ngẫu nhiên (dùng ở target_generator) để
    phá vân tay nhịp quét đều đặn — tín hiệu dễ bị IDS bắt nhất.

Module thuần logic, KHÔNG tự mở socket; an toàn khi import. Thread-safe cho
các truy cập trạng thái (dùng trong pipeline đa luồng fingerprint/exploit).
"""

import logging
import random
import re
import threading
import time

log = logging.getLogger("sofia.rate_limiter")


# ══════════════════════════════════════════════════════════════════════════
# Token bucket — pacing phía Python (dùng cho pha request HTTP nếu cần)
# ══════════════════════════════════════════════════════════════════════════
class TokenBucket:
    """Bể token đơn giản (thread-safe). `rate` = token/giây."""

    def __init__(self, rate, burst=None):
        self.rate = max(0.001, float(rate))
        self.burst = float(burst if burst is not None else max(1.0, self.rate))
        self._tokens = self.burst
        self._last = time.monotonic()
        self._lock = threading.Lock()

    def set_rate(self, rate):
        with self._lock:
            self.rate = max(0.001, float(rate))

    def _refill(self):
        now = time.monotonic()
        self._tokens = min(self.burst, self._tokens + (now - self._last) * self.rate)
        self._last = now

    def take(self, n=1):
        """Lấy `n` token. Trả về số giây phải chờ (0 = lấy được ngay)."""
        with self._lock:
            self._refill()
            self._tokens -= n
            return 0.0 if self._tokens >= 0 else (-self._tokens) / self.rate

    def wait(self, n=1):
        need = self.take(n)
        if need > 0:
            time.sleep(need)
        return need


# ══════════════════════════════════════════════════════════════════════════
# Bộ điều tiết thích ứng (AIMD + cooldown backoff)
# ══════════════════════════════════════════════════════════════════════════
class AdaptiveRate:
    """
    Máy trạng thái điều tiết pps cho quét dải lớn.

    Vòng đời:
        ctl = AdaptiveRate(start=500, min_rate=50, max_rate=4000)
        pps = ctl.current_rate()            # đưa vào --rate / -r
        ...
        ctl.record_success()                # batch có kết quả → tăng pps
        ctl.record_zero_batch("0 target")   # batch rỗng → đếm; đủ ngưỡng → chặn
        ctl.record_block("sendto failed")   # dấu hiệu chặn rõ ràng → giảm + cooldown
        if ctl.cooldown_remaining(): time.sleep(...)

    Tất cả thao tác có khoá; an toàn khi gọi từ nhiều luồng.
    """

    def __init__(self, start=500.0, min_rate=50.0, max_rate=4000.0,
                 increase=1.15, decrease=0.5, zero_batches=2,
                 backoff_min=30.0, backoff_max=600.0, backoff_factor=2.0,
                 seed=0):
        self.min_rate = max(1.0, float(min_rate))
        self.max_rate = max(self.min_rate, float(max_rate))
        self.start = min(self.max_rate, max(self.min_rate, float(start)))
        self.rate = self.start
        self.increase = max(1.0, float(increase))
        self.decrease = min(1.0, max(0.05, float(decrease)))
        self.zero_batches = max(1, int(zero_batches))
        self.backoff_min = max(0.0, float(backoff_min))
        self.backoff_max = max(self.backoff_min, float(backoff_max))
        self.backoff_factor = max(1.0, float(backoff_factor))
        self._rng = random.Random(int(seed)) if int(seed) > 0 else random.Random()
        self._lock = threading.RLock()
        self._consecutive_zero = 0
        self._consecutive_block = 0
        self._cooldown_until = 0.0
        self.block_events = 0
        self.batches_clean = 0
        self.batches_zero = 0
        self.total_batches = 0
        self.last_reason = ""

    # ── Trạng thái ──────────────────────────────────────────────────────
    def current_rate(self):
        with self._lock:
            return self.rate

    def cooldown_remaining(self):
        with self._lock:
            return max(0.0, self._cooldown_until - time.monotonic())

    def in_cooldown(self):
        return self.cooldown_remaining() > 0.0

    # ── Phản hồi ────────────────────────────────────────────────────────
    def record_success(self):
        """Batch tìm thấy mục tiêu → mạng bình thường: tăng pps dần (additive)."""
        with self._lock:
            self.batches_clean += 1
            self.total_batches += 1
            self._consecutive_zero = 0
            self._consecutive_block = max(0, self._consecutive_block - 1)
            self.rate = min(self.max_rate, max(self.rate, self.rate * self.increase))
            return self.rate

    def record_zero_batch(self, reason="0 kết quả"):
        """Batch 0 kết quả. Đủ ngưỡng LIÊN TIẾP → coi là dấu hiệu bị chặn."""
        with self._lock:
            self.batches_zero += 1
            self.total_batches += 1
            self._consecutive_zero += 1
            if self._consecutive_zero >= self.zero_batches:
                return self._apply_block_locked(reason)
            return self.rate

    def record_block(self, reason="block signal"):
        """Dấu hiệu bị chặn rõ ràng (stderr công cụ) → giảm mạnh + cooldown."""
        with self._lock:
            return self._apply_block_locked(reason)

    def record_error(self):
        """Lỗi công cụ KHÔNG phải dấu hiệu chặn — giảm nhẹ, không cooldown."""
        with self._lock:
            self.rate = max(self.min_rate, self.rate * 0.9)
            return self.rate

    def _apply_block_locked(self, reason):
        self.block_events += 1
        self._consecutive_block += 1
        self._consecutive_zero = 0
        self.last_reason = str(reason)
        self.rate = max(self.min_rate, self.rate * self.decrease)
        cooldown = min(self.backoff_max,
                       self.backoff_min * (self.backoff_factor ** (self._consecutive_block - 1)))
        cooldown *= self._rng.uniform(0.8, 1.2)          # jitter — tránh nhịp đều
        self._cooldown_until = time.monotonic() + cooldown
        log.warning("Anti-block: nghi bị chặn (%s) → pps=%.0f, cooldown=%.0fs",
                    reason, self.rate, cooldown)
        return self.rate

    # ── Quan sát ────────────────────────────────────────────────────────
    def snapshot(self):
        with self._lock:
            return {
                "rate_pps": round(self.rate, 1),
                "cooldown_s": round(max(0.0, self._cooldown_until - time.monotonic()), 1),
                "block_events": self.block_events,
                "batches_clean": self.batches_clean,
                "batches_zero": self.batches_zero,
                "last_reason": self.last_reason,
            }


# ══════════════════════════════════════════════════════════════════════════
# Xoay IP nguồn
# ══════════════════════════════════════════════════════════════════════════
class SourceRotator:
    """Xoay vòng danh sách IP nguồn (zmap -S / masscan --source-ip/--adapter-ip)."""

    def __init__(self, ips=None, seed=0):
        self.ips = [str(x).strip() for x in (ips or []) if str(x).strip()]
        self._idx = 0
        self._lock = threading.Lock()

    def next(self):
        with self._lock:
            if not self.ips:
                return ""
            ip = self.ips[self._idx % len(self.ips)]
            self._idx += 1
            return ip

    def __bool__(self):
        return bool(self.ips)

    def __len__(self):
        return len(self.ips)


# ══════════════════════════════════════════════════════════════════════════
# Helpers: shard / source-port / phát hiện dấu hiệu bị chặn
# ══════════════════════════════════════════════════════════════════════════
_SHARD_RE = re.compile(r"^\s*(\d+)\s*/\s*(\d+)\s*$")


def parse_shard(spec):
    """'1/4' → (index, total) với index 1-based. Trả None nếu rỗng/sai."""
    if not spec:
        return None
    m = _SHARD_RE.match(str(spec))
    if not m:
        log.warning("SCAN_SHARD không hợp lệ: %r (định dạng 'x/N')", spec)
        return None
    idx, total = int(m.group(1)), int(m.group(2))
    if total < 1 or idx < 1 or idx > total:
        log.warning("SCAN_SHARD ngoài miền: %r (cần 1 <= x <= N)", spec)
        return None
    return idx, total


def masscan_source_port_ok(spec):
    """
    masscan yêu cầu source-port là 1 cổng hoặc dải CĂN lũy thừa 2
    (VD '40000-40063' / '49152-65535'). Trả True nếu chấp nhận được.
    """
    if not spec:
        return False
    s = str(spec).strip()
    if s.isdigit():
        return 1 <= int(s) <= 65535
    m = re.match(r"^(\d+)-(\d+)$", s)
    if not m:
        return False
    lo, hi = int(m.group(1)), int(m.group(2))
    if not (0 <= lo <= hi <= 65535):
        return False
    span = hi - lo + 1
    return lo % span == 0 and (span & (span - 1)) == 0   # lo căn + span = 2^k


# Dấu hiệu bị chặn/giới hạn phía mạng (ít nhiều đặc trưng của zmap/masscan).
_BLOCK_RE = re.compile(
    r"(sendto|transmit|tx|recv|rx)[^\n]{0,40}(fail|error|refus|drop|permission)|"
    r"resource temporarily unavailable|temporarily unavailable|eagain|"
    r"no buffer space|message too long|network is unreachable|no route to host|"
    r"host unreachable|too many open files|cannot allocate memory|"
    r"rate.?limit|throttl|blocked|blackhole|hitrate (?:is )?too low|"
    r"min.?hitrate",
    re.I)

# Lỗi MÔI TRƯỜNG (không phải mạng chặn nhưng scan không chạy được).
_ENV_RE = re.compile(
    r"permission denied|must be (?:run(?:ning)? as )?root|are you root|"
    r"need to specify seed|unknown option|unrecognized option|invalid range|"
    r"no interfaces found|could not (?:init|open|load)|failed to (?:init|open|load)",
    re.I)


def scan_block_signal(stderr_text):
    """
    Phân tích stderr của zmap/masscan → (nghi_block, lý do).
    Ưu tiên nhận diện lỗi môi trường trước (permission/root) để KHÔNG hiểu
    nhầm thành bị chặn mạng; sau đó mới tới dấu hiệu mạng.
    """
    text = (stderr_text or "").strip()
    if not text:
        return False, ""
    env = _ENV_RE.search(text)
    if env:
        return False, "env: %s" % env.group(0)[:80]
    m = _BLOCK_RE.search(text)
    if m:
        return True, m.group(0)[:100]
    return False, ""


# ══════════════════════════════════════════════════════════════════════════
# Singleton toàn cục (dùng chung target_generator + main)
# ══════════════════════════════════════════════════════════════════════════
_lock = threading.Lock()
_controller = None
_rotator = None
_configured = False


def configure_from_config():
    """Khởi tạo controller + rotator từ config.py (lazy import tránh vòng)."""
    global _controller, _rotator, _configured
    from config import (
        SCAN_RATE_START, SCAN_RATE_MIN, SCAN_RATE_MAX, SCAN_RATE_INCREASE,
        SCAN_RATE_DECREASE, SCAN_BLOCK_ZERO_BATCHES, SCAN_BLOCK_BACKOFF_MIN,
        SCAN_BLOCK_BACKOFF_MAX, SCAN_BLOCK_BACKOFF_FACTOR, SCAN_SEED, SOURCE_IPS,
    )
    with _lock:
        _controller = AdaptiveRate(
            start=SCAN_RATE_START, min_rate=SCAN_RATE_MIN, max_rate=SCAN_RATE_MAX,
            increase=SCAN_RATE_INCREASE, decrease=SCAN_RATE_DECREASE,
            zero_batches=SCAN_BLOCK_ZERO_BATCHES,
            backoff_min=SCAN_BLOCK_BACKOFF_MIN,
            backoff_max=SCAN_BLOCK_BACKOFF_MAX,
            backoff_factor=SCAN_BLOCK_BACKOFF_FACTOR, seed=SCAN_SEED)
        _rotator = SourceRotator(SOURCE_IPS, seed=SCAN_SEED)
        _configured = True
        log.info("Rate limiter: pps=%.0f (min=%.0f max=%.0f) adaptive, %d IP nguồn",
                 _controller.current_rate(), _controller.min_rate,
                 _controller.max_rate, len(_rotator))
    return _controller


def ensure_configured():
    if not _configured:
        configure_from_config()
    return _controller


def get_controller():
    return ensure_configured()


def get_rotator():
    ensure_configured()
    return _rotator


def reset():
    """Xoá singleton (dùng cho test hoặc khi CLI ghi đè cấu hình)."""
    global _controller, _rotator, _configured
    with _lock:
        _controller = None
        _rotator = None
        _configured = False


def configure(adaptive=True, start=500.0, min_rate=50.0, max_rate=4000.0,
              increase=1.15, decrease=0.5, zero_batches=2,
              backoff_min=30.0, backoff_max=600.0, backoff_factor=2.0,
              source_ips=None, seed=0):
    """Ghi đè cấu hình controller/rotator (dùng bởi CLI)."""
    global _controller, _rotator, _configured
    with _lock:
        _controller = AdaptiveRate(start=start, min_rate=min_rate,
                                   max_rate=max_rate, increase=increase,
                                   decrease=decrease, zero_batches=zero_batches,
                                   backoff_min=backoff_min,
                                   backoff_max=backoff_max,
                                   backoff_factor=backoff_factor, seed=seed)
        _rotator = SourceRotator(source_ips or [], seed=seed)
        _configured = True
    return _controller


__all__ = [
    "TokenBucket", "AdaptiveRate", "SourceRotator",
    "parse_shard", "masscan_source_port_ok", "scan_block_signal",
    "configure_from_config", "ensure_configured", "get_controller",
    "get_rotator", "reset", "configure",
]
