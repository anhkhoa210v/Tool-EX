# -*- coding: utf-8 -*-
"""
Giai đoạn 4: Webhook notification.

Khi phát hiện RCE (hoặc bất kỳ trạng thái đáng chú ý nào nếu NOTIFY_ALL=True),
Sofia-iot gửi 1 POST JSON tới WEBHOOK_URL (cấu hình trong config.py hoặc biến
môi trường SOFIA_WEBHOOK_URL). Dùng thư viện chuẩn urllib — không phụ thuộc
`requests`, phù hợp khi chạy trên máy tối giản / trong container.

Payload mẫu:
    {
      "tool": "sofia-iot | sofiaRt7x9Qm", "type": "iot-vulnerability",
      "timestamp": "2026-09-09T12:00:00Z",
      "finding": {"cve": "...", "host": "...", "port": 80, "status": "RCE_CONFIRMED", ...}
    }

Định danh máy gửi: mỗi máy chạy Sofia-iot mang một hậu tố ngẫu nhiên
"sofia" + 7 ký tự (vd "sofiaRt7x9Qm") để khi nhiều máy cùng báo cáo về một
webhook vẫn phân biệt được nguồn gửi.
"""

import hashlib
import hmac
import json
import logging
import os
import secrets
import string
import time
import urllib.error
import urllib.request

from config import (
    NOTIFY_ALL,
    RESULTS_DIR,
    WEBHOOK_RETRY_ATTEMPTS,
    WEBHOOK_RETRY_BACKOFF,
    WEBHOOK_SECRET,
    WEBHOOK_TIMEOUT,
    WEBHOOK_URL,
)

log = logging.getLogger("sofia.webhook")


# ── Định danh máy gửi báo cáo ───────────────────────────────────────────
# Mỗi máy chạy Sofia-iot có một hậu tố "sofia" + 7 ký tự ngẫu nhiên để các
# báo cáo webhook từ nhiều máy khác nhau phân biệt được nguồn gửi. Hậu tố
# được sinh MỘT lần rồi lưu xuống results/machine_id, nhờ đó cùng một máy
# giữ nguyên định danh qua các lần chạy. Có thể ghi đè bằng biến môi trường
# SOFIA_MACHINE_TAG (giá trị dùng nguyên văn, vd "sofiaRt7x9Qm").
_MACHINE_TAG_FILE = os.path.join(RESULTS_DIR, "machine_id")
_TAG_ALPHABET = string.ascii_letters + string.digits


def _random_suffix(length=7):
    """Sinh hậu tố ngẫu nhiên gồm chữ + số (mặc định 7 ký tự)."""
    return "".join(secrets.choice(_TAG_ALPHABET) for _ in range(length))


def _load_machine_tag():
    """
    Trả về hậu tố định danh máy: 'sofia' + 7 ký tự ngẫu nhiên (ổn định).
    Thứ tự ưu tiên: biến môi trường SOFIA_MACHINE_TAG → file results/machine_id
    → sinh mới (và lưu lại). Nếu không ghi được file thì vẫn dùng giá trị
    vừa sinh cho tiến trình hiện tại.
    """
    tag = os.environ.get("SOFIA_MACHINE_TAG", "").strip()
    if tag:
        return tag
    try:
        with open(_MACHINE_TAG_FILE, "r", encoding="utf-8") as fh:
            tag = fh.read().strip()
        if tag:
            return tag
    except OSError:
        pass
    tag = "sofia" + _random_suffix()
    try:
        os.makedirs(os.path.dirname(_MACHINE_TAG_FILE), exist_ok=True)
        with open(_MACHINE_TAG_FILE, "w", encoding="utf-8") as fh:
            fh.write(tag)
    except OSError as exc:
        log.warning("Không lưu được định danh máy %s: %r", _MACHINE_TAG_FILE, exc)
    return tag


MACHINE_TAG = _load_machine_tag()          # vd "sofiaRt7x9Qm"
TOOL_NAME = "sofia-iot | " + MACHINE_TAG    # field JSON "tool"
DISPLAY_NAME = "Sofia-iot | " + MACHINE_TAG  # tiêu đề / username trên Discord

# Trạng thái "đáng báo" — luôn gửi webhook
_ALWAYS_NOTIFY = {"RCE_CONFIRMED", "RCE_PROBABLE", "CONFIRMED", "FINGERPRINT_ONLY"}


def _is_discord(url):
    """True nếu URL là webhook Discord (cần payload đặc biệt)."""
    return ("discord.com/api/webhooks" in url or "discordapp.com/api/webhooks" in url)


def _discordify(payload):
    """
    Chuyển payload JSON thường → định dạng webhook Discord.
    Discord chỉ chấp nhận các field hợp lệ (content, username, ...); field lạ
    như tool/type/finding sẽ bị trả HTTP 400 "Invalid Form Body". Nội dung
    được rút gọn để không vượt giới hạn 2000 ký tự của content.
    """
    ptype = payload.get("type")
    if ptype == "iot-vulnerability":
        f = payload.get("finding", {})
        lines = [
            "**%s — phát hiện lỗ hổng**" % DISPLAY_NAME,
            "CVE      : `%s`" % f.get("cve", "?"),
            "Tên      : %s" % (f.get("name") or "?"),
            "Mục tiêu : `%s:%s`" % (f.get("host", "?"), f.get("port", "?")),
            "Trạng thái : `%s`" % f.get("status", "?"),
            "Thiết bị : %s" % (f.get("device") or "?"),
        ]
        ev = (f.get("evidence") or "").strip()
        if ev:
            lines.append("Bằng chứng : `%s`" % ev[:600])
    elif ptype == "scan-phase":
        p = payload.get("phase", {})
        lines = [
            "**%s — %s**" % (DISPLAY_NAME, p.get("event") or "cập nhật tiến độ"),
        ]
        msg = (p.get("message") or "").strip()
        if msg:
            lines.append(msg[:1700])
        if p.get("batch_index") is not None:
            lines.append("Batch %d/%d · xong %d/%d dải /16" % (
                p.get("batch_index"), p.get("batch_total"),
                p.get("done"), p.get("total")))
    else:
        s = payload.get("stats", {})
        lines = ["**%s — tóm tắt đợt quét**" % DISPLAY_NAME,
                 "Tổng findings : %d" % s.get("total_findings", 0)]
        for k, v in (s.get("by_status") or {}).items():
            lines.append("- `%s` : %d" % (k, v))
        if s.get("ranges_done") is not None:
            lines.append("Dải /16 : %d/%d" % (s.get("ranges_done"), s.get("ranges_total")))
    content = "\n".join(lines)[:1900]
    return {"content": content, "username": DISPLAY_NAME}


def _sign_payload(data, secret=None):
    """
    HMAC-SHA256 của body (bytes) bằng WEBHOOK_SECRET (hoặc secret truyền vào).
    Trả về hex digest; chuỗi rỗng nếu chưa cấu hình secret → receiver có thể
    bỏ qua xác thực (tương thích ngược với webhook không có HMAC).
    """
    secret = WEBHOOK_SECRET if secret is None else secret
    if not secret:
        return ""
    return hmac.new(secret.encode("utf-8"), data, hashlib.sha256).hexdigest()


def _post_json(url, payload, timeout=None):
    """
    POST JSON tới url với HMAC signature + retry/backoff (P0 — 0.3):
      - HTTP 2xx                → True
      - HTTP 4xx                → False (payload bị từ chối — không retry)
      - lỗi mạng / HTTP >= 500  → retry tối đa WEBHOOK_RETRY_ATTEMPTS lần,
                                  ngủ backoff*2^n giây giữa các lần
      - hết lượt                → False nếu từng nhận HTTP >= 500; None nếu
                                 toàn bộ là lỗi mạng/timeout
    Khi WEBHOOK_SECRET khác rỗng, header X-Sofia-Signature: sha256=<hex>
    được thêm vào để receiver xác thực nguồn gửi (chống giả mạo finding).
    """
    timeout = WEBHOOK_TIMEOUT if timeout is None else timeout
    data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    attempts = max(1, WEBHOOK_RETRY_ATTEMPTS)
    sig = _sign_payload(data)
    last = None
    for attempt in range(1, attempts + 1):
        req = urllib.request.Request(url, data=data, method="POST")
        req.add_header("Content-Type", "application/json")
        req.add_header("User-Agent", "sofia-iot/1.0")
        if sig:
            req.add_header("X-Sofia-Signature", "sha256=" + sig)
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                if 200 <= resp.status < 300:
                    return True
                last = False
        except urllib.error.HTTPError as exc:
            last = False
            if 400 <= exc.code < 500:
                log.warning("Webhook từ chối (HTTP %d): %s — không retry", exc.code, url)
                return False
            log.warning("Webhook lỗi HTTP %d (lần %d/%d): %s",
                        exc.code, attempt, attempts, url)
        except Exception as exc:
            log.warning("Webhook gửi thất bại (lần %d/%d): %s — %s",
                        attempt, attempts, url, exc)
        if attempt < attempts:
            time.sleep(WEBHOOK_RETRY_BACKOFF * (2 ** (attempt - 1)))
    log.error("Webhook %s thất bại sau %d lần thử", url, attempts)
    return last


def notify(finding, notify_all=None, url=None):
    """
    Gửi 1 finding lên webhook nếu trạng thái đáng báo (hoặc notify_all=True).
    `finding` là dict kết quả của verifier. Trả về True/False/None như _post_json,
    hoặc None ngay nếu chưa cấu hình WEBHOOK_URL.
    notify_all/url = None → dùng giá trị trong module (cho phép override runtime).
    """
    if notify_all is None:
        notify_all = NOTIFY_ALL
    if url is None:
        url = WEBHOOK_URL
    if not url:
        return None
    status = finding.get("status", "")
    if status not in _ALWAYS_NOTIFY and not notify_all:
        return None

    payload = {
        "tool": TOOL_NAME,
        "type": "iot-vulnerability",
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "finding": finding,
    }
    if _is_discord(url):
        payload = _discordify(payload)
    ok = _post_json(url, payload)
    log.info("Webhook finding %s %s → %s", finding.get("host"), status,
             "OK" if ok else ("HTTP-lỗi" if ok is False else "FAIL"))
    return ok


def notify_summary(stats, url=None):
    """
    (Tùy chọn) Gửi bản tóm tắt cuối đợt quét: số host quét, số RCE, ...
    Dùng khi NOTIFY_ALL=False nhưng vẫn muốn biết pipeline đã chạy xong.
    url=None → dùng WEBHOOK_URL hiện tại của module.
    """
    if url is None:
        url = WEBHOOK_URL
    if not url:
        return None
    payload = {
        "tool": TOOL_NAME,
        "type": "scan-summary",
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "stats": stats,
    }
    if _is_discord(url):
        payload = _discordify(payload)
    return _post_json(url, payload)


def notify_phase(event, message, phase=None, url=None):
    """
    (Nâng cấp) Gửi thông báo TIẾN ĐỘ pipeline — batch /16 bắt đầu/hoàn tất,
    discovery xong, exploit xong... Payload type="scan-phase".

    `phase` (dict, tùy chọn): batch_index, batch_total, done, total,
    findings, rce — dùng để vẽ tiến độ trên Discord/khách.
    Trả về True/False/None như _post_json; None nếu chưa cấu hình URL.
    """
    if url is None:
        url = WEBHOOK_URL
    if not url:
        return None
    payload = {
        "tool": TOOL_NAME,
        "type": "scan-phase",
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "phase": {
            "event": event,
            "message": message,
            **(phase or {}),
        },
    }
    if _is_discord(url):
        payload = _discordify(payload)
    return _post_json(url, payload)


__all__ = ["notify", "notify_summary", "notify_phase", "NOTIFY_ALL", "WEBHOOK_URL",
           "WEBHOOK_SECRET", "MACHINE_TAG", "TOOL_NAME", "DISPLAY_NAME",
           "_sign_payload", "_post_json"]








