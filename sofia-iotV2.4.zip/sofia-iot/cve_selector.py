# -*- coding: utf-8 -*-
"""
cve_selector.py — ENGINE CHỌN CVE THÔNG MINH (nâng cấp cơ chế chọn CVE).

Vấn đề của cơ chế cũ:
  * `PORT_CVE_MAP` gán MỌI CVE của cổng cho host, rồi cắt top-N theo CVSS →
    bắn CVE lệch vendor (dương giả hàng loạt) và cắt mất CVE ĐÚNG nhưng điểm
    CVSS thấp hơn (âm giả).
  * Không dùng version/phiên bản đã fingerprint được để loại CVE ngoài khoảng.
  * Không phân biệt CVE có PoC chạy được (high) với CVE chỉ version-only (low).

Giải pháp: chấm ĐIỂM KHẢ DỤNG cho từng (CVE × fingerprint) theo bằng chứng:
  severity(CVSS) + vendor/platform/ssh khớp fingerprint + version trong khoảng
  + cổng khớp + độ tin cậy module + KEV − (lệch vendor) − (cần auth mà thiếu cred)
  − (chỉ fingerprint). CVE có version NGOÀI khoảng bị LOẠI cứng.

API chính:
  score_cve(cve, info, port)          → dict {cve, score, reasons, excluded, ...}
  rank_candidates(cves, info, port)   → list dict đã sắp giảm dần theo score
  select(cves, info, port, ...)       → (kept, suppressed) sau gating top-N/min-score
  explain(ranked, limit)              → chuỗi log nhiều dòng

Tất cả trọng số có thể override qua config (CVE_SELECT_WEIGHTS) — xem config.py.
Hàm thuần (pure), không I/O mạng → test offline dễ.
"""

import cve_intel

# ── Trọng số mặc định (override được qua config.CVE_SELECT_WEIGHTS) ──────
DEFAULT_WEIGHTS = {
    "cvss": 4.0,          # (cvss/10) * w  → 9.8 ⇒ 3.92
    "vendor": 6.0,        # khớp marker VENDOR (bằng chứng mạnh)
    "platform": 2.5,      # khớp marker NỀN TẢNG (goahead/boa/...)
    "ssh": 5.0,           # khớp marker SSH server
    "version_in": 5.0,    # version nằm trong khoảng bị ảnh hưởng
    "port": 1.5,          # cổng phát hiện thuộc "ports" của CVE
    "reliability_high": 3.0,
    "reliability_medium": 1.0,
    "reliability_low": 0.0,
    "kev": 1.5,
    "mismatch": -6.0,     # CVE chỉ định vendor khác hẳn fingerprint
    "requires_auth": -2.0,
    "fingerprint_only": -2.0,
    "explicit": 100.0,    # CVE khai tay (lab override) — luôn giữ
}

_RELIABILITY_KEY = {
    "high": "reliability_high",
    "medium": "reliability_medium",
    "low": "reliability_low",
}


def _weights():
    """Trọng số hiệu dụng: mặc định, ghi đè bởi config.CVE_SELECT_WEIGHTS nếu có."""
    w = dict(DEFAULT_WEIGHTS)
    try:
        import config
        override = getattr(config, "CVE_SELECT_WEIGHTS", None)
        if isinstance(override, dict):
            w.update({k: float(v) for k, v in override.items() if k in w})
    except Exception:  # noqa: BLE001 — thiếu config vẫn chạy
        pass
    return w


def _marker_set(info):
    """Tập marker nhận diện của fingerprint (bỏ tiền tố loại tín hiệu)."""
    out = set()
    for m in (info or {}).get("markers") or []:
        if m:
            out.add(str(m).lower())
    dev = (info or {}).get("device_key") or ""
    if dev:
        out.add(str(dev).lower())
    return out


def _strong_vendors(markers):
    """Marker VENDOR mạnh trong tập marker (loại bỏ platform/ssh/generic)."""
    return {m for m in markers if m in cve_intel.VENDOR_MARKERS}


def _registry_ports(cve, registry):
    try:
        entry = (registry or {}).get(cve) or {}
        return [int(p) for p in (entry.get("ports") or []) if str(p).isdigit()]
    except Exception:  # noqa: BLE001
        return []


def score_cve(cve, info, port, cvss=None, registry=None, explicit=False):
    """
    Chấm điểm khả dụng của `cve` trên fingerprint `info` tại `port`.

    Trả về dict:
      {cve, score, reasons[], excluded(bool), exclude_reason(str),
       evidence(str: 'vendor'|'platform'|'ssh'|'port'|'none')}
    """
    w = _weights()
    prof = cve_intel.get_profile(cve)
    markers = _marker_set(info)
    versions = (info or {}).get("versions") or {}
    reasons = []
    evidence = "none"

    # 0) CVE khai tay (lab override) — luôn giữ, không cần bằng chứng
    if explicit:
        return {"cve": cve, "score": w["explicit"], "reasons": ["explicit"],
                "excluded": False, "exclude_reason": "", "evidence": "explicit"}

    score = 0.0

    # 1) Severity nền
    if cvss is None:
        try:
            import config
            cvss = float(getattr(config, "CVE_SEVERITY", {}).get(cve, 0.0))
        except Exception:  # noqa: BLE001
            cvss = 0.0
    score += (float(cvss) / 10.0) * w["cvss"]

    # 2) Bằng chứng khớp fingerprint
    v_hit = cve_intel.cve_vendor_markers(cve) & markers
    p_hit = cve_intel.cve_platform_markers(cve) & markers
    s_hit = cve_intel.cve_ssh_markers(cve) & markers
    if v_hit:
        score += w["vendor"]
        evidence = "vendor"
        reasons.append("vendor=%s" % ",".join(sorted(v_hit)))
    elif p_hit:
        score += w["platform"]
        evidence = "platform"
        reasons.append("platform=%s" % ",".join(sorted(p_hit)))
    elif s_hit:
        score += w["ssh"]
        evidence = "ssh"
        reasons.append("ssh=%s" % ",".join(sorted(s_hit)))

    # 2b) Lệch vendor: fingerprint chỉ ra vendor MẠNH khác mà CVE không liên quan
    strong = _strong_vendors(markers)
    cve_vendors = cve_intel.cve_vendor_markers(cve)
    if strong and cve_vendors and not (cve_vendors & strong) and not p_hit and not s_hit:
        score += w["mismatch"]
        reasons.append("vendor-mismatch(%s vs %s)"
                       % (",".join(sorted(strong)), ",".join(sorted(cve_vendors))))

    # 3) Version: trong khoảng → +điểm; ngoài khoảng → LOẠI CỨNG
    for product, rng in cve_intel.known_versions(cve).items():
        ver = versions.get(product)
        if not ver:
            continue
        aff = cve_intel.version_affected(cve, product, ver)
        if aff is True:
            score += w["version_in"]
            reasons.append("version-in(%s %s)" % (product, ver))
        elif aff is False:
            return {"cve": cve, "score": 0.0,
                    "reasons": reasons + ["version-out(%s %s)" % (product, ver)],
                    "excluded": True,
                    "exclude_reason": "%s %s ngoài khoảng %s bị ảnh hưởng"
                                      % (product, ver, (rng[0], rng[1])),
                    "evidence": evidence}

    # 4) Cổng khớp
    if port is not None and int(port) in _registry_ports(cve, registry):
        score += w["port"]
        reasons.append("port=%s" % port)

    # 5) Độ tin cậy module
    score += w[_RELIABILITY_KEY.get(prof["reliability"], "reliability_medium")]
    reasons.append("reliability=%s" % prof["reliability"])

    # 6) KEV
    if prof.get("kev"):
        score += w["kev"]
        reasons.append("kev")

    # 7) Cần auth nhưng không có default cred → khó khai thác
    if prof.get("requires_auth"):
        try:
            import config
            has_creds = cve in (getattr(config, "DEFAULT_CREDS", {}) or {})
        except Exception:  # noqa: BLE001
            has_creds = False
        if not has_creds:
            score += w["requires_auth"]
            reasons.append("requires-auth-no-creds")

    # 8) Chỉ fingerprint / client-side → nhiễu
    if cve_intel.is_fingerprint_only(cve):
        score += w["fingerprint_only"]
        reasons.append("fingerprint-only")

    return {"cve": cve, "score": round(score, 3), "reasons": reasons,
            "excluded": False, "exclude_reason": "", "evidence": evidence}


def rank_candidates(cves, info, port, severity=None, registry=None,
                    explicit_cves=()):
    """
    Sắp xếp danh sách CVE theo điểm khả dụng giảm dần (ổn định theo tên CVE).
    explicit_cves: iterable CVE khai tay — luôn được chấm 'explicit' (top).
    Trả về list dict score_cve().
    """
    explicit = {c for c in (explicit_cves or [])}
    sev = severity
    if sev is None:
        try:
            import config
            sev = getattr(config, "CVE_SEVERITY", {})
        except Exception:  # noqa: BLE001
            sev = {}
    scored = []
    for cve in sorted(set(cves)):
        scored.append(score_cve(cve, info, port, cvss=sev.get(cve),
                                registry=registry, explicit=(cve in explicit)))
    # giảm dần theo score, rồi alphabetical (tái lập được)
    scored.sort(key=lambda d: (-d["score"], d["cve"]))
    return scored


def select(cves, info, port, max_per_host=0, min_score=None,
           registry=None, explicit_cves=(), drop_fingerprint_only=False,
           drop_below_min=True, drop_mismatch=False):
    """
    Chọn CVE để khai thác trên 1 target.

    Quy tắc:
      * CVE khai tay (explicit) LUÔN giữ, không bị lọc/min-score/max.
      * CVE bị version-out → loại (trừ explicit).
      * drop_fingerprint_only=True → loại CVE chỉ-fingerprint không bằng chứng.
      * drop_mismatch=True → loại CVE lệch vendor rõ ràng (fingerprint mạnh khác).
      * min_score: loại CVE có score < ngưỡng (mặc định config.CVE_SELECT_MIN_SCORE).
      * max_per_host>0: giữ N CVE điểm cao nhất (explicit không tính vào N).

    Trả về (kept:list[dict], suppressed:list[dict]) — cả hai đã sắp theo score.
    """
    if min_score is None:
        try:
            import config
            min_score = float(getattr(config, "CVE_SELECT_MIN_SCORE", 0.0))
        except Exception:  # noqa: BLE001
            min_score = 0.0

    ranked = rank_candidates(cves, info, port, registry=registry,
                             explicit_cves=explicit_cves)
    kept, suppressed = [], []
    explicit_set = {c for c in (explicit_cves or [])}

    for item in ranked:
        cve = item["cve"]
        is_explicit = cve in explicit_set
        if is_explicit:
            kept.append(item)
            continue
        if item["excluded"]:
            suppressed.append(dict(item, suppress_reason="version-out"))
            continue
        if drop_mismatch and any(
                str(r).startswith("vendor-mismatch")
                for r in (item.get("reasons") or [])):
            suppressed.append(dict(item, suppress_reason="vendor-mismatch"))
            continue
        if drop_fingerprint_only and cve_intel.is_fingerprint_only(cve) \
                and item["evidence"] == "none":
            suppressed.append(dict(item, suppress_reason="fingerprint-only"))
            continue
        if drop_below_min and min_score > 0 and item["score"] < min_score:
            suppressed.append(dict(item, suppress_reason="below-min-score"))
            continue
        kept.append(item)

    # top-N theo score (không kể explicit)
    if max_per_host and max_per_host > 0:
        non_explicit = [it for it in kept if it["cve"] not in explicit_set]
        keep_n = max_per_host
        allowed = {it["cve"] for it in non_explicit[:keep_n]}
        new_kept = []
        for it in kept:
            if it["cve"] in explicit_set or it["cve"] in allowed:
                new_kept.append(it)
            else:
                suppressed.append(dict(it, suppress_reason="over-max-per-host"))
        kept = new_kept

    # giữ thứ tự score giảm dần cho cả hai
    kept.sort(key=lambda d: (-d["score"], d["cve"]))
    suppressed.sort(key=lambda d: (-d["score"], d["cve"]))
    return kept, suppressed


def explain(ranked, limit=8):
    """Chuỗi nhiều dòng mô tả bảng điểm (dùng cho log DEBUG/INFO)."""
    lines = []
    for it in ranked[:limit]:
        flag = "X" if it.get("excluded") else (
            "K" if it.get("suppress_reason") is None else "-")
        lines.append("  [%s] %-16s %6.2f  %s"
                     % (flag, it["cve"], it.get("score", 0.0),
                        "; ".join(it.get("reasons", []))[:120]))
    return "\n".join(lines)


__all__ = ["DEFAULT_WEIGHTS", "score_cve", "rank_candidates", "select", "explain"]
