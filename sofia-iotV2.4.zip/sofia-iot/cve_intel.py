# -*- coding: utf-8 -*-
"""
cve_intel.py — LỚP TRÍ TUỆ CVE (nâng cấp cơ chế chọn CVE trên target).

Mục tiêu: thay vì chỉ "cổng → bắn hết CVE của cổng rồi cắt top-N theo CVSS"
(hành vi cũ dễ bắn CVE vô căn cứ vào host lệch vendor, và cắt mất CVE đúng
nhưng điểm CVSS thấp hơn), lớp này mô tả TỪNG CVE bằng các thuộc tính giúp
chấm điểm mức độ "khả dụng thực tế" trên một fingerprint cụ thể:

  vendors     — marker VENDOR cần khớp (hikvision, tp-link, draytek...).
                Khớp vendor = bằng chứng mạnh.
  platforms   — marker NỀN TẢNG web/nhúng (goahead, boa, lighttpd, httpd,
                mini_httpd, nginx, apache, iis, jetty, openwrt...). Khớp
                platform = bằng chứng TRUNG BÌNH (nhiều vendor dùng chung nền).
  ssh         — marker SSH server (openssh, libssh, dropbear) — dùng cho cổng 22.
  versions    — {product_key: (min_tuple, max_tuple)}: khoảng phiên bản bị ảnh
                hưởng. Nếu fingerprint trích được version của product_key:
                  * trong khoảng  → tăng điểm mạnh (bằng chứng phiên bản)
                  * ngoài khoảng  → LOẠI (không thể dính) — chống dương giả.
  reliability — "high" | "medium" | "low": độ tin cậy của module khai thác
                (high = PoC non-blind có output thật; medium = blind/deterministic
                nhiễu; low = fingerprint_only/version-only/client-side).
  kind        — "rce" | "auth_bypass" | "info_leak" | "fingerprint" | "client".
  inject      — cách chèn lệnh: "hardcoded" (module tự bọc metachar) |
                "verbatim" (chèn thẳng giá trị → verifier mở rộng biên) | "none".
  kev         — có trong CISA KEV (đang bị khai thác thực tế) → ưu tiên hơn.
  cwe         — mã CWE (báo cáo).
  affected_ports — cổng đặc trưng (chỉ để tham chiếu; registry đã có "ports").

API:
  get_profile(cve_id)                  → dict profile đã chuẩn hoá (kèm default)
  known_versions(cve_id)               → {product: (lo, hi)} | {}
  version_affected(cve_id, product, v) → True | False | None (không kết luận)
  cve_vendor_tokens(cve_id)            → set(vendor/platform/ssh tokens)
  reliability_tier(cve_id)             → "high"|"medium"|"low"
  is_fingerprint_only(cve_id)          → bool

Module này KHÔNG phụ thuộc REGISTRY để tránh vòng import: selectors sẽ kết hợp
thêm thông tin từ exploits.REGISTRY khi cần.
"""

# ── Phân loại marker (khop với scanner._*_MARKERS) ──────────────────────
# Vendor thật (bằng chứng mạnh khi khớp).
VENDOR_MARKERS = {
    "hikvision", "tp-link", "omada", "tenda", "d-link", "zte", "dvr",
    "draytek", "edimax", "vacron", "telesquare", "sonicwall", "struts",
    "huawei", "mikrotik", "routeros", "dahua", "netgear", "linksys",
    "ubiquiti", "asus", "ruijie", "zyxel", "fortinet", "cisco", "xiongmai",
    "grandstream", "fritz", "turenas",
}
# Nền tảng web/nhúng (bằng chứng trung bình).
PLATFORM_MARKERS = {
    "goahead", "boa", "lighttpd", "httpd", "mini_httpd", "nginx", "apache",
    "iis", "jetty", "openwrt", "tr069", "sip",
}
# SSH server.
SSH_MARKERS = {"openssh", "libssh", "dropbear"}

ALL_MARKERS = VENDOR_MARKERS | PLATFORM_MARKERS | SSH_MARKERS


# Chuẩn hoá phiên bản: OpenSSH dạng "8.5p1" / "9.7" / "1.2.3".
def parse_version(text):
    """Chuỗi version → tuple int (bỏ hậu tố pN/commit). None nếu không parse."""
    if not text:
        return None
    import re
    m = re.search(r"(\d+)(?:\.(\d+))?(?:\.(\d+))?", str(text))
    if not m:
        return None
    parts = [int(x) if x is not None else 0 for x in m.groups()]
    while len(parts) < 3:
        parts.append(0)
    # OpenSSH "8.5p1" → patchlevel đẩy vào phần thứ 3 để so sánh tương đối
    pm = re.search(r"p(\d+)", str(text))
    if pm:
        parts[2] = int(pm.group(1))
    return tuple(parts[:3])


# ── Bảng hồ sơ CVE ──────────────────────────────────────────────────────
# Chỉ khai các trường KHÁC default; profile() sẽ bù default.
# Default: reliability="medium", kind="rce", inject="hardcoded", kev=False.
CVE_PROFILE = {
    # ── Web / IoT RCE command injection ────────────────────────────────
    "CVE-2017-17215": {
        "vendors": ["huawei"], "platforms": ["tr069"],
        "reliability": "medium", "kind": "rce", "inject": "hardcoded",
        "cwe": "CWE-78", "note": "Huawei HG532 UPnP SOAP — blind",
    },
    "CVE-2017-5638": {
        "vendors": ["struts"], "platforms": ["apache"],
        "reliability": "high", "kind": "rce", "inject": "hardcoded",
        "kev": True, "cwe": "CWE-20",
    },
    "CVE-2018-9866": {
        "vendors": ["sonicwall"], "reliability": "low", "kind": "rce",
        "inject": "hardcoded", "note": "XML-RPC GMS — PoC công khai chưa đầy đủ",
    },
    "CVE-2018-9995": {
        "vendors": ["xiongmai", "dvr"], "platforms": ["boa", "goahead"],
        "reliability": "high", "kind": "info_leak", "inject": "none",
        "kev": True, "cwe": "CWE-306",
    },
    "CVE-2018-10933": {
        "ssh": ["libssh"], "reliability": "high", "kind": "rce",
        "inject": "none", "versions": {"libssh": ((0, 6, 0), (0, 8, 3))},
        "cwe": "CWE-287",
    },
    "CVE-2019-17621": {
        "vendors": ["d-link"], "reliability": "high", "kind": "rce",
        "inject": "verbatim", "cwe": "CWE-78",
    },
    "CVE-2020-8515": {
        "vendors": ["draytek"], "reliability": "high", "kind": "rce",
        "inject": "verbatim", "cwe": "CWE-78",
    },
    "CVE-2021-33044": {
        "vendors": ["dahua"], "reliability": "high", "kind": "auth_bypass",
        "inject": "none", "cwe": "CWE-287",
    },
    "CVE-2021-36260": {
        "vendors": ["hikvision"], "platforms": ["goahead", "boa", "mini_httpd"],
        "reliability": "high", "kind": "rce", "inject": "hardcoded",
        "cwe": "CWE-78",
    },
    "CVE-2021-46422": {
        "vendors": ["telesquare"], "reliability": "high", "kind": "rce",
        "inject": "verbatim", "cwe": "CWE-78",
    },
    "CVE-2022-30023": {
        "vendors": ["tenda"], "platforms": ["boa"],
        "reliability": "high", "kind": "rce", "inject": "hardcoded",
        "cwe": "CWE-78",
    },
    "CVE-2022-30525": {
        "vendors": ["zyxel"], "reliability": "high", "kind": "rce",
        "inject": "hardcoded", "kev": True, "cwe": "CWE-78",
    },
    "CVE-2023-1389": {
        "vendors": ["tp-link"], "reliability": "medium", "kind": "rce",
        "inject": "hardcoded", "kev": True, "cwe": "CWE-78",
        "note": "Archer AX21 luci — blind",
    },
    "CVE-2023-25280": {
        "vendors": ["d-link"], "reliability": "high", "kind": "rce",
        "inject": "verbatim", "kev": True, "cwe": "CWE-78",
    },
    "CVE-2023-27240": {
        "vendors": ["tenda"], "reliability": "high", "kind": "rce",
        "inject": "verbatim", "cwe": "CWE-78",
    },
    "CVE-2023-33538": {
        "vendors": ["tp-link"], "reliability": "high", "kind": "rce",
        "inject": "verbatim", "cwe": "CWE-78",
    },
    "CVE-2024-3721": {
        "vendors": ["dvr", "dahua", "vacron"], "platforms": ["goahead", "boa"],
        "reliability": "high", "kind": "rce", "inject": "verbatim",
        "cwe": "CWE-78",
    },
    "CVE-2025-1316": {
        "vendors": ["edimax"], "reliability": "high", "kind": "rce",
        "inject": "verbatim", "cwe": "CWE-78",
    },
    "CVE-2025-29635": {
        "vendors": ["d-link"], "reliability": "high", "kind": "rce",
        "inject": "verbatim", "cwe": "CWE-78",
    },
    "CVE-2025-34043": {
        "vendors": ["vacron"], "platforms": ["goahead"],
        "reliability": "high", "kind": "rce", "inject": "verbatim",
        "cwe": "CWE-78",
    },

    # ── SSH (cổng 22) ──────────────────────────────────────────────────
    "CVE-2024-6387": {
        "ssh": ["openssh"], "reliability": "low", "kind": "rce",
        "inject": "none", "versions": {"openssh": ((8, 5, 0), (9, 7, 999))},
        "cwe": "CWE-364", "note": "regreSSHion — race, chỉ đánh giá version",
    },
    "CVE-2023-48795": {
        "ssh": ["openssh", "dropbear"], "reliability": "low", "kind": "info_leak",
        "inject": "none", "cwe": "CWE-354", "note": "Terrapin — deterministic KEX",
    },
    "CVE-2016-6210": {
        "ssh": ["openssh"], "reliability": "low", "kind": "info_leak",
        "inject": "none", "versions": {"openssh": ((0, 0, 0), (7, 2, 2))},
        "cwe": "CWE-208", "note": "user enum timing",
    },
    "CVE-2021-41617": {
        "ssh": ["openssh"], "reliability": "low", "kind": "fingerprint",
        "inject": "none", "requires_auth": True,
        "versions": {"openssh": ((6, 2, 0), (8, 7, 999))}, "cwe": "CWE-269",
    },
    "CVE-2023-38408": {
        "ssh": ["openssh"], "reliability": "low", "kind": "client",
        "inject": "none", "cwe": "CWE-668",
    },
    "CVE-2020-14145": {
        "ssh": ["openssh"], "reliability": "low", "kind": "client",
        "inject": "none", "versions": {"openssh": ((5, 7, 0), (8, 5, 0))},
        "cwe": "CWE-201",
    },
    "CVE-2016-7406": {
        "ssh": ["dropbear"], "reliability": "low", "kind": "client",
        "inject": "none", "cwe": "CWE-134",
    },
    "CVE-2024-3094": {
        "ssh": ["openssh"], "platforms": ["openwrt"],
        "reliability": "low", "kind": "fingerprint", "inject": "none",
        "kev": True, "cwe": "CWE-506",
    },

    # ── Fingerprint-only / mồ côi ──────────────────────────────────────
    "CVE-2018-0296":        {"vendors": ["cisco"], "reliability": "low",
                             "kind": "info_leak", "inject": "none",
                             "requires_auth": True},
    "CVE-2018-13379":       {"vendors": ["fortinet"], "reliability": "low",
                             "kind": "info_leak", "inject": "none", "kev": True},
    "CVE-2018-14847":       {"vendors": ["mikrotik"], "platforms": ["routeros"],
                             "reliability": "low", "kind": "info_leak",
                             "inject": "none", "kev": True},
    "CVE-2020-29583":       {"vendors": ["zyxel"], "reliability": "low",
                             "kind": "auth_bypass", "inject": "none"},
    "CVE-2021-33045":       {"vendors": ["dahua"], "reliability": "low",
                             "kind": "auth_bypass", "inject": "none"},
    "CVE-2021-3373":        {"vendors": ["ubiquiti"], "reliability": "low",
                             "kind": "fingerprint", "inject": "none"},
    "CVE-2021-35395":       {"vendors": [], "platforms": ["httpd", "goahead"],
                             "reliability": "low", "kind": "fingerprint",
                             "inject": "none"},
    "CVE-2022-40684":       {"vendors": ["fortinet"], "reliability": "low",
                             "kind": "auth_bypass", "inject": "none",
                             "kev": True},
    "CVE-2023-22945":       {"vendors": ["netgear"], "reliability": "low",
                             "kind": "fingerprint", "inject": "none"},
    "CVE-2023-30799":       {"vendors": ["mikrotik"], "platforms": ["routeros"],
                             "reliability": "low", "kind": "fingerprint",
                             "inject": "none", "requires_auth": True},
    "CVE-2024-30877":       {"vendors": ["asus"], "reliability": "low",
                             "kind": "fingerprint", "inject": "none"},
    "CVE-2024-45414":       {"vendors": ["zte"], "reliability": "low",
                             "kind": "fingerprint", "inject": "none"},
    "CVE-2018-10088":       {"vendors": ["xiongmai"], "platforms": ["httpd"],
                             "reliability": "low", "kind": "fingerprint",
                             "inject": "none"},
}

# CVE không có profile → default an toàn.
_DEFAULT = {
    "vendors": [], "platforms": [], "ssh": [], "versions": {},
    "reliability": "medium", "kind": "rce", "inject": "hardcoded",
    "kev": False, "requires_auth": False, "cwe": "",
}


def get_profile(cve_id):
    """Profile đã chuẩn hoá (bù default) cho 1 CVE."""
    prof = dict(_DEFAULT)
    prof.update(CVE_PROFILE.get(cve_id, {}))
    # đảm bảo list không None
    for k in ("vendors", "platforms", "ssh"):
        prof[k] = list(prof.get(k) or [])
    prof["versions"] = dict(prof.get("versions") or {})
    return prof


def known_versions(cve_id):
    """{product_key: (min_tuple, max_tuple)} của CVE (rỗng nếu không khai)."""
    return dict(get_profile(cve_id).get("versions") or {})


def version_affected(cve_id, product, version):
    """
    So khớp phiên bản với khoảng bị ảnh hưởng.
      * (lo, hi) cho product_key khớp product → True nếu lo ≤ version ≤ hi, ngược lại False.
      * CVE không khai khoảng cho product này → None (không kết luận).
      * version không parse được → None.
    product: khoá chuẩn ('openssh','libssh','dropbear'...). version: str|tuple.
    """
    rng = known_versions(cve_id).get((product or "").lower())
    if not rng:
        return None
    vt = version if isinstance(version, tuple) else parse_version(version)
    if not vt:
        return None
    return rng[0] <= vt <= rng[1]


def cve_vendor_tokens(cve_id):
    """Tập marker (vendor/platform/ssh) mà CVE liên quan tới."""
    prof = get_profile(cve_id)
    return set(prof["vendors"]) | set(prof["platforms"]) | set(prof["ssh"])


def cve_vendor_markers(cve_id):
    """Chỉ marker VENDOR (bằng chứng mạnh)."""
    return set(get_profile(cve_id)["vendors"])


def cve_platform_markers(cve_id):
    return set(get_profile(cve_id)["platforms"])


def cve_ssh_markers(cve_id):
    return set(get_profile(cve_id)["ssh"])


def reliability_tier(cve_id):
    return get_profile(cve_id)["reliability"]


def is_fingerprint_only(cve_id):
    return get_profile(cve_id)["kind"] in ("fingerprint", "client") \
        and reliability_tier(cve_id) == "low"


def injection_style(cve_id):
    return get_profile(cve_id)["inject"]


def kind(cve_id):
    return get_profile(cve_id)["kind"]


def requires_auth(cve_id):
    return bool(get_profile(cve_id).get("requires_auth"))


def is_kev(cve_id):
    return bool(get_profile(cve_id).get("kev"))


__all__ = [
    "VENDOR_MARKERS", "PLATFORM_MARKERS", "SSH_MARKERS", "ALL_MARKERS",
    "CVE_PROFILE", "get_profile", "known_versions", "version_affected",
    "cve_vendor_tokens", "cve_vendor_markers", "cve_platform_markers",
    "cve_ssh_markers", "reliability_tier", "is_fingerprint_only",
    "injection_style", "kind", "requires_auth", "is_kev", "parse_version",
]
