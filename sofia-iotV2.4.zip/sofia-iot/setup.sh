#!/usr/bin/env bash
# setup.sh — Cài phụ thuộc cho sofia-iot (Debian/Ubuntu)
#   * công cụ hệ thống: zmap, masscan
#   * gói Python: cryptography (xem requirements.txt — phụ thuộc pip DUY NHẤT)
# Chạy: bash setup.sh
#
# Ghi chú: dự án KHÔNG cần `requests` (webhook.py cố ý dùng urllib chuẩn,
# scanner/exploits dựng HTTP trực tiếp bằng socket+ssl). Chỉ cryptography
# là thư viện bên thứ ba bắt buộc — nó bật engine SSH transport thật
# (exploits/ssh_client.py) và nhánh đo timing của CVE-2016-6210.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

REQ_FILE="$SCRIPT_DIR/requirements.txt"
# Phiên bản cryptography tối thiểu (khớp requirements.txt).
CRYPTO_MIN="41.0.0"

log()  { echo -e "\033[1;34m[+]\033[0m $*"; }
ok()   { echo -e "\033[1;32m[OK]\033[0m $*"; }
warn() { echo -e "\033[1;33m[!]\033[0m $*"; }

SUDO=""
if [ "$(id -u)" -ne 0 ] && command -v sudo >/dev/null 2>&1; then
    SUDO="sudo"
fi
apt_install() { $SUDO apt-get install -y -qq "$@"; }

# ─── 0. Python 3 + pip ───────────────────────────────────────
if ! command -v python3 >/dev/null 2>&1; then
    log "Cài python3..."
    $SUDO apt-get update -qq
    apt_install python3 python3-pip
fi

# ─── 1. Cập nhật apt ─────────────────────────────────────────
log "Cập nhật apt cache..."
$SUDO apt-get update -qq

# ─── 2. Cài masscan ──────────────────────────────────────────
if ! command -v masscan >/dev/null 2>&1; then
    log "Cài masscan từ apt..."
    apt_install masscan \
        || warn "apt không có masscan — thử build từ source..."
fi

if ! command -v masscan >/dev/null 2>&1; then
    log "Build masscan từ source..."
    apt_install git make gcc libpcap-dev
    TMP="$(mktemp -d)"
    git clone --depth 1 https://github.com/robertdavidgraham/masscan.git "$TMP/masscan"
    make -C "$TMP/masscan" -j"$(nproc)"
    $SUDO make -C "$TMP/masscan" install
    rm -rf "$TMP"
fi

if command -v masscan >/dev/null 2>&1; then
    ok "masscan: $(command -v masscan)"
else
    warn "masscan: THIẾU"
fi

# ─── 3. Cài zmap ─────────────────────────────────────────────
if ! command -v zmap >/dev/null 2>&1; then
    log "Cài zmap từ apt..."
    apt_install zmap \
        || warn "apt không có zmap — thử build từ source..."
fi

if ! command -v zmap >/dev/null 2>&1; then
    log "Build zmap từ source..."
    apt_install git cmake make gcc \
        libgmp3-dev gengetopt libpcap-dev flex byacc libjson-c-dev libunistring-dev
    TMP="$(mktemp -d)"
    git clone --depth 1 https://github.com/zmap/zmap.git "$TMP/zmap"
    cmake -S "$TMP/zmap" -B "$TMP/zmap/build" -DENABLE_DEVELOPMENT=OFF
    make -C "$TMP/zmap/build" -j"$(nproc)"
    $SUDO make -C "$TMP/zmap/build" install
    rm -rf "$TMP"
fi

if command -v zmap >/dev/null 2>&1; then
    ok "zmap: $(command -v zmap)"
else
    warn "zmap: THIẾU"
fi

# ─── 4. Cài gói Python (cryptography) ─────────────────────────
# Ưu tiên pip + requirements.txt để tôn trọng ràng buộc phiên bản.
# apt có thể có bản cũ (< 41) nên chỉ dùng làm phương án dự phòng.
crypto_ok() {
    python3 - <<'PY'
import sys
try:
    import cryptography
except Exception:
    sys.exit(1)
def _t(v):
    out=[]
    for p in v.split("."):
        try: out.append(int(p))
        except ValueError: out.append(0)
    return tuple(out) + (0,0,0)
sys.exit(0 if _t(cryptography.__version__) >= (41,0,0) else 2)
PY
}

if crypto_ok; then
    ok "python module 'cryptography' (>= $CRYPTO_MIN): đã có"
else
    log "Cài cryptography (pip)..."
    if [ -f "$REQ_FILE" ]; then
        pip3 install -r "$REQ_FILE" 2>/dev/null \
            || pip3 install --break-system-packages -r "$REQ_FILE" 2>/dev/null \
            || true
    fi
    # Nếu requirements.txt không có / pip thất bại → cài trực tiếp.
    if ! crypto_ok; then
        pip3 install "cryptography>=$CRYPTO_MIN" 2>/dev/null \
            || pip3 install --break-system-packages "cryptography>=$CRYPTO_MIN" 2>/dev/null \
            || true
    fi
    # Dự phòng cuối: gói apt (có thể cũ hơn CRYPTO_MIN).
    if ! crypto_ok; then
        warn "pip thất bại — thử apt python3-cryptography (có thể cũ hơn $CRYPTO_MIN)..."
        apt_install python3-cryptography || true
    fi
fi

# ─── 5. Kiểm tra ─────────────────────────────────────────────
echo ""
log "Kiểm tra:"
MISSING=0
for b in masscan zmap; do
    command -v "$b" >/dev/null 2>&1 && ok "$b: $(command -v "$b")" || { warn "$b: THIẾU"; MISSING=1; }
done

if crypto_ok; then
    ok "cryptography: $(python3 -c 'import cryptography; print(cryptography.__version__)') (đủ engine SSH transport + CVE-2016-6210 timing)"
else
    if python3 -c "import cryptography" >/dev/null 2>&1; then
        warn "cryptography: có nhưng < $CRYPTO_MIN — nên nâng cấp (pip3 install -U 'cryptography>=$CRYPTO_MIN')"
    else
        warn "cryptography: THIẾU — các module SSH sẽ hạ cấp về version-only"
    fi
    MISSING=1
fi

echo ""
[ "$MISSING" -eq 0 ] && ok "✅ Xong!" || { warn "⚠ Còn thiếu — xem log trên"; exit 1; }
