"""SofiaTool v2 — Tunnel manager (webhook.site ưu tiên, cloudflared dự phòng).

Thứ tự ưu tiên khi start:
  1. WebhookSiteTunnel — tạo token qua REST API `POST https://webhook.site/token`,
     chạy `whcli forward --token=<uuid> --target=http://localhost:<port>`.
     URL dạng `https://<uuid>.webhook.site` (dạng subdomain, theo khuyến nghị
     docs để path/query được forward nguyên vẹn về listener).
  2. CloudflareTunnel  — `cloudflared tunnel --url http://localhost:<port>`,
     regex bắt `https://xxxx.trycloudflare.com` từ log, health-check qua CF edge.

Cả hai expose cùng interface: start() / stop() / restart_on_fail() /
available / url — PHA 2 trong sofia.py gọi thống nhất qua create_tunnel().
"""
import json
import os
import re
import shutil
import subprocess
import time
import urllib.request

from core import config
from core.logger import get_logger

log = get_logger()

TUNNEL_RE = re.compile(r"https://([a-z0-9-]+\.trycloudflare\.com)", re.I)

WEBHOOKSITE_API = "https://webhook.site/token"
HEALTH_BODY = b"sofia-listener-ok"   # body do listener trả ở GET /healthz


def _http_request(url, method="GET", headers=None, timeout=15):
    """GET/POST/DELETE đơn giản. Trả (status, body) — lỗi mạng để caller xử lý."""
    req = urllib.request.Request(url, method=method, headers=headers or {})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.status, r.read()


class BaseTunnel:
    """Interface chung cho mọi loại tunnel."""

    name = "base"

    def __init__(self, port=None):
        self.port = port or config.LISTENER_PORT
        self.proc = None
        self.url = None

    @property
    def available(self):
        """True nếu binary/tool cần thiết có mặt (chưa chắc API sẵn sàng)."""
        return False

    def start(self, max_wait=45):
        """Khởi động tunnel, chờ ready. Trả URL public hoặc None."""
        raise NotImplementedError

    def stop(self):
        if self.proc and self.proc.poll() is None:
            try:
                self.proc.terminate()
                self.proc.wait(timeout=8)
            except (subprocess.TimeoutExpired, ProcessLookupError):
                self.proc.kill()
        self.proc = None
        self.url = None

    def restart_on_fail(self):
        """Kiểm tra định kỳ; tunnel chết → kill + spawn (URL mới)."""
        if self.proc is None:
            return self.start()
        if self.proc.poll() is not None or not self.health_check():
            log.warning("tunnel %s dead — restarting with new URL", self.name)
            self.stop()
            return self.start()
        return self.url

    def health_check(self):
        """GET /healthz qua edge.

        Webhook.site luôn trả HTTP 200 (trang dashboard) kể cả khi whcli chưa
        forward → bắt buộc kiểm tra cả body chứa 'sofia-listener-ok'. Cloudflare
        trả trang lỗi (502/530/1033) khi origin chết nên body check vẫn đúng.
        """
        if not self.url:
            return False
        try:
            req = urllib.request.Request(
                self.url + "/healthz",
                headers={"User-Agent": config.USER_AGENT},
            )
            with urllib.request.urlopen(req, timeout=10) as r:
                return r.status == 200 and HEALTH_BODY in r.read(1024)
        except Exception:
            return False


class WebhookSiteTunnel(BaseTunnel):
    """Tunnel qua Webhook.site CLI (`whcli forward`).

    URL tạo trước được qua REST API nên không cần parse log; token mới mỗi lần
    spawn (giống cloudflared sinh URL mới khi restart). Cần whcli:
        npm install -g @webhooksite/cli     (hoặc đặt biến env WHCLI_BIN)
    Free user không cần API key; tài khoản trả phí set WEBHOOKSITE_API_KEY.
    """

    name = "webhook.site"

    def __init__(self, port=None, api_key=None):
        super().__init__(port=port)
        self.api_key = config.WEBHOOKSITE_API_KEY if api_key is None else api_key
        self.binary = shutil.which("whcli") or os.environ.get("WHCLI_BIN")
        self.token = None
        self.log_path = os.path.join(config.REPORT_DIR, f"whcli_{os.getpid()}.log")

    @property
    def available(self):
        return self.binary is not None

    # -------------------------------------------------------------- token API
    def _create_token(self):
        """POST /token -> {"uuid": ...}. Trả (tunnel_url, token) hoặc (None, None)."""
        headers = {"Accept": "application/json", "Content-Type": "application/json"}
        if self.api_key:
            headers["Api-Key"] = self.api_key
        try:
            status, body = _http_request(WEBHOOKSITE_API, method="POST",
                                         headers=headers)
        except Exception as e:
            log.error("webhook.site: không tạo được token: %s", e)
            return None, None
        try:
            uuid = json.loads(body.decode("utf-8", "replace")).get("uuid")
        except ValueError:
            log.error("webhook.site: response không phải JSON: %s", body[:200])
            return None, None
        # POST /token trả 201 Created khi thành công
        if not (200 <= status < 300) or not uuid:
            log.error("webhook.site: tạo token thất bại (HTTP %s)", status)
            return None, None
        # dạng subdomain https://<uuid>.webhook.site — path/query forward giữ nguyên
        return f"https://{uuid}.webhook.site", uuid

    def _delete_token(self, token):
        """Dọn token sau khi dừng (best-effort, lỗi chỉ log debug)."""
        headers = {"Accept": "application/json"}
        if self.api_key:
            headers["Api-Key"] = self.api_key
        try:
            _http_request(f"{WEBHOOKSITE_API}/{token}", method="DELETE",
                          headers=headers)
        except Exception as e:
            log.debug("webhook.site: xoá token %s thất bại (bỏ qua): %s", token, e)

    # ------------------------------------------------------------------ spawn
    def _spawn(self):
        self.url, self.token = self._create_token()
        if not self.url:
            return
        cmd = [self.binary, "forward",
               f"--token={self.token}",
               f"--target=http://localhost:{self.port}"]
        if self.api_key:
            cmd.append(f"--api-key={self.api_key}")
        self.log_path = os.path.join(config.REPORT_DIR,
                                     f"whcli_{os.getpid()}.log")
        with open(self.log_path, "ab") as lf:
            self.proc = subprocess.Popen(cmd, stdout=lf, stderr=lf,
                                         start_new_session=True)
        log.info("whcli spawned pid=%d url=%s", self.proc.pid, self.url)

    def start(self, max_wait=45):
        """Spawn whcli, chờ healthz qua edge trả đúng body của listener."""
        if not self.available:
            log.error("whcli binary not found (npm i -g @webhooksite/cli "
                      "hoặc set WHCLI_BIN)")
            return None
        self._spawn()
        if not self.proc:
            return None
        deadline = time.time() + max_wait
        while time.time() < deadline:
            if self.proc.poll() is not None:
                log.warning("whcli exited (rc=%s) -> respawn", self.proc.returncode)
                self._spawn()
                if not self.proc:
                    return None
            if self.health_check():
                log.info("tunnel ready (webhook.site): %s", self.url)
                return self.url
            time.sleep(2)
        log.error("tunnel webhook.site không ready trong %ds (log: %s)",
                  max_wait, self.log_path)
        return None

    def stop(self):
        super().stop()
        if self.token:
            self._delete_token(self.token)
            self.token = None


class CloudflareTunnel(BaseTunnel):
    """Cloudflare quick-tunnel qua cloudflared (dự phòng).

    Spawn: cloudflared tunnel --url http://localhost:<port>; regex bắt URL
    trycloudflare từ log; health-check qua CF edge; tự restart khi tunnel chết.
    """

    name = "cloudflare"

    def __init__(self, port=None, binary=None):
        super().__init__(port=port)
        self.binary = binary or (shutil.which("cloudflared")
                                 or os.environ.get("CLOUDFLARED_BIN"))
        self.log_path = os.path.join(config.REPORT_DIR,
                                     f"cloudflared_{os.getpid()}.log")

    @property
    def available(self):
        return self.binary is not None

    # ------------------------------------------------------------------ spawn
    def _spawn(self):
        # log riêng mỗi lần spawn — tránh đọc URL cũ từ lần chạy trước
        self.log_path = os.path.join(config.REPORT_DIR,
                                     f"cloudflared_{os.getpid()}.log")
        cmd = [self.binary, "tunnel", "--url", f"http://localhost:{self.port}",
               "--no-autoupdate", "--protocol", "http2", "--logfile", self.log_path]
        # --logfile -> stdout sạch, parse từ file log cho chắc
        self.proc = subprocess.Popen(
            cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            start_new_session=True,
        )
        log.info("cloudflared spawned pid=%d", self.proc.pid)

    def start(self, max_wait=45):
        if not self.available:
            log.error("cloudflared binary not found (PATH or CLOUDFLARED_BIN)")
            return None
        self._spawn()
        deadline = time.time() + max_wait
        while time.time() < deadline:
            self.url = self.parse_tunnel_url()
            if self.url:
                if self.health_check():
                    log.info("tunnel ready (cloudflare): %s", self.url)
                    return self.url
                log.warning("tunnel URL nhưng origin unhealthy -> restart")
            if self.proc.poll() is not None:
                log.warning("cloudflared exited (rc=%s) -> respawn",
                            self.proc.returncode)
                self._spawn()
            time.sleep(2)
        log.error("tunnel cloudflare không ready trong %ds (log: %s)",
                  max_wait, self.log_path)
        return None

    # ------------------------------------------------------------------ parse
    def parse_tunnel_url(self, text=None):
        """Đọc log cloudflared, regex bắt URL trycloudflare."""
        text = text or ""
        if not text:
            try:
                with open(self.log_path, encoding="utf-8", errors="replace") as f:
                    text = f.read()
            except OSError:
                return None
        m = TUNNEL_RE.search(text)
        return m.group(0) if m else None


# ------------------------------------------------------------------ factory
_TUNNEL_CLASSES = {
    "webhook.site": WebhookSiteTunnel,
    "cloudflare": CloudflareTunnel,
}


def create_tunnel(port=None, prefer="auto"):
    """Chọn tunnel class theo prefer.

    prefer="auto" (mặc định): webhook.site nếu có whcli, ngược lại cloudflare.
    prefer="webhook.site" / "cloudflare": lấy đúng class đó (không fallback) —
    việc thử/fallback do phase_tunnel trong sofia.py điều phối.
    """
    if prefer == "auto":
        t = WebhookSiteTunnel(port=port)
        if t.available:
            log.info("tunnel: chọn webhook.site (ưu tiên)")
            return t
        log.warning("tunnel: webhook.site không khả dụng (thiếu whcli) "
                    "— dùng cloudflare")
        return CloudflareTunnel(port=port)
    return _TUNNEL_CLASSES[prefer](port=port)


# backward-compat alias: code cũ gọi TunnelManager(port=...) vẫn chạy được
TunnelManager = CloudflareTunnel