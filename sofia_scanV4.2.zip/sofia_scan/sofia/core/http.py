"""SofiaTool v2 — HTTP dùng chung cho các bước CHỈ ĐỌC (discovery/classify).

Mục tiêu TỐC ĐỘ khi xử lý danh sách target lớn:

  * Connection pool + keep-alive: tái dùng Session/client thay vì mở lại
    TCP/TLS cho từng host/probe -> giảm độ trễ handshake.
  * Retry CHỈ cho method idempotent (GET/HEAD): lỗi mạng tạm thời (429/5xx/
    connection) được thử lại ngay trong pool, KHÔNG bắn lại payload khai thác
    (POST/XXE) — tránh nhân đôi tác dụng phụ lên target.
  * Thread-local session: an toàn khi chạy trong ThreadPoolExecutor của
    PHA 1b (nhiều luồng classify song song).

Các exploit (POST payload) vẫn tự tạo session riêng — cố ý KHÔNG retry tự
động để không gửi trùng payload. Chỉ module discovery/classify dùng file này.

CHỈ DÙNG CHO MỤC ĐÍCH KIỂM THỬ BẢO MẬT ĐƯỢC UỶ QUYỀN.
"""
import threading

import httpx
import requests
import urllib3
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from core import config

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

_TLS = threading.local()

# Chỉ method idempotent mới được retry tự động (an toàn cho target).
_RETRY_METHODS = frozenset(["GET", "HEAD", "OPTIONS"])
_RETRY_STATUS = (429, 500, 502, 503, 504)


def _pool_size():
    return max(4, int(getattr(config, "HTTP_POOL", 50) or 50))


def _retries():
    try:
        return max(0, int(getattr(config, "HTTP_RETRIES", 2) or 0))
    except (TypeError, ValueError):
        return 2


def _requests_adapter():
    retry = Retry(
        total=_retries(),
        connect=_retries(),
        read=_retries(),
        status=_retries(),
        backoff_factor=0.25,
        status_forcelist=_RETRY_STATUS,
        allowed_methods=_RETRY_METHODS,
        raise_on_status=False,
    )
    pool = _pool_size()
    return HTTPAdapter(pool_connections=pool, pool_maxsize=pool,
                       max_retries=retry)


def make_session(verify=False, proxy=None):
    """Session `requests` có pool + retry (GET/HEAD). Dùng cho 1 host/probe."""
    s = requests.Session()
    s.verify = verify
    s.headers.update({"User-Agent": config.USER_AGENT})
    adapter = _requests_adapter()
    s.mount("http://", adapter)
    s.mount("https://", adapter)
    if proxy:
        s.proxies.update({"http": proxy, "https": proxy})
    return s


def thread_session():
    """Session cache theo LUỒNG — tránh tạo session mới liên tục trong pool."""
    s = getattr(_TLS, "session", None)
    if s is None:
        s = make_session()
        _TLS.session = s
    return s


def close_thread_session():
    """Đóng session của luồng hiện tại (gọi khi luồng kết thúc, nếu cần)."""
    s = getattr(_TLS, "session", None)
    if s is not None:
        try:
            s.close()
        except Exception:  # pragma: no cover
            pass
        _TLS.session = None


def make_httpx_client(timeout=None, proxy=None):
    """httpx.Client có retry (connect) + giới hạn connection/keep-alive."""
    pool = _pool_size()
    limits = httpx.Limits(max_connections=max(10, pool),
                          max_keepalive_connections=max(5, pool // 2),
                          keepalive_expiry=30.0)
    transport = httpx.HTTPTransport(retries=_retries(), limits=limits)
    kwargs = dict(
        verify=False,
        timeout=timeout or config.TIMEOUT,
        follow_redirects=True,
        headers={"User-Agent": config.USER_AGENT},
        transport=transport,
    )
    if proxy:
        kwargs["proxy"] = proxy
    return httpx.Client(**kwargs)
