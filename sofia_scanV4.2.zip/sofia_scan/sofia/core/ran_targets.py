"""SofiaTool v2 — SỔ TARGET ĐÃ KIỂM TRA (`ran_target.json`).

Mục tiêu: mỗi khi một target chạy XONG (mọi job CVE của nó hoàn tất, hoặc target
không có CVE nào phù hợp), target được ghi vào `ran_target.json`. Các lần chạy
SAU tự động BỎ QUA target đã có trong sổ — kể cả bước nhận diện nền tảng (PHA 1b)
— nên không chạm mạng lại và không khai thác lại.

Định dạng file (JSON, ghi atomic):

    {
      "generated": "<iso lần tạo đầu>",
      "updated":   "<iso lần ghi gần nhất>",
      "count":     2,
      "targets":   ["https://a.example.com", "https://b.example.com"]
    }

Thiết kế:
  * Nạp 1 lần (in-memory dict key -> url hiển thị), ghi lại theo lô -> I/O tuyến tính.
  * AN TOÀN ĐA LUỒNG: khoá RLock + ghi atomic (tmp -> os.replace).
  * So khớp theo URL đã chuẩn hoá (dùng `discovery.target_queue.normalize`) nên
    "example.com", "http://example.com/path" và "https://example.com" là MỘT.

Đường dẫn lấy từ `config.RAN_TARGET_FILE` (mặc định `<sofia>/ran_target.json`),
ghi đè bằng `--ran-file` hoặc biến môi trường `SOFIA_RAN_FILE`. Tắt hẳn tính
năng bằng `--no-skip-ran` / `SOFIA_SKIP_RAN=0`.

CHỈ DÙNG CHO MỤC ĐÍCH KIỂM THỬ BẢO MẬT ĐƯỢC UỶ QUYỀN.
"""
import json
import os
import threading

from core import config
from core.logger import get_logger, now_iso

log = get_logger()

_LOCK = threading.RLock()


def key_of(host):
    """Khoá chuẩn hoá cho 1 host/URL.

    Dùng normalize của target_queue rồi BỎ SCHEME -> so khớp theo host[:port],
    nên `example.com`, `http://example.com/x` và `https://example.com` là MỘT.
    """
    from discovery.target_queue import normalize
    url = normalize(host) or (host or "").strip().lower()
    if "://" in url:
        url = url.split("://", 1)[1]
    return url.strip("/").lower()


def _display(host):
    """URL hiển thị/ghi file cho 1 host (đã chuẩn hoá nếu được)."""
    from discovery.target_queue import normalize
    return normalize(host) or (host or "").strip()


class RanTargets:
    """Sổ target đã kiểm tra: in-memory + persist. Thread-safe."""

    def __init__(self, path=None, enabled=True):
        self.enabled = bool(enabled)
        self.path = path or getattr(config, "RAN_TARGET_FILE", None) \
            or os.path.join(config.ROOT, "ran_target.json")
        self._keys = {}        # key chuẩn hoá -> url hiển thị
        self._created = None   # giữ "generated" gốc của file cũ
        self._dirty = False
        if self.enabled:
            self._load()

    # ------------------------------------------------------------------ I/O
    def _load(self):
        with _LOCK:
            try:
                with open(self.path, encoding="utf-8") as f:
                    d = json.load(f)
            except (OSError, json.JSONDecodeError):
                d = None
            urls = []
            if isinstance(d, dict):
                self._created = d.get("generated")
                urls = d.get("targets") or []
            elif isinstance(d, list):  # chấp nhận cả file dạng mảng thuần
                urls = d
            for u in urls:
                if not isinstance(u, str) or not u.strip():
                    continue
                k = key_of(u)
                if k:
                    self._keys.setdefault(k, _display(u))
            if self._keys:
                log.info("ran_target.json: nạp %d target đã kiểm tra (%s)",
                         len(self._keys), self.path)

    def flush(self):
        """Ghi sổ xuống đĩa (atomic). No-op nếu tắt / không có thay đổi."""
        if not self.enabled or not self._dirty:
            return
        with _LOCK:
            targets = list(self._keys.values())
            payload = {
                "generated": self._created or now_iso(),
                "updated": now_iso(),
                "count": len(targets),
                "targets": targets,
            }
            try:
                d = os.path.dirname(self.path)
                if d:
                    os.makedirs(d, exist_ok=True)
                tmp = self.path + ".tmp"
                with open(tmp, "w", encoding="utf-8") as f:
                    json.dump(payload, f, ensure_ascii=False, indent=2)
                os.replace(tmp, self.path)
                self._created = payload["generated"]
                self._dirty = False
            except OSError as e:  # pragma: no cover
                log.debug("ran_target ghi lỗi: %s", e)

    # --------------------------------------------------------------- entry
    def __len__(self):
        return len(self._keys)

    def contains(self, host):
        """True nếu target đã có trong sổ (đã kiểm tra xong)."""
        if not self.enabled:
            return False
        k = key_of(host)
        if not k:
            return False
        with _LOCK:
            return k in self._keys

    def add(self, host):
        """Thêm 1 target vào sổ. Trả True nếu là target MỚI. Không tự flush."""
        if not self.enabled:
            return False
        k = key_of(host)
        if not k:
            return False
        with _LOCK:
            if k in self._keys:
                return False
            self._keys[k] = _display(host)
            self._dirty = True
        return True

    def add_many(self, hosts, flush=True):
        """Thêm nhiều target; trả số target mới. flush=True -> ghi đĩa 1 lần."""
        n = 0
        for h in hosts:
            if self.add(h):
                n += 1
        if n and flush:
            self.flush()
        return n

    def filter_hosts(self, hosts):
        """Loại khỏi danh sách những host đã có trong sổ (đã kiểm tra)."""
        if not self.enabled:
            return list(hosts)
        out = []
        with _LOCK:
            for h in hosts:
                k = key_of(h)
                if k and k in self._keys:
                    continue
                out.append(h)
        return out

    def stats(self):
        with _LOCK:
            return {"size": len(self._keys), "enabled": self.enabled,
                    "path": self.path}


# ----------------------------------------------------------- singleton ------
_store = None
_store_lock = threading.RLock()


def get_store(path=None, enabled=None):
    """Trả sổ dùng chung (lazy). Đọc cấu hình từ `config` ở lần gọi đầu.

    Gọi SAU `config.configure(args)` để tôn trọng `--ran-file` / `--skip-ran`.
    """
    global _store
    with _store_lock:
        if _store is None:
            _store = RanTargets(
                path=path,
                enabled=config.SKIP_RAN if enabled is None else enabled)
        return _store


def reset_store():
    """Xoá singleton (chủ yếu cho kiểm thử)."""
    global _store
    with _store_lock:
        _store = None
