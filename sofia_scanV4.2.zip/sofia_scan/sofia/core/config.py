"""SofiaTool v2 — global configuration.

Mọi tham số có thể ghi đè qua CLI (--threads / --wait ...) hoặc biến môi trường
SOFIA_* — tiện cho việc chạy nhiều phiên song song với cấu hình khác nhau.
"""
import os

# --- Tunables ---------------------------------------------------------------
THREADS = 20              # số luồng exploit song song
TIMEOUT = 15              # timeout HTTP mỗi request tới target
WAIT_CALLBACK = 30        # timeout chờ OOB callback sau mỗi payload
LISTENER_HOST = "0.0.0.0"
LISTENER_PORT = 8000      # cổng listener nội bộ (phía sau tunnel public)
RETRY_HTTP = 2            # số lần retry khi request HTTP fail tạm thời

# --- Hiệu năng danh sách lớn ------------------------------------------------
# Số luồng SONG SONG cho PHA 1b (nhận diện nền tảng + dò version/plugin).
# 0 = tự chọn theo kích thước danh sách (khuyến nghị cho list lớn).
CLASSIFY_THREADS = int(os.environ.get("SOFIA_CLASSIFY_THREADS", "0") or "0")
CLASSIFY_THREADS_MAX = int(os.environ.get("SOFIA_CLASSIFY_THREADS_MAX", "64") or "64")
# Kích thước connection pool mỗi host + giới hạn connection httpx.
HTTP_POOL = int(os.environ.get("SOFIA_HTTP_POOL", "50") or "50")
# Số lần retry cho request CHỈ ĐỌC (GET/HEAD) của discovery/classify.
HTTP_RETRIES = int(os.environ.get("SOFIA_HTTP_RETRIES", "2") or "2")
# 0 = chỉ hợp nhất report.json ở cuối lượt (nhanh nhất, O(n)); >0 = hợp nhất
# lại mỗi N entry (an toàn hơn nếu tiến trình bị kill cứng, đổi lại chậm hơn).
REPORT_FLUSH_EVERY = int(os.environ.get("SOFIA_REPORT_FLUSH_EVERY", "0") or "0")
# Từ ngần này entry trở lên, report.json ghi dạng compact (bỏ indent) cho nhanh.
REPORT_COMPACT_AFTER = int(os.environ.get("SOFIA_REPORT_COMPACT_AFTER", "400") or "400")

USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
)

# --- Tunnel ----------------------------------------------------------------
# Webhook.site là tunnel ưu tiên (PHA 2). Free user không cần key; chỉ cần khi
# token thuộc tài khoản trả phí: set WEBHOOKSITE_API_KEY.
# Binary: ưu tiên PATH, có thể ghi đè bằng WHCLI_BIN / CLOUDFLARED_BIN.
WEBHOOKSITE_API_KEY = os.environ.get("WEBHOOKSITE_API_KEY")

# --- Search-engine API keys (PHA 1) ------------------------------------------
FOFA_EMAIL = os.environ.get("FOFA_EMAIL")
FOFA_KEY = os.environ.get("FOFA_KEY")
ZOOMEYE_API_KEY = os.environ.get("ZOOMEYE_API_KEY")
CENSYS_API_ID = os.environ.get("CENSYS_API_ID")
CENSYS_API_SECRET = os.environ.get("CENSYS_API_SECRET")
SHODAN_API_KEY = os.environ.get("SHODAN_API_KEY")
URLSCAN_API_KEY = os.environ.get("URLSCAN_API_KEY")  # tùy chọn, urlscan free không cần

# --- Scope guard --------------------------------------------------------------
# Danh sách whitelist (suffix domain). None = mọi target từ nguồn đều hợp lệ.
SCOPE_WHITELIST = None

# --- Multi-target -------------------------------------------------------------
# Batch xử lý theo lô (0 = xử lý hết một lần); resume bỏ qua target đã có kết quả
# trong report/report.json. Ghi đè qua CLI: --batch-size / --resume / --no-resume.
BATCH_SIZE = int(os.environ.get("SOFIA_BATCH_SIZE", "50"))
RESUME = os.environ.get("SOFIA_RESUME", "1").lower() in ("1", "true", "yes", "on")

# --- Webhook ----------------------------------------------------------------
# URL mặc định (Discord) khi không truyền -w; có thể ghi đè bằng SOFIA_WEBHOOK_URL.
DEFAULT_WEBHOOK_URL = (
    "https://discord.com/api/webhooks/1543533186242322432/"
    "Mm8jBY-PEIUwDO1XPMXcpF8R3n8gLLQOkX5PfC95X6rSrLruEs3z-uUEh-qqnbRDtpuE"
)
WEBHOOK_URL = os.environ.get("SOFIA_WEBHOOK_URL", DEFAULT_WEBHOOK_URL)
WEBHOOK_FORMAT = "auto"   # auto | discord | slack | plain

# --- Thư mục -----------------------------------------------------------------
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
REPORT_DIR = os.environ.get("SOFIA_REPORT_DIR", os.path.join(ROOT, "report"))
EVIDENCE_DIR = os.environ.get("SOFIA_EVIDENCE_DIR", os.path.join(ROOT, "evidence"))

# --- Sổ target đã kiểm tra (ran_target.json) ---------------------------------
# Mỗi target chạy XONG được ghi thêm vào file này; lần chạy sau TỰ ĐỘNG bỏ qua
# các target đã có trong sổ (kể cả bước nhận diện nền tảng). Ghi đè qua CLI:
# --ran-file / --no-skip-ran hoặc biến môi trường SOFIA_RAN_FILE / SOFIA_SKIP_RAN.
RAN_TARGET_FILE = os.environ.get("SOFIA_RAN_FILE",
                                 os.path.join(ROOT, "ran_target.json"))
SKIP_RAN = os.environ.get("SOFIA_SKIP_RAN", "1").lower() in ("1", "true", "yes", "on")


def configure(args=None):
    """Ghi đè cấu hình từ namespace args của argparse (nếu có)."""
    global THREADS, WAIT_CALLBACK, TIMEOUT, WEBHOOK_URL, WEBHOOK_FORMAT
    global SCOPE_WHITELIST, BATCH_SIZE, RESUME
    global CLASSIFY_THREADS, HTTP_POOL, HTTP_RETRIES, REPORT_FLUSH_EVERY
    global RAN_TARGET_FILE, SKIP_RAN
    args = args or {}
    if getattr(args, "threads", None):
        THREADS = args.threads
    if getattr(args, "wait", None):
        WAIT_CALLBACK = args.wait
    if getattr(args, "timeout", None):
        TIMEOUT = args.timeout
    if getattr(args, "webhook", None):
        WEBHOOK_URL = args.webhook
    bs = getattr(args, "batch_size", None)
    if bs is not None:
        BATCH_SIZE = bs
    if hasattr(args, "resume"):
        RESUME = bool(args.resume)
    if getattr(args, "ran_file", None):
        RAN_TARGET_FILE = args.ran_file
    if hasattr(args, "skip_ran"):
        SKIP_RAN = bool(args.skip_ran)
    if getattr(args, "classify_threads", None) is not None:
        CLASSIFY_THREADS = args.classify_threads
    if getattr(args, "http_pool", None) is not None:
        HTTP_POOL = args.http_pool
    if getattr(args, "http_retries", None) is not None:
        HTTP_RETRIES = args.http_retries
    if getattr(args, "flush_every", None) is not None:
        REPORT_FLUSH_EVERY = args.flush_every
    if getattr(args, "scope", None):
        SCOPE_WHITELIST = [s.strip().lower().lstrip("*.") for s in args.scope.split(",") if s.strip()]
    # tự detect format webhook
    if WEBHOOK_URL:
        if "discord.com/api/webhooks" in WEBHOOK_URL:
            WEBHOOK_FORMAT = "discord"
        elif "hooks.slack.com" in WEBHOOK_URL:
            WEBHOOK_FORMAT = "slack"
        else:
            WEBHOOK_FORMAT = "plain"
    for d in (REPORT_DIR, EVIDENCE_DIR):
        os.makedirs(d, exist_ok=True)


