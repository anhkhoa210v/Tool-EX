"""SofiaTool v2 — logging + xuất kết quả.

Ghi runtime log ra report/sofia.log + console. Các hàm report_* phụ trách xuất
kết quả đã xác nhận vào report.json / hits.csv (PHA 5).

THIẾT KẾ CHO DANH SÁCH LỚN (tối ưu tốc độ):
  Trước đây mỗi job gọi add_target_report() -> ghi lại TOÀN BỘ report.json
  (O(n^2) I/O khi có hàng nghìn job). Bản này dùng JOURNAL APPEND-ONLY:

    * add_target_report(): thêm entry vào RAM + APPEND 1 dòng JSON vào
      report/report.journal.jsonl -> O(1) mỗi job, tổng O(n).
    * flush_report()/save_report(): HỢP NHẤT journal vào report.json một lần
      (atomic tmp -> os.replace) rồi xoá journal.
    * load_report(): đọc report.json + merge journal còn sót của lượt bị dừng
      đột ngột (dedup theo (cve,url)) -> --resume vẫn thấy đủ job đã xong.

  => Tiến trình bị kill cứng giữa chừng KHÔNG mất kết quả (journal đã ghi),
     mà tổng I/O vẫn tuyến tính theo số job.
"""
import atexit
import json
import logging
import os
import sys
import threading
from datetime import datetime, timezone

from core import config

_FMT = "%(asctime)s [%(levelname).1s] %(message)s"
_DATEFMT = "%H:%M:%S"

_logger = None

# Khoá ghi report.json/hits.csv: nhiều worker (Magento + WooCommerce) chạy song
# song và cùng đọc-sửa-ghi report -> nếu không khoá sẽ MẤT entry khi quy mô lớn.
_REPORT_LOCK = threading.RLock()

# Cache report.json trong RAM.
_REPORT_CACHE = None
_REPORT_CACHE_PATH = None
# Số entry đã thêm (trong RAM + journal) kể từ lần hợp nhất gần nhất.
_PENDING = 0


def get_logger():
    global _logger
    if _logger is not None:
        return _logger
    os.makedirs(config.REPORT_DIR, exist_ok=True)
    _logger = logging.getLogger("sofia")
    _logger.setLevel(logging.INFO)
    _logger.propagate = False

    if not _logger.handlers:
        sh = logging.StreamHandler(sys.stderr)
        sh.setFormatter(logging.Formatter(_FMT, _DATEFMT))
        fh = logging.FileHandler(os.path.join(config.REPORT_DIR, "sofia.log"), encoding="utf-8")
        fh.setFormatter(logging.Formatter("%(asctime)s " + _FMT, _DATEFMT))
        _logger.addHandler(sh)
        _logger.addHandler(fh)
    return _logger


def now_iso():
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")


# ---------------------------------------------------------------- report.json
def _report_path():
    return os.path.join(config.REPORT_DIR, "report.json")


def _journal_path():
    return os.path.join(config.REPORT_DIR, "report.journal.jsonl")


def _read_journal():
    """Đọc journal append-only của lượt chạy hiện tại (bền qua crash)."""
    out = []
    try:
        with open(_journal_path(), encoding="utf-8") as f:
            for ln in f:
                ln = ln.strip()
                if not ln:
                    continue
                try:
                    out.append(json.loads(ln))
                except json.JSONDecodeError:
                    continue
    except OSError:
        pass
    return out


def _append_journal(entry):
    """Append 1 entry vào journal (O(1)). Lỗi I/O không làm chết job."""
    try:
        with open(_journal_path(), "a", encoding="utf-8") as f:
            f.write(json.dumps(entry, ensure_ascii=False, default=str) + "\n")
    except OSError as e:  # pragma: no cover
        get_logger().debug("journal ghi lỗi: %s", e)


def _clear_journal():
    try:
        os.remove(_journal_path())
    except OSError:
        pass


def _entry_key(e):
    if not isinstance(e, dict):
        return None
    cve = str(e.get("cve") or "").upper()
    url = str(e.get("url") or "").lower()
    if cve and url:
        return (cve, url)
    return None


def load_report():
    """Trả report hiện hành (RAM). Lần đầu đọc report.json + merge journal."""
    global _REPORT_CACHE, _REPORT_CACHE_PATH
    path = _report_path()
    with _REPORT_LOCK:
        if _REPORT_CACHE is None or _REPORT_CACHE_PATH != path:
            try:
                with open(path, encoding="utf-8") as f:
                    data = json.load(f)
            except (OSError, json.JSONDecodeError):
                data = None
            if not isinstance(data, dict):
                data = {"generated": now_iso(), "targets": []}
            targets = data.get("targets")
            if not isinstance(targets, list):
                targets = []
                data["targets"] = targets

            # merge journal (lượt trước bị dừng giữa chừng) + dedup theo (cve,url)
            seen = {k for k in (_entry_key(e) for e in targets) if k}
            for e in _read_journal():
                k = _entry_key(e)
                if k and k in seen:
                    continue
                targets.append(e)
                if k:
                    seen.add(k)

            _REPORT_CACHE = data
            _REPORT_CACHE_PATH = path
        return _REPORT_CACHE


def _write_report(data):
    """Ghi report.json (atomic). Compact khi nhiều entry để nhanh + gọn."""
    tmp = _report_path() + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        if len(data.get("targets") or []) >= config.REPORT_COMPACT_AFTER:
            json.dump(data, f, ensure_ascii=False, separators=(",", ":"),
                      default=str)
        else:
            json.dump(data, f, indent=2, ensure_ascii=False, default=str)
    os.replace(tmp, _report_path())


def _consolidate_locked():
    """Hợp nhất RAM -> report.json + xoá journal. Gọi khi đang giữ khoá."""
    global _PENDING
    if _REPORT_CACHE is None:
        _PENDING = 0
        return
    try:
        _write_report(_REPORT_CACHE)
    except OSError as e:  # pragma: no cover
        get_logger().warning("không ghi được report.json: %s", e)
        return
    _clear_journal()
    _PENDING = 0


def save_report(data):
    """Ghi report.json ngay (dùng ở PHA 5). Hợp nhất + xoá journal."""
    global _REPORT_CACHE, _REPORT_CACHE_PATH
    with _REPORT_LOCK:
        _REPORT_CACHE = data
        _REPORT_CACHE_PATH = _report_path()
        _consolidate_locked()


def flush_report(force=False):
    """Hợp nhất journal vào report.json.

    force=True: ghi cả khi chưa tích đủ ngưỡng (dùng khi kết thúc tiến trình).
    An toàn để gọi nhiều lần / từ atexit.
    """
    with _REPORT_LOCK:
        if _PENDING or force:
            _consolidate_locked()


def add_target_report(entry):
    """Ghi 1 entry target/CVE: RAM + journal append-only (O(1), thread-safe)."""
    global _PENDING
    with _REPORT_LOCK:
        data = load_report()
        data.setdefault("targets", []).append(entry)
        _append_journal(entry)
        _PENDING += 1
        every = int(getattr(config, "REPORT_FLUSH_EVERY", 0) or 0)
        if every and _PENDING >= every:
            _consolidate_locked()


def report_stats():
    """Thông tin cache report (số entry, số đang chờ hợp nhất)."""
    with _REPORT_LOCK:
        size = len((_REPORT_CACHE or {}).get("targets") or [])
        return {"size": size, "pending": _PENDING, "journal": _journal_path()}


# Đảm bảo journal được hợp nhất khi tiến trình thoát bình thường (kể cả lỗi).
atexit.register(flush_report, True)


# -------------------------------------------------------------------- hits.csv
def _hits_path():
    return os.path.join(config.REPORT_DIR, "hits.csv")


def write_hit(domain, cve, evidence_path, key_masked, size, sha256, extra=""):
    """domain | cve | evidence_path | key(mask) | time (+extra)."""
    line = " | ".join([
        domain, cve, evidence_path or "-", key_masked or "-",
        str(size or "-"), sha256 or "-", now_iso(), extra or "",
    ])
    with _REPORT_LOCK:
        with open(_hits_path(), "a", encoding="utf-8") as f:
            f.write(line + "\n")
    get_logger().info("HIT recorded -> %s", line)
    return line
