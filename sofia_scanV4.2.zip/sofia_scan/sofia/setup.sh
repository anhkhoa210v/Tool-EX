#!/usr/bin/env bash
# ============================================================================
# SofiaTool v2 — setup tự động
#   1) cài đặt công cụ base (curl, unzip, python3-pip, node/npm nếu thiếu)
#   2) cài whcli  (Webhook.site CLI — npm @webhooksite/cli)
#   3) cài cloudflared (quick tunnel dự phòng)
#   4) pip deps từ requirements.txt
#   5) nâng cấp sofia.py lên bản multi-target (--batch-size / --resume)
#      — idempotent: chạy lại không làm gì thừa, không ghi đè cấu hình
#
# Chạy:
#   bash setup.sh
#
# Kết quả (kiểm tra ở cuối):
#   whcli --version
#   cloudflared --version
#   python3 sofia.py --help   -> thấy --batch-size và --resume
# ============================================================================
set -euo pipefail

VER="[setup]"
OK_CNT=0
WARN_CNT=0

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# ------------------------------------------------ helpers ------------------------------------------------
log()  { printf '%s %s\n' "$VER" "$*"; }
ok()   { OK_CNT=$((OK_CNT + 1)); printf '%s  ✔ %s\n' "$VER" "$*"; }
warn() { WARN_CNT=$((WARN_CNT + 1)); printf '%s  ⚠ %s\n' "$VER" "$*" >&2; }
err()  { printf '%s  ✖ %s\n' "$VER" "$*" >&2; }

have() { command -v "$1" >/dev/null 2>&1; }

add_path() {
    # thêm thư mục vào PATH vĩnh viễn (~/.bashrc) nếu chưa có
    local dir="$1"
    case ":$PATH:" in
        *":$dir:"*) ;;
        *)
            export PATH="$dir:$PATH"
            if [ -n "${SHELL_RC:-}" ]; then
                grep -qF "export PATH=\"$dir:\$PATH\"" "$SHELL_RC" 2>/dev/null \
                    || printf '\n# SofiaTool: %s\nexport PATH="%s:$PATH"\n' "$dir" "$dir" >> "$SHELL_RC"
            fi
            ;;
    esac
}

run_as_root() {
    # `sudo` nếu cần (có sudo và không phải root); nếu root thì chạy thẳng
    if [ "$(id -u)" -eq 0 ]; then
        "$@"
    elif have sudo; then
        sudo "$@"
    else
        return 1
    fi
}

# ------------------------------------------------ 0) apt base ------------------------------------------------
log "Bước 0: kiểm tra công cụ base (apt)..."
NEED_APT=()
for c in curl unzip ca-certificates gnupg; do
    have "$c" || NEED_APT+=("$c")
done
if [ ${#NEED_APT[@]} -gt 0 ]; then
    log "cài qua apt: ${NEED_APT[*]}"
    run_as_root apt-get update -y
    run_as_root apt-get install -y "${NEED_APT[@]}" || warn "apt install ${NEED_APT[*]} thất bại (một số tính năng có thể thiếu)"
fi

# node/npm (chỉ khi thiếu — môi trường đã có sẵn sẽ bỏ qua)
if ! have node || ! have npm; then
    log "cài nodejs + npm qua apt..."
    run_as_root apt-get install -y nodejs npm || warn "không cài được nodejs/npm — whcli sẽ không dùng được"
fi

# python3-pip (chỉ khi python3 không có pip)
if ! python3 -m pip --version >/dev/null 2>&1; then
    run_as_root apt-get install -y python3-pip || warn "không cài được python3-pip"
fi

# ------------------------------------------------ 1) whcli ------------------------------------------------
log "Bước 1: whcli (Webhook.site CLI)..."
if have whcli; then
    ok "whcli đã có: $(whcli --version 2>&1 | head -1)"
else
    log "cài whcli qua npm (gói @webhooksite/cli)..."
    if npm install -g @webhooksite/cli 2>/tmp/whcli_npm.err; then
        has_whcli=1
    elif [ -d "$HOME/.local" ] && [ -w "$HOME/.local" ]; then
        # EACCES với prefix mặc định -> user prefix
        warn "npm global mặc định lỗi — thử user prefix ~/.local (${HOME}/.local)"
        npm config set prefix "$HOME/.local"
        SHELL_RC="$HOME/.bashrc" add_path "$HOME/.local/bin"
        npm install -g @webhooksite/cli || { err "cài whcli vẫn lỗi: $(tail -5 /tmp/whcli_npm.err)"; has_whcli=0; }
    else
        err "cài whcli thất bại: $(tail -5 /tmp/whcli_npm.err)"
        has_whcli=0
    fi
    if [ "${has_whcli:-0}" -eq 1 ]; then
        ok "đã cài whcli: $(whcli --version 2>&1 | head -1)"
    else
        warn "whcli chưa cài được — tunnel webhook.site sẽ fallback sang cloudflare"
    fi
fi

# ------------------------------------------------ 2) cloudflared ------------------------------------------------
log "Bước 2: cloudflared (quick tunnel dự phòng)..."
if have cloudflared; then
    ok "cloudflared đã có: $(cloudflared --version 2>&1 | head -1)"
else
    ARCH="$(uname -m)"
    case "$ARCH" in
        x86_64|amd64) CF_ARCH="amd64" ;;
        aarch64|arm64) CF_ARCH="arm64" ;;
        *) CF_ARCH=""; warn "kiến trúc lạ ($ARCH) — bỏ tải binary, thử apt repo" ;;
    esac
    CF_URL="https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-${CF_ARCH}"
    CF_TMP="$(mktemp)"
    CF_OK=0
    if [ -n "${CF_ARCH:-}" ]; then
        log "tải cloudflared: ${CF_URL}"
        if curl -fsSL --retry 3 -o "$CF_TMP" "$CF_URL" && [ -s "$CF_TMP" ]; then
            chmod +x "$CF_TMP"
            # cài vào /usr/local/bin (sudo) — fallback ~/.local/bin
            if run_as_root install -m 0755 "$CF_TMP" /usr/local/bin/cloudflared; then
                CF_OK=1
            elif mkdir -p "$HOME/.local/bin" \
                 && install -m 0755 "$CF_TMP" "$HOME/.local/bin/cloudflared"; then
                SHELL_RC="$HOME/.bashrc" add_path "$HOME/.local/bin"
                CF_OK=1
            fi
        else
            warn "tải binary cloudflared thất bại — thử apt repo pkg.cloudflare.com"
        fi
    fi
    if [ "$CF_OK" -eq 1 ]; then
        ok "đã cài cloudflared: $(cloudflared --version 2>&1 | head -1)"
    else
        # apt repo chính thức của Cloudflare
        log "apt repo: pkg.cloudflare.com..."
        run_as_root mkdir -p --mode=0755 /usr/share/keyrings
        curl -fsSL https://pkg.cloudflare.com/cloudflare-main.gpg \
            | run_as_root tee /usr/share/keyrings/cloudflare-main.gpg >/dev/null \
            || warn "không lấy được khoá Cloudflare GPG"
        echo "deb [signed-by=/usr/share/keyrings/cloudflare-main.gpg] https://pkg.cloudflare.com/cloudflared $(lsb_release -cs 2>/dev/null || echo any) main" \
            | run_as_root tee /etc/apt/sources.list.d/cloudflared.list >/dev/null
        if run_as_root apt-get update -y >/dev/null 2>&1 \
           && run_as_root apt-get install -y cloudflared; then
            ok "đã cài cloudflared (apt): $(cloudflared --version 2>&1 | head -1)"
        else
            warn "cloudflared chưa cài được — tunnel cloudflare sẽ không khả dụng; dùng --tunnel-url"
        fi
    fi
    rm -f "$CF_TMP"
fi

# ------------------------------------------------ 3) pip deps ------------------------------------------------
log "Bước 3: pip dependencies (requests / urllib3 / httpx)..."
PIP_OK=0
set +e
python3 -m pip install --upgrade -r requirements.txt >/tmp/sofia_pip.log 2>&1 \
    || python3 -m pip install --user --upgrade -r requirements.txt >>/tmp/sofia_pip.log 2>&1 \
    || python3 -m pip install --break-system-packages --upgrade -r requirements.txt >>/tmp/sofia_pip.log 2>&1 \
    || run_as_root python3 -m pip install --upgrade -r requirements.txt >>/tmp/sofia_pip.log 2>&1
if [ $? -eq 0 ]; then PIP_OK=1; fi
set -e
if [ "$PIP_OK" -eq 1 ]; then
    ok "pip deps đã sẵn sàng"
else
    warn "pip install có vấn đề — xem /tmp/sofia_pip.log (sofia có thể vẫn chạy nếu deps đã có)"
fi

# ------------------------------------------------ 4) nâng cấp multi-target ------------------------------------------------
log "Bước 4: nâng cấp sofia.py lên bản multi-target (--batch-size / --resume)..."
if [ ! -f sofia.py ]; then
    err "không thấy sofia.py trong $SCRIPT_DIR — bỏ qua nâng cấp"
elif grep -q "SOFIA-MT" sofia.py && grep -q "def processed_urls" sofia.py; then
    ok "sofia.py đã ở bản multi-target — bỏ qua"
else
    if [ -f tools/upgrade_multitarget.py ] && python3 tools/upgrade_multitarget.py sofia.py; then
        ok "sofia.py đã nâng cấp lên bản multi-target"
    else
        warn "không nâng cấp được sofia.py tự động — xem tools/upgrade_multitarget.py"
    fi
fi

# ------------------------------------------------ 5) targets.txt mẫu ------------------------------------------------
if [ ! -f targets.txt ]; then
    cat > targets.txt <<'EOF'
# SofiaTool v2 — danh sách target (1 host/URL mỗi dòng, # = chú thích)
# Dùng: python3 sofia.py -t targets.txt --threads 20 --batch-size 50 --resume
# https://shop.example.com
# https://admin.example.net
EOF
    ok "đã tạo targets.txt mẫu (thay URL giả bằng target thật)"
else
    ok "targets.txt đã có — giữ nguyên"
fi

# ------------------------------------------------ 6) kiểm tra cuối ------------------------------------------------
log ""
log "====================== KIỂM TRA CUỐI ======================"
log ""
for c in whcli cloudflared; do
    if have "$c"; then
        ok "$c: $($c --version 2>&1 | head -1)"
    else
        warn "$c: CHƯA CÀI"
    fi
done
if python3 - <<'PY' >/dev/null 2>&1
import requests, urllib3, httpx
PY
then
    ok "python deps: requests, urllib3, httpx import được"
else
    warn "python deps: import lỗi — chạy lại bước 3 hoặc xem /tmp/sofia_pip.log"
fi
if python3 -m py_compile sofia.py; then
    ok "sofia.py: py_compile OK"
fi
if python3 sofia.py --help 2>&1 | grep -q -- "--batch-size" \
   && python3 sofia.py --help 2>&1 | grep -q -- "--resume"; then
    ok "sofia.py: hỗ trợ --batch-size và --resume (multi-target)"
else
    warn "sofia.py: --help không thấy --batch-size/--resume — chạy lại bước 4"
fi

log ""
log "---------------------- CÁCH DÙNG ----------------------"
log "  python3 sofia.py -t targets.txt --threads 20 --batch-size 50 --resume"
log "  python3 sofia.py -t targets.txt --batch-size 0          # 0 = tất cả cùng lúc"
log "  python3 sofia.py --discover --scope example.com --batch-size 50 --resume"
log "-------------------------------------------------------"
log "Hoàn tất: $OK_CNT ✔ / $WARN_CNT ⚠  (⚠ không chặn — xem chi tiết phía trên)"
if [ "$WARN_CNT" -gt 0 ]; then
    exit 0
fi