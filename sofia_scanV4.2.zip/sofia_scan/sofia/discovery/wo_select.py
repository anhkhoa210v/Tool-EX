"""SofiaTool v2 — PHA 1b (WooCommerce): chọn CVE PHÙ HỢP với target.

Với mỗi target WooCommerce, module này dò các PLUGIN có trong KB `exploit_wo.kb`
( theo `slug`), lấy version qua readme.txt/changelog.txt/asset `?ver=`, rồi ánh
xạ sang ĐÚNG danh sách CVE cần chạy bằng ngưỡng `affected`/`fixed` của từng CVE.

Kết quả `select(...)`:

    {
      "url"   : base,
      "cves"  : [CVE cần chạy],
      "plugins": {slug: version|None},   # plugin phát hiện được
      "reasons": {cve: lý do},           # vì sao chọn/bỏ
      "mode"  : "targeted" | "fallback-all" | "none" | "none-vuln" | "invalid",
      "woocommerce_version": str|None,
    }

Cơ chế chọn (tối ưu cho danh sách lớn — KHÔNG phải bắn hết 13 CVE vào mọi site):

  * Plugin CÓ MẶT + rõ version:
        - version < ngưỡng vá  -> chạy CVE đó
        - version >= ngưỡng vá -> BỎ (đã vá), không sinh job
  * Plugin CÓ MẶT nhưng không rõ version -> vẫn chạy (module tự xác minh hành vi)
  * Plugin KHÔNG thấy (readme 404 và asset không xuất hiện) -> BỎ CVE đó
  * Không detect được plugin nào trong KB:
        - fallback="all"  (mặc định): chạy toàn bộ CVE (an toàn, không bỏ lỡ —
          hợp với plugin thương mại không có readme.txt)
        - fallback="none" : bỏ qua target (chế độ tối ưu tốc độ, opt-in)

So sánh version dùng `exploit_wo.common.version_lt` (dotted, pad phần thiếu = 0).

CHỈ DÙNG CHO MỤC ĐÍCH KIỂM THỬ BẢO MẬT ĐƯỢC UỶ QUYỀN.
"""
import re
from concurrent.futures import ThreadPoolExecutor, as_completed

import httpx

from core import config, http
from core.logger import get_logger

log = get_logger()

# import metadata + helper so sánh version của package exploit_wo
from exploit_wo import kb as wo_kb
from exploit_wo.common import normalize, version_lt

_STABLE_RE = re.compile(r"Stable tag:\s*([0-9][0-9A-Za-z._\-]*)", re.I)
_CHANGELOG_RE = re.compile(r"=\s*([0-9][0-9A-Za-z._\-]*)\s*=")
_WOO_CORE = "woocommerce"


def _unique_slugs():
    """Tất cả slug plugin trong KB + plugin woocommerce (để lấy version core)."""
    slugs = {c["slug"] for c in wo_kb.CVES}
    slugs.add(_WOO_CORE)
    return sorted(slugs)


def _safe_get(cli, url):
    try:
        return cli.get(url)
    except httpx.HTTPError:
        return None


def _parse_readme(txt):
    m = _STABLE_RE.search(txt)
    if m:
        return m.group(1)
    m = _CHANGELOG_RE.search(txt)
    if m:
        return m.group(1)
    return None


def _probe_slug(cli, base, slug, home_text):
    """Trả (present: bool, version: str|None, source: str|None)."""
    for path in (f"/wp-content/plugins/{slug}/readme.txt",
                 f"/wp-content/plugins/{slug}/changelog.txt"):
        r = _safe_get(cli, base + path)
        if r is not None and r.status_code == 200:
            return True, _parse_readme(r.text or ""), "readme/changelog"
    if f"/wp-content/plugins/{slug}/" in home_text:
        m = re.search(
            re.escape(f"/wp-content/plugins/{slug}/") +
            r"[^\"'\s>]*\?ver=([0-9][0-9A-Za-z._\-]*)", home_text, re.I)
        return True, (m.group(1) if m else None), "asset"
    return False, None, None


def _version_affected(ver, entry):
    """True = dính, False = đã vá/không dính, None = không rõ version."""
    if not ver:
        return None
    affected = (entry.get("affected") or "").strip()
    fixed = entry.get("fixed") or ""
    if affected.startswith("<="):
        return not version_lt(affected[2:].strip(), ver)
    if affected.startswith("<"):
        return version_lt(ver, affected[1:].strip())
    if fixed:
        return version_lt(ver, fixed)
    return None


def _match_tokens(entry, tokens):
    if not tokens:
        return False
    hay = " ".join(str(entry.get(k, ""))
                   for k in ("cve", "slug", "module")).lower()
    return any(tok in hay for tok in tokens)


def choose_cves(plugins, sources=None, fallback="all", only=None, exclude=None):
    """THUẦN logic (KHÔNG HTTP): ánh xạ plugin+version -> {cves, reasons, mode}.

    `plugins`  : {slug: version|None} — plugin phát hiện được (version có thể None)
    `sources`  : {slug: nguồn} tuỳ chọn (chỉ dùng cho lý do/log)

    Tách riêng để (a) runner dùng sau bước dò HTTP, và (b) cache phân loại tái
    dùng lại quyết định mà không cần chạm mạng — quan trọng khi xử lý danh sách
    target lớn / chạy resume nhiều lần.
    """
    plugins = plugins or {}
    sources = sources or {}
    only_t = [t.strip().lower() for t in (only or "").split(",") if t.strip()]
    excl_t = [t.strip().lower() for t in (exclude or "").split(",") if t.strip()]

    cves, reasons = [], {}
    for entry in wo_kb.CVES:
        cve, slug = entry["cve"], entry["slug"]
        if only_t and not _match_tokens(entry, only_t):
            reasons[cve] = "bị lọc bởi --only"
            continue
        if excl_t and _match_tokens(entry, excl_t):
            reasons[cve] = "bị lọc bởi --exclude"
            continue
        if slug in plugins:
            ver = plugins[slug]
            src = sources.get(slug, "probe")
            hit = _version_affected(ver, entry)
            if hit is False:
                reasons[cve] = f"đã vá ({slug} {ver} >= {entry.get('fixed')})"
                continue
            cves.append(cve)
            reasons[cve] = f"{slug} {ver or '(version ?)'} [{src}]"
        else:
            reasons[cve] = f"plugin {slug} không thấy cài"

    if cves:
        mode = "targeted"
    elif plugins:
        mode = "none-vuln"
    elif fallback == "none":
        mode = "none"
    else:
        cves = [c["cve"] for c in wo_kb.CVES]
        for c in wo_kb.CVES:
            reasons[c["cve"]] = "fallback-all (không detect plugin nào)"
        mode = "fallback-all"
    return {"cves": cves, "reasons": reasons, "mode": mode}


def select(base, timeout=None, fallback="all", only=None, exclude=None,
           home_text=None):
    """Chọn CVE cho 1 target WooCommerce. Trả dict mô tả ở docstring module.

    `home_text`: HTML trang chủ đã lấy sẵn (từ PHA 1b) -> bỏ GET '/' lại.
    """
    base = normalize(base)
    if not base:
        return {"url": base, "cves": [], "plugins": {}, "reasons": {},
                "mode": "invalid", "woocommerce_version": None}

    probes = {}
    to = timeout or config.TIMEOUT
    try:
        with http.make_httpx_client(timeout=to) as cli:
            if home_text is None:
                home = _safe_get(cli, base + "/")
                home_text = (home.text or "")[:400_000] if home is not None else ""
            else:
                home_text = home_text[:400_000]
            slugs = _unique_slugs()
            with ThreadPoolExecutor(max_workers=6) as pool:
                futs = {pool.submit(_probe_slug, cli, base, slug, home_text): slug
                        for slug in slugs}
                for fut in as_completed(futs):
                    slug = futs[fut]
                    try:
                        probes[slug] = fut.result()
                    except Exception as e:  # pragma: no cover
                        log.debug("[%s] probe %s lỗi: %s", base, slug, e)
                        probes[slug] = (False, None, None)
    except httpx.HTTPError as e:
        log.debug("[%s] wo_select httpx error: %s", base, e)

    present = {s: (v, src) for s, (p, v, src) in probes.items() if p}
    woo_ver = present.get(_WOO_CORE, (None, None))[0]
    plugins = {s: v for s, (v, _src) in present.items()}
    sources = {s: src for s, (_v, src) in present.items()}

    decision = choose_cves(plugins, sources=sources, fallback=fallback,
                           only=only, exclude=exclude)
    return {"url": base, **decision, "plugins": plugins,
            "woocommerce_version": woo_ver}
