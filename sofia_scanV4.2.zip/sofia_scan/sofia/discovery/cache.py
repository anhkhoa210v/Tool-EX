"""SofiaTool v2 — cache PHÂN LOẠI target (PHA 1b) cho danh sách lớn.

PHA 1b (nhận diện nền tảng + dò version/plugin) là phần CHẠM MẠNG nhiều nhất khi
xử lý danh sách lớn: mỗi host tốn 1-6 request GET chỉ để classify. Khi chạy lại
(batch/`--resume`/nhiều phiên), việc classify lại từ đầu vừa chậm vừa tạo tải vô
ích lên target.

Module này lưu **SỰ THẬT NHẬN DIỆN** (không lưu danh sách CVE) xuống
`report/classify_cache.json`:

    {
      "<host-key>": {
        "_ts": <epoch>,
        "kind": "magento" | "woocommerce",
        "facts": { platform, engine, edition, signals,
                   version?            # magento/adobe: chuỗi version dò được
                   plugins?, woocommerce_version? }   # woo: plugin + version
      }, ...
    }

Vì cache chỉ giữ sự thật (version/plugin), danh sách CVE luôn được TÍNH LẠI từ
`discovery.version` / `discovery.wo_select.choose_cves` khi đọc cache — nên khi
ngưỡng CVE trong KB thay đổi, cache cũ không sinh quyết định sai.

Thiết kế cho tải lớn:
  * Nạp file 1 lần (in-memory dict), ghi lại 1 lần khi flush -> tránh O(n²) I/O.
  * AN TOÀN ĐA LUỒNG: có khoá + ghi atomic (tmp -> os.replace).
  * TTL (mặc định 24h, `SOFIA_CLASSIFY_TTL`): entry quá cũ coi như miss.

CHỈ DÙNG CHO MỤC ĐÍCH KIỂM THỬ BẢO MẬT ĐƯỢC UỶ QUYỀN.
"""
import json
import os
import threading
import time

from core import config
from core.logger import get_logger

log = get_logger()

_LOCK = threading.RLock()
DEFAULT_TTL = int(os.environ.get("SOFIA_CLASSIFY_TTL", "86400") or "86400")

# tăng khi cấu trúc entry đổi -> cache cũ tự bị bỏ qua
SCHEMA = 2


def _path():
    return os.path.join(config.REPORT_DIR, "classify_cache.json")


def key_of(host):
    """Khoá cache cho 1 host/URL (dùng normalize của target_queue)."""
    from discovery.target_queue import normalize
    url = normalize(host) or (host or "").strip().lower()
    return url.lower()


class ClassifyCache:
    """Cache phân loại in-memory + persist. Thread-safe."""

    def __init__(self, enabled=True, ttl=None):
        self.enabled = bool(enabled)
        self.ttl = DEFAULT_TTL if ttl is None else int(ttl)
        self._data = {}
        self._dirty = False
        self._hits = 0
        self._misses = 0
        if self.enabled:
            self._load()

    # ------------------------------------------------------------------ I/O
    def _load(self):
        with _LOCK:
            try:
                with open(_path(), encoding="utf-8") as f:
                    d = json.load(f)
            except (OSError, json.JSONDecodeError):
                d = {}
            if not isinstance(d, dict) or d.get("_schema") != SCHEMA:
                self._data = {}
                return
            hosts = d.get("hosts")
            self._data = hosts if isinstance(hosts, dict) else {}

    def flush(self):
        """Ghi cache xuống đĩa (atomic). No-op nếu tắt / không có thay đổi."""
        if not self.enabled or not self._dirty:
            return
        with _LOCK:
            payload = {"_schema": SCHEMA, "generated": time.time(),
                       "hosts": self._data}
            try:
                os.makedirs(config.REPORT_DIR, exist_ok=True)
                tmp = _path() + ".tmp"
                with open(tmp, "w", encoding="utf-8") as f:
                    json.dump(payload, f, ensure_ascii=False)
                os.replace(tmp, _path())
                self._dirty = False
            except OSError as e:  # pragma: no cover
                log.debug("classify cache ghi lỗi: %s", e)

    # --------------------------------------------------------------- entry
    def _fresh(self, entry):
        if not isinstance(entry, dict):
            return False
        ts = entry.get("_ts") or 0
        if self.ttl and ts and (time.time() - ts) > self.ttl:
            return False
        return entry.get("kind") in ("magento", "woocommerce")

    def get(self, host):
        """Trả entry {kind, facts} còn hạn, hoặc None (miss)."""
        if not self.enabled:
            return None
        k = key_of(host)
        with _LOCK:
            e = self._data.get(k)
        if self._fresh(e):
            self._hits += 1
            return e
        self._misses += 1
        return None

    def put(self, host, kind, facts):
        """Lưu sự thật nhận diện của 1 host. Trả True nếu có thay đổi."""
        if not self.enabled:
            return False
        k = key_of(host)
        entry = {"_ts": time.time(), "kind": kind, "facts": facts}
        with _LOCK:
            if self._data.get(k) == entry:
                return False
            self._data[k] = entry
            self._dirty = True
        return True

    def stats(self):
        return {"hits": self._hits, "misses": self._misses,
                "size": len(self._data), "enabled": self.enabled}
