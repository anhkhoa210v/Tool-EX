"""SofiaTool v2 — PHA 1: nhận diện NỀN TẢNG của target.

Phân loại mỗi host thành 1 trong 4 giá trị:

  "magento"         Magento Open Source (Community)   -> pipeline `exploit/`
  "adobe_commerce"  Adobe Commerce (Enterprise/B2B/Cloud) -> `exploit/`
                    (Adobe Commerce dùng CHUNG bộ CVE lõi với Magento —
                     các CVE trong `discovery/version.py` áp cho cả hai)
  "woocommerce"     WordPress + WooCommerce            -> pipeline `exploit_wo/`
  "unknown"         không nhận diện được (bị bỏ qua)

Thứ tự ưu tiên khi dò (mạnh -> yếu), tránh nhầm nền tảng:

  Magento
    1. header  X-Magento-Cache-Debug / X-Magento-Tags   (mạnh)
    2. body    "static/version" + "mage/cookies"
    3. REST    /rest/V1/store/storeConfigs -> JSON array
    4. /magento_version
    Adobe Commerce vs Community (chỉ để hiển thị/định tuyến):
       composer.json|lock có magento/product-enterprise-edition |
       product-adobe-commerce | product-b2b-edition  -> adobe_commerce
       magento/product-community-edition              -> community

  WooCommerce
    Bắt buộc có dấu hiệu WordPress (wp-content/wp-includes/wp-json/
    meta generator) VÀ >=1 dấu hiệu WooCommerce MẠNH:
       /wp-content/plugins/woocommerce/  (asset đang enqueue)
       ?ver= của asset woocommerce
       cookie woocommerce
       REST  /wp-json/wc/store/v1/storeInfo|cart  (Store API)

Đây là bước CHỈ ĐỌC (GET) — không gửi payload. Kết quả dùng để định tuyến
target sang đúng pipeline khai thác, nên danh sách target trộn lẫn Magento /
WooCommerce vẫn xử lý đúng.

CHỈ DÙNG CHO MỤC ĐÍCH KIỂM THỬ BẢO MẬT ĐƯỢC UỶ QUYỀN.
"""
import re
from concurrent.futures import ThreadPoolExecutor

import requests
import urllib3

from core import config, http
from core.logger import get_logger
from discovery import fingerprint

log = get_logger()
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Trần ký tự HTML trang chủ dùng lại cho cả probe magento + woo + version.
HOME_TEXT_LIMIT = 400_000

PLATFORMS = ("magento", "adobe_commerce", "woocommerce", "unknown")

# --- WordPress / WooCommerce signals ----------------------------------------
_WP_RE = re.compile(r"/wp-(?:content|includes)/", re.I)
_WP_GEN_RE = re.compile(
    r'<meta[^>]+name=["\']generator["\'][^>]+content=["\']WordPress', re.I)
_WOO_DIR_RE = re.compile(r"/wp-content/plugins/woocommerce/", re.I)
_WOO_VER_RE = re.compile(
    r"/wp-content/plugins/woocommerce/[^\"'\s>]*\?ver=([0-9][0-9A-Za-z._\-]*)",
    re.I)
_WOO_CART_RE = re.compile(r"(?:wc-ajax|wc_cart|add-to-cart=)", re.I)
_WOO_WEAK_RE = re.compile(r"\bwoocommerce\b", re.I)
_WOO_README_VER_RE = re.compile(
    r"Stable tag:\s*([0-9][0-9A-Za-z._\-]*)", re.I)

# --- Adobe Commerce edition markers -----------------------------------------
_ADOBE_EDITIONS = (
    "magento/product-enterprise-edition",
    "magento/product-adobe-commerce",
    "magento/product-b2b-edition",
    "adobe-commerce",
)
_COMMUNITY_EDITION = "magento/product-community-edition"
_ADOBE_TEXT_RE = re.compile(
    r"adobe\s+commerce|magento\s+commerce|enterprise\s+edition", re.I)

# dấu hiệu WooCommerce "mạnh" (khó trùng với 1 site WP thường)
_WOO_STRONG = frozenset({"woo-dir", "woo-asset", "woo-cookie", "wc-store-rest"})
_WOO_MEDIUM = frozenset({"wc-cart"})


def _session():
    # Session có connection pool + retry GET/HEAD (core.http).
    return http.make_session()


def _get(sess, url):
    try:
        return sess.get(url, timeout=config.TIMEOUT, allow_redirects=True)
    except requests.RequestException:
        return None


# --------------------------------------------------------------- Magento -----
def _magento_edition(base, sess, home_text):
    """Suy edition từ composer.json/lock rồi tới HTML trang chủ. None nếu mù."""
    for path in ("/composer.json", "/composer.lock", "/composer/composer.lock"):
        r = _get(sess, base + path)
        if r is None or r.status_code != 200:
            continue
        t = (r.text or "")[:200_000].lower()
        if any(e in t for e in _ADOBE_EDITIONS):
            return "adobe_commerce"
        if _COMMUNITY_EDITION in t:
            return "community"
    if _ADOBE_TEXT_RE.search(home_text or ""):
        return "adobe_commerce"
    return None


def probe_magento(base, sess, home=None):
    """Trả (is_magento, signals, edition). Chỉ GET, không payload.

    `home`: response trang chủ đã lấy sẵn (tái dùng, KHÔNG GET lại).
    """
    signals = []
    text = ""
    r = home if home is not None else _get(sess, base + "/")
    if r is not None:
        if fingerprint.check_headers(r):
            signals.append("headers")
        text = (r.text or "")[:200_000]
        if fingerprint.check_body(text):
            signals.append("body")
    if not signals and fingerprint.check_rest(base, sess):
        signals.append("rest")
    if not signals:
        m = _get(sess, base + "/magento_version")
        if m is not None and m.status_code == 200 and "magento" in (m.text or "").lower():
            signals.append("magento_version")
    if not signals:
        return False, [], None
    edition = _magento_edition(base, sess, text)
    return True, signals, edition


# ------------------------------------------------------------ WooCommerce ----
def _wc_store_rest(base, sess):
    """Store API của WooCommerce (JSON) — dấu hiệu mạnh, độc lập theme/CDN."""
    for path in ("/wp-json/wc/store/v1/storeInfo", "/wp-json/wc/store/v1/cart"):
        r = _get(sess, base + path)
        if r is None or r.status_code != 200:
            continue
        ctype = (r.headers.get("Content-Type") or "").lower()
        if "json" not in ctype:
            continue
        try:
            j = r.json()
        except ValueError:
            continue
        if isinstance(j, dict):
            return True
    return False


def probe_woocommerce(base, sess, home=None, home_text=None):
    """Trả (is_woocommerce, is_wordpress, signals, woo_version).

    `home`/`home_text`: response/nội dung trang chủ đã lấy sẵn (tái dùng).
    """
    signals = []
    r = home if home is not None else _get(sess, base + "/")
    if home_text is not None:
        text = home_text[:HOME_TEXT_LIMIT]
    else:
        text = (r.text or "")[:HOME_TEXT_LIMIT] if r is not None else ""
    wp = bool(_WP_GEN_RE.search(text) or _WP_RE.search(text)
              or "wp-json" in text)
    if wp:
        signals.append("wordpress")
    if _WOO_DIR_RE.search(text):
        signals.append("woo-dir")
    m = _WOO_VER_RE.search(text)
    woo_ver = m.group(1) if m else None
    if m:
        signals.append("woo-asset")
    if _WOO_CART_RE.search(text):
        signals.append("wc-cart")
    if r is not None:
        try:
            if any("woocommerce" in (c or "").lower() for c in r.cookies.keys()):
                signals.append("woo-cookie")
        except Exception:  # pragma: no cover - cookie jar bất thường
            pass
    if wp and "wc-store-rest" not in signals and _wc_store_rest(base, sess):
        signals.append("wc-store-rest")
    # version từ readme.txt của plugin woocommerce (nếu lộ)
    if wp and not woo_ver:
        rr = _get(sess, base + "/wp-content/plugins/woocommerce/readme.txt")
        if rr is not None and rr.status_code == 200:
            mm = _WOO_README_VER_RE.search(rr.text or "")
            if mm:
                woo_ver = mm.group(1)
    is_woo = wp and (any(s in _WOO_STRONG for s in signals)
                     or any(s in _WOO_MEDIUM for s in signals))
    return is_woo, wp, signals, woo_ver


# ---------------------------------------------------------------- detect -----
def _detect_scheme(base, sess, want_home=False):
    # Lấy trang chủ MỘT LẦN rồi tái dùng cho cả probe magento + woo
    # (bản cũ GET '/' hai lần khi target không phải Magento).
    home = _get(sess, base + "/")
    home_text = ""
    if home is not None:
        home_text = (home.text or "")[:HOME_TEXT_LIMIT]

    is_m, m_sig, edition = probe_magento(base, sess, home=home)
    if is_m:
        info = {"platform": "adobe_commerce" if edition == "adobe_commerce"
                else "magento",
                "engine": "magento", "edition": edition, "signals": m_sig}
        if want_home:
            info["_home_text"] = home_text
        return info

    is_woo, wp, w_sig, woo_ver = probe_woocommerce(base, sess, home=home,
                                                   home_text=home_text)
    if is_woo:
        info = {"platform": "woocommerce", "engine": "wordpress",
                "edition": None, "signals": w_sig,
                "woocommerce_version": woo_ver}
    else:
        info = {"platform": "unknown", "engine": None, "edition": None,
                "signals": w_sig if wp else []}
    if want_home:
        info["_home_text"] = home_text
    return info


def detect(host, sess=None, schemes=("https", "http"), want_home=False):
    """Nhận diện nền tảng 1 host. Trả dict:

        {url, platform, engine, edition, signals, [woocommerce_version]}

    `platform` thuộc PLATFORMS. Thử https rồi http nếu https không ra kết quả.
    `want_home=True` -> kèm khoá TẠM `_home_text` (HTML trang chủ) để lớp gọi
    tái dùng cho dò version/plugin, tránh GET lại trang chủ.
    """
    if not host:
        return {"url": None, "platform": "unknown", "engine": None,
                "edition": None, "signals": []}
    raw = host.strip()
    if "://" in raw:
        base_raw = raw.rstrip("/")
        schemes = (base_raw.split("://", 1)[0],)
        host_only = base_raw.split("://", 1)[1]
    else:
        host_only = raw.rstrip("/")
    own = sess is None
    sess = sess or _session()
    try:
        last = None
        for scheme in schemes:
            base = f"{scheme}://{host_only}"
            info = _detect_scheme(base, sess, want_home=want_home)
            info["url"] = base
            if info["platform"] != "unknown":
                return info
            last = info
        return last or {"url": f"{schemes[0]}://{host_only}",
                        "platform": "unknown", "engine": None,
                        "edition": None, "signals": []}
    finally:
        if own:
            try:
                sess.close()
            except Exception:  # pragma: no cover
                pass


def detect_many(hosts, max_workers=None):
    """Nhận diện song song nhiều host. Trả list dict theo ĐÚNG thứ tự đầu vào."""
    hosts = list(hosts)
    if not hosts:
        return []
    workers = max_workers or min(32, max(4, len(hosts)))
    out = [None] * len(hosts)

    def _one(idx, h):
        try:
            out[idx] = detect(h)
        except Exception as e:  # không để 1 host làm chết cả lượt
            log.debug("platform.detect lỗi [%s]: %s", h, e)
            out[idx] = {"url": h, "platform": "unknown", "engine": None,
                        "edition": None, "signals": [], "error": str(e)}

    with ThreadPoolExecutor(max_workers=workers) as pool:
        futs = [pool.submit(_one, i, h) for i, h in enumerate(hosts)]
        for f in futs:
            f.result()
    return out
