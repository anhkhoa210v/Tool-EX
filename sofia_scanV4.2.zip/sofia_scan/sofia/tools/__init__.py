"""SofiaTool v2 — package tools (tiện ích dùng chung, tách khỏi core/exploit)."""
