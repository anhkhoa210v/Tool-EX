#!/usr/bin/env python3
"""Benchmark tối ưu tốc độ cho danh sách target lớn (SofiaTool v2).

Đo 2 điểm nóng đã tối ưu, KHÔNG gửi payload khai thác (chỉ GET, an toàn):

  A) report I/O  — so sánh ghi report.json kiểu CŨ (rewrite toàn bộ, indent=2,
     O(n^2)) với kiểu MỚI (journal append-only O(n)) ở N=1000 và N=4000.
     Kỳ vọng: bản cũ tăng ~bình phương (16x khi n gấp 4), bản mới ~tuyến tính.

  B) classify HTTP — dựng mock HTTP server nội bộ (127.0.0.1), đếm số request
     mỗi host cho đường CŨ (detect + version/wo_select GET lại '/') và đường
     MỚI (PHA 1b lấy trang chủ 1 lần rồi tái dùng). Kỳ vọng: giảm 2-3 GET '/'
     mỗi host (bản cũ GET '/' 2-4 lần, bản mới 1 lần).

Cách chạy:
    cd sofia && python3 tools/bench_large_list.py
    python3 tools/bench_large_list.py --sizes 1000,4000 --json out.json

CHỈ DÙNG CHO MỤC ĐÍCH KIỂM THỬ BẢO MẬT ĐƯỢC UỶ QUYỀN.
"""
import argparse
import json
import os
import sys
import tempfile
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

# đảm bảo import được package gốc sofia/ khi chạy trực tiếp từ tools/
_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

from core import config                      # noqa: E402
from core import http as httpmod             # noqa: E402
from core import logger as logmod            # noqa: E402
from discovery import platform, version, wo_select  # noqa: E402


# --------------------------------------------------------------- tiện ích ----
def _make_entry(i):
    return {
        "url": f"http://t{i}.example.com",
        "cve": "CVE-2024-34102",
        "hit": (i % 5 == 0),
        "time": "2026-01-01T00:00:00+00:00",
        "error": None,
    }


# ================================================================= PHẦN A ====
def _legacy_write_run(report_dir, n):
    """Mô phỏng add_target_report CŨ: load + json.dump(toàn bộ, indent=2)."""
    path = os.path.join(report_dir, "report.json")
    data = {"generated": "", "targets": []}
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    t0 = time.perf_counter()
    for i in range(n):
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        data["targets"].append(_make_entry(i))
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
    return time.perf_counter() - t0


def _reset_logger(report_dir):
    config.REPORT_DIR = report_dir
    config.REPORT_COMPACT_AFTER = 400
    logmod._REPORT_CACHE = None
    logmod._REPORT_CACHE_PATH = None
    logmod._PENDING = 0
    for p in (logmod._report_path(), logmod._journal_path()):
        try:
            os.remove(p)
        except OSError:
            pass


def _new_write_run(report_dir, n):
    """add_target_report MỚI: journal append-only O(n) + flush cuối."""
    _reset_logger(report_dir)
    t0 = time.perf_counter()
    for i in range(n):
        logmod.add_target_report(_make_entry(i))
    logmod.flush_report(force=True)
    return time.perf_counter() - t0


def bench_report(sizes):
    out = {}
    with tempfile.TemporaryDirectory() as base:
        for n in sizes:
            d_old = os.path.join(base, f"old_{n}")
            d_new = os.path.join(base, f"new_{n}")
            os.makedirs(d_old, exist_ok=True)
            os.makedirs(d_new, exist_ok=True)
            t_old = _legacy_write_run(d_old, n)
            t_new = _new_write_run(d_new, n)
            sz_old = os.path.getsize(os.path.join(d_old, "report.json"))
            sz_new = os.path.getsize(os.path.join(d_new, "report.json"))
            out[n] = {"old_s": t_old, "new_s": t_new,
                      "old_bytes": sz_old, "new_bytes": sz_new}
    # dọn cache logger để atexit KHÔNG ghi vào thư mục tạm đã bị xoá
    logmod._REPORT_CACHE = None
    logmod._REPORT_CACHE_PATH = None
    logmod._PENDING = 0
    return out


# ================================================================= PHẦN B ====
class _MockHandler(BaseHTTPRequestHandler):
    mode = "magento"           # hoặc "woocommerce"
    counts = {}
    counts_lock = threading.Lock()

    def log_message(self, *a):  # tắt log ồn ào
        pass

    def do_GET(self):
        with _MockHandler.counts_lock:
            _MockHandler.counts[self.path] = \
                _MockHandler.counts.get(self.path, 0) + 1
        path = self.path.split("?", 1)[0]
        body = b""
        ctype = "text/html; charset=utf-8"
        headers = []
        if path == "/":
            if _MockHandler.mode == "magento":
                headers.append(("X-Magento-Tags", "cat_p,store,cms_b"))
                body = (b"<html><head><title>Magento 2.4.6 store</title></head>"
                        b"<body>static/version1234567890/frontend/</body></html>")
            else:
                headers.append(("Set-Cookie", "woocommerce_cart_hash=x; Path=/"))
                body = (b"<html><head><meta name=\"generator\" "
                        b"content=\"WordPress 6.6\"></head><body>"
                        b"/wp-content/plugins/woocommerce/assets/x.css"
                        b"</body></html>")
            self.send_response(200)
        else:
            self.send_response(404)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        for k, v in headers:
            self.send_header(k, v)
        self.end_headers()
        if body:
            self.wfile.write(body)


def _start_mock(mode):
    _MockHandler.mode = mode
    _MockHandler.counts = {}
    srv = ThreadingHTTPServer(("127.0.0.1", 0), _MockHandler)
    th = threading.Thread(target=srv.serve_forever, daemon=True)
    th.start()
    return srv, srv.server_address[1]


def _root_gets():
    c = _MockHandler.counts
    return c.get("/", 0), sum(c.values())


def _run_before(base):
    """Đường CŨ: detect không reuse + version/wo_select tự GET lại '/'."""
    platform.detect(base)
    version.fetch_version(base)
    wo_select.select(base, timeout=5)


def _run_after(base):
    """Đường MỚI: lấy trang chủ 1 lần rồi tái dùng cho mọi bước."""
    info = platform.detect(base, want_home=True)
    home_text = info.pop("_home_text", "") or ""
    version.fetch_version(base, home_text=home_text)
    wo_select.select(base, timeout=5, home_text=home_text)


def bench_classify(mode):
    config.TIMEOUT = 5
    httpmod._TLS.__dict__.clear()      # session sạch
    srv, port = _start_mock(mode)
    base = f"http://127.0.0.1:{port}"
    try:
        _MockHandler.counts = {}
        _run_before(base)
        root_before, tot_before = _root_gets()

        httpmod._TLS.__dict__.clear()
        _MockHandler.counts = {}
        _run_after(base)
        root_after, tot_after = _root_gets()
    finally:
        srv.shutdown()
        srv.server_close()
    return {"mode": mode,
            "root_get_before": root_before, "root_get_after": root_after,
            "total_req_before": tot_before, "total_req_after": tot_after}


# ================================================================= MAIN ======
def main(argv=None):
    ap = argparse.ArgumentParser(description="Benchmark SofiaTool danh sách lớn")
    ap.add_argument("--sizes", default="1000,4000",
                    help="kích thước n cho phần report I/O (mặc định 1000,4000)")
    ap.add_argument("--json", dest="json_out", default=None,
                    help="ghi kết quả ra file JSON")
    args = ap.parse_args(argv)
    sizes = [int(s) for s in args.sizes.split(",") if s.strip()]

    print("=" * 68)
    print("A) REPORT I/O  (O(n^2) cũ  vs  O(n) journal mới)")
    print("=" * 68)
    rep = bench_report(sizes)
    for n, r in rep.items():
        sp = r["old_s"] / r["new_s"] if r["new_s"] else float("inf")
        print(f"  n={n:<6} cũ={r['old_s']:.3f}s  mới={r['new_s']:.4f}s  "
              f"-> nhanh {sp:.1f}x   "
              f"(file {r['old_bytes']//1024}KB -> {r['new_bytes']//1024}KB)")
    ks = sorted(rep)
    if len(ks) >= 2:
        lo, hi = ks[0], ks[-1]
        sc_o = rep[hi]["old_s"] / rep[lo]["old_s"] if rep[lo]["old_s"] else 0
        sc_n = rep[hi]["new_s"] / rep[lo]["new_s"] if rep[lo]["new_s"] else 0
        print(f"  tỉ lệ thời gian khi n gấp {hi//lo}x: cũ ~{sc_o:.1f}x "
              f"(bình phương)  |  mới ~{sc_n:.1f}x (tuyến tính)")

    print()
    print("=" * 68)
    print("B) CLASSIFY HTTP  (số request mỗi host)")
    print("=" * 68)
    cl = []
    for mode in ("magento", "woocommerce"):
        r = bench_classify(mode)
        cl.append(r)
        print(f"  [{mode:<11}] GET '/' : {r['root_get_before']} -> "
              f"{r['root_get_after']}   |   tổng request: "
              f"{r['total_req_before']} -> {r['total_req_after']}")

    if args.json_out:
        with open(args.json_out, "w", encoding="utf-8") as f:
            json.dump({"report_io": rep, "classify": cl}, f,
                      ensure_ascii=False, indent=2)
        print(f"\nđã ghi {args.json_out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
