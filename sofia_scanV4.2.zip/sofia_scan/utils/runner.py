"""Wrapper subprocess cho masscan / httpx / nuclei / dig / openssl.

BỀN VỮNG (nâng cấp): trước đây dùng subprocess.run(timeout=...) — khi hết thời
gian chỉ kill TIẾN TRÌNH CON trực tiếp, còn các tiến trình CHÁU (worker pool của
nuclei, luồng của masscan) vẫn sống và giữ pipe mở → mất output một phần và rò rỉ
tiến trình khi quét dài. Nay:

  * Popen với `start_new_session=True` → mỗi lệnh là 1 process-group riêng;
  * khi timeout: gửi SIGTERM cho CẢ NHÓM (os.killpg), chờ `grace` giây,
    rồi SIGKILL cả nhóm → không còn tiến trình mồ côi;
  * GIỮ LẠI output một phần đã đọc được (nuclei thường in finding trước khi
    bị dừng) thay vì vứt đi như trước.

Không bao giờ raise ra ngoài: trả subprocess.CompletedProcess với returncode
124 khi timeout, 127 khi thiếu binary.
"""
import os
import shutil
import signal
import subprocess
import time

from utils.logger import debug, warn

# Thời gian chờ giữa SIGTERM và SIGKILL (giây) — đủ để tool flush output.
DEFAULT_GRACE = 3.0


def which(binary):
    return shutil.which(binary)


def require(binary):
    path = shutil.which(binary)
    if not path:
        raise RuntimeError(f"Thiếu binary bắt buộc: {binary}")
    return path


def _as_text(value):
    """bytes/str/None → str (Popen có thể trả bytes nếu text chưa kịp áp dụng)."""
    if value is None:
        return ""
    if isinstance(value, bytes):
        return value.decode("utf-8", "ignore")
    return str(value)


def _signal_group(proc, sig):
    """Gửi tín hiệu cho CẢ nhóm tiến trình (con + cháu); fallback kill trực tiếp."""
    try:
        os.killpg(os.getpgid(proc.pid), sig)
        return True
    except (ProcessLookupError, PermissionError, OSError):
        pass
    try:
        proc.send_signal(sig)
        return True
    except (ProcessLookupError, OSError):
        return False


def _terminate_group(proc, grace=DEFAULT_GRACE):
    """SIGTERM nhóm → chờ grace → SIGKILL nhóm. Không raise."""
    _signal_group(proc, signal.SIGTERM)
    deadline = time.monotonic() + max(0.0, float(grace))
    while time.monotonic() < deadline:
        if proc.poll() is not None:
            return
        time.sleep(0.1)
    if proc.poll() is None:
        _signal_group(proc, signal.SIGKILL)
        try:
            proc.wait(timeout=2)
        except subprocess.TimeoutExpired:
            pass


def _drain(proc, fallback_out, fallback_err):
    """Sau khi kill, cố thu nốt output còn lại; nếu không → dùng phần đã có."""
    try:
        out, err = proc.communicate(timeout=5)
        return _as_text(out) or fallback_out, _as_text(err) or fallback_err
    except subprocess.TimeoutExpired:
        proc.kill()
        try:
            proc.communicate(timeout=2)
        except Exception:  # noqa: BLE001 — chỉ là dọn dẹp
            pass
        return fallback_out, fallback_err
    except (ValueError, OSError):
        return fallback_out, fallback_err


def run(cmd, timeout=300, input_text=None, grace=DEFAULT_GRACE):
    """Chạy lệnh, capture stdout/stderr; không bao giờ raise ra ngoài.

    Timeout → dừng CẢ NHÓM tiến trình và trả CompletedProcess(returncode=124,
    stdout/stderr = phần output thu được cho tới lúc dừng).
    """
    debug(f"[runner] {' '.join(cmd)}")
    try:
        proc = subprocess.Popen(
            cmd,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            start_new_session=True,
        )
    except FileNotFoundError:
        warn(f"[runner] không tìm thấy binary: {cmd[0]}")
        return subprocess.CompletedProcess(cmd, 127, "", "not found")
    except (OSError, ValueError) as exc:
        warn(f"[runner] không chạy được {cmd[0]}: {exc}")
        return subprocess.CompletedProcess(cmd, 126, "", str(exc))

    try:
        out, err = proc.communicate(input=input_text, timeout=timeout)
        return subprocess.CompletedProcess(cmd, proc.returncode,
                                           _as_text(out), _as_text(err))
    except subprocess.TimeoutExpired as exc:
        warn(f"[runner] timeout {timeout}s: {' '.join(cmd)} — dừng nhóm tiến trình")
        partial_out = _as_text(exc.stdout)
        partial_err = _as_text(exc.stderr)
        _terminate_group(proc, grace)
        out, err = _drain(proc, partial_out, partial_err)
        return subprocess.CompletedProcess(cmd, 124, out, err)
