"""Lớp HTTP dùng chung cho toàn bộ pipeline — bền vững (long-run) + nhanh.

Vấn đề của bản cũ:
    * Mỗi thread tự tạo `requests.Session()` mới cho từng host → không tái dùng
      kết nối TLS (tốn handshake), dễ rò rỉ file descriptor khi chạy hàng giờ.
    * Không có retry transport: một lỗi TCP read thoáng qua làm mất host oan.
    * Trang chủ của cùng một host bị GET lặp lại ở nhiều stage (fingerprint →
      store_detect → versioning) → tăng tải và thời gian.

Giải pháp trong module này:
    * `get_session(retries)` — Session theo TỪNG THREAD (thread-local), tái dùng
      connection pool có giới hạn rõ ràng (pool_connections/pool_maxsize) nên
      không phình FD khi chạy lâu. `pool_block=True` để chờ pool thay vì mở
      thêm socket vô hạn.
    * `Retry` chỉ cho connect/read (KHÔNG retry theo status code) để không nhân
      đôi tải lên server khi bị chặn; `backoff_factor` nhỏ.
    * `PageCache` — LRU có khóa, giới hạn số entry + tổng byte + TTL. Cache chỉ
      dùng cho GET trang chủ (đắt và lặp lại), không cache endpoint con.

API chính:
    configure(cfg)              — nạp cấu hình (timeout, threads, user_agent, retries…)
    get_session(retries=None)   — Session thread-local
    fetch(url, timeout, ...)    — GET an toàn, không bao giờ raise RequestException
    fetch_limited(...)          — GET/POST đọc TỐI ĐA N byte (streaming) — nhanh + ít RAM
    post_json(...)              — POST JSON (GraphQL/REST probe)
    get_page_cache()/set_page_cache() — cache module-global (pipeline đặt theo CIDR)
    stats()/reset_stats()       — bộ đếm request/byte/lỗi cho log sức khoẻ chạy dài

NÂNG CẤP (bền vững chạy dài):
    * `fetch_limited` đọc thân trang có TRẦN byte bằng streaming → không tải cả
      trang 5-10MB chỉ để lấy 200KB đầu (nhanh, ít RAM, ít băng thông).
    * `max_redirects` cấu hình được trên session dùng chung (stage store_detect
      trước đây phải tạo Session riêng cho từng URL → rò FD khi chạy hàng giờ).
    * `stats()` đếm requests/responses/errors/bytes/cache hit-miss để pipeline in
      định kỳ (phát hiện rò tài nguyên sớm khi chạy dài ngày).
"""
import json
import random
import threading
import time
from collections import OrderedDict, deque

import requests
import urllib3
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from utils.logger import warn

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

DEFAULT_USER_AGENT = "Mozilla/5.0 (compatible; SofiaScan/1.0)"
DEFAULT_RETRIES = 1
DEFAULT_MAX_ENTRIES = 4096
DEFAULT_MAX_TOTAL_BYTES = 64 * 1024 * 1024  # 64MB
DEFAULT_TTL = 300
CACHE_BODY_LIMIT = 300000  # chỉ lưu tối đa 300KB thân trang vào cache
DEFAULT_TIMEOUT = 15
DEFAULT_MAX_BODY_BYTES = 262144  # 256KB — trần đọc thân mỗi request (streaming)
DEFAULT_MAX_REDIRECTS = 10

# ── Chống block (NÂNG CẤP) ────────────────────────────────────────────────
# Pool User-Agent “thật” — xoay vòng mỗi request để không lộ mẫu UA scanner
# cố định (một số WAF/CDN chặn theo UA). Có thể thay bằng `http.ua_pool`.
DEFAULT_UA_POOL = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:126.0) Gecko/20100101 Firefox/126.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 "
    "(KHTML, like Gecko) Version/17.4 Safari/605.1.15",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36 Edg/124.0.0.0",
]
DEFAULT_ROTATE_UA = True
DEFAULT_MAX_RPS = 0.0            # 0 = không giới hạn RPS toàn cục
DEFAULT_BLOCK_COOLDOWN = 60      # giây nghỉ khi phát hiện bị block

# --- Cấu hình toàn cục (nạp 1 lần bởi configure) ----------------------------
_cfg_lock = threading.Lock()
_configured = {
    "user_agent": DEFAULT_USER_AGENT,
    "retries": DEFAULT_RETRIES,
    "max_entries": DEFAULT_MAX_ENTRIES,
    "max_total_bytes": DEFAULT_MAX_TOTAL_BYTES,
    "ttl": DEFAULT_TTL,
    "pool_maxsize": 20,
    "pool_connections": 10,
    "verify": False,
    "timeout": DEFAULT_TIMEOUT,
    "max_body_bytes": DEFAULT_MAX_BODY_BYTES,
    "max_redirects": DEFAULT_MAX_REDIRECTS,
    "rotate_user_agent": DEFAULT_ROTATE_UA,
    "ua_pool": list(DEFAULT_UA_POOL),
    "max_rps": DEFAULT_MAX_RPS,
    "block_cooldown_seconds": DEFAULT_BLOCK_COOLDOWN,
}

# Bộ đếm sức khoẻ (thread-safe) — pipeline in định kỳ khi chạy dài.
_metrics_lock = threading.Lock()
_metrics = {
    "requests": 0, "responses": 0, "errors": 0, "body_bytes": 0,
    "cache_hits": 0, "cache_misses": 0, "limiter_cut": 0, "blocked": 0,
}

# Cảm biến block: mốc thời gian (monotonic) của các response 403/429 gần đây.
_block_lock = threading.Lock()
_block_times = deque()

# Limiter tốc độ toàn cục: các thread lần lượt “đặt chỗ” mốc gửi kế tiếp.
_rate_lock = threading.Lock()
_next_send = 0.0

# Session theo từng thread, khóa theo số retry để tôn trọng cấu hình per-call.
_local = threading.local()
# Cache trang chủ dùng chung (module-global) cho cả luồng xử lý.
_page_cache = None


def configure(cfg):
    """Nạp cấu hình từ dict `cfg` (khối `http:` nếu có, fallback khóa cấp cao).

    Không raise: giá trị sai kiểu sẽ bị bỏ qua, giữ mặc định.
    """
    cfg = cfg or {}
    http = cfg.get("http") or {}

    def _pick(key, default, cast):
        value = http.get(key, cfg.get(key, default))
        try:
            return cast(value)
        except (TypeError, ValueError):
            return default

    with _cfg_lock:
        _configured["user_agent"] = str(
            http.get("user_agent", cfg.get("user_agent", DEFAULT_USER_AGENT)))
        _configured["retries"] = max(0, _pick("retries", DEFAULT_RETRIES, int))
        _configured["max_entries"] = max(16, _pick("cache_max_entries", DEFAULT_MAX_ENTRIES, int))
        _configured["max_total_bytes"] = max(
            1 << 20, _pick("cache_max_bytes", DEFAULT_MAX_TOTAL_BYTES, int))
        _configured["ttl"] = max(0, _pick("cache_ttl", DEFAULT_TTL, int))
        _configured["pool_maxsize"] = max(2, _pick("pool_maxsize", 20, int))
        _configured["pool_connections"] = max(1, _pick("pool_connections", 10, int))
        _configured["verify"] = bool(http.get("verify", cfg.get("verify", False)))
        _configured["timeout"] = max(1, _pick("timeout", cfg.get("timeout", DEFAULT_TIMEOUT), float))
        _configured["max_body_bytes"] = max(
            4096, _pick("max_body_bytes", DEFAULT_MAX_BODY_BYTES, int))
        _configured["max_redirects"] = max(
            0, _pick("max_redirects", DEFAULT_MAX_REDIRECTS, int))
        _configured["rotate_user_agent"] = bool(
            http.get("rotate_user_agent", cfg.get("rotate_user_agent",
                                                  DEFAULT_ROTATE_UA)))
        pool = http.get("ua_pool") or cfg.get("ua_pool")
        if isinstance(pool, list) and pool:
            _configured["ua_pool"] = [str(u) for u in pool if u]
        else:
            _configured["ua_pool"] = list(DEFAULT_UA_POOL)
        _configured["max_rps"] = max(
            0.0, _pick("max_requests_per_sec", DEFAULT_MAX_RPS, float))
        _configured["block_cooldown_seconds"] = max(
            0, _pick("block_cooldown_seconds", DEFAULT_BLOCK_COOLDOWN, int))
    # Cấu hình đổi → session cũ không còn đúng; xóa cache session theo thread.
    _local.__dict__.clear()


def _config(key):
    with _cfg_lock:
        return _configured.get(key)


def _bump(key, amount=1):
    """Cộng bộ đếm sức khoẻ (bỏ qua khóa lạ — không bao giờ raise)."""
    with _metrics_lock:
        if key in _metrics:
            _metrics[key] += amount


def stats():
    """Ảnh chụp bộ đếm HTTP + số thread đang sống (dùng cho log/monitor)."""
    with _metrics_lock:
        out = dict(_metrics)
    out["threads"] = threading.active_count()
    return out


def reset_stats():
    """Đưa bộ đếm về 0 (gọi đầu mỗi CIDR để log theo dải)."""
    with _metrics_lock:
        for key in _metrics:
            _metrics[key] = 0


def _random_ua():
    """Chọn ngẫu nhiên 1 UA trong pool (rotation chống chặn theo UA)."""
    pool = _config("ua_pool") or [DEFAULT_USER_AGENT]
    return random.choice(pool)


def _apply_ua(headers):
    """Gắn UA xoay vòng vào headers của 1 request (không ghi đè UA caller tự đặt)."""
    if not _config("rotate_user_agent"):
        return headers
    merged = dict(headers or {})
    merged.setdefault("User-Agent", _random_ua())
    return merged


def _throttle():
    """Giới hạn tốc độ request TOÀN CỤC (max_rps request/giây, 0 = tắt).

    Mỗi thread lấy 1 “slot” thời gian trước khi gửi → tổng lưu lượng của cả
    pipeline không vượt trần, giảm nguy cơ bị chặn theo lưu lượng.
    """
    global _next_send
    max_rps = _config("max_rps") or 0.0
    if max_rps <= 0:
        return
    slot = 1.0 / max_rps
    with _rate_lock:
        now = time.monotonic()
        start = max(now, _next_send)
        _next_send = start + slot
        wait = start - now
    if wait > 0:
        time.sleep(wait)


def _track_status(status_code):
    """Ghi nhận dấu hiệu bị chặn: 403 (WAF) / 429 (rate-limit)."""
    if status_code in (403, 429):
        _bump("blocked")
        with _block_lock:
            _block_times.append(time.monotonic())


def block_pressure(window=300):
    """Số response 403/429 trong `window` giây gần nhất (cảm biến bị block)."""
    now = time.monotonic()
    with _block_lock:
        while _block_times and now - _block_times[0] > window:
            _block_times.popleft()
        return len(_block_times)


def cool_down(seconds=None):
    """Nghỉ toàn pipeline `seconds` giây khi phát hiện bị block (None = config)."""
    if seconds is None:
        seconds = _config("block_cooldown_seconds") or 0
    seconds = max(0.0, float(seconds))
    if seconds > 0:
        warn(f"[http] phát hiện dấu hiệu block ({block_pressure()}×403/429/5ph) "
             f"— cooldown {seconds:.0f}s")
        time.sleep(seconds)


def _build_session(retries):
    """Tạo Session mới với pool giới hạn + retry transport an toàn."""
    session = requests.Session()
    session.verify = bool(_config("verify"))
    session.max_redirects = _config("max_redirects")
    # UA gốc của session: nếu bật rotation thì mỗi request tự gắn UA riêng,
    # còn không thì dùng UA cấu hình (hành vi cũ).
    session.headers["User-Agent"] = (_random_ua() if _config("rotate_user_agent")
                                     else _config("user_agent"))
    session.headers.setdefault("Accept", "*/*")
    session.headers.setdefault("Accept-Language", "en-US,en;q=0.9")

    retry = Retry(
        total=retries,
        connect=retries,
        read=retries,
        status=0,  # không retry theo status code (tránh nhân đôi tải)
        backoff_factor=0.5,
        allowed_methods=frozenset(["GET", "HEAD"]),
        raise_on_status=False,
        respect_retry_after_header=False,
    )
    adapter = HTTPAdapter(
        max_retries=retry,
        pool_connections=_config("pool_connections"),
        pool_maxsize=_config("pool_maxsize"),
        pool_block=True,
    )
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    return session


def get_session(retries=None):
    """Session thread-local; tạo mới lần đầu mỗi (thread, retries)."""
    if retries is None:
        retries = _config("retries")
    retries = max(0, int(retries))
    store = getattr(_local, "sessions", None)
    if store is None:
        store = {}
        _local.sessions = store
    session = store.get(retries)
    if session is None:
        session = _build_session(retries)
        store[retries] = session
    return session


# --- Cache trang chủ (LRU, thread-safe) --------------------------------------
class CachedResponse:
    """Đối tượng giả lập tối thiểu của requests.Response cho cache."""

    __slots__ = ("status_code", "headers", "text", "url", "content")

    def __init__(self, status_code, headers, text, url=""):
        self.status_code = status_code
        self.headers = dict(headers or {})
        self.text = text or ""
        self.content = self.text.encode("utf-8", "ignore")
        self.url = url

    def __repr__(self):
        return f"<CachedResponse {self.status_code} {self.url}>"


class PageCache:
    """LRU cache cho kết quả GET trang chủ.

    Giới hạn đồng thời:
        * số entry (max_entries)
        * tổng dung lượng thân (max_total_bytes)
        * TTL (giây)
    Chỉ nên dùng cho trang chủ; endpoint con không cache để giữ tính tươi.
    """

    def __init__(self, max_entries=DEFAULT_MAX_ENTRIES,
                 max_total_bytes=DEFAULT_MAX_TOTAL_BYTES, ttl=DEFAULT_TTL):
        self.max_entries = max_entries
        self.max_total_bytes = max_total_bytes
        self.ttl = ttl
        self._lock = threading.Lock()
        self._data = OrderedDict()  # url -> (expires_at, size, CachedResponse)
        self._bytes = 0
        self.hits = 0
        self.misses = 0

    def _prune_locked(self, now):
        # Xóa entry hết hạn.
        expired = [k for k, (exp, _s, _r) in self._data.items() if exp <= now]
        for k in expired:
            self._drop_locked(k)
        # Ép giới hạn số entry.
        while len(self._data) > self.max_entries:
            self._drop_locked(next(iter(self._data)))
        # Ép giới hạn tổng byte.
        while self._bytes > self.max_total_bytes and self._data:
            self._drop_locked(next(iter(self._data)))

    def _drop_locked(self, key):
        item = self._data.pop(key, None)
        if item is not None:
            self._bytes -= item[1]

    def get(self, url):
        now = time.monotonic()
        with self._lock:
            self._prune_locked(now)
            item = self._data.get(url)
            if item is None:
                self.misses += 1
                return None
            exp, _size, resp = item
            if exp <= now:
                self._drop_locked(url)
                self.misses += 1
                return None
            self._data.move_to_end(url)
            self.hits += 1
            return resp

    def put(self, url, response):
        if response is None or self.ttl <= 0:
            return
        text = response.text or ""
        # Không cache response quá lớn hay lỗi 5xx (dễ là lỗi tạm thời).
        if len(text) > CACHE_BODY_LIMIT:
            return
        if getattr(response, "status_code", 0) >= 500:
            return
        cached = CachedResponse(
            response.status_code, dict(response.headers), text, url)
        size = len(cached.content) + len(url)
        now = time.monotonic()
        with self._lock:
            if url in self._data:
                self._drop_locked(url)
            self._data[url] = (now + self.ttl, size, cached)
            self._bytes += size
            self._data.move_to_end(url)
            self._prune_locked(now)

    def clear(self):
        with self._lock:
            self._data.clear()
            self._bytes = 0

    def stats(self):
        with self._lock:
            return {"entries": len(self._data), "bytes": self._bytes,
                    "hits": self.hits, "misses": self.misses}


def get_page_cache():
    """Trả về cache toàn cục (None nếu chưa đặt)."""
    return _page_cache


def set_page_cache(cache):
    """Đặt/xóa cache toàn cục. cache=None để tắt."""
    global _page_cache
    _page_cache = cache
    return _page_cache


def make_page_cache():
    """Tạo PageCache mới theo cấu hình hiện hành."""
    return PageCache(
        max_entries=_config("max_entries"),
        max_total_bytes=_config("max_total_bytes"),
        ttl=_config("ttl"),
    )


# --- GET an toàn --------------------------------------------------------------
def fetch(url, timeout=None, retries=None, allow_redirects=True,
          headers=None, cache=None, stream=False):
    """GET an toàn. Trả về response giống requests (hoặc CachedResponse).

    Không bao giờ raise RequestException: lỗi mạng → trả None để caller xử lý.
    Nếu `cache` truyền vào (PageCache) thì đọc/ghi cache theo URL.
    `timeout=None` → dùng `http.timeout` (hoặc `timeout` cấp cao) đã configure.
    """
    if timeout is None:
        timeout = _config("timeout") or DEFAULT_TIMEOUT
    if cache is not None:
        hit = cache.get(url)
        if hit is not None:
            _bump("cache_hits")
            return hit
        _bump("cache_misses")
    session = get_session(retries)
    headers = _apply_ua(headers)
    _throttle()
    _bump("requests")
    try:
        resp = session.get(
            url, timeout=timeout, allow_redirects=allow_redirects,
            headers=headers, stream=stream,
        )
    except requests.RequestException:
        _bump("errors")
        return None
    _bump("responses")
    _track_status(resp.status_code)
    if cache is not None:
        cache.put(url, resp)
    return resp


# --- GET/POST đọc có trần byte (streaming) -----------------------------------
def fetch_limited(url, timeout=None, limit=None, method="GET", data=None,
                  headers=None, allow_redirects=True, cache=None,
                  retries=None, session=None):
    """GET/POST an toàn, đọc TỐI ĐA `limit` byte thân phản hồi (streaming).

    Vì sao: các stage chỉ cần vài trăm KB đầu trang để chấm điểm/chắt chữ ký,
    nhưng `resp.text` của requests kéo về TOÀN BỘ trang (nhiều MB) → tốn băng
    thông, RAM và thời gian khi quét hàng triệu host. Hàm này stream rồi chỉ đọc
    phần cần thiết rồi ĐÓNG kết nối ngay.

    Trả về đối tượng giống response (CachedResponse) hoặc None khi lỗi mạng.
    Kết quả GET được đưa vào `cache` nếu truyền (PageCache) — nhờ vậy nhiều
    stage cùng đọc trang chủ chỉ tốn 1 request.
    """
    method = (method or "GET").upper()
    if timeout is None:
        timeout = _config("timeout") or DEFAULT_TIMEOUT
    if limit is None:
        limit = _config("max_body_bytes") or DEFAULT_MAX_BODY_BYTES
    limit = max(1024, int(limit))

    cacheable = cache is not None and method == "GET"
    if cacheable:
        hit = cache.get(url)
        if hit is not None:
            _bump("cache_hits")
            return hit
        _bump("cache_misses")

    session = session or get_session(retries)
    headers = _apply_ua(headers)
    _throttle()
    _bump("requests")
    try:
        resp = session.request(
            method, url, timeout=timeout, headers=headers, data=data,
            allow_redirects=allow_redirects, stream=True,
        )
    except requests.RequestException:
        _bump("errors")
        return None
    if resp is not None:
        _track_status(resp.status_code)

    raw = b""
    try:
        raw = resp.raw.read(limit, decode_content=True) or b""
        if len(raw) >= limit:
            _bump("limiter_cut")  # chạm trần → có thể còn dữ liệu phía sau
        out = CachedResponse(
            resp.status_code, dict(resp.headers),
            raw.decode("utf-8", "ignore"), url)
    except Exception:  # noqa: BLE001 — đọc stream lỗi → coi như host không dùng được
        _bump("errors")
        out = None
    finally:
        try:
            resp.close()
        except Exception:  # noqa: BLE001
            pass

    if out is None:
        return None
    _bump("responses")
    _bump("body_bytes", len(raw))
    if cacheable:
        cache.put(url, out)
    return out


def post_json(url, payload, timeout=None, limit=None, headers=None,
              allow_redirects=False, session=None):
    """POST JSON an toàn (dùng cho probe GraphQL/REST cần body).

    Không cache (POST không idempotent) — trả response hoặc None.
    """
    hdrs = {"Content-Type": "application/json", "Accept": "application/json"}
    hdrs.update(headers or {})
    body = payload if isinstance(payload, (str, bytes)) else json.dumps(payload)
    return fetch_limited(url, timeout=timeout, limit=limit, method="POST",
                         data=body, headers=hdrs,
                         allow_redirects=allow_redirects, session=session)


# Ghi chú API mới (chống block):
#   block_pressure(window=300) — số 403/429 trong `window` giây gần nhất
#   cool_down(seconds=None)    — ngủ toàn pipeline khi phát hiện bị block
#   (rotate_user_agent / max_requests_per_sec / block_cooldown_seconds — config)
