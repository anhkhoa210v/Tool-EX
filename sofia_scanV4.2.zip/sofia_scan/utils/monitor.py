"""Giám sát tài nguyên tiến trình — phục vụ quét CHẠY DÀI (hàng giờ, hàng triệu host).

Vì sao cần: các lỗi "chết giữa chừng" khi quét dài thường là do (a) cạn file
descriptor khi số socket tăng, (b) RSS phình vì buffer/cache giữ quá nhiều body,
(c) số thread vượt trần. Module này đọc /proc/self (Linux, không cần psutil):

    snapshot()             → dict {rss_mb, threads, fds, fd_soft, fd_hard}
    tick(label, extra)     → log định kỳ theo `monitor.interval` (mặc định 60s)
    raise_nofile(target)   → nâng soft limit RLIMIT_NOFILE (tối đa hard limit)
    stats()                → bản tổng hợp gần nhất (cho report/webhook)

Cấu hình (block `monitor` trong config.yaml):
    enabled     bật/tắt (true) — tắt thì tick() không log
    interval    giây giữa 2 lần log (60)
    rss_warn_mb ngưỡng cảnh báo RSS (900)
    fd_warn     ngưỡng cảnh báo số FD (800)
    nofile      soft limit mong muốn cho RLIMIT_NOFILE (65535)

Mọi hàm ở đây KHÔNG bao giờ raise — thiếu /proc (macOS/Windows) thì trả giá trị 0.
"""
import os
import threading
import time

from utils.logger import info, warn

DEFAULT_INTERVAL = 60.0
DEFAULT_RSS_WARN_MB = 900.0
DEFAULT_FD_WARN = 800
DEFAULT_NOFILE = 65535

_lock = threading.Lock()
_last_log = 0.0
_cfg = {"enabled": True, "interval": DEFAULT_INTERVAL,
        "rss_warn_mb": DEFAULT_RSS_WARN_MB, "fd_warn": DEFAULT_FD_WARN,
        "nofile": DEFAULT_NOFILE}
_last_snapshot = {}


def configure(cfg):
    """Nạp block `monitor` từ config (gọi 1 lần ở đầu run)."""
    mc = (cfg or {}).get("monitor") or {}
    try:
        _cfg["enabled"] = bool(mc.get("enabled", True))
        _cfg["interval"] = max(5.0, float(mc.get("interval", DEFAULT_INTERVAL)))
        _cfg["rss_warn_mb"] = float(mc.get("rss_warn_mb", DEFAULT_RSS_WARN_MB))
        _cfg["fd_warn"] = int(mc.get("fd_warn", DEFAULT_FD_WARN))
        _cfg["nofile"] = int(mc.get("nofile", DEFAULT_NOFILE))
    except (TypeError, ValueError):
        pass
    return dict(_cfg)


def _read_status():
    """Parse /proc/self/status → {VmRSS: kB, Threads: n} (rỗng nếu không có)."""
    out = {}
    try:
        with open("/proc/self/status", "r", encoding="utf-8", errors="ignore") as handle:
            for line in handle:
                if line.startswith(("VmRSS:", "Threads:")):
                    parts = line.split()
                    if len(parts) >= 2:
                        out[parts[0].rstrip(":")] = parts[1]
    except OSError:
        pass
    return out


def _fd_count():
    try:
        return len(os.listdir("/proc/self/fd"))
    except OSError:
        return 0


def _rlimits():
    try:
        import resource
        soft, hard = resource.getrlimit(resource.RLIMIT_NOFILE)
        return soft, hard
    except Exception:  # noqa: BLE001
        return 0, 0


def snapshot():
    """Ảnh chụp tài nguyên hiện tại — an toàn trên mọi hệ điều hành."""
    global _last_snapshot
    status = _read_status()
    try:
        rss_kb = float(status.get("VmRSS", 0))
    except ValueError:
        rss_kb = 0.0
    try:
        threads = int(status.get("Threads", 0))
    except ValueError:
        threads = 0
    soft, hard = _rlimits()
    snap = {
        "rss_mb": round(rss_kb / 1024.0, 1),
        "threads": threads,
        "fds": _fd_count(),
        "fd_soft": soft,
        "fd_hard": hard,
        "time": time.time(),
    }
    _last_snapshot = snap
    return snap


def format_snapshot(snap, label="", extra=None):
    parts = []
    if label:
        parts.append(str(label))
    parts.append(f"rss={snap.get('rss_mb', 0)}MB")
    parts.append(f"threads={snap.get('threads', 0)}")
    parts.append(f"fds={snap.get('fds', 0)}/{snap.get('fd_soft', 0)}")
    if extra:
        parts.append(" ".join(f"{k}={v}" for k, v in extra.items()))
    return " ".join(parts)


def maybe_warn(snap):
    """Cảnh báo khi vượt ngưỡng cấu hình — giúp phát hiện rò rỉ trước khi chết."""
    if snap.get("rss_mb", 0) >= _cfg["rss_warn_mb"]:
        warn(f"[monitor] RSS cao: {snap['rss_mb']}MB "
             f"(ngưỡng {_cfg['rss_warn_mb']}MB)")
    soft = snap.get("fd_soft") or 0
    fds = snap.get("fds", 0)
    if fds >= _cfg["fd_warn"] or (soft and fds >= soft * 0.8):
        warn(f"[monitor] sắp cạn FD: {fds}/{soft} — cân nhắc giảm threads")


def tick(label="", extra=None, force=False):
    """Log ảnh chụp định kỳ (mặc định mỗi `monitor.interval` giây)."""
    global _last_log
    if not _cfg["enabled"]:
        return None
    now = time.monotonic()
    with _lock:
        if not force and (now - _last_log) < _cfg["interval"]:
            return None
        _last_log = now
    snap = snapshot()
    info("[monitor] " + format_snapshot(snap, label, extra))
    maybe_warn(snap)
    return snap


def stats():
    """Ảnh chụp gần nhất + cấu hình hiệu lực (cho report/webhook)."""
    return {"last": dict(_last_snapshot), "config": dict(_cfg)}


def raise_nofile(target=None):
    """Nâng soft limit RLIMIT_NOFILE (tối đa bằng hard limit). Trả (soft, hard)."""
    target = int(target or _cfg["nofile"])
    try:
        import resource
        soft, hard = resource.getrlimit(resource.RLIMIT_NOFILE)
        if hard != resource.RLIM_INFINITY:
            target = min(target, hard)
        if target > soft:
            resource.setrlimit(resource.RLIMIT_NOFILE, (target, hard))
            info(f"[monitor] RLIMIT_NOFILE: {soft} → {target}")
            return target, hard
        return soft, hard
    except Exception as exc:  # noqa: BLE001 — chỉ là tối ưu, không bắt buộc
        warn(f"[monitor] không nâng được RLIMIT_NOFILE: {exc}")
        return 0, 0
