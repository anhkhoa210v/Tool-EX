"""Mã máy (machine ID) — định danh thiết bị chạy SofiaScan.

Mục đích: phân biệt báo cáo webhook đến từ THIẾT BỊ NÀO khi chạy song song
nhiều máy/VPS cùng một kênh Discord/Slack.

Format: "sofia" + 8 ký tự ngẫu nhiên [a-z0-9]  →  vd: sofiak3x9pq2m (13 ký tự).

Thứ tự ưu tiên khi lấy mã:
  1. Biến môi trường SOFIA_MACHINE_ID (ghi đè thủ công, phải đúng format)
  2. File trạng thái (mặc định output/machine_id.txt) — sinh 1 LẦN rồi dùng
     lại ổn định giữa các lần chạy, nên 1 máy = 1 mã cố định
  3. Tự sinh mã mới và lưu vào file trạng thái

Mã chỉ mang tính định danh (không phải bí mật): sinh bằng `secrets` để tránh
trùng giữa các máy, nhưng không dùng cho xác thực.
"""
import os
import re
import secrets
import string

_ALPHABET = string.ascii_lowercase + string.digits
# sofia + đúng 8 ký tự [a-z0-9]
_PATTERN = re.compile(r"^sofia[a-z0-9]{8}$")
MACHINE_ID_LEN = 8
DEFAULT_STATE_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "output", "machine_id.txt",
)


def generate_machine_id():
    """Sinh mã máy mới: 'sofia' + 8 ký tự ngẫu nhiên [a-z0-9]."""
    return "sofia" + "".join(secrets.choice(_ALPHABET)
                             for _ in range(MACHINE_ID_LEN))


def is_valid(machine_id):
    """Kiểm tra format: 'sofia' + 8 ký tự [a-z0-9] (không phân biệt hoa/thường)."""
    return bool(machine_id) and bool(_PATTERN.match(str(machine_id).strip()))


def normalize(machine_id):
    """Chuẩn hóa (lowercase) nếu hợp lệ, ngược lại trả về ''. Không raise."""
    text = str(machine_id or "").strip().lower()
    return text if is_valid(text) else ""


def _read_state(state_path):
    try:
        with open(state_path, encoding="utf-8") as fh:
            return normalize(fh.read())
    except OSError:
        return ""


def _write_state(state_path, machine_id):
    """Ghi an toàn: ghi file tạm rồi os.replace để không bao giờ để lại file dở."""
    try:
        directory = os.path.dirname(state_path)
        if directory:
            os.makedirs(directory, exist_ok=True)
        tmp = state_path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            fh.write(machine_id + "\n")
        os.replace(tmp, state_path)
        return True
    except OSError:
        return False


def get_machine_id(state_path=None, env=None):
    """Trả về mã máy ổn định cho thiết bị hiện tại. Không bao giờ raise.

    env: dict biến môi trường (mặc định os.environ) — khóa SOFIA_MACHINE_ID.
    state_path: nơi lưu mã (mặc định output/machine_id.txt).
    """
    env = os.environ if env is None else env
    if not state_path:
        state_path = DEFAULT_STATE_PATH

    # 1) Ghi đè thủ công qua môi trường
    from_env = normalize(env.get("SOFIA_MACHINE_ID"))
    if from_env:
        return from_env

    # 2) Đã có trong file trạng thái → dùng lại (1 máy = 1 mã cố định)
    stored = _read_state(state_path)
    if stored:
        return stored

    # 3) Sinh mới + lưu
    new_id = generate_machine_id()
    _write_state(state_path, new_id)
    return new_id
