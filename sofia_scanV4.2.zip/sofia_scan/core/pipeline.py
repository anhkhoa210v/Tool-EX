"""Pipeline: tuần tự 4 stage theo từng CIDR + resume + webhook (batch).

Với MỖI CIDR:
  stage1 scanner → stage2a fingerprint ┐
                                       ├─ (chạy SONG SONG) →
               stage2a-woo woo_fingerprint ┘
  → stage2c store_detect → stage2b versioning → stage3 cve_scan
  → stage4 resolver (đếm domain) → webhook.scan_done (buffer, gửi gộp).

stage 2c store_detect (xem core/store_detect.py) lọc các URL Magento thành
"cửa hàng THẬT" (storefront đang bán); chỉ các cửa hàng thật mới được đẩy
xuống stage 2b→4 (nên t.txt chỉ chứa domain cửa hàng thật).
Bật/tắt + ngưỡng ở `store_detect` trong config.yaml (tắt = chạy như cũ).

NHÁNH WOOCOMMERCE/WORDPRESS (xem core/woo_*.py) — chạy SONG SONG với Magento
trên cùng danh sách host: woo_fingerprint phát hiện WordPress/WooCommerce →
woo_versioning dò version TỪNG PLUGIN → woo_cve_scan khớp
cves/woo_version_map.yaml (offline) + nuclei cộng đồng. Kết quả gộp chung
vuln.txt/vul.txt; URL Woo cũng được đưa vào resolver để ra domain (t.txt).
Bật/tắt ở `woocommerce.enabled` (mặc định bật).

NÂNG CẤP HIỆU NĂNG / BỀN VỮNG:
  * `http.configure(cfg)` + `monitor.configure(cfg)` nạp 1 lần khi tạo Pipeline
    (trước đây khối `http:` trong config.yaml là dead code — không ai gọi).
  * Mỗi CIDR có PageCache RIÊNG (`http.make_page_cache`) rồi xoá khi xong:
    fingerprint, woo_fingerprint, store_detect và woo_versioning cùng đọc trang
    chủ của một host → chỉ còn 1 GET thay vì 3-5 GET.
  * Hai nhánh DISCOVERY (Magento fingerprint || Woo fingerprint) chạy song song
    → thời gian mỗi CIDR gần bằng nhánh chậm nhất thay vì tổng hai nhánh.
  * CIDR lỗi được THỬ LẠI với backoff (`pipeline.retry_attempts`,
    `pipeline.retry_backoff`) — một sự cố mạng thoáng qua không làm mất cả dải.
  * `monitor.tick()` log RSS/threads/FD định kỳ + cảnh báo sớm khi sắp cạn tài
    nguyên; `http.stats()` log tỉ lệ cache hit/miss từng CIDR.

CIDR đã có marker .complete trong output/work/<slug>/ sẽ được bỏ qua (resume).
"""
import concurrent.futures
import os
import random
import time

import webhook
from core import (cve_scan, exploit_runner, fingerprint, resolver, scanner,
                  store_detect, versioning, woo_cve_scan, woo_fingerprint,
                  woo_versioning)
from utils import cleanup, file_io, http, monitor
from utils.logger import error, info, success, warn

# Số lần chạy lại 1 CIDR khi thất bại + backoff cơ bản (giây, tăng dần theo lần).
DEFAULT_RETRY_ATTEMPTS = 2
DEFAULT_RETRY_BACKOFF = 30.0

# NÂNG CẤP chống block: nếu số response 403/429 trong 5 phút vượt ngưỡng này
# → nghỉ (cooldown) trước khi tiếp tục, tránh bị block IP nguồn lâu dài.
BLOCK_PRESSURE_LIMIT = 10
DEFAULT_BLOCK_COOLDOWN = 60  # giây


class Pipeline:
    def __init__(self, cfg):
        self.cfg = cfg
        self.output_dir = cfg["paths"]["output_dir"]
        self.work_dir = os.path.join(self.output_dir, "work")
        # Chuỗi CIDR thất bại liên tiếp → nhân thời gian politeness (chống block)
        self._fail_streak = 0
        # Nạp cấu hình tầng HTTP + monitor (trước đây không ai gọi → cấu hình chết).
        http.configure(cfg)
        monitor.configure(cfg)
        webhook.configure(cfg.get("webhook"))

    def _global(self, name):
        return os.path.join(self.output_dir, name)

    def _cleanup_live(self):
        """Cắt output/live.txt nếu vượt cleanup.live_txt_max_mb (giữ dòng cuối).

        Gọi sau stage 1 mỗi CIDR — kiểm tra chỉ tốn 1 lần get size; file dưới
        trần thì không có thao tác nào khác.
        """
        try:
            if cleanup.enforce_live(self._global("live.txt"), cfg=self.cfg):
                info(f"[{self._global('live.txt')}] đã cắt bớt (trần "
                     f"{self.cfg.get('cleanup', {}).get('live_txt_max_mb', 0)}MB)")
        except Exception as exc:
            warn(f"cleanup live.txt lỗi: {exc}")

    def _politeness_sleep(self, done, total):
        """Ngủ ngẫu nhiên GIỮA các CIDR (scanner.politeness) — quét dài ngày
        với nhịp đều, không phun liên tục nhiều dải cạnh nhau dễ bị nhà mạng
        / WAF chặn nguồn quét. Không ngủ sau CIDR cuối (tránh trễ kết thúc)."""
        pol = (self.cfg.get("scanner") or {}).get("politeness") or {}
        lo = float(pol.get("sleep_min") or 0.0)
        hi = float(pol.get("sleep_max") or 0.0)
        if hi <= 0 or hi < lo:
            return
        if total is not None and done >= total:
            return
        seconds = random.uniform(lo, hi)
        # NÂNG CẤP chống block — giãn nhịp THÍCH ỨNG: mỗi CIDR thất bại liên
        # tiếp (thường do bị chặn/rate-limit) → ngủ lâu hơn 50%/lần (tối đa x4)
        # để IP nguồn “nguội” trước khi chạm dải kế tiếp.
        streak = min(self._fail_streak, 6)
        if streak:
            seconds *= (1 + 0.5 * streak)
        info(f"politeness: ngủ {seconds:.1f}s giữa các CIDR "
             f"({lo:.0f}-{hi:.0f}s"
             + (f", giãn x{1 + 0.5 * streak:.1f} sau {streak} lần lỗi)"
                if streak else ")")
             + " — chống block nguồn quét")
        time.sleep(seconds)

    def _run_exploit(self, cidr):
        """NÂNG CẤP: sau mỗi batch (CIDR) → chạy sofia.py khai thác vuln.txt.

        Vòng lặp: batch xong → `sofia/sofia.py -t output/vuln.txt` (đợi xong)
        → sang batch kế → lặp lại. Lỗi hook KHÔNG làm chết vòng quét.
        """
        try:
            exploit_runner.run_sofia(self.cfg, context=cidr)
        except Exception as exc:  # noqa: BLE001 — quét phải sống sót
            error(f"[{cidr}] exploit hook lỗi ngoài dự kiến: {exc}")

    def run(self, targets, resume=True, total=None):
        total_domains = 0
        done = 0
        # lookahead 1 phần tử: biết khi nào là CIDR cuối (để không ngủ thừa
        # sau CIDR cuối khi total không xác định — targets có thể là generator)
        it = iter(targets)
        item = next(it, None)
        while item is not None:
            cidr, rir, country = item
            done += 1
            info(f"=== [{done}/{total if total is not None else '?'}] "
                 f"{cidr} ({rir}, {country}) ===")
            total_domains += self.run_cidr(cidr, rir, country, resume=resume)
            # NÂNG CẤP: batch (CIDR) vừa xong → chạy sofia.py trên vuln.txt
            # TRƯỚC khi sang batch kế; sofia.py xong mới tiếp tục quét (lặp lại).
            self._run_exploit(cidr)
            item = next(it, None)
            if item is not None:
                self._politeness_sleep(done, total)
        success(f"Hoàn tất {done} CIDR — tổng {total_domains} domain trong t.txt")

    def run_cidr(self, cidr, rir, country, resume=True):
        """Chạy 1 CIDR (cache riêng + retry có backoff) → số domain ghi vào t.txt."""
        workdir = os.path.join(self.work_dir, file_io.slugify(cidr))
        done_marker = os.path.join(workdir, ".complete")
        if resume and os.path.exists(done_marker):
            info(f"[{cidr}] đã hoàn tất trước đó — bỏ qua (resume)")
            return 0
        os.makedirs(workdir, exist_ok=True)

        pipe_cfg = self.cfg.get("pipeline") or {}
        try:
            attempts = max(1, int(pipe_cfg.get("retry_attempts",
                                               DEFAULT_RETRY_ATTEMPTS)))
        except (TypeError, ValueError):
            attempts = DEFAULT_RETRY_ATTEMPTS
        try:
            backoff = max(0.0, float(pipe_cfg.get("retry_backoff",
                                                  DEFAULT_RETRY_BACKOFF)))
        except (TypeError, ValueError):
            backoff = DEFAULT_RETRY_BACKOFF

        domains, findings, ok = [], [], False
        try:
            for attempt in range(1, attempts + 1):
                # PageCache RIÊNG cho CIDR: nhiều stage cùng đọc trang chủ của một
                # host → chỉ còn 1 GET. Xoá sau mỗi lần thử để tránh giữ body
                # của hàng trăm nghìn host trong RAM.
                http.set_page_cache(http.make_page_cache())
                http.reset_stats()
                domains, findings, ok = self._attempt_cidr(cidr, workdir)
                self._log_http_stats(cidr)
                self._block_check(cidr)
                http.set_page_cache(None)
                monitor.tick(f"[{cidr}]", {"attempt": attempt, "ok": ok})

                if ok:
                    break
                if attempt < attempts:
                    delay = backoff * attempt
                    warn(f"[{cidr}] lần {attempt}/{attempts} chưa hoàn tất — "
                         f"thử lại sau {delay:.0f}s")
                    time.sleep(delay)
        finally:
            http.set_page_cache(None)
            webhook.scan_done(cidr, country, len(domains), n_findings=len(findings))

        # NÂNG CẤP: theo dõi chuỗi thất bại → politeness giãn dần (chống block)
        if ok:
            self._fail_streak = 0
            file_io.atomic_write(done_marker, "ok\n")
        else:
            self._fail_streak += 1
        info(f"[{cidr}] xong — {len(domains)} domain")
        return len(domains)

    def _block_check(self, cidr):
        """Cảm biến bị block: quá nhiều 403/429 trong 5 phút → nghỉ cooldown.

        Không raise; cooldown chỉ là giãn nhịp phòng thủ khi WAF/CDN bắt đầu
        trả 403/429 hàng loạt — tiếp tục quét ngay lúc đó dễ bị block IP nguồn.
        """
        try:
            pressure = http.block_pressure()
        except Exception:  # noqa: BLE001 — chỉ là phòng thủ
            return
        if pressure < BLOCK_PRESSURE_LIMIT:
            return
        http_cfg = self.cfg.get("http") or {}
        try:
            seconds = float(http_cfg.get("block_cooldown_seconds",
                                         DEFAULT_BLOCK_COOLDOWN))
        except (TypeError, ValueError):
            seconds = DEFAULT_BLOCK_COOLDOWN
        warn(f"[{cidr}] cảm biến block: {pressure}×403/429 trong 5 phút "
             f"— nghỉ {seconds:.0f}s trước khi tiếp tục")
        http.cool_down(seconds)

    def _log_http_stats(self, cidr):
        """Log hiệu quả cache + bộ đếm HTTP của dải này (theo dõi hiệu năng dài)."""
        try:
            cache = http.get_page_cache()
            cache_stats = cache.stats() if cache is not None else {}
            stats = http.stats()
            info(f"[{cidr}] HTTP: {stats.get('requests', 0)} req, "
                 f"{stats.get('errors', 0)} lỗi, "
                 f"{stats.get('body_bytes', 0) // 1024}KB body, "
                 f"cache hit={cache_stats.get('hits', 0)}/"
                 f"miss={cache_stats.get('misses', 0)}")
        except Exception as exc:  # noqa: BLE001 — chỉ là log
            warn(f"[{cidr}] không log được thống kê HTTP: {exc}")

    def _attempt_cidr(self, cidr, workdir):
        """1 lần chạy đầy đủ cho CIDR → (domains, findings, ok). Không raise."""
        domains = []
        findings = []
        ok = False
        try:
            hosts = scanner.scan(cidr, workdir, self._global("live.txt"), self.cfg)
            self._cleanup_live()  # live.txt quá nặng → cắt bớt, giữ dòng mới nhất

            woo_cfg = self.cfg.get("woocommerce") or {}
            woo_urls = []
            woo_findings = []

            # HAI NHÁNH DISCOVERY SONG SONG: Magento (fingerprint) và
            # WordPress/WooCommerce (woo_fingerprint) độc lập nhau; mỗi hàm tự có
            # ThreadPoolExecutor bên trong nên chỉ cần 2 worker ở đây.
            with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
                mag_future = pool.submit(fingerprint.run, hosts, workdir,
                                         self._global("magento.txt"), self.cfg)
                woo_future = None
                if woo_cfg.get("enabled", True):
                    woo_future = pool.submit(
                        woo_fingerprint.run, hosts, workdir,
                        self._global("wordpress.txt"),
                        self._global("woocommerce.txt"), self.cfg)

                try:
                    magento = mag_future.result() or []
                except Exception as exc:
                    warn(f"[{cidr}] lỗi fingerprint Magento: {exc} — bỏ qua dải này")
                    magento = []
                if woo_future is not None:
                    # Lỗi nhánh Woo KHÔNG được làm mất kết quả Magento.
                    try:
                        _, woo_urls = woo_future.result() or (None, [])
                    except Exception as exc:
                        warn(f"[{cidr}] lỗi nhánh WooCommerce (discovery): {exc} "
                             f"— tiếp tục Magento")
                        woo_urls = []

            if woo_urls:
                try:
                    woo_versions = woo_versioning.run(woo_urls, workdir, self.cfg)
                    woo_findings = woo_cve_scan.run(
                        woo_urls, woo_versions, workdir,
                        self._global("vuln.txt"), self.cfg)
                except Exception as exc:
                    warn(f"[{cidr}] lỗi nhánh WooCommerce (version/CVE): {exc} "
                         f"— tiếp tục Magento")
                    woo_findings = []
            elif woo_cfg.get("enabled", True):
                info(f"[{cidr}] không có target WooCommerce — bỏ qua stage 2b-3 woo")

            # stage 2c — lọc cửa hàng THẬT; các stage sau chỉ nhận cửa hàng thật
            sd_cfg = self.cfg.get("store_detect") or {}
            urls = magento
            if sd_cfg.get("enabled", True):
                urls = store_detect.run(magento, workdir,
                                        self._global("stores.txt"), self.cfg)
                if magento and not urls:
                    warn(f"[{cidr}] không có cửa hàng thật trong "
                         f"{len(magento)} Magento — bỏ qua stage 2b-4")
            versions = versioning.run(urls, workdir,
                                      self._global("magento_versions.txt"), self.cfg)
            findings = cve_scan.run(urls, workdir, self._global("vuln.txt"),
                                    self.cfg, versions=versions)
            # stage4: gộp URL Magento + WooCommerce để lấy domain (t.txt)
            all_urls = file_io.dedupe_sort(list(urls) + list(woo_urls))
            domains = resolver.run(all_urls, workdir, self._global("t.txt"), self.cfg)
            file_io.append_lines(self._global("t.txt"), domains)
            findings = findings + woo_findings
            ok = True
        except Exception as exc:
            error(f"[{cidr}] lỗi trong pipeline: {exc}")
        return domains, findings, ok
