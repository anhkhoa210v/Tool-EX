"""STAGE 2b: lấy version Magento → output/magento_versions.txt.

Thứ tự thử (rẻ → đắt, dùng chung session thread-local để tận dụng keep-alive):
  1. GET /magento_version      — text "Magento/2.4.6-p3" (nếu cấu hình lỏ)
  2. GET /static/version/      — JSON {"version": "2.4.6-p3"} (Magento 2.4+)
Không có endpoint nào lộ → bỏ qua (không raise).

NÂNG CẤP:
  * Dùng lớp HTTP chung (utils/http.py) — session tái dùng + retry transport,
    không tạo Session mới mỗi host (nhanh hơn, ít rò rỉ FD khi chạy dài).
  * run() chạy SONG SONG bằng ThreadPoolExecutor(cfg.threads) thay vì tuần tự
    → stage 2b không còn là điểm nghẽn khi có nhiều URL.

run() trả về dict url → version để stage 3 khớp CVE offline.
"""
import concurrent.futures
import json
import re

import requests
import urllib3

from utils import file_io, http
from utils.logger import info

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

USER_AGENT = "Mozilla/5.0 (compatible; SofiaScan/1.0)"

VERSION_RE = re.compile(r"Magento/?\s*v?\s*([0-9][0-9A-Za-z.\-p_]*)", re.IGNORECASE)
JSON_VERSION_KEYS = ("version", "magento_version")


def _from_magento_version(text):
    match = VERSION_RE.search((text or "")[:200])
    if match:
        return f"Magento/{match.group(1)}"
    return None


def _from_static_version(text):
    """Parse JSON /static/version/ → 'Magento/2.4.6-p3' hoặc None."""
    try:
        data = json.loads((text or "")[:2000])
    except (ValueError, TypeError):
        return None
    if not isinstance(data, dict):
        return None
    for key in JSON_VERSION_KEYS:
        value = data.get(key)
        if isinstance(value, str) and value:
            return f"Magento/{value}"
    return None


def fetch_version(url, timeout, session=None):
    """Trả về chuỗi kiểu 'Magento/2.4.6-p3' hoặc None. Không bao giờ raise.

    Không truyền `session` → dùng http.fetch_limited (trần byte nhỏ, /magento_version
    và /static/version/ chỉ vài trăm byte) nên không tải body trang thừa.
    """
    base = url.rstrip("/")

    def _get(target):
        if session is None:
            return http.fetch_limited(target, timeout=timeout, limit=8192)
        return session.get(target, timeout=timeout, allow_redirects=True)

    try:
        resp = _get(base + "/magento_version")
        if resp is not None:
            version = _from_magento_version(resp.text)
            if version:
                return version
        resp = _get(base + "/static/version/")
        if resp is not None:
            version = _from_static_version(resp.text)
            if version:
                return version
    except requests.RequestException:
        pass
    return None


def run(urls, workdir, global_versions, cfg):
    """urls: list URL Magento → dict {url: version}; append 'url version' ra file.

    Chạy song song theo cfg.threads — dùng chung session thread-local.
    """
    timeout = cfg.get("timeout", 15)
    versions = {}
    rows = []
    urls = list(urls)
    if not urls:
        info("stage2b: 0 URL cần dò version")
        return versions
    workers = max(1, min(int(cfg.get("threads", 50)), len(urls)))
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
        futures = {pool.submit(fetch_version, u, timeout): u for u in urls}
        for future in concurrent.futures.as_completed(futures):
            url = futures[future]
            version = future.result()
            if version:
                versions[url] = version
                rows.append(f"{url} {version}")
    rows = file_io.dedupe_sort(rows)
    file_io.append_lines(global_versions, rows)
    info(f"stage2b: {len(versions)}/{len(urls)} URL có version (threads={workers})")
    return versions
