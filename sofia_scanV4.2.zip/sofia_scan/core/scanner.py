"""STAGE 1: phát hiện host mở cổng (80/443/8080) — engine masscan hoặc zmap.

Hỗ trợ 2 engine quét port:
  - masscan: 1 lần quét nhiều cổng (-p 80,443,8080) → output -oL
  - zmap   : quét từng cổng (per-port loop — tương thích mọi bản zmap,
             kể cả bản chỉ quét 1 cổng/lần) → output mặc định 1 IP/dòng

Chọn engine theo `scanner.engine` trong config:
  - "masscan" / "zmap": dùng đúng engine (warn nếu thiếu binary → fallback auto)
  - "auto" (mặc định): masscan nếu có binary, ngược lại zmap

zmap cần root (raw socket) như masscan; chạy `sudo python3 main.py`.

─── Chống block + chạy dài ngày ổn định ──────────────────────────────────
* CIDR LỚN bị chia CHUNK: mỗi chunk ≤ chunk_max_hosts host (mặc định 262144),
  tối thiểu /16 (chunk_prefix mặc định 16 — cùng mức với chế độ tự sinh IPv4).
  Chunk nhỏ = 1 lần chạy engine ngắn → ít gây chú ý, dễ gom kết quả.
* RESUME TỪNG CHUNK: chunk nào xong được ghi ngay vào
  output/work/<slug>/scan_chunks_done.txt + kết quả gộp vào live_chunks.txt.
  Crash/block giữa CIDR → lần sau chỉ quét lại các chunk còn dang dở.
* RETRY + BACKOFF: engine exit != 0 (mạng rớt, bị chặn tạm) → thử lại
  `scanner.retries` lần, ngủ tăng dần (retry_backoff_base * 2^n + jitter).
* POLITENESS: ngủ ngẫu nhiên chunk_sleep_min..max giây GIỮA các chunk của cùng
  CIDR (nhịp đều, không quét liên tục 1 vùng khiến dễ bị nhà mạng để ý).
* max_scan_seconds > 0 → truyền --max-time cho masscan và chặn mềm mỗi lần
  chạy engine qua timeout (tránh 1 lần quét "bất tử" kẹt cả pipeline).
* masscan nhận thêm --seed / --source-port / --source-ip / -e nếu khai trong
  config (tái lập + điều khiển nguồn phát — hữu ích khi cần cố định seed để
  so sánh, hoặc đổi source IP khi bị chặn).

─── NÂNG CẤP zmap cho quét QUY MÔ LỚN (nhiều dải IP) ────────────────────
* QUÉT SONG SONG THEO CỔNG (`parallel_ports`): thay vì quét lần lượt 80 → 443
  → 8080 (3 lượt đi qua cùng chunk, 3x thời gian), chạy ĐỒNG THỜI 1 tiến trình
  zmap mỗi cổng. Rate tổng chia đều cho các instance (tổng gói/giây KHÔNG đổi)
  → nhanh gấp n lần mà tổng lưu lượng giữ nguyên → giảm thời gian "lộ sóng"
  trên mỗi dải, ít bị để ý hơn.
* XOAY PORT NGUỒN THEO TỪNG GÓI (`--source-port A-B`): zmap 2.1.1+ hỗ trợ dải
  port nguồn — mỗi gói SYN đi ra với 1 port nguồn NGẪU NHIÊN trong dải thay vì
  1 port cố định/chunk → không thể bị lọc theo port nguồn. Dải được CHIA RIÊNG
  rời rạc cho từng instance song song để không xung đột bind.
* WARMUP: chunk đầu chạy ở rate thấp (`warmup_start_frac`) rồi tăng dần lên
  100% sau `warmup_chunks` chunk — tránh khởi động đột ngột bị throttle ngay.
* LÙI RATE KHI BỊ THROTTLE: chunk retry lần n → rate × `retry_rate_scale^n`
  (mặc định mỗi lần thử lại hạ còn 50%) — khi nhà mạng bắt đầu chặn thì chậm
  lại thay dùi cui tiếp, kết hợp backoff thời gian sẵn có.
* TỰ DÙNG config/exclude.txt khi `zmap.exclude_file` trống — loại trừ dải
  nhạy cảm (quân sự/chính phủ...) ngay từ đầu, không phụ thuộc nhớ cấu hình.
* FLAG TỰ DÙNG THEO PHIÊN BẢN: đọc `zmap --help` 1 lần để biết bản zmap hỗ
  trợ gì (source-port range, --max-runtime, --sender-threads, --min-hitrate,
  --exclude-file vs --blacklist-file) — chỉ truyền flag được hỗ trợ, chạy
  được trên cả zmap cũ lẫn mới.
* `--max-runtime`: zmap TỰ dừng gửi đúng hẹn (rồi chạy cooldown, flush kết
  quả sạch) thay vì bị runner giết cứng khi quá timeout.
* `--sender-threads` (mặc định 1): tăng khi cần rate rất cao (≥ 200k pps).
* `--min-hitrate`: dừng sớm chunk nếu tỉ lệ hồi đáp thấp bất thường — dấu
  hiệu bị chặn → chunk rơi vào nhánh retry/backoff thay vì quét vô ích.
"""
import concurrent.futures
import ipaddress
import os
import random
import shutil
import time

from utils import file_io, runner
from utils.logger import info, warn

DEFAULT_PORTS = "80,443,8080"
DEFAULT_CHUNK_MAX_HOSTS = 262144   # 2^18 — 1 chunk quét tối đa ngần này host
DEFAULT_CHUNK_PREFIX = 16          # chunk nhỏ nhất /16 (65536 host) — floor
DEFAULT_MAX_SCAN_SECONDS = 3600    # chặn mềm 1 lần chạy engine khi không khai
DEFAULT_RETRIES = 2
DEFAULT_RETRY_BACKOFF_BASE = 15    # giây
# ── chống block (NÂNG CẤP) ──
DEFAULT_RATE_JITTER = 0.15         # dao động ±15% rate mỗi chunk (mẫu không đều)
DEFAULT_SHUFFLE_CHUNKS = True      # xáo thứ tự chunk (không quét dải liền kề)
DEFAULT_RANDOM_SOURCE_PORT = True  # port nguồn ngẫu nhiên mỗi chunk (40000-60000)
# ── chống block cho quét QUY MÔ LỚN (NÂNG CẤP) ──
DEFAULT_PARALLEL_PORTS = True      # zmap: 1 tiến trình mỗi cổng chạy đồng thời
DEFAULT_SOURCE_PORT_RANGE = "40000-60000"  # dải xoay port nguồn theo từng gói
DEFAULT_WARMUP_CHUNKS = 2          # số chunk đầu tăng rate dần (0 = tắt)
DEFAULT_WARMUP_START_FRAC = 0.5    # rate khởi đầu = 50% rồi lên 100%
DEFAULT_RETRY_RATE_SCALE = 0.5     # mỗi lần retry hạ rate còn 50% (throttle → lùi)
DEFAULT_SENDER_THREADS = 1         # zmap --sender-threads (tăng khi rate rất cao)
DEFAULT_MIN_HITRATE = 0.0          # 0 = tắt; >0 = zmap dừng nếu hitrate thấp hơn

# Đếm chunk HOÀN THÀNH toàn phiên (chung cho mọi engine/CIDR) — dùng cho warmup:
# càng quét nhiều chunk (mạng đã "nạp nhiệt") rate càng được tăng lên đủ.
_CHUNKS_DONE = {"n": 0}

# Cache capability của bản zmap đang cài (đọc `zmap --help` đúng 1 lần)
_ZMAP_CAPS = {"caps": None}

# Đường dẫn binary chuẩn — /usr/sbin (zmap) có thể thiếu trong PATH user


CHUNK_DONE_FILE = "scan_chunks_done.txt"
CHUNK_LIVE_FILE = "live_chunks.txt"

# Các thư mục binary chuẩn — /usr/sbin (zmap) có thể thiếu trong PATH user
_COMMON_PATHS = ("/usr/bin", "/usr/sbin", "/usr/local/bin",
                 "/usr/local/sbin", "/bin", "/sbin")


def _find(binary):
    """shutil.which + fallback quét thư mục chuẩn (zmap thường ở /usr/sbin)."""
    path = shutil.which(binary)
    if path:
        return path
    for base in _COMMON_PATHS:
        candidate = os.path.join(base, binary)
        if os.path.isfile(candidate) and os.access(candidate, os.X_OK):
            return candidate
    return None


def _is_ipv4(text):
    try:
        return ipaddress.IPv4Address(text.strip()).version == 4
    except ValueError:
        return False


def parse_list_file(path):
    """Parse masscan -oL (list format): 'open tcp <port> <ip> <ts>' → ip:port."""
    out = []
    if not os.path.exists(path):
        return out
    with open(path, encoding="utf-8", errors="ignore") as fh:
        for line in fh:
            parts = line.split()
            if len(parts) >= 4 and parts[0] == "open" and parts[1] == "tcp":
                out.append(f"{parts[3]}:{parts[2]}")
    return file_io.dedupe_sort(out)


def parse_zmap_output(path, port):
    """Parse zmap output → list 'ip:port'.

    Hỗ trợ 2 định dạng:
      - mặc định: 1 IP mỗi dòng (output-fields = saddr)
      - CSV: 'ip,port' nếu output-fields gồm saddr,sport
    Bỏ qua comment (dòng bắt đầu bằng #) và dòng trống.
    """
    out = []
    if not os.path.exists(path):
        return out
    with open(path, encoding="utf-8", errors="ignore") as fh:
        for raw in fh:
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if "," in line:
                parts = [p.strip() for p in line.split(",")]
                if len(parts) >= 2 and _is_ipv4(parts[0]) and parts[1].isdigit():
                    out.append(f"{parts[0]}:{parts[1]}")
            elif _is_ipv4(line):
                out.append(f"{line}:{port}")
    return file_io.dedupe_sort(out)


def _engine_config(cfg):
    """Trả về dict chuẩn hóa của block `scanner` (engine/ports/masscan/zmap/chunk)."""
    sc = cfg.get("scanner") or {}
    warmup = sc.get("warmup_chunks")
    wfrac = sc.get("warmup_start_frac")
    rscale = sc.get("retry_rate_scale")
    return {
        "engine": (sc.get("engine") or "auto").lower(),
        "ports": str(sc.get("ports") or DEFAULT_PORTS),
        "masscan": sc.get("masscan") or {},
        "zmap": sc.get("zmap") or {},
        "chunk_max_hosts": int(sc.get("chunk_max_hosts") or DEFAULT_CHUNK_MAX_HOSTS),
        "chunk_prefix": int(sc.get("chunk_prefix") or 0),  # 0 = tự suy từ chunk_max_hosts
        "chunk_sleep_min": float(sc.get("chunk_sleep_min") or 0.0),
        "chunk_sleep_max": float(sc.get("chunk_sleep_max") or 0.0),
        "retries": int(sc.get("retries") or DEFAULT_RETRIES),
        "retry_backoff_base": int(sc.get("retry_backoff_base")
                                   or DEFAULT_RETRY_BACKOFF_BASE),
        "max_scan_seconds": int(sc.get("max_scan_seconds") or 0),
        # ── chống block (NÂNG CẤP) ──
        "rate_jitter": float(sc.get("rate_jitter", DEFAULT_RATE_JITTER)),
        "shuffle_chunks": bool(sc.get("shuffle_chunks", DEFAULT_SHUFFLE_CHUNKS)),
        "random_source_port": bool(sc.get("random_source_port",
                                          DEFAULT_RANDOM_SOURCE_PORT)),
        # ── quét quy mô lớn (NÂNG CẤP zmap) ──
        "parallel_ports": bool(sc.get("parallel_ports", DEFAULT_PARALLEL_PORTS)),
        "warmup_chunks": (int(warmup) if warmup is not None
                          else DEFAULT_WARMUP_CHUNKS),
        "warmup_start_frac": (float(wfrac) if wfrac is not None
                              else DEFAULT_WARMUP_START_FRAC),
        "retry_rate_scale": (float(rscale) if rscale is not None
                             else DEFAULT_RETRY_RATE_SCALE),
    }


def _jittered_rate(base_rate, jitter):
    """Rate ±jitter% ngẫu nhiên mỗi chunk — tránh mẫu lưu lượng đều đặn dễ bị
    hệ thống phát hiện bất thường của nhà mạng/ISP để ý."""
    rate = int(base_rate or 0)
    if rate <= 0 or jitter <= 0:
        return rate
    return max(1, int(rate * (1.0 + random.uniform(-jitter, jitter))))


def _random_source_port(sc, engine_cfg):
    """Port nguồn ngẫu nhiên mỗi chunk (40000-60000) khi bật và KHÔNG khai rõ
    source_port — giảm khả năng bị lọc theo port nguồn cố định."""
    if engine_cfg.get("source_port"):
        return None  # người dùng đã cố định → tôn trọng
    return random.randint(40000, 60000) if sc["random_source_port"] else None


def _effective_rate(sc, attempt, base_rate):
    """Rate thực tế cho 1 chunk: warmup ramp → lùi rate khi retry → jitter.

    * warmup: `_CHUNKS_DONE` chunk đầu chạy rate thấp (warmup_start_frac)
      rồi tăng dần lên 100% sau warmup_chunks chunk — vừa khởi động không
      phóng full rate ngay (dễ bị throttle/nghi ngờ ngay từ đầu).
    * retry: lần thử thứ n của cùng chunk → rate × retry_rate_scale^(n-1)
      (mặc định mỗi lần retry hạ còn 50%) — bị throttle thì LÙI lại thay vì
      đâm đầu tiếp, kết hợp với backoff thời gian sẵn có.
    * jitter: ±rate_jitter % ngẫu nhiên — lưu lượng không đều đặn máy móc.
    """
    rate = int(base_rate or 0)
    if rate <= 0:
        return 0
    warmup = max(0, sc["warmup_chunks"])
    done = _CHUNKS_DONE["n"]
    if warmup > 0 and done < warmup:
        frac = (sc["warmup_start_frac"]
                + (1.0 - sc["warmup_start_frac"]) * (done / warmup))
        rate = max(1, int(rate * frac))
    scale = sc["retry_rate_scale"]
    if attempt > 1 and 0.0 < scale < 1.0:
        rate = max(1, int(rate * (scale ** (attempt - 1))))
    return _jittered_rate(rate, sc["rate_jitter"])


def _split_port_range(text, n, idx):
    """Chia dải port 'A-B' (hoặc 'A') thành n đoạn RỜI RẠCH — instance song
    song idx nhận đoạn thứ idx. Trả chuỗi 'A-B'/'A', hoặc None nếu không chia
    được (dải quá nhỏ / sai định dạng). Việc chia riêng tránh 2 tiến trình
    zmap cùng bind 1 port nguồn (sẽ lỗi hoặc nhận nhầm gói trả về của nhau)."""
    text = str(text or "").strip()
    if not text:
        return None
    a, _, b = text.partition("-")
    try:
        lo = int(a)
        hi = int(b) if b.strip() else lo
    except ValueError:
        return text if n <= 1 else None
    if not (1 <= lo <= 65535 and 1 <= hi <= 65535) or lo > hi:
        return text if n <= 1 else None
    if n <= 1:
        return text
    span = (hi - lo + 1) // n
    if span <= 0:
        return None
    start = lo + idx * span
    end = hi if idx == n - 1 else start + span - 1
    if start > end:
        return None
    return f"{start}-{end}" if end > start else str(start)


def _instance_source_port(sc, zm, idx, n, caps):
    """Spec port nguồn cho instance idx/n của 1 chunk zmap.

    Ưu tiên: source_port khai rõ > dải xoay THEO TỪNG GÓI (source_port_range,
    cần zmap hỗ trợ 'port|range') > port ngẫu nhiên đơn cho từng instance >
    None. Dải luôn được chia riêng theo idx để các instance song song không
    bind trùng port nguồn.
    """
    fixed = str(zm.get("source_port") or "").strip()
    if fixed:
        if "-" in fixed:
            return _split_port_range(fixed, n, idx)
        try:
            port = int(fixed)
        except ValueError:
            return fixed if n <= 1 else None
        if n > 1:
            # các instance song song không thể cùng bind 1 port → dịch theo idx
            shifted = port + idx
            return str(shifted) if 1 <= shifted <= 65535 else None
        return str(port)
    if sc["random_source_port"]:
        rng = str(zm.get("source_port_range") or DEFAULT_SOURCE_PORT_RANGE).strip()
        if "source_port_range" in caps:
            return _split_port_range(rng, n, idx)
        # zmap cũ không hỗ trợ dải → 1 port ngẫu nhiên RIÊNG cho từng instance
        return str(random.randint(40000, 60000))
    return None


def _default_exclude_file():
    """config/exclude.txt trong thư mục dự án — tự dùng khi exclude_file trống
    để luôn loại trừ dải nhạy cảm (quân sự/chính phủ...) mà không cần nhớ cấu
    hình. Trả '' nếu file không tồn tại."""
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    path = os.path.join(root, "config", "exclude.txt")
    return path if os.path.isfile(path) else ""


def pick_engine(cfg):
    """Chọn engine khả dụng theo config; trả về 'masscan' | 'zmap' | None."""
    sc = _engine_config(cfg)
    engine = sc["engine"]
    if engine in ("masscan", "zmap"):
        if _find(engine):
            return engine
        warn(f"[scanner] engine '{engine}' không có binary — thử 'auto'")
    if _find("masscan"):
        return "masscan"
    if _find("zmap"):
        return "zmap"
    return None


# ─── Chunk CIDR lớn ─────────────────────────────────────────────────────


def _chunk_prefix(sc):
    """Prefix mỗi chunk.

    - chunk_prefix khai rõ (>0) → dùng thẳng (chỉ siết lại nếu vượt
      chunk_max_hosts).
    - mặc định tự suy: prefix tối đa mà 2^(32-p) <= chunk_max_hosts, nhưng
      không quá thô hơn /16 (floor — 1 lần quét ≤ 65536 host, cùng mức chế độ
      tự sinh IPv4) → mặc định cho ra /16.
    """
    max_hosts = max(1, sc["chunk_max_hosts"])
    preferred = sc["chunk_prefix"]
    if preferred > 0:
        prefix = preferred
    else:
        # cần prefix p sao cho 2^(32-p) <= max_hosts → p >= 32 - ceil(log2(max_hosts))
        needed = 32 - (max_hosts - 1).bit_length()
        prefix = max(DEFAULT_CHUNK_PREFIX, needed)
    while prefix < 30 and (1 << (32 - prefix)) > max_hosts:
        prefix += 1
    return prefix


def _iter_chunks(network, prefix):
    """Chunk đều theo prefix: CIDR nhỏ hơn → chạy nguyên 1 lần (yield chính nó)."""
    if network.prefixlen >= prefix:
        yield network
        return
    yield from network.subnets(new_prefix=prefix)


def _chunk_dir(workdir):
    chunk_dir = os.path.join(workdir, "chunks")
    os.makedirs(chunk_dir, exist_ok=True)
    return chunk_dir


def _read_done(workdir):
    """Set chunk CIDR đã quét xong (resume từng chunk)."""
    path = os.path.join(workdir, CHUNK_DONE_FILE)
    return set(file_io.read_lines(path))


def _mark_done(workdir, chunk):
    file_io.append_line(os.path.join(workdir, CHUNK_DONE_FILE), str(chunk))


def _accumulate(workdir, hosts):
    file_io.append_lines(os.path.join(workdir, CHUNK_LIVE_FILE), hosts)


def _scan_chunks(cidr, workdir, sc, cfg, chunk_runner):
    """Chia CIDR → chunk, chạy từng chunk có retry/backoff + resume.

    chunk_runner(network_text, chunk_dir) → list 'ip:port' nếu OK, None nếu lỗi.
    Trả list 'ip:port' gộp TẤT CẢ chunk đã xong (cũ + mới). Raise RuntimeError
    nếu 1 chunk thất bại hết lượt retry (để pipeline không đánh dấu .complete —
    lần chạy sau resume phần còn dang dở).
    """
    prefix = _chunk_prefix(sc)
    network = ipaddress.ip_network(cidr, strict=False)
    chunks = list(_iter_chunks(network, prefix))
    if len(chunks) > 1:
        info(f"[{cidr}] chia {len(chunks)} chunk /{prefix} — "
             f"{1 << (32 - prefix)} host/chunk (resume từng chunk)")

    done = _read_done(workdir)
    remaining = [chunk for chunk in chunks if str(chunk) not in done]
    if done and len(remaining) < len(chunks):
        info(f"[{cidr}] resume: {len(chunks) - len(remaining)}/{len(chunks)} "
             f"chunk đã xong trước đó — quét tiếp {len(remaining)} chunk")

    # NÂNG CẤP chống block: xáo thứ tự chunk — quét các dải KHÔNG liền kề theo
    # thứ tự ngẫu nhiên, mẫu quét không theo quy luật địa lý dễ nhận diện.
    if sc["shuffle_chunks"] and len(remaining) > 1:
        random.shuffle(remaining)
        info(f"[{cidr}] xáo thứ tự {len(remaining)} chunk (chống nhận diện mẫu quét)")

    chunk_dir = _chunk_dir(workdir)
    sleep_span = sc["chunk_sleep_max"] - sc["chunk_sleep_min"]
    for idx, chunk in enumerate(remaining):
        chunk_text = str(chunk)
        attempts = max(1, sc["retries"] + 1)
        hosts = None
        last_err = ""
        for attempt in range(1, attempts + 1):
            hosts = chunk_runner(chunk_text, chunk_dir, attempt)
            if hosts is not None:
                break
            last_err = f"chunk {chunk_text} thất bại lần {attempt}/{attempts}"
            if attempt < attempts:
                backoff = sc["retry_backoff_base"] * (2 ** (attempt - 1))
                backoff += random.uniform(0, sc["retry_backoff_base"] / 2)
                warn(f"[scanner] {last_err} — thử lại sau {backoff:.0f}s")
                time.sleep(backoff)
        if hosts is None:
            raise RuntimeError(f"{last_err} — đã cạn lượt retry (xem log engine)")
        _accumulate(workdir, hosts)
        _mark_done(workdir, chunk)
        # chunk xong an toàn → tăng biến đếm toàn phiên (warmup dựa vào đây):
        # càng quét nhiều chunk, rate càng được nâng dần lên mức tối đa.
        _CHUNKS_DONE["n"] += 1
        # politeness giữa các chunk của cùng CIDR
        if idx < len(remaining) - 1 and sleep_span > 0:
            time.sleep(sc["chunk_sleep_min"] + random.random() * sleep_span)

    merged = file_io.dedupe_sort(file_io.read_lines(
        os.path.join(workdir, CHUNK_LIVE_FILE)))
    return merged


def _runner_timeout(sc):
    """Chặn mềm 1 lần chạy engine (giây)."""
    return sc["max_scan_seconds"] or DEFAULT_MAX_SCAN_SECONDS


def _masscan_chunk_runner(sc, cfg):
    def run_chunk(chunk_text, chunk_dir, attempt=1):
        slug = file_io.slugify(chunk_text)
        targets_file = os.path.join(chunk_dir, f"{slug}.txt")
        raw = os.path.join(chunk_dir, f"{slug}.list")
        file_io.atomic_write(targets_file, chunk_text + "\n")

        mc = sc["masscan"]
        # NÂNG CẤP: rate đi qua warmup ramp + lùi rate khi retry + jitter
        rate = _effective_rate(sc, attempt, mc.get("rate") or cfg.get("rate", 10000))
        wait = mc.get("wait", 0)
        cmd = [
            "masscan", "-iL", targets_file, "-p", sc["ports"],
            "--rate", str(rate), "--wait", str(wait),
            "-oL", raw,
        ]
        # các tùy chọn giúp tái lập / điều khiển nguồn phát (chống block)
        if mc.get("seed"):
            cmd += ["--seed", str(mc["seed"])]
        source_port = str(mc["source_port"]) if mc.get("source_port") else \
            _random_source_port(sc, mc)
        if source_port:
            cmd += ["--source-port", source_port]
        if mc.get("source_ip"):
            cmd += ["--source-ip", str(mc["source_ip"])]
        if mc.get("interface"):
            cmd += ["-e", str(mc["interface"])]
        if sc["max_scan_seconds"] > 0:
            cmd += ["--max-time", str(sc["max_scan_seconds"])]

        proc = runner.run(cmd, timeout=_runner_timeout(sc))
        if proc.returncode == 124:
            warn(f"[masscan] chunk {chunk_text} quá {_runner_timeout(sc)}s — bị chặn")
            return None
        if proc.returncode != 0 and proc.stderr:
            warn(f"[masscan] chunk {chunk_text} exit {proc.returncode}: "
                 f"{proc.stderr.strip()[-300:]}")
            return None
        if proc.returncode != 0:
            warn(f"[masscan] chunk {chunk_text} exit {proc.returncode} (không có stderr)")
            return None
        return parse_list_file(raw)
    return run_chunk


# Cache help text + capability của zmap (đọc `zmap --help` đúng 1 LẦN/phiên)
_ZMAP_HELP = {"text": None}
_ZMAP_CAPS = {"caps": None}


def _zmap_help():
    """Nội dung `zmap --help` (cache 1 lần) — dùng để dò capability của bản cài."""
    if _ZMAP_HELP["text"] is not None:
        return _ZMAP_HELP["text"]
    try:
        text = runner.run(["zmap", "--help"], timeout=30).stdout or ""
    except Exception:
        text = ""
    _ZMAP_HELP["text"] = text
    return text


def _zmap_exclude_flag():
    """zmap >= 4 dùng --exclude-file; bản cũ dùng --blacklist-file."""
    help_text = _zmap_help()
    flag = "--exclude-file"
    if flag not in help_text and "--blacklist-file" in help_text:
        flag = "--blacklist-file"
    return flag


def _zmap_caps():
    """Set flag zmap đang cài hỗ trợ — đọc help đúng 1 lần rồi cache.

    zmap thay đổi flag theo phiên bản (2.1.1: --source-port=port|range,
    --max-runtime, --sender-threads, --min-hitrate; khác nhau giữa các bản)
    nên chỉ truyền flag nào help xác nhận, tránh crash vì flag lạ trên bản cũ.
    """
    if _ZMAP_CAPS["caps"] is not None:
        return _ZMAP_CAPS["caps"]
    text = _zmap_help()
    caps = set()
    if "port|range" in text or "port-range" in text:
        caps.add("source_port_range")
    if "--max-runtime" in text:
        caps.add("max_runtime")
    if "--min-hitrate" in text:
        caps.add("min_hitrate")
    if "--sender-threads" in text:
        caps.add("sender_threads")
    _ZMAP_CAPS["caps"] = caps
    return caps


def _build_zmap_cmd(zm, caps, port, targets_file, raw, rate, source_spec,
                    max_scan_seconds):
    """Dựng lệnh zmap cho 1 cặp (chunk × cổng); trả (cmd, runner_timeout).

    Chỉ truyền flag mà bản zmap đang cài hỗ trợ (qua `caps`) — chạy được trên
    cả bản cũ lẫn mới. Khi có --max-runtime: zmap TỰ dừng gửi đúng hẹn rồi
    cooldown + flush kết quả sạch, nên runner timeout được NỚI RA
    (max_runtime + cooldown + 60s) thay vì giết zmap đúng lúc đang thu kết quả.
    """
    cmd = ["zmap", "-p", str(port), "-w", targets_file,
           "--rate", str(rate), "-o", raw]
    if zm.get("bandwidth"):
        cmd += ["--bandwidth", str(zm["bandwidth"])]
    if zm.get("cooldown") is not None:
        cmd += ["--cooldown", str(zm["cooldown"])]
    if zm.get("seed"):
        cmd += ["--seed", str(zm["seed"])]
    if source_spec:
        cmd += ["--source-port", str(source_spec)]
    if zm.get("interface"):
        cmd += ["-i", str(zm["interface"])]
    if zm.get("quiet", True):
        cmd += ["--quiet"]
    if zm.get("dryrun"):
        cmd += ["--dryrun"]  # chỉ validate config, không gửi gói
    threads = int(zm.get("sender_threads") or DEFAULT_SENDER_THREADS)
    if threads > 1 and "sender_threads" in caps:
        cmd += ["--sender-threads", str(threads)]
    hitrate = float(zm.get("min_hitrate") or DEFAULT_MIN_HITRATE)
    if hitrate > 0 and "min_hitrate" in caps:
        cmd += ["--min-hitrate", str(hitrate)]
    timeout = max_scan_seconds or DEFAULT_MAX_SCAN_SECONDS
    if max_scan_seconds > 0 and "max_runtime" in caps:
        cmd += ["--max-runtime", str(max_scan_seconds)]
        cooldown = int(zm.get("cooldown") or 0)
        timeout = max_scan_seconds + cooldown + 60
    excl = (zm.get("exclude_file") or "").strip()
    if not excl and zm.get("exclude_default", True):
        excl = _default_exclude_file()
    if excl and os.path.exists(excl):
        cmd += [_zmap_exclude_flag(), excl]
    extra = zm.get("extra_args") or []
    if extra:
        cmd += [str(a) for a in extra]
    return cmd, timeout


def _zmap_chunk_runner(sc, cfg):
    """Runner zmap cho 1 chunk — NÂNG CẤP cho quét QUY MÔ LỚN:

    * SONG SONG THEO CỔNG (parallel_ports): mỗi cổng 1 tiến trình zmap chạy
      đồng thời thay vì lần lượt 80 → 443 → 8080; rate tổng chia đều cho các
      instance (tổng gói/giây KHÔNG đổi) → nhanh gấp n lần, giảm thời gian
      "lộ sóng" trên mỗi dải.
    * Mỗi instance có dải port nguồn RIÊNG (chia từ source_port_range, xoay
      theo từng gói) + rate jitter riêng → không bind trùng, lưu lượng không
      đều đặn dễ nhận diện.
    * Cổng nào lỗi → cả chunk thất bại (retry + backoff, lùi rate dần).
    * Rate đi qua _effective_rate: warmup ramp khi mới start + lùi rate khi retry.
    """
    zm = sc["zmap"]
    ports = [p.strip() for p in sc["ports"].split(",") if p.strip()]
    caps = _zmap_caps()
    zmap_bin = _find("zmap") or "zmap"
    n_inst = max(1, len(ports)) if sc["parallel_ports"] else 1

    def run_one(idx, port, targets_file, raw, base_rate, attempt, chunk_text):
        """1 tiến trình zmap cho (chunk × cổng); trả list host hoặc None nếu lỗi."""
        spec = _instance_source_port(sc, zm, idx, n_inst, caps)
        if spec is None and (zm.get("source_port") or sc["random_source_port"]):
            warn(f"[zmap] không chia được port nguồn cho port {port} "
                 f"(instance {idx + 1}/{n_inst}) — chạy không source-port")
        # rate TỔNG chia đều cho các instance → tổng pps giữ nguyên mức config
        per_rate = (max(1, int(int(base_rate or 0) / n_inst))
                    if n_inst > 1 else base_rate)
        rate = _effective_rate(sc, attempt, per_rate)
        cmd, timeout = _build_zmap_cmd(zm, caps, port, targets_file, raw,
                                       rate, spec, sc["max_scan_seconds"])
        cmd[0] = zmap_bin
        proc = runner.run(cmd, timeout=timeout)
        if proc.returncode == 124:
            warn(f"[zmap] chunk {chunk_text} port {port} quá {timeout}s — bị chặn")
            return None
        if proc.returncode != 0 and proc.stderr:
            warn(f"[zmap] chunk {chunk_text} port {port} exit {proc.returncode}: "
                 f"{proc.stderr.strip()[-300:]}")
            return None
        if proc.returncode != 0:
            warn(f"[zmap] chunk {chunk_text} port {port} exit "
                 f"{proc.returncode} (không có stderr)")
            return None
        hosts = parse_zmap_output(raw, port)
        if not hosts:
            info(f"[zmap] chunk {chunk_text} port {port}: 0 kết quả "
                 f"(dải tối hoặc bị chặn — theo dõi nếu lặp lại ở nhiều chunk)")
        return hosts

    def run_chunk(chunk_text, chunk_dir, attempt=1):
        if not ports:
            return []
        slug = file_io.slugify(chunk_text)
        targets_file = os.path.join(chunk_dir, f"{slug}.txt")
        file_io.atomic_write(targets_file, chunk_text + "\n")
        base_rate = zm.get("rate") or cfg.get("rate", 10000)

        if n_inst > 1:
            # SONG SONG: 1 tiến trình zmap mỗi cổng (rate đã chia đều trước đó)
            with concurrent.futures.ThreadPoolExecutor(max_workers=n_inst) as pool:
                futures = [
                    pool.submit(run_one, i, port, targets_file,
                                os.path.join(chunk_dir, f"{slug}_p{port}.out"),
                                base_rate, attempt, chunk_text)
                    for i, port in enumerate(ports)
                ]
                results = []
                for fut in futures:
                    try:
                        results.append(fut.result())
                    except Exception as exc:  # noqa: BLE001 — 1 cổng lỗi không chết pipeline
                        warn(f"[zmap] lỗi ngoài dự kiến khi quét: {exc}")
                        results.append(None)
        else:
            results = [
                run_one(i, port, targets_file,
                        os.path.join(chunk_dir, f"{slug}_p{port}.out"),
                        base_rate, attempt, chunk_text)
                for i, port in enumerate(ports)
            ]

        if any(r is None for r in results):
            return None  # cả chunk thất bại → retry + backoff (lùi rate)
        chunk_hosts = []
        for r in results:
            chunk_hosts += r or []
        return file_io.dedupe_sort(chunk_hosts)
    return run_chunk


def scan_masscan(cidr, workdir, global_live, cfg):
    """Quét CIDR bằng masscan (tự chia chunk nếu lớn); trả list 'ip:port'."""
    sc = _engine_config(cfg)
    return _scan_chunks(cidr, workdir, sc, cfg, _masscan_chunk_runner(sc, cfg))


def scan_zmap(cidr, workdir, global_live, cfg):
    """Quét CIDR bằng zmap (tự chia chunk nếu lớn); trả list 'ip:port'."""
    sc = _engine_config(cfg)
    return _scan_chunks(cidr, workdir, sc, cfg, _zmap_chunk_runner(sc, cfg))


def scan(cidr, workdir, global_live, cfg):
    """Quét 1 CIDR bằng engine đã chọn; append vào global_live; trả 'ip:port'.

    Chunk đã xong (scan_chunks_done.txt) được bỏ qua khi chạy lại CIDR này —
    resume ở mức chunk, an toàn cho lần quét dài ngày bị ngắt giữa chừng.
    """
    engine = pick_engine(cfg)
    hosts = []
    if engine == "masscan":
        hosts = scan_masscan(cidr, workdir, global_live, cfg)
    elif engine == "zmap":
        hosts = scan_zmap(cidr, workdir, global_live, cfg)
    else:
        warn("[scanner] không tìm thấy masscan/zmap — bỏ qua stage 1")

    file_io.append_lines(global_live, hosts)
    info(f"[{cidr}] stage1 ({engine or 'none'}): {len(hosts)} host mở "
         f"{_engine_config(cfg)['ports']}")
    return hosts

