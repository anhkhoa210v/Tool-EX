"""STAGE 3-woo: dò version PLUGIN WordPress/WooCommerce (+ version WP core).

Khác Magento (1 sản phẩm), WordPress để lộ version TỪNG PLUGIN qua asset tĩnh:

    /wp-content/plugins/<slug>/assets/x.js?ver=3.15.0.3

Nguồn:
  1. Asset path trong HTML/JS của trang chủ (và trang thêm): regex
     `/wp-content/plugins/<slug>/...?ver=<version>`; hỗ trợ cả biến thể
     `&#038;ver=` / `&amp;ver=` (HTML escaped) do theme chèn query nối.
  2. readme.txt (nếu config `woocommerce.fetch_readme`): GET
     `/wp-content/plugins/<slug>/readme.txt`, đọc dòng "Stable tag: X.Y.Z"
     — dùng khi asset không kèm `?ver` hoặc bị cache-buster.
  3. Version WordPress CORE từ `<meta name="generator" content="WordPress X.Y.Z">`;
     nếu thiếu, tuỳ chọn đọc `/readme.html` (config `woocommerce.core_readme`).
     Lưu dưới slug "wordpress".

Version trả về là chuỗi thô ("3.15.0.3", "84.3"); việc chuẩn hoá/so khớp do
`woo_cve_map.parse_plugin_version` lo (không parse ở đây để giữ 1 nguồn sự thật).

Nhiều hit cho cùng 1 slug → chọn version xuất hiện NHIỀU NHẤT (tie: version lớn
nhất) vì asset cùng plugin thường lặp nhiều lần với cùng `?ver`, còn
cache-buster lạ chỉ xuất hiện lẻ tẻ.

BỀN VỮNG (nâng cấp): bỏ ThreadPoolExecutor lồng trong từng host + Session dùng
chung giữa nhiều thread (thread-unsafe). Thay bằng: 1 session thread-local
(utils/http.py) + đọc readme TUẦN TỰ, giới hạn README_MAX slug/host → tránh
bùng nổ số socket (trước đây ~threads×8) khi chạy dài.

Output: work/<slug>/woo_plugins.txt — "url plugin_slug version" (debug).
Contract: run(woo_urls, workdir, cfg) → {host_url: {plugin_slug: version}}.
"""
import concurrent.futures
import os
import re
from collections import Counter

import requests
import urllib3

from core.woo_cve_map import parse_plugin_version
from utils import file_io, http
from utils.logger import info

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

USER_AGENT = "Mozilla/5.0 (compatible; SofiaScan/1.0)"
BODY_LIMIT = 300000
DEFAULT_MAX_PLUGINS = 200
# Số slug tối đa thử đọc readme.txt mỗi host — chặn bùng nổ request khi chạy dài.
README_MAX = 12
# Slug LUÔN thử đọc readme.txt dù không thấy trong HTML (asset bị gộp/minify).
DEFAULT_ALWAYS_PROBE = ("woocommerce",)

# Bắt: /wp-content/plugins/<slug>/<bất kỳ>?ver=<version>
# Hỗ trợ query nối ở dạng HTML escaped: ?ver=, &amp;ver=, &#038;ver=, &#38;ver=
PLUGIN_ASSET_RE = re.compile(
    r"wp-content/plugins/([A-Za-z0-9._\-]+)/[^\"'?#\s<>]*?"
    r"(?:[?]|&amp;|&#0?38;|&)(?:amp;|#0?38;)?ver=([0-9][0-9A-Za-z.\-]*)",
)
# slug plugin xuất hiện trong asset dù KHÔNG có ?ver (để biết plugin CÓ MẶT)
PLUGIN_ANY_RE = re.compile(r"wp-content/plugins/([A-Za-z0-9._\-]+)/")
STABLE_TAG_RE = re.compile(
    r"stable\s+tag:\s*([0-9]+(?:\.[0-9]+){0,3})", re.I)
VERSION_QUERY_RE = re.compile(
    r"(?:[?&]|&amp;|&#0?38;)(?:amp;|#0?38;)?ver=([0-9][0-9A-Za-z.\-]*)")
# Version WordPress core từ <meta name="generator" content="WordPress 6.5.3">
WP_CORE_META_RE = re.compile(
    r"<meta[^>]+name=[\"']generator[\"'][^>]+content=[\"']WordPress\s+"
    r"([0-9][0-9A-Za-z.\-]*)", re.I)
WP_CORE_META_RE2 = re.compile(
    r"<meta[^>]+content=[\"']WordPress\s+([0-9][0-9A-Za-z.\-]*)[\"']"
    r"[^>]*name=[\"']generator[\"']", re.I)
# readme.html mặc định: "<br /> Version 6.5.3"
WP_CORE_README_RE = re.compile(r"\bVersion\s+([0-9]+\.[0-9]+(?:\.[0-9]+)?)", re.I)

# Cấu hình đọc /readme.html khi thiếu generator meta — run() ghi đè.
_core_readme = True
# Slug luôn probe readme (ngoài các slug bắt được từ HTML).
_always_probe = DEFAULT_ALWAYS_PROBE


def plugins_from_html(html):
    """HTML → {slug: version} (chỉ plugin có ?ver hợp lệ); bỏ slug rỗng."""
    found = {}
    if not html:
        return found
    for raw_slug, raw_version in PLUGIN_ASSET_RE.findall(html):
        slug = raw_slug.strip().lower()
        version = raw_version.strip()
        if not slug:
            continue
        if parse_plugin_version(version) is None:
            continue
        found.setdefault(slug, []).append(version)
    return found


def plugin_slugs(html):
    """Tập slug plugin xuất hiện trong HTML (kể cả KHÔNG có ?ver)."""
    return {m.strip().lower() for m in PLUGIN_ANY_RE.findall(html or "") if m.strip()}


def wp_core_version(html):
    """Version WordPress core từ generator meta (hoặc None)."""
    for regex in (WP_CORE_META_RE, WP_CORE_META_RE2):
        match = regex.search(html or "")
        if match and parse_plugin_version(match.group(1)):
            return match.group(1)
    return None


def readme_core_version(html):
    """Version WP core từ nội dung readme.html (hoặc None)."""
    match = WP_CORE_README_RE.search((html or "")[:20000])
    if match and parse_plugin_version(match.group(1)):
        return match.group(1)
    return None


def _pick_version(versions):
    """list version thô → version đại diện (nhiều nhất, tie: lớn nhất)."""
    if not versions:
        return None
    counter = Counter(versions)
    top = max(counter.values())
    candidates = [v for v, n in counter.items() if n == top]
    return max(candidates, key=lambda v: parse_plugin_version(v) or (0, 0, 0, 0))


def fetch_plugin_version(url, slug, timeout, session=None):
    """GET readme.txt → 'Stable tag' / '?ver' trong body → version hoặc None.

    Không truyền `session` → dùng http.fetch_limited (trần byte, không cache);
    truyền `session` (test/mock hoặc caller cũ) → giữ nguyên hành vi `session.get`.
    """
    for base in (url, url.rstrip("/")):
        target = f"{base}/wp-content/plugins/{slug}/readme.txt"
        try:
            if session is None:
                resp = http.fetch_limited(target, timeout=timeout, limit=BODY_LIMIT)
            else:
                resp = session.get(target, timeout=timeout, allow_redirects=True)
        except requests.RequestException:
            return None
        if resp is None or resp.status_code != 200:
            continue
        text = resp.text[:BODY_LIMIT]
        match = STABLE_TAG_RE.search(text)
        if match:
            return match.group(1)
        match = VERSION_QUERY_RE.search(text)
        if match and parse_plugin_version(match.group(1)):
            return match.group(1)
    return None


def _scan_host(url, timeout, fetch_readme, max_plugins, always_probe=None):
    """1 host → {slug: version} (đã chọn version đại diện, tối đa max_plugins slug).

    Trang chủ + readme.html đọc qua http.fetch_limited (trần byte, trang chủ lấy
    từ PageCache nên không GET lại nếu stage trước đã tải). Đọc readme TUẦN TỰ
    (giới hạn README_MAX) — không tạo thread pool lồng trong mỗi host.

    `always_probe`: slug luôn thử đọc readme.txt dù không xuất hiện trong HTML
    (mặc định: woocommerce) — bắt được version Woo khi asset bị gộp/minify.
    """
    always_probe = tuple(always_probe or _always_probe)
    cache = http.get_page_cache()
    resp = http.fetch_limited(url, timeout=timeout, limit=BODY_LIMIT, cache=cache)
    if resp is None:
        return {}
    html = resp.text[:BODY_LIMIT]

    raw = plugins_from_html(html)
    slugs = set(raw) | plugin_slugs(html) | set(always_probe)

    result = {}
    for slug, versions in list(raw.items())[:max_plugins]:
        picked = _pick_version(versions)
        if picked:
            result[slug] = picked

    # Bổ sung version từ readme.txt cho slug thiếu version (tuần tự, có trần).
    # `always_probe` được ưu tiên lên đầu để không bị README_MAX cắt mất.
    if fetch_readme:
        candidates = list(always_probe) + [s for s in sorted(slugs)
                                           if s not in always_probe]
        missing = [s for s in candidates if s not in result][:README_MAX]
        for slug in missing:
            version = fetch_plugin_version(url, slug, timeout)
            if version:
                result[slug] = version

    # Version WordPress core (generator meta → fallback readme.html)
    if "wordpress" not in result:
        core = wp_core_version(html)
        if not core and _core_readme:
            resp2 = http.fetch_limited(url.rstrip("/") + "/readme.html",
                                       timeout=timeout, limit=BODY_LIMIT)
            if resp2 is not None and resp2.status_code == 200:
                core = readme_core_version(resp2.text[:BODY_LIMIT])
        if core:
            result["wordpress"] = core
    # Giữ trần max_plugins tổng thể
    if len(result) > max_plugins:
        result = dict(list(result.items())[:max_plugins])
    return result


def run(woo_urls, workdir, cfg):
    """woo_urls: list URL WooCommerce → {url: {slug: version}}; ghi debug file."""
    global _core_readme, _always_probe
    timeout = cfg.get("timeout", 15)
    wc = cfg.get("woocommerce") or {}
    fetch_readme = bool(wc.get("fetch_readme", True))
    _core_readme = bool(wc.get("core_readme", True))
    max_plugins = int(wc.get("max_plugins", DEFAULT_MAX_PLUGINS))
    _always_probe = tuple(
        str(s).strip().lower() for s in
        (wc.get("always_probe_slugs", DEFAULT_ALWAYS_PROBE) or ())
        if str(s).strip())

    versions = {}
    rows = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=cfg.get("threads", 50)) as pool:
        futures = {
            pool.submit(_scan_host, u, timeout, fetch_readme, max_plugins): u
            for u in woocommerce_urls(woo_urls)
        }
        for future in concurrent.futures.as_completed(futures):
            url = futures[future]
            host_plugins = future.result()
            versions[url] = host_plugins
            for slug, version in host_plugins.items():
                rows.append(f"{url} {slug} {version}")

    out_file = os.path.join(workdir, "woo_plugins.txt")
    file_io.write_lines(out_file, file_io.dedupe_sort(rows))
    total_plugins = sum(len(v) for v in versions.values())
    info(f"stage3-woo: {total_plugins} plugin/version trên "
         f"{sum(1 for v in versions.values() if v)}/{len(versions)} host "
         f"(fetch_readme={fetch_readme}, core_readme={_core_readme})")
    return versions


def woocommerce_urls(urls):
    """Chuẩn hoá input: nhận list URL hoặc list 'ip:port'."""
    out = []
    for item in urls or []:
        item = str(item).strip()
        if not item:
            continue
        out.append(item if item.startswith("http") else f"http://{item}")
    return out
