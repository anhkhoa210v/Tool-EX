"""STAGE 2a-woo: phát hiện WordPress và WooCommerce — probe ĐA ENDPOINT + chấm điểm.

Song song với core/fingerprint.py (Magento). Mỗi host được probe thêm endpoint
đặc trưng (cấu hình `woocommerce.endpoints`, mặc định):
    /wp-login.php                    → trang đăng nhập WordPress
    /wp-json/                        → WP REST API (JSON, có "routes"/"namespaces")
    /wp-json/wc/store/v1/products    → WooCommerce Store API (JSON) — DẤU HIỆU WOO
    /readme.html                     → readme mặc định WordPress
    /cart/  /shop/                   → trang giỏ hàng / cửa hàng WooCommerce

Chấm điểm tin cậy (confidence scoring):
    header x-powered-by: WordPress                          +3
    header Link chứa wp-json                                +3
    cookie wordpress_*/wp-settings*/wp_lang/wp_test_cookie   +3
    cookie woocommerce_*/wp_woocommerce_session             +3 (WOO)
    body chữ ký WordPress (wp-content/wp-includes/wp-json/wp-emoji/wp-block-library) +3
    body <meta generator> WordPress                        +2
    body chữ ký WOOCOMMERCE (plugins/woocommerce/, wc-…)    +3   ← woo-specific
    /wp-json/ trả JSON (routes/namespaces)                  +3
    /wp-json/ body chứa namespace wc/store hoặc wc/v3       +3   ← woo-specific
    /wp-json/wc/store/ trả JSON                             +3   ← woo-specific
    /wp-login.php 200 + wp-login trong body                 +2
    /readme.html 200 + "WordPress"                          +2
    /cart/ 200   /shop/ 200                                 +2 mỗi cái

Tổng đạt `woocommerce.min_score` (mặc định 3) → kết luận WordPress. Kết luận
WooCommerce khi có ≥1 BẰNG CHỨNG WOO RIÊNG (asset plugin woocommerce, Store API
JSON, cookie woo, marker `wc-…`) VÀ tổng điểm đạt ngưỡng.

Short-circuit: đủ ngưỡng + đã có bằng chứng woo → dừng probe sớm cho woo.

NÂNG CẤP: trang chủ GET qua lớp HTTP chung (utils/http.py) + PageCache → tái
dùng kết quả giữa các stage; retry transport; pool thread-local an toàn chạy dài.

Output:
    output/wordpress.txt       — 1 URL WordPress mỗi dòng
    output/woocommerce.txt     — 1 URL WooCommerce mỗi dòng (tập con WordPress)
    output/work/<slug>/woo_scored.txt — "url score bằng_chứng" (debug)
Contract: run(hosts, workdir, global_wp, global_woo, cfg) → list URL WooCommerce.
"""
import concurrent.futures
import os

import requests
import urllib3

from utils import file_io, http
from utils.logger import info

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

USER_AGENT = "Mozilla/5.0 (compatible; SofiaScan/1.0)"
BODY_LIMIT = 200000

DEFAULT_ENDPOINTS = (
    "/wp-login.php", "/wp-json/", "/wp-json/wc/store/v1/products",
    "/readme.html", "/cart/", "/shop/",
)
# Endpoint nặng bằng chứng WOOCOMMERCE (đặc trưng plugin, không phải WP chung).
WOO_DEEP_ENDPOINTS = (
    "/wp-json/wc/store/v1/cart",            # Store API cart → JSON (không cần auth)
    "/wp-content/plugins/woocommerce/readme.txt",  # plugin CÓ MẶT (kể cả khi asset bị gộp)
)
DEFAULT_MIN_SCORE = 3

JSON_TYPES = "application/json"
HTML_TYPES = "text/html"


def _hdrs(headers):
    return {str(k).lower(): str(v) for k, v in (headers or {}).items()}


# --- Bằng chứng WordPress (chung) -------------------------------------------
WP_BODY_MARKERS = (
    "/wp-content/", "wp-content/", "/wp-includes/", "wp-includes/",
    "wp-emoji", "wp-emoji-release", "/wp-json", "wp-block-", "wp-block-library",
    "wp-embed", "wpadminbar", "wordpress",
)

# --- Bằng chứng WOOCOMMERCE (riêng) -----------------------------------------
# Xuất hiện khi site thật sự chạy plugin WooCommerce (asset/marker/class).
WOO_BODY_MARKERS = (
    "/wp-content/plugins/woocommerce/",
    "wp-content/plugins/woocommerce/",
    "woocommerce-page", "woocommerce-info", "woocommerce-message",
    "wc-block-", "wc-blocks", "wc-block-components", "wc-item-meta",
    "wp-block-woocommerce", "wc-ajax", "wc_add_to_cart", "wc_get_cart_url",
    "wc-store", "wc-store-api", "add_to_cart_button", "woocommerce-cart",
    "woocommerce-checkout", "class=\"woocommerce", "wc-forward",
    "cart-fragments", "wc_cart_hash", "wc_cart_fragments_params",
    "woocommerce_assets_url", "data-block-name=\"woocommerce/",
    "woocommerce-Reviews", "wc-single-product",
)
WOO_COOKIE_RE = "woocommerce_"
WOO_SESSION_COOKIE = "wp_woocommerce_session"
WOO_STORE_API_PATH = "/wp-json/wc/store/"
# namespace WooCommerce trong REST index body
WOO_REST_NS_RE = ("wc/store", "wc/v3", "wc/v2")


def score_response(status, headers, body, endpoint=None, store_api=None):
    """Chấm điểm 1 response.

    Trả về (score, woo_points, [bằng_chứng]) — woo_points>0 nghĩa là có bằng
    chứng WOOCOMMERCE riêng (dùng để phân biệt woo với WordPress thường)."""
    hdrs = _hdrs(headers)
    score = 0
    woo = 0
    evidence = []

    powered = hdrs.get("x-powered-by", "")
    if "wordpress" in powered.lower():
        score += 3
        evidence.append("header:x-powered-by")

    link = hdrs.get("link", "")
    if "wp-json" in link.lower():
        score += 3
        evidence.append("header:link-wp-json")

    for header in ("set-cookie", "cookie"):
        value = hdrs.get(header, "")
        if not value:
            continue
        low = value.lower()
        if ("wordpress_" in low or "wp-settings" in low
                or "wp_lang" in low or "wp_test_cookie" in low):
            score += 3
            evidence.append("cookie:wordpress")
        if WOO_SESSION_COOKIE in low:
            score += 3
            woo += 3
            evidence.append("cookie:woo-session")
        elif WOO_COOKIE_RE in low:
            score += 3
            woo += 3
            evidence.append("cookie:woo")

    body = body or ""
    low_body = body.lower()
    if any(m in low_body for m in WP_BODY_MARKERS):
        score += 3
        evidence.append("body:wordpress")
    if "name=\"generator\"" in low_body and "wordpress" in low_body:
        score += 2
        evidence.append("body:generator")
    if any(m in low_body for m in WOO_BODY_MARKERS):
        score += 3
        woo += 3
        evidence.append("body:woocommerce")

    if endpoint:
        ctype = hdrs.get("content-type", "").lower()
        is_json = JSON_TYPES in ctype
        if endpoint.startswith("/wp-json/"):
            is_store_api = endpoint.startswith(store_api)
            if status == 200 and is_json and (
                    "routes" in body or "namespaces" in body or is_store_api):
                score += 3
                evidence.append("endpoint:wp-rest")
            # namespace WooCommerce lộ ngay trong REST index (/wp-json/)
            if status == 200 and is_json and any(ns in low_body for ns in WOO_REST_NS_RE):
                score += 3
                woo += 3
                evidence.append("endpoint:woo-rest-ns")
            if is_store_api and status == 200 and is_json:
                score += 3
                woo += 3
                evidence.append("endpoint:woo-store-api")
        elif endpoint == "/wp-login.php":
            if status == 200 and "wp-login" in low_body:
                score += 2
                evidence.append("endpoint:wp-login")
        elif endpoint == "/readme.html":
            if status == 200 and "wordpress" in low_body:
                score += 2
                evidence.append("endpoint:readme")
        elif endpoint in ("/cart/", "/shop/", "/my-account/"):
            if status == 200:
                score += 2
                evidence.append(f"endpoint:{endpoint.strip('/')}")
        elif endpoint.endswith("readme.txt"):
            # readme.txt của plugin WooCommerce: chứng minh plugin CÓ MẶT kể cả khi
            # asset bị gộp/minify không lộ đường dẫn ("Stable tag" còn cho version).
            if status == 200 and "woocommerce" in low_body:
                score += 3
                woo += 3
                evidence.append("endpoint:woo-readme")
            elif status == 200 and ("wordpress" in low_body or "stable tag" in low_body):
                score += 2
                evidence.append("endpoint:plugin-readme")

    return score, woo, evidence


def check_woocommerce(status, headers, body, min_score=DEFAULT_MIN_SCORE):
    """True nếu response đơn lẻ đủ điểm WordPress (tương thích test)."""
    score, _woo, _ev = score_response(status, headers, body)
    return score >= min_score


def _endpoints_from_cfg(cfg):
    wc = cfg.get("woocommerce") or {}
    endpoints = wc.get("endpoints")
    return tuple(endpoints) if endpoints else DEFAULT_ENDPOINTS


def _min_score_from_cfg(cfg):
    wc = cfg.get("woocommerce") or {}
    return int(wc.get("min_score", DEFAULT_MIN_SCORE))


def _store_api_from_cfg(cfg):
    wc = cfg.get("woocommerce") or {}
    return str(wc.get("store_api", WOO_STORE_API_PATH))


def _probe(url, timeout, endpoints, min_score, store_api, deep=True):
    """Probe chi tiết → (url, is_wordpress, is_woocommerce, score, woo, evidence).

    Giữ ĐÚNG chữ ký 5 tham số (test cũ monkeypatch hàm này); `deep` là tham số
    thêm có default nên không phá vỡ contract cũ.

    Trang chủ + endpoint dùng http.fetch_limited (trần byte, cache trang chủ).
    `deep` bật probe "chứng cứ Woo" (/wp-json/wc/store/v1/cart,
    /wp-content/plugins/woocommerce/readme.txt) khi chưa kết luận Woo — chỉ chạy
    khi host đã có tín hiệu WordPress nên không nạp thêm host lạ.
    """
    cache = http.get_page_cache()

    total = 0
    woo_total = 0
    evidence = []

    def visit(path, use_cache=False):
        nonlocal total, woo_total, evidence
        resp = http.fetch_limited(path, timeout=timeout, limit=BODY_LIMIT,
                                  cache=cache if use_cache else None)
        if resp is None:
            return False
        ep = None if path == url else path[len(url):]
        score, woo, ev = score_response(
            resp.status_code, dict(resp.headers), resp.text[:BODY_LIMIT],
            endpoint=ep, store_api=store_api,
        )
        total += score
        woo_total += woo
        evidence.extend(ev)
        return True

    try:
        visit(url, use_cache=True)
        if total >= min_score and woo_total > 0:
            return url, True, True, total, woo_total, evidence
        for ep in tuple(endpoints):
            visit(url + ep)
            if total >= min_score and woo_total > 0:
                return url, True, True, total, woo_total, evidence
        # Chưa đủ kết luận Woo nhưng host CÓ vẻ WordPress → tìm chứng cứ Woo
        # đặc trưng (plugin readme / Store API cart) trước khi loại.
        if deep and total > 0 and woo_total == 0:
            for ep in WOO_DEEP_ENDPOINTS:
                visit(url + ep)
                if total >= min_score and woo_total > 0:
                    break
        return url, total >= min_score, total >= min_score and woo_total > 0, \
            total, woo_total, evidence
    except requests.RequestException:
        return url, False, False, total, woo_total, evidence


def probe(url, timeout, endpoints=DEFAULT_ENDPOINTS, min_score=DEFAULT_MIN_SCORE,
          store_api=WOO_STORE_API_PATH):
    """Contract nhẹ: trả (url, is_wordpress, is_woocommerce)."""
    result = _probe(url, timeout, endpoints, min_score, store_api)
    return result[0], result[1], result[2]


def _scheme_for(host_port):
    return "https" if host_port.endswith(":443") else "http"


def run(hosts, workdir, global_wp, global_woo, cfg):
    """hosts: list 'ip:port' → list URL WooCommerce; append wordpress.txt/woocommerce.txt.

    Trả về (wordpress_urls, woocommerce_urls) — woo là tập con của wordpress.
    """
    timeout = cfg.get("timeout", 15)
    endpoints = _endpoints_from_cfg(cfg)
    min_score = _min_score_from_cfg(cfg)
    store_api = _store_api_from_cfg(cfg)
    urls = [f"{_scheme_for(h)}://{h}" for h in hosts]

    wp_found = set()
    woo_found = set()
    scored = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=cfg.get("threads", 50)) as pool:
        futures = [
            pool.submit(_probe, u, timeout, endpoints, min_score, store_api)
            for u in urls
        ]
        for future in concurrent.futures.as_completed(futures):
            url, is_wp, is_woo, score, woo, evidence = future.result()
            scored.append(f"{url} {score} woo:{woo} {' '.join(evidence)}".strip())
            if is_wp:
                wp_found.add(url)
            if is_woo:
                woo_found.add(url)

    wp_found = file_io.dedupe_sort(wp_found)
    woo_found = file_io.dedupe_sort(woo_found)
    file_io.append_lines(global_wp, wp_found)
    file_io.append_lines(global_woo, woo_found)

    scored_file = os.path.join(workdir, "woo_scored.txt")
    file_io.write_lines(scored_file, file_io.dedupe_sort(scored))
    info(f"stage2a-woo: {len(wp_found)}/{len(urls)} WordPress, "
         f"{len(woo_found)} WooCommerce (min_score={min_score}, "
         f"endpoints={','.join(endpoints) or '-'})")
    return wp_found, woo_found
