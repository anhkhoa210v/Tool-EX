"""STAGE 3-woo: phát hiện CVE WooCommerce/WordPress — 2 lớp (giống cve_scan.py):

  A. OFFLINE (version match) — luôn chạy, không cần nuclei:
     version TỪNG PLUGIN (stage 3-woo) → khớp cves/woo_version_map.yaml
     (core/woo_cve_map.py) → dòng
     "[version] <url> <slug> <version> — khả năng CVE-... [SEV] (name) — dính trong <label>".
     Không gửi request thêm; plugin không rõ version thì không có dòng này.

  B. ONLINE (nuclei) — CÓ THỂ TẮT qua cve.nuclei.enabled:
     template CỘNG ĐỒNG qua -id (woocommerce.community_ids; nếu để trống thì
     lấy toàn bộ CVE có trong woo_version_map.yaml). KHÔNG có template local
     cho Woo (quyết định thiết kế: tránh template viết mù → false positive);
     dùng chung cờ nuclei với Magento (cve.nuclei: concurrency/rate_limit/…).

Dùng lại helper của core/cve_scan.py (nuclei_config/_run_nuclei/_append_vul_hosts/
community_template_ids/_nuclei_flags) để 2 nhánh Magento & Woo hành xử nhất quán.
Findings gộp append vào output/vuln.txt, host dính ghi vào output/vul.txt; riêng
offline ghi work/<slug>/woo_cve_version.txt, nuclei ghi work/<slug>/woo_nuclei.txt.
Hàm nào cũng không raise (an toàn pipeline).
Contract: run(urls, versions, workdir, global_vuln, cfg) → list dòng finding.
"""
import os
import shutil

from core import cve_scan, woo_cve_map
from utils import file_io
from utils.logger import info, warn

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _map_path(cfg):
    """Đường dẫn woo_version_map (cfg.woocommerce.version_map, tương đối → BASE_DIR)."""
    path = (cfg.get("woocommerce") or {}).get("version_map")
    if path and not os.path.isabs(path):
        path = os.path.join(BASE_DIR, path)
    return path


def version_candidates(urls, versions, cfg):
    """(url, {slug: version}) → dòng '[version] ...' cho mỗi plugin dính lỗi."""
    if not versions:
        return []
    plugin_map = woo_cve_map.load_map(_map_path(cfg))
    if not plugin_map:
        return []

    lines = []
    for url in urls:
        host_plugins = versions.get(url) or {}
        for slug, version in host_plugins.items():
            for hit in woo_cve_map.match(slug, version, plugin_map):
                sev = hit["severity"].upper() if hit["severity"] != "n/a" else "n/a"
                name = f" ({hit['name']})" if hit["name"] else ""
                lines.append(
                    f"[version] {url} {slug} {version} — khả năng {hit['cve']} "
                    f"[{sev}]{name} — dính trong {hit['label']}"
                )
    return file_io.dedupe_sort(lines)


def community_ids(cfg):
    """CVE cộng đồng cho Woo: cfg.woocommerce.community_ids, trống → toàn bộ map."""
    ids = [str(cve).strip().upper()
           for cve in ((cfg.get("woocommerce") or {}).get("community_ids") or [])
           if str(cve).strip()]
    if ids:
        return ids
    return sorted(woo_cve_map.all_cves(woo_cve_map.load_map(_map_path(cfg))))


def run(urls, versions, workdir, global_vuln, cfg):
    """urls: list URL WooCommerce; versions: {url: {slug: version}}.

    Trả list dòng finding (offline + nuclei); append vuln.txt + vul.txt.
    """
    if not urls:
        return []
    findings = []

    # A) offline version match — chạy trước, có kết quả kể cả khi thiếu nuclei
    version_lines = version_candidates(urls, versions or {}, cfg)
    if version_lines:
        file_io.append_lines(global_vuln, version_lines)
        file_io.append_lines(os.path.join(workdir, "woo_cve_version.txt"), version_lines)
        findings += version_lines

    ncfg = cve_scan.nuclei_config(cfg)
    if not ncfg["enabled"]:
        info(f"stage3-woo: {len(findings)} findings offline "
             f"(nuclei tắt trong cve.nuclei.enabled)")
        cve_scan._append_vul_hosts(findings, global_vuln)
        return findings
    if shutil.which("nuclei") is None:
        warn("[nuclei] không tìm thấy nuclei — giữ nguyên kết quả version match (woo)")
        info(f"stage3-woo: {len(findings)} findings offline (không có nuclei)")
        cve_scan._append_vul_hosts(findings, global_vuln)
        return findings

    ids = community_ids(cfg)
    if not ids:
        warn("[nuclei] woocommerce.community_ids trống và map rỗng — "
             "giữ nguyên kết quả version match (woo)")
        cve_scan._append_vul_hosts(findings, global_vuln)
        return findings

    targets_file = os.path.join(workdir, "woocommerce.txt")
    file_io.atomic_write(targets_file, "".join(u + "\n" for u in urls))
    out = os.path.join(workdir, "woo_nuclei.txt")
    findings += cve_scan._run_nuclei(targets_file, out, ["-id", ",".join(ids)], cfg)

    findings = file_io.dedupe_sort(findings)
    file_io.append_lines(global_vuln, findings)
    cve_scan._append_vul_hosts(findings, global_vuln)
    info(f"stage3-woo: {len(findings)} findings "
         f"(offline {len(version_lines)} + nuclei "
         f"{max(0, len(findings) - len(version_lines))}, {len(ids)} template id)")
    return findings
