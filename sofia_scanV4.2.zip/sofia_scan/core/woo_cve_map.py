"""Khớp (plugin WooCommerce, version) → CVE offline (không cần nuclei).

Đọc cves/woo_version_map.yaml. Khác Magento (`core/cve_map.py`: MỘT sản phẩm,
nhiều dòng version), WordPress/WooCommerce có NHIỀU plugin, mỗi plugin một
version riêng → khóa theo SLUG plugin, so cặp (slug, version).

Mỗi plugin khai `aliases` (các slug khác cùng plugin: bản free/pro, đổi tên)
và `cves`. Mỗi CVE khai khoảng dính lỗi theo 1 trong 2 cách (kết hợp được):

  below: "X.Y.Z"        # dính khi version < X.Y.Z (X.Y.Z là bản đã vá)
  ranges:               # danh sách khoảng ĐÓNG [lo, hi]
    - ["1.0.0", "1.7.1"]

Dùng `below` khi vendor chỉ công bố bản vá. Dùng `ranges` khi có bản trung
gian đã được backport (tránh false positive). Version plugin parse dạng số
tối đa 4 thành phần (X.Y[.Z[.W]]) — khớp version thật của WordPress
("3.15.0.3", "84.3", "1.12.1"); thiếu thành phần = 0.
"""
import os
import re

import yaml

from utils.logger import warn

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEFAULT_MAP_PATH = os.path.join(BASE_DIR, "cves", "woo_version_map.yaml")

# Version plugin: tối đa 4 nhóm số; rào cản chặn cắt giữa version dài hơn
# (vd "1.2.3.4.5" bị lookahead `(?![0-9.])` loại). Cho phép tiền tố "v".
PLUGIN_VERSION_RE = re.compile(r"(?<![\w.-])(?:v)?(\d+(?:\.\d+){0,3})(?![0-9.])")
CVE_RE = re.compile(r"CVE-\d{4}-\d{4,}$", re.I)
SEVERITIES = ("critical", "high", "medium", "low", "info")


def parse_plugin_version(text):
    """text → tuple số (pad 4 phần) hoặc None nếu không có version hợp lệ.

    Ví dụ: "7.1.8" → (7,1,8,0); "3.15.0.3" → (3,15,0,3); "84.3" → (84,3,0,0).
    """
    if not text:
        return None
    match = PLUGIN_VERSION_RE.search(str(text))
    if not match:
        return None
    parts = [int(p) for p in match.group(1).split(".")]
    parts = (parts + [0, 0, 0, 0])[:4]
    return tuple(parts)


def _valid_cve(cve):
    return bool(CVE_RE.match(str(cve).strip()))


def _norm_severity(text):
    sev = str(text or "").strip().lower()
    return sev if sev in SEVERITIES else "n/a"


def _fmt(v):
    """tuple → 'X.Y[.Z[.W]]' (bỏ .0 thừa ở đuôi) cho báo cáo."""
    parts = list(v)
    while len(parts) > 2 and parts[-1] == 0:
        parts.pop()
    return ".".join(str(p) for p in parts)


def _parse_bound(bound, cve, key):
    parsed = parse_plugin_version(bound)
    if parsed is None:
        warn(f"[woo_cve_map] bỏ qua {key} không hợp lệ {bound!r} ({cve})")
    return parsed


def _load_rule(plugin_slug, plugin, cve, rule):
    """1 CVE rule → dict chuẩn {name, severity, cvss, ranges, below, references}.

    Trả None nếu không có dữ liệu version hợp lệ."""
    if not isinstance(rule, dict):
        warn(f"[woo_cve_map] bỏ qua rule không phải dict: {cve} ({plugin_slug})")
        return None

    ranges = []
    for pair in rule.get("ranges") or []:
        if not isinstance(pair, (list, tuple)) or len(pair) != 2:
            warn(f"[woo_cve_map] bỏ qua range không hợp lệ {pair!r} ({cve})")
            continue
        lo = _parse_bound(str(pair[0]).strip(), cve, "range.lo")
        hi = _parse_bound(str(pair[1]).strip(), cve, "range.hi")
        if lo is None or hi is None:
            continue
        if lo > hi:
            warn(f"[woo_cve_map] range lo > hi {pair} ({cve}) — bỏ qua")
            continue
        ranges.append((lo, hi, f"{_fmt(lo)}..{_fmt(hi)}"))

    below = None
    if rule.get("below") is not None:
        below = _parse_bound(str(rule["below"]).strip(), cve, "below")

    if not ranges and below is None:
        warn(f"[woo_cve_map] {cve} ({plugin_slug}): không có ranges/below hợp lệ "
             f"— bỏ offline match")
        return None

    return {
        "name": str(rule.get("name") or "").strip(),
        "severity": _norm_severity(rule.get("severity")),
        "cvss": rule.get("cvss"),
        "references": rule.get("references") or [],
        "ranges": ranges,
        "below": below,
    }


def load_maps(paths):
    """Nhiều file map → gộp ở mức từng plugin.

    CVE trùng trong cùng plugin: file SAU ghi đè. Plugin trùng tên: gộp cves +
    aliases (file sau thắng khi xung đột). Không bao giờ raise.
    """
    result = {}
    for path in paths or []:
        part = load_map(path)
        for slug, entry in part.items():
            if slug not in result:
                result[slug] = entry
                continue
            merged = result[slug]
            merged["cves"].update(entry["cves"])
            merged["aliases"].update(entry["aliases"])
    return result


def load_map(path=None):
    """path → {slug_chuẩn: {name, aliases: {slug: chuẩn}, cves: {CVE: rule}}}.

    Không bao giờ raise. `aliases` là dict ánh xạ MỌI slug (kể cả chuẩn) → slug chuẩn.
    """
    path = path or DEFAULT_MAP_PATH
    if not os.path.exists(path):
        warn(f"[woo_cve_map] không tìm thấy {path} — bỏ khớp version")
        return {}
    try:
        with open(path, encoding="utf-8") as fh:
            raw = yaml.safe_load(fh) or {}
    except yaml.YAMLError as exc:
        warn(f"[woo_cve_map] lỗi parse YAML {path}: {exc}")
        return {}

    plugins = raw.get("plugins") if isinstance(raw, dict) else None
    if not isinstance(plugins, dict):
        warn(f"[woo_cve_map] {path}: thiếu mapping 'plugins' — bỏ khớp version")
        return {}

    result = {}
    for slug, plugin in plugins.items():
        slug = str(slug).strip().lower()
        if not slug:
            continue
        if not isinstance(plugin, dict):
            warn(f"[woo_cve_map] bỏ qua plugin không phải dict: {slug}")
            continue

        cves = {}
        for cve, rule in (plugin.get("cves") or {}).items():
            cve = str(cve).strip().upper()
            if not _valid_cve(cve):
                warn(f"[woo_cve_map] bỏ qua key không phải CVE-ID: {cve!r}")
                continue
            loaded = _load_rule(slug, plugin, cve, rule)
            if loaded is not None:
                cves[cve] = loaded

        aliases = {slug: slug}
        for alias in plugin.get("aliases") or []:
            alias = str(alias).strip().lower()
            if alias:
                aliases[alias] = slug

        result[slug] = {
            "name": str(plugin.get("name") or slug).strip(),
            "aliases": aliases,
            "cves": cves,
        }
    return result


def resolve_slug(slug, plugin_map):
    """slug bất kỳ → slug chuẩn trong map (tra qua aliases); None nếu không có."""
    if not slug:
        return None
    slug = str(slug).strip().lower()
    for canonical, entry in plugin_map.items():
        if slug in entry["aliases"]:
            return canonical
    return None


def _inside(v, lo, hi):
    return lo <= v <= hi


def match(plugin_slug, version_text, plugin_map=None, map_path=None):
    """(slug, version) → list dict hit {cve, plugin, name, severity, cvss, how, label}.

    how: 'range' | 'below' — lý do khớp (để báo cáo & đối chiếu)."""
    if plugin_map is None:
        plugin_map = load_map(map_path)
    canonical = resolve_slug(plugin_slug, plugin_map)
    if canonical is None:
        return []
    version = parse_plugin_version(version_text)
    if version is None:
        return []

    entry = plugin_map[canonical]
    hits = []
    for cve, rule in entry["cves"].items():
        how = None
        label = None
        for lo, hi, label_text in rule["ranges"]:
            if _inside(version, lo, hi):
                how, label = "range", label_text
                break
        if how is None and rule["below"] is not None and version < rule["below"]:
            how = "below"
            label = f"< {_fmt(rule['below'])} (bản đã vá)"
        if how:
            hits.append({
                "cve": cve,
                "plugin": entry["name"],
                "slug": canonical,
                "name": rule["name"],
                "severity": rule["severity"],
                "cvss": rule["cvss"],
                "how": how,
                "label": label,
            })
    return hits


def match_version_map(versions, plugin_map=None, map_path=None):
    """{slug: version} → list hit (kèm slug + version nguồn)."""
    if plugin_map is None:
        plugin_map = load_map(map_path)
    out = []
    for slug, version in (versions or {}).items():
        for hit in match(slug, version, plugin_map):
            out.append({**hit, "version": version})
    return out


def all_cves(plugin_map=None, map_path=None):
    """Tập CVE-ID có trong map (cho community_ids mặc định / kiểm tra)."""
    if plugin_map is None:
        plugin_map = load_map(map_path)
    cves = set()
    for entry in plugin_map.values():
        cves |= set(entry["cves"].keys())
    return cves
