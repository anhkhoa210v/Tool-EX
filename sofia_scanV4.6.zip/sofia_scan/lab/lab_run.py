#!/usr/bin/env python3
"""Lab driver cho sofia_scan — chạy ĐẦY ĐỦ pipeline trên mock server localhost.

Stage 1 (masscan/zmap) được thay bằng scanner.scan giả trả 3 host mock
(127.0.0.1:18080 Magento / 18081 Woo / 18082 host kiểm soát). Mọi stage sau
(2a fingerprint magento+woo → 2c store_detect → 2b versioning → 3 cve_scan
nuclei → 4 resolver → hook exploit) chạy GIỐNG HỆT production qua Pipeline.

Hook exploit dùng lab/stub_sofia.py (không khai thác thật) để chứng minh
pipeline tự chạy sofia.py sau mỗi batch CIDR.

Chỉ dùng cho mục đích kiểm thử bảo mật được uỷ quyền (lab nội bộ).
"""
import copy
import os
import sys

LAB_DIR = os.path.dirname(os.path.abspath(__file__))
BASE_DIR = os.path.dirname(LAB_DIR)  # …/sofia_scan
sys.path.insert(0, BASE_DIR)
# nuclei cài ở ~/.local/bin
os.environ["PATH"] = os.environ.get("PATH", "") + os.pathsep \
    + os.path.expanduser("~/.local/bin")

HOSTS = ["127.0.0.1:18080", "127.0.0.1:18081", "127.0.0.1:18082"]


def main():
    import main as sofia_main
    from core import scanner
    from core.pipeline import Pipeline
    from utils import file_io

    cfg = copy.deepcopy(sofia_main.DEFAULT_CONFIG)
    out = os.path.join(LAB_DIR, "output")
    cfg["paths"]["output_dir"] = out
    cfg["webhook"] = {"type": "generic", "url": ""}   # không gửi ra ngoài
    cfg["exploit"]["script"] = os.path.join(LAB_DIR, "stub_sofia.py")
    cfg["exploit"]["timeout"] = 120

    # Xoá kết quả lab cũ (resume=false nên work marker không cản, nhưng file
    # append-only như magento.txt/vuln.txt cần sạch để đếm đúng)
    import shutil
    if os.path.isdir(out):
        shutil.rmtree(out)
    os.makedirs(out, exist_ok=True)

    # Thay stage 1: không masscan (máy lab không có raw socket), trả host mock
    def fake_scan(cidr, workdir, live, conf):
        file_io.append_lines(live, HOSTS)
        return list(HOSTS)

    scanner.scan = fake_scan

    # Bật mock server (Magento/Woo/control) trong cùng tiến trình
    import mock_server
    mock_server.start_all()

    info = sofia_main.info
    info("=== LAB bắt đầu — hosts mock: " + ", ".join(HOSTS))
    Pipeline(cfg).run([("127.0.0.1/32", "lab", "XX")], resume=False, total=1)
    info("=== LAB kết thúc")

    # ---- KIỂM CHỨNG KẾT QUẢ ----
    def show(name):
        path = os.path.join(out, name)
        if not os.path.exists(path):
            print(f"[{' '}] {name}: KHÔNG TỒN TẠI")
            return
        with open(path, encoding="utf-8", errors="replace") as fh:
            lines = [l.rstrip("\n") for l in fh if l.strip()]
        print(f"[x] {name}: {len(lines)} dòng")
        for line in lines[:8]:
            print(f"      {line}")

    print("\n===== KIỂM CHỨNG FILE OUTPUT =====")
    for name in ("live.txt", "magento.txt", "wordpress.txt", "woocommerce.txt",
                 "stores.txt", "magento_versions.txt", "vuln.txt",
                 "vuln_version.txt", "vul.txt", "t.txt"):
        show(name)
    show("exploit_state.json")
    stub = os.path.join(out, "stub_sofia_ran.json")
    if not os.path.exists(stub):
        stub = os.path.join(os.path.dirname(os.path.abspath(__file__)), "stub_sofia_ran.json")
    if os.path.exists(stub):
        print("[x] stub_sofia_ran.json (hook exploit ĐÃ tự chạy):")
        print("      " + open(stub, encoding="utf-8").read().replace("\n", "\n      "))
    else:
        print("[ ] stub_sofia_ran.json: hook exploit KHÔNG chạy")
    log = os.path.join(out, "sofia_exploit.log")
    if os.path.exists(log):
        print(f"[x] sofia_exploit.log ({os.path.getsize(log)} bytes)")


if __name__ == "__main__":
    main()
