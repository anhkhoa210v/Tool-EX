#!/usr/bin/env python3
"""Lab mock server cho sofia_scan.

3 "host" giả trên localhost, mỗi port một nền tảng:
  * 18080 — Magento 2.4.6-p3 (cửa hàng thật, dính CVE-2024-34102 /
           CVE-2025-54236 theo cves/version_map.yaml)
  * 18081 — WordPress/WooCommerce (dính CVE-2024-3957 qua readme.txt;
           mock đúng flow CVE-2025-6440 để nuclei local template khớp online)
  * 18082 — host kiểm soát (KHÔNG Magento/Không Woo) — phải bị loại ở stage 2a

Chỉ dùng cho mục đích kiểm thử bảo mật được uỷ quyền (lab nội bộ).
"""
import json
import re
import sys
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

# uniq/fname từ template → nội dung file upload (giả lập wcdp handler)
UPLOADED = {}


def _parse_multipart(body, ctype):
    match = re.search(r"boundary=(.+)", ctype or "")
    if not match:
        return {}
    boundary = ("--" + match.group(1)).encode()
    fields = {}
    for part in body.split(boundary):
        part = part.strip(b"\r\n")
        if not part or part == b"--":
            continue
        if b"\r\n\r\n" not in part:
            continue
        head, _, value = part.partition(b"\r\n\r\n")
        name_match = re.search(rb'name="([^"]+)"', head)
        fname = re.search(rb'filename="([^"]+)"', head)
        key = name_match.group(1).decode() if name_match else ""
        fields[key] = (fname.group(1).decode() if fname else None, value)
    return fields


MAGENTO_HOME = """<!DOCTYPE html><html><head><title>Mock Magento Store</title></head><body>
<script src="/static/frontend/Magento/luma/en_US/requirejs/require.js"></script>
<script type="text/x-magento-init">{"*":{"Magento_Theme/js/view":{}}}</script>
<div class="minicart-wrapper" data-block="minicart"><a class="action showcart"></a></div>
<div class="price-box">99.00</div><form action="/catalogsearch/result/"><input name="q"></form>
<a href="/customer/account/login/">Sign In</a>
<a href="/checkout/cart/">Cart</a>
</body></html>"""

MAGENTO_CART = """<!DOCTYPE html><html><head><title>Shopping Cart</title></head>
<body><div class="minicart-wrapper">empty cart</div><table class="checkout/cart"></table></body></html>"""

MAGENTO_LOGIN = """<!DOCTYPE html><html><head><title>Customer Login</title></head>
<body><form id="login-form" action="/customer/account/loginPost/"></form></body></html>"""

WOO_HOME = """<!DOCTYPE html><html><head>
<meta name="generator" content="WordPress 6.4.2" />
<title>Mock Woo Shop</title></head><body>
<script src="/wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min.js?ver=9.4.2"></script>
<script src="/wp-content/plugins/woocommerce-jetpack/booster.js?ver=7.1.8"></script>
<div class="woocommerce wc-store">products grid</div>
<a href="/cart/">Cart</a> <a href="/shop/">Shop</a> <a href="/my-account/">Account</a>
</body></html>"""

WOO_PAGE = """<!DOCTYPE html><html><head><title>Shop page</title></head>
<body><div class="woocommerce">woocommerce content</div></body></html>"""

WOO_LOGIN = """<!DOCTYPE html><html><head><title>Log In</title></head>
<body><form name="loginform" id="loginform" action="/wp-login.php"></form></body></html>"""

WOO_REST = json.dumps({
    "name": "Mock Woo", "namespaces": ["wc/v1", "wc/v2", "wc/store/v1"],
    "routes": {"/wc/store/v1": {"namespace": "wc/store/v1"},
               "/wp/v2": {"namespace": "wp/v2"}},
})

WOO_PRODUCTS = json.dumps([{"id": 1, "name": "Test Product", "prices": {"price": "9900"}}])
WOO_CART = json.dumps({"items": [], "totals": {"total_items": 0}})


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *_args):  # im lặng
        pass

    def _send(self, code, body, ctype="text/html", extra=None):
        payload = body if isinstance(body, bytes) else body.encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(payload)))
        for key, value in (extra or {}).items():
            self.send_header(key, value)
        self.end_headers()
        self.wfile.write(payload)

    def do_POST(self):
        length = int(self.headers.get("Content-Length") or 0)
        body = self.rfile.read(length) if length else b""
        path = self.path.split("?")[0]
        if self.server.server_address[1] == 18080 and path == "/graphql":
            self._send(200, '{"data":{"storeConfig":{"base_currency_code":"USD"}}}',
                       "application/json")
            return
        if self.server.server_address[1] == 18081 and path == "/wp-admin/admin-ajax.php":
            self._woo_ajax(body, self.headers.get("Content-Type", ""))
            return
        self._send(404, "not found", "text/plain")

    def _woo_ajax(self, body, ctype):
        fields = _parse_multipart(body, ctype)
        action = (fields.get("action") or (None, ""))[1] if "action" in fields else ""
        if isinstance(action, bytes):
            action = action.decode(errors="replace").strip()
        if ctype.startswith("application/x-www-form-urlencoded"):
            from urllib.parse import parse_qs
            qs = parse_qs(body.decode(errors="replace"))
            action = (qs.get("action") or [""])[0]
        if action == "wcdp_save_canvas_design_ajax":
            params = (fields.get("params") or (None, "{}"))[1]
            try:
                meta = json.loads(params.decode(errors="replace"))
            except ValueError:
                meta = {}
            uniq = str(meta.get("uniq", ""))
            files = meta.get("files") or []
            fname = str(files[0].get("name", "x")) if files else "x"
            content = (fields.get("file1") or (None, b""))[1]
            path = f"/wp-content/uploads/wcdp-uploads/temp/{uniq}/{fname}.{meta.get('ext', 'php')}"
            UPLOADED[path] = content.decode(errors="replace")
            self._send(200, json.dumps({"success": True, "data": {"url": path}}),
                       "application/json")
            return
        if action == "wc_upload_nonce":
            self._send(200, json.dumps({"success": True, "nonce": "abcdef123456"}),
                       "application/json")
            return
        if action == "dnd_codedropz_upload_chunks_wc":
            chunk = fields.get("chunks-file") or (None, b"")
            fname = (chunk[0] or "x.php").rsplit(".", 1)[0]
            self._send(200, json.dumps({"success": True,
                                        "data": {"path": f"temp/{fname}",
                                                 "file": fname + ".php"}}),
                       "application/json")
            return
        self._send(400, "unknown action", "text/plain")

    def do_GET(self):
        port = self.server.server_address[1]
        path = self.path.split("?")[0]
        if path in UPLOADED:
            self._send(200, UPLOADED[path], "text/plain")
            return
        if port == 18080:
            self._magento(path)
        elif port == 18081:
            self._woo(path)
        else:
            if path == "/":
                self._send(200, "<html><body>Hello World</body></html>")
            else:
                self._send(404, "not found", "text/plain")

    def _magento(self, path):
        extra = {"X-Magento-Tags": "store,cms_page",
                 "Set-Cookie": "private_content_version=abc123; path=/"}
        if path == "/":
            self._send(200, MAGENTO_HOME, extra=extra)
        elif path == "/magento_version":
            self._send(200, "Magento/2.4.6-p3", "text/plain")
        elif path == "/static/version/":
            self._send(200, '{"version":"2.4.6-p3"}', "application/json")
        elif path == "/rest/V1/directory/countries":
            self._send(200, '[{"id":"US"}]', "application/json")
        elif path == "/rest/V1/store/storeConfigs":
            self._send(200, '{"store_code":"default"}', "application/json")
        elif path == "/customer/section/load/":
            self._send(200, '{"sections":{}}', "application/json")
        elif path == "/checkout/cart/":
            self._send(200, MAGENTO_CART, extra=extra)
        elif path == "/customer/account/login/":
            self._send(200, MAGENTO_LOGIN, extra=extra)
        else:
            self._send(404, "not found", "text/plain")

    def _woo(self, path):
        if path == "/":
            self._send(200, WOO_HOME, extra={
                "X-Powered-By": "WordPress",
                "Link": '<http://127.0.0.1:18081/wp-json/>; rel="https://api.w.org/"',
                "Set-Cookie": "wp_woocommerce_session_abc=hash; path=/"})
        elif path == "/wp-login.php":
            self._send(200, WOO_LOGIN)
        elif path == "/wp-json/":
            self._send(200, WOO_REST, "application/json")
        elif path == "/wp-json/wc/store/v1/products":
            self._send(200, WOO_PRODUCTS, "application/json")
        elif path == "/wp-json/wc/store/v1/cart":
            self._send(200, WOO_CART, "application/json")
        elif path == "/wp-content/plugins/woocommerce-jetpack/readme.txt":
            self._send(200, "=== Booster for WooCommerce ===\nStable tag: 7.1.8\n",
                       "text/plain")
        elif path == "/wp-content/plugins/woocommerce/readme.txt":
            self._send(200, "=== WooCommerce ===\nStable tag: 9.4.2\n", "text/plain")
        elif path == "/readme.html":
            self._send(200, "<html><body>Semantic Version 6.4.2<br /> WordPress</body></html>")
        elif path in ("/cart/", "/shop/", "/my-account/"):
            self._send(200, WOO_PAGE)
        else:
            self._send(404, "not found", "text/plain")


def serve(port):
    server = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    return server


def start_all():
    servers = [serve(p) for p in (18080, 18081, 18082)]
    print("mock servers: magento=18080 woo=18081 control=18082", flush=True)
    return servers


if __name__ == "__main__":
    start_all()
    try:
        threading.Event().wait()
    except KeyboardInterrupt:
        sys.exit(0)
