#!/usr/bin/env python3
"""Stub thay thế sofia/sofia.py trong lab — KHÔNG khai thác thật.

Chỉ ghi nhận lệnh hook gọi (argv) + số dòng target được nạp để chứng minh
pipeline tự chạy sofia.py sau MỖI batch (CIDR). Kết quả ghi ra file JSON
bên cạnh (đường dẫn tuyệt đối, hook chạy với cwd = thư mục chứa stub).
"""
import json
import os
import sys
import time

out = {
    "time": time.strftime("%Y-%m-%d %H:%M:%S"),
    "argv": sys.argv[1:],
    "cwd": os.getcwd(),
    "targets": [],
}
if len(sys.argv) >= 3 and sys.argv[1] == "-t":
    path = sys.argv[2]
    try:
        with open(path, encoding="utf-8", errors="replace") as fh:
            out["targets"] = [line.strip() for line in fh
                              if line.strip() and not line.strip().startswith("#")]
    except OSError as exc:
        out["error"] = str(exc)

json.dump(out, open("stub_sofia_ran.json", "w"), indent=2)
print(f"STUB sofia.py ran: -t {out['argv'][1] if len(out['argv']) > 1 else '?'} "
      f"({len(out['targets'])} targets)")
