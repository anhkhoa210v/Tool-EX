# sofia-sqli

Automated **SQL injection discovery and verification** pipeline.

It dorks Google / Bing / DuckDuckGo and queries the **urlscan.io** API to collect
candidate URLs, persists them to `config/targets.txt`, discovers injectable
parameters, pre-screens with a fast heuristic detector, then **confirms every
finding with sqlmap** and posts a rich **Discord embed** in the requested format:

```
Domain | He Quan Tri Du Lieu + phien ban | Ten 3 bang trong database | vi tri bi injection
```

---

## Pipeline

| Step | Module | What it does |
|------|--------|--------------|
| 1. Discovery | `core/crawler.py` | Dork search (Google/Bing/DuckDuckGo) + urlscan.io search API |
| 2. Persist | `main.py` | Appends de-duplicated URLs to `config/targets.txt` |
| 3. Normalise | `core/param_discovery.py` | Builds `Target` objects, discovers GET/POST params, light page crawl |
| 4. Heuristic | `core/sqli_detector.py` | Error-based / boolean-based / time-based pre-screen |
| 5. Verify | `core/exploit.py` + `core/parser.py` | Runs sqlmap (`--dbs --banner`, then `-D <db> --tables`) and parses DBMS, version, databases, tables, injection points |
| 6. Report | `core/reporter.py` | Posts a Discord embed (retry-aware, 429-safe) |

---

## Install

```bash
cd sofia-sqli
python3 -m pip install -r requirements.txt

# sqlmap is required for the verification step
python3 -m pip install sqlmap          # pip install method
# or
sudo apt install sqlmap                # distro package
# or clone: git clone https://github.com/sqlmapproject/sqlmap
```

Verify:

```bash
sqlmap --version
python3 main.py --help
```

---

## Configuration

Edit `config/settings.yaml`:

* `general.threads` – worker pool size (multi-threaded).
* `general.retries`, `retry_backoff` – per-request retry policy.
* `general.parallel_discovery` – run dork / urlscan / wayback / commoncrawl
  concurrently (each keeps its own rate limiter and a crashed source is
  isolated from the rest of the run).
* `general.smart_dedupe` – collapse URLs that differ only in parameter values
  (`product.php?id=1` vs `?id=2`) into the best-scoring representative per
  (host, path, param-names) key. Saves sqlmap budget and reduces noise.
* `dork.max_auto_queries` – how many auto-rotated dorks are added per run
  (the pool is much larger now; rotation keeps SERP results fresh).
* `dork.engines` – which search engines to use.
* `dork.queries` – the dork list.
* `urlscan.queries` – urlscan.io search queries.
* `param_discovery.*` – step-3 parameter discovery: `enabled` (allow the light
  page crawl for targets without parameters), `max_links` (links scanned per
  page), `crawl_timeout` (0 = `general.timeout`), `user_agent` (empty =
  `general.user_agent`), `max_params` (cap candidate parameters, interesting
  ones first; 0 = unlimited) and `extra_param_names` (extra parameter names
  treated as injection-prone by `rank_params`).
* `sqli.*` – sqlmap level/risk/technique/tamper/threads/timeout, plus
  `random_agent` (`--random-agent`), `parse_errors` (`--parse-errors`),
  `flush_session` (`--flush-session`, clears stale sqlmap session cache) and
  `extra_args` (extra sqlmap tokens, list or whitespace-separated string).
* `sqli.blocked_statuses` – status codes treated as a block by the detector's
  blanket-block check (default `403/406/429`).
* `discord.webhook_url` – your webhook (**or** set `SOFIA_DISCORD_WEBHOOK`).

Environment overrides:

| Variable | Effect |
|----------|--------|
| `SOFIA_DISCORD_WEBHOOK` | Discord webhook URL |
| `SOFIA_SQLMAP_PATH` | Path to the sqlmap binary |
| `SOFIA_THREADS` | Worker thread count |

---

## targets.txt format

```text
# GET target with params
https://example.com/product.php?id=1

# POST target: "POST <url> [k=v&k2=v2]"
POST https://example.com/login [username=admin&password=test]

# Optional per-target headers on the following line
HEADERS: Cookie: sess=abc; X-Custom: 1
```

Crawler output is appended automatically under a timestamped comment block.

---

## Usage

```bash
# Full run: dork + urlscan + verify + report
python3 main.py

# Verify only existing targets (skip discovery)
python3 main.py --only-verify

# Single ad-hoc target (GET)
python3 main.py --url "http://testphp.vulnweb.com/artists.php?artist=1"

# Single ad-hoc target (POST)
python3 main.py --url "http://site/login" --data "user=admin&pass=1"

# 12 workers, custom webhook, verbose
python3 main.py --threads 12 --webhook "https://discord.com/api/webhooks/xxx/yyy" -v

# Discovery only (no sqlmap, no webhook)
python3 main.py --dry-run

# Skip only dork, keep urlscan
python3 main.py --no-dork
```

### Full flag list

| Flag | Purpose |
|------|---------|
| `-c, --config` | Path to `settings.yaml` |
| `-t, --targets` | Path to `targets.txt` |
| `--url`, `--data` | Ad-hoc GET/POST target |
| `--threads` | Override worker count |
| `--webhook` | Override Discord webhook |
| `--only-verify` | Skip dork + urlscan |
| `--no-dork` / `--no-urlscan` | Disable one discovery source |
| `--no-wayback` / `--no-commoncrawl` | Disable one discovery source |
| `--no-rank` | Keep targets.txt order (no ranking) |
| `--no-smart-dedupe` | Keep value-variant duplicates of the same endpoint |
| `--force-sqlmap` | Run sqlmap even without a heuristic signal |
| `--no-tables` | Skip table enumeration |
| `--no-report` | Never post to Discord |
| `--dry-run` | Discovery only, no sqlmap |
| `-v, --verbose` | DEBUG logging |

---

## Discord embed layout

Each confirmed finding becomes one embed:

* **Title / URL** – `SQL Injection Confirmed` + target link
* **Description** – the exact report line:
  `Domain | DBMS+version | table1, table2, table3 | GET parameter 'id'`
* **Fields** – Domain, DBMS + Version, Injection Point, Tables (top 3),
  Technique, Stack, Context (db/user), Payload sample, Note
* **Footer** – `sofia-sqli | verified by sqlmap`

A run summary message is posted at the end.

---

## Output artifacts (`results/`)

* `<host>_detect.txt` – raw sqlmap stdout/stderr for the detect phase.
* `<host>_tables.txt` – raw sqlmap output for the table-enumeration phase.
* `<host>_finding.json` – structured finding (DBMS, tables, injection points…).
* `sofia-sqli.log` – full run log.

---

## Testing

The test suite covers the heuristic detector, sqlmap parser, reporter,
target parsing/ranking and the full pipeline with an in-process fixture
server (43 tests):

```bash
python3 -m pytest tests/ -v
```

The SQLi fixture lives in `tests/fixture_sqli_server.py`. pytest runs it
in-process; you can also start it standalone (it binds `127.0.0.1:8899`):

```bash
python3 tests/fixture_sqli_server.py
# fixture server on http://127.0.0.1:8899/  (Ctrl+C to stop)
```

Endpoints:

| Endpoint | SQLi vector | Behaviour |
|----------|-------------|-----------|
| `/product.php?id=1` | GET `id` concatenated into SQL | error + boolean + time + UNION |
| `/post.php` | POST body `user` concatenated into SQL | error + boolean + time (POST SQLi) |
| `/log.php` | `User-Agent` concatenated into an INSERT, rendered back | quote -> error, `SLEEP(x)` -> delay |
| `/noisy.php?id=1` | GET SQLi with per-request nonces | boolean-similarity training ground |
| `/safe.php?id=1` | parameterized control | must stay clean |
| `/waf.php?id=1` | Cloudflare-like edge simulation | blocks hostile probes with 403 |
| `/cf-soft.php?id=1` | passive-only Cloudflare fingerprints, injectable | WAF detected but not blocked |

Time primitives are simulated: any injected value containing `SLEEP(x)`,
`pg_sleep(x)`, `WAITFOR DELAY '0:0:x'`, `dbms_pipe.receive_message(...,x)`
or `randomblob(x00000000)` stalls the handler ~x seconds (capped at 8s),
which lets the multi-DBMS time probes run deterministically.

The fixture database (SQLite) has three tables: `products`, `users`,
`access_log`.

---

## E2E local test (against the fixture server)

With the fixture server running on `127.0.0.1:8899`, the whole pipeline can
be exercised end-to-end without touching the internet:

```bash
# 1) start the fixture server in a second terminal
python3 tests/fixture_sqli_server.py

# 2) pipeline, GET target (--only-verify skips dork/urlscan; --no-report skips Discord)
python3 main.py --url "http://127.0.0.1:8899/product.php?id=1" \
    --only-verify --no-report -v

# 3) pipeline, POST target (targets.txt line syntax via --url)
python3 main.py --url "POST http://127.0.0.1:8899/post.php [user=1&pass=x]" \
    --only-verify --no-report -v

# 4) direct sqlmap with the same flags the pipeline uses (settings.yaml: sqli.*)
sqlmap -u "http://127.0.0.1:8899/product.php?id=1" --batch --level=2 --risk=1 \
    --technique=BEUST --dbs --banner --parse-errors --tables
```

Expected results (verified):

* GET run – heuristic signal `error-based, boolean-based`, then:
  `CONFIRMED injection on 127.0.0.1:8899: SQLite 3.9` and the report line
  `[VULN] 127.0.0.1:8899 | SQLite 3.9 | access_log, products, users | GET parameter 'id'`.
* POST run – heuristic signal on param `user`, then
  `[VULN] 127.0.0.1:8899 | SQLite 3.9 | access_log, products, users | POST parameter 'user'`.
* Direct sqlmap – 5 injection types on `id` (boolean-based blind, error-based,
  stacked queries, time-based blind, UNION query), `banner: '3.45.1'`
  (the local SQLite library version) and the 3 fixture tables.

> **Stale sqlmap session cache**: sqlmap caches per-URL session data under
> `~/.local/share/sqlmap/output/<host>/`. If the same URL is re-pointed at a
> different backend (e.g. the fixture server replaced by another app on the
> same port), re-runs can replay stale table lists. Either clear the cache
> (`rm -rf ~/.local/share/sqlmap/output/<host>`) or set
> `sqli.flush_session: true` in `config/settings.yaml` (the pipeline then adds
> `--flush-session` to every sqlmap invocation).

---

## Notes on reliability

* **Multi-threading**: each target is processed by a worker; sqlmap runs as an
  isolated subprocess per target.
* **Retry**: all HTTP calls use exponential backoff + jitter; Discord honours
  `429 retry_after`.
* **False-positive control**: sqlmap is the source of truth. Heuristics only
  decide whether it is worth invoking sqlmap (`--force-sqlmap` disables that).
* **WAF awareness**: the detector flags blanket 403/406/429 or challenge pages
  and reports them instead of producing noise.

---

## Legal

Use only against systems you are explicitly authorized to test.
