"""Target discovery via search-engine dorking, urlscan.io, Wayback and Common Crawl.

Responsibilities
----------------
1. Query Google / Bing / DuckDuckGo / Mojeek for dorked pages (URLs with query params).
   Engine x query combinations run concurrently with a shared rate limiter.
2. Query the urlscan.io search API for URLs that look like SQLi candidates.
3. Query the Wayback Machine CDX API for historical URLs with parameters.
4. Optionally query the Common Crawl index for parameterised URLs.
5. Normalise, dedupe, filter, score and rank candidate targets.

The crawler only *collects* candidate URLs. Verification (heuristics + sqlmap)
happens later in the pipeline. All network calls honour a shared rate limiter
and retry policy, and every engine failure is isolated from the others.
"""

from __future__ import annotations

import base64
import html
import json
import random
import re
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from typing import Iterable
from urllib.parse import parse_qsl, unquote, urlparse, urlunparse

import requests
from bs4 import BeautifulSoup

from utils.logger import get_logger
from utils.rate_limit import JitteredBackoff, RateLimiter, retry

log = get_logger("sofia-sqli.crawler")

_URL_RE = re.compile(r"https?://[^\s\"'<>\\]+", re.IGNORECASE)
_GOOGLE_REDIRECT_RE = re.compile(r"/url\?.*?(?:q|url)=([^&]+)", re.IGNORECASE)
# Bing wraps every SERP result in /ck/a?...&u=a1<base64url-of-real-url>
_BING_REDIRECT_RE = re.compile(r"[?&]u=a1([A-Za-z0-9_\-=]+)")
# DuckDuckGo's html endpoint uses //duckduckgo.com/l/?uddg=<urlencoded-real-url>
_DDG_REDIRECT_RE = re.compile(r"[?&]uddg=([^&]+)")

# Suffixes that are never useful targets (search engine internals, assets...).
_BLACKLIST_HOSTS = (
    "google.", "bing.", "duckduckgo.", "microsoft.", "youtube.", "facebook.",
    "twitter.", "x.com", "instagram.", "linkedin.", "pinterest.", "wikipedia.",
    "urlscan.io", "cloudflare.", "gstatic.", "googleusercontent.",
    "mojeek.", "startpage.", "ecosia.", "yandex.", "yahoo.", "baidu.",
    "github.com", "gitlab.com", "stackoverflow.", "stackexchange.",
    "amazon.", "ebay.", "aliexpress.", "etsy.", "medium.", "reddit.",
    "tiktok.", "discord.", "telegram.", "w3.org", "archive.org",
    "commoncrawl.org", "web.archive.org", "npmjs.", "pypi.", "docker.",
)

# Static asset extensions that can never carry injectable parameters.
_ASSET_EXT_RE = re.compile(
    r"\.(css|js|mjs|json|xml|rss|svg|png|jpe?g|gif|webp|avif|ico|bmp|woff2?|"
    r"ttf|eot|otf|mp[34]|m4a|ogg|wav|avi|mov|webm|mkv|pdf|zip|gz|tar|rar|7z|"
    r"exe|dmg|apk|iso|csv|xls x?|docx?|pptx?)(\?|$)",
    re.IGNORECASE,
)

# Tracking / analytics parameters that carry no injection surface.
_JUNK_PARAM_RE = re.compile(
    r"^(?:utm_[a-z0-9_]*|gclid|fbclid|yclid|_ga|_gl|mc_[ce][a-z0-9_]*|msclkid|"
    r"igshid|ref_?src|spm|track[a-z0-9_]*|trk[a-z0-9_]*|pk_[a-z0-9_]*|"
    r"mtm_[a-z0-9_]*|hsa_[a-z0-9_]*|vero_[a-z0-9_]*|oly_[a-z0-9_]*|nnse|"
    r"__hstc|__hssc|__hsfp|fb_action[a-z0-9_]*|fb_source|action_object_map|"
    r"action_type_map|action_ref_map|campaign[a-z0-9_]*|promo[a-z0-9_]*|"
    r"affiliate[a-z0-9_]*|phpsessid|jsessionid|aspsessionid[a-z0-9_]*|"
    r"sessionid|csrf|_csrf|_token|token)$",
    re.IGNORECASE,
)

# Param names that historically correlate with SQL injection sinks.
_INTERESTING_PARAM_RE = re.compile(
    r"(^|_|\b)(id|pid|uid|sid|nid|cid|cat|category|prod|product|item|news|page|"
    r"p|article|view|doc|file|folder|dir|path|key|search|q|query|user|account|"
    r"order|sort|filter|sel|select|lang|code|num|no|ref|report|menu|mod|"
    r"tid|aid|gid|uid2?|emp|record|listing|info|detail|artist|game|topic|"
    r"thread|forum|member|profile|brand|shop|store|type|year|month|week|"
    r"day|email|name|title|keyword|tag|label|level|group|section|content|"
    r"row|col|column|table|db|field|value|action|cmd|exec|run|show|get|"
    r"load|include|read|write|delete|update|edit|add|insert|remove)($|_|\b)",
    re.IGNORECASE,
)

# Numeric-looking parameter values suggest a classic primary-key sink.
_NUMERIC_VALUE_RE = re.compile(r"^\d{1,12}$")

# File extensions that are classic SQLi surfaces.
_SINK_EXT_RE = re.compile(
    r"\.(php[345]?|asp|aspx|jsp|jspx|cfm|cgi|pl|py|rb|do|action|shtml)(\?|$)",
    re.IGNORECASE,
)

# Engine block / CAPTCHA fingerprints. When one of these shows up the engine
# is marked throttled instead of quietly returning zero results.
_BLOCK_MARKERS = (
    "unusual traffic from your computer network",
    "our systems have detected unusual traffic",
    "recaptcha",
    "are you a robot",
    "verify you are a human",
    "sorry, this page has been blocked",
    "access denied",
    "request unsuccessful. incapsula",
    "attention required! | cloudflare",
    "just a moment...",
    "pardon our interruption",
    "one more step",
    "checking your browser",
    "you have been blocked",
    "too many requests",
    "cyber protection",
)


def _looks_blocked(text: str) -> bool:
    """Heuristically decide whether a fetched SERP page is a CAPTCHA/block wall."""
    if not text:
        return False
    low = html.unescape(text[:20000]).lower()
    return any(m in low for m in _BLOCK_MARKERS)


@dataclass
class DiscoveryResult:
    """Container for discovered candidate URLs."""

    urls: list[str] = field(default_factory=list)
    stats: dict[str, int] = field(default_factory=dict)
    throttled: list[str] = field(default_factory=list)

    def extend(self, items: Iterable[str]) -> None:
        self.urls.extend(items)


def _unwrap_engine_redirect(url: str) -> str:
    """Resolve search-engine link wrappers to the real destination URL.

    Handles Bing's ``/ck/a?...&u=a1<base64url>`` and DuckDuckGo's
    ``/l/?uddg=<urlencoded>`` wrappers. Returns ``url`` unchanged when the
    input is not a recognised wrapper or the payload cannot be decoded.
    """
    if not url:
        return url
    low = url.lower()

    if "/ck/a" in low:
        m = _BING_REDIRECT_RE.search(url)
        if m:
            blob = m.group(1) + "=" * (-len(m.group(1)) % 4)
            try:
                decoded = base64.urlsafe_b64decode(blob).decode("utf-8", "replace")
                if decoded.lower().startswith(("http://", "https://")):
                    return decoded
            except Exception:  # noqa: BLE001 - base64 junk, keep original
                pass

    if "/l/?" in low or "uddg=" in low:
        m = _DDG_REDIRECT_RE.search(url)
        if m:
            decoded = unquote(m.group(1))
            if decoded.lower().startswith(("http://", "https://")):
                return decoded

    return url


def _clean_url(url: str) -> str | None:
    """Normalise a candidate URL, dropping tracking junk."""
    if not url:
        return None
    url = _unwrap_engine_redirect(url.strip())
    if not url.lower().startswith(("http://", "https://")):
        if url.startswith("//"):
            url = "https:" + url
        else:
            return None

    try:
        parts = urlparse(url)
    except ValueError:
        return None
    if not parts.scheme or not parts.netloc:
        return None

    query = parts.query
    if query:
        try:
            qpairs = parse_qsl(query, keep_blank_values=True)
        except ValueError:
            qpairs = []
        keep = [(k, v) for k, v in qpairs
                if not _JUNK_PARAM_RE.match(k)]
        query = "&".join(f"{k}={v}" for k, v in keep)
        if not keep:
            return None

    return urlunparse((parts.scheme, parts.netloc, parts.path, parts.params, query, ""))


def _has_query_params(url: str) -> bool:
    try:
        return bool(parse_qsl(urlparse(url).query, keep_blank_values=True))
    except ValueError:
        return False


def dedupe_key(url: str) -> str | None:
    """Build a smart-dedupe key: (host, path, sorted param names).

    Collapses value-only variants of the same endpoint (``product.php?id=1``
    vs ``product.php?id=2``) so the pipeline spends its sqlmap budget on
    *distinct sinks* instead of dozens of copies of the same endpoint.
    """
    try:
        parts = urlparse(url)
        qpairs = parse_qsl(parts.query, keep_blank_values=True)
    except ValueError:
        return None
    # Tracking junk must not make two copies of the same endpoint look distinct.
    names = sorted(k.lower() for k, _ in qpairs if not _JUNK_PARAM_RE.match(k))
    if not parts.netloc:
        return None
    host = parts.netloc.lower().removeprefix("www.")
    path = parts.path.rstrip("/") or "/"
    return f"{host}{path}?{','.join(names)}"


def smart_dedupe_urls(urls: Iterable[str]) -> list[str]:
    """Dedupe URLs by (host, path, param-names), keeping the best-scoring one."""
    best: dict[str, tuple[int, str]] = {}
    for url in urls:
        key = dedupe_key(url)
        if key is None:
            # Unparseable URLs are dropped entirely - they never test well.
            continue
        s = score_url(url)
        cur = best.get(key)
        if cur is None or s > cur[0] or (s == cur[0] and url < cur[1]):
            best[key] = (s, url)
    return [u for _, u in sorted(best.values(), key=lambda t: (-t[0], t[1]))]


def score_url(url: str) -> int:
    """Score how promising a candidate URL is for SQL injection testing.

    Higher is better. The ranking is heuristic only - every surviving URL is
    still tested downstream - but the pipeline spends its sqlmap budget on the
    most promising candidates first.
    """
    score = 0
    try:
        parts = urlparse(url)
        query = parts.query
        path = parts.path or ""
    except ValueError:
        return 0
    if not query:
        return 0

    try:
        pairs = parse_qsl(query, keep_blank_values=True)
    except ValueError:
        return 0
    if not pairs:
        return 0

    interesting = 0
    numeric = 0
    for name, value in pairs:
        if _INTERESTING_PARAM_RE.search(name):
            interesting += 1
        if _NUMERIC_VALUE_RE.match(value or ""):
            numeric += 1
    score += min(6, interesting * 2)
    score += min(3, numeric)

    if _SINK_EXT_RE.search(path + "?"):
        score += 4
    # Classic extensionless frameworks are less common sinks but still valid.
    if path.count("/") <= 2:
        score += 1
    # Prefer a small number of parameters (focused endpoints).
    if 1 <= len(pairs) <= 3:
        score += 1
    elif len(pairs) > 8:
        score -= 1
    # Very long URLs are usually session-carrying noise.
    if len(url) > 300:
        score -= 2
    return max(score, 0)


class DorkCrawler:
    """Collect candidate SQLi targets from search engines and archive APIs."""

    _SERP_BUILDERS = {
        "google": "https://www.google.com/search?q={q}&num={n}&start={start}&hl=en",
        "bing": "https://www.bing.com/search?q={q}&count={n}&first={start}",
        "duckduckgo": "https://html.duckduckgo.com/html/?q={q}&s={start}",
        "ddglite": "https://lite.duckduckgo.com/lite/?q={q}&s={start}",
        "mojeek": "https://www.mojeek.com/search?q={q}&s={start}",
        "startpage": "https://www.startpage.com/sp/search?query={q}",
        "yandex": "https://yandex.com/search/?text={q}&p={pg}",
    }
    _PAGINATED = {"google", "bing", "duckduckgo", "ddglite", "mojeek"}

    # Dork fragments auto-generated on top of the configured queries so the
    # dork list stays fresh without manual edits.
    _AUTO_PARAM_FRAGMENTS = (
        # classic primary-key sinks
        "id", "pid", "cid", "tid", "aid", "bid", "sid", "nid", "eid", "uid",
        "mid", "rid", "kid", "xid", "uid2",
        # e-commerce / catalog
        "cat", "category", "catid", "prod", "product", "productid", "item",
        "itemid", "sku", "brand", "shop", "store", "listing",
        # content / CMS
        "news", "newsid", "article", "artid", "post", "postid", "blog",
        "page", "pageid", "view", "content", "contentid", "section",
        "topic", "thread", "forum", "member", "profile", "comment",
        # files / downloads
        "doc", "document", "file", "fileid", "download", "attachment", "media",
        # misc classic sinks
        "user", "userid", "info", "detail", "record", "recid", "event",
        "album", "photo", "gallery", "video", "song", "game", "recipe",
        "staff", "emp", "empid", "order", "invoice", "booking", "hotel",
        "tour", "property", "estate", "car", "vehicle", "job", "course",
        "lesson", "exam", "question", "answer", "poll", "survey", "vote",
        "lang", "year", "month", "week", "day", "date", "keyword", "search",
        "query", "q", "s", "text", "name", "title", "code", "ref", "no",
        "num", "val", "value", "key", "type", "status", "action", "task",
        "cmd", "mode", "do", "go", "show", "get", "load", "read",
    )

    _AUTO_EXTENSIONS = (".php", ".asp", ".aspx", ".jsp", ".cfm",
                        ".cgi", ".pl", ".py", ".do", ".action", ".shtml")

    # Dork operators auto-rotated on top of the base pattern so each run pulls
    # a different slice of the search space (reduces SERP staleness/blocks).
    _AUTO_PATTERNS = (
        'inurl:"{ext}?{param}="',          # URL path contains ext?param=
        'intitle:"{ext}?{param}="',        # title leaks the raw script URL
        'inurl:"{ext}?id=" intitle:"index of"',
    )
    _AUTO_PATTERN_DEFAULT = 'inurl:"{ext}?{param}="'

    def __init__(self, cfg: dict, session: requests.Session | None = None):
        self.cfg = cfg or {}
        gen = self.cfg.get("general", {}) or {}
        dork = self.cfg.get("dork", {}) or {}
        uscan = self.cfg.get("urlscan", {}) or {}
        wayb = self.cfg.get("wayback", {}) or {}
        ccol = self.cfg.get("commoncrawl", {}) or {}

        self.dork = dork
        self.urlscan = uscan
        self.wayback = wayb
        self.commoncrawl = ccol
        self.timeout = float(gen.get("timeout", 20))
        self.retries = int(gen.get("retries", 3))
        self.user_agent = gen.get(
            "user_agent",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Chrome/124.0 Safari/537.36",
        )
        self.threads = max(1, int(gen.get("discovery_threads", gen.get("threads", 5))))
        self.max_targets = int(gen.get("max_targets", 0) or 0)

        self.dork_limiter = RateLimiter(
            min_interval=float(dork.get("min_interval", 2.0)),
            max_per_window=dork.get("max_per_window") or None,
            window=float(dork.get("window", 60)),
        )
        self.urlscan_limiter = RateLimiter(
            min_interval=float(uscan.get("min_interval", 1.5)),
        )
        self.wayback_limiter = RateLimiter(
            min_interval=float(wayb.get("min_interval", 1.0)),
        )
        self.cc_limiter = RateLimiter(
            min_interval=float(ccol.get("min_interval", 2.0)),
        )
        self.backoff = JitteredBackoff(base=float(gen.get("retry_backoff", 1.5)))

        self.session = session or requests.Session()
        self.session.headers.update({
            "User-Agent": self.user_agent,
            "Accept-Language": "en-US,en;q=0.9",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        })
        self._lock = threading.Lock()
        self._seen: set[str] = set()
        self._throttled: set[str] = set()

    # ------------------------------------------------------------------ HTTP
    def _get(self, url: str, *, params: dict | None = None,
             headers: dict | None = None, limiter: RateLimiter | None = None,
             retries: int | None = None) -> requests.Response:
        limiter = limiter or self.dork_limiter

        @retry(retries=self.retries if retries is None else retries,
               exceptions=(requests.RequestException,), backoff=self.backoff)
        def _do() -> requests.Response:
            limiter.acquire()
            resp = self.session.get(url, params=params, headers=headers, timeout=self.timeout)
            if resp.status_code in (429, 503):
                raise requests.RequestException(f"HTTP {resp.status_code} (throttled)")
            resp.raise_for_status()
            return resp

        return _do()

    # ------------------------------------------------------------- SERP parse
    @staticmethod
    def _extract_links_from_html(text: str) -> list[str]:
        """Best-effort, engine-agnostic link extraction from a SERP page."""
        found: list[str] = []
        try:
            soup = BeautifulSoup(text, "lxml")
        except Exception:  # noqa: BLE001
            soup = BeautifulSoup(text, "html.parser")

        # Bing / generic result anchors.
        for a in soup.find_all("a", href=True):
            href = a["href"]
            if href.startswith("/url?"):
                m = _GOOGLE_REDIRECT_RE.search(href)
                if m:
                    found.append(unquote(m.group(1)))
                continue
            if href.startswith("http") or href.startswith("//"):
                found.append(_unwrap_engine_redirect(
                    href if href.startswith("http") else "https:" + href))

        # DuckDuckGo sometimes emits redirect links.
        for a in soup.select("a.result__a, a.result__url, a[data-testid='result-title-a']"):
            if a.get("href"):
                found.append(_unwrap_engine_redirect(a["href"]))

        # Raw regex fallback for anything the DOM parser missed.
        if len(found) < 3:
            found.extend(_URL_RE.findall(text))
        return found

    def _dork_engine(self, engine: str, query: str) -> list[str]:
        """Run one dork query against one engine; returns cleaned URLs."""
        engine = engine.lower().strip()
        builder = self._SERP_BUILDERS.get(engine)
        if not builder:
            log.warning("Unknown dork engine '%s' - skipped", engine)
            return []

        per_query = int(self.dork.get("max_results_per_query", 25))
        collected: list[str] = []
        pages = max(1, (per_query + 9) // 10)  # ~10 results per SERP page

        for page in range(pages):
            start = page * 10
            if engine == "yandex":
                url = builder.format(q=requests.utils.quote(query), pg=page)
            else:
                url = builder.format(q=requests.utils.quote(query), n=per_query, start=start)
            try:
                resp = self._get(url)
            except Exception as exc:  # noqa: BLE001 - keep crawling other pages/engines
                log.warning("[%s] dork '%s' page %d failed: %s", engine, query, page, exc)
                break

            if _looks_blocked(resp.text):
                log.warning("[%s] dork '%s' page %d: engine returned a block/CAPTCHA page",
                            engine, query, page)
                with self._lock:
                    self._throttled.add(engine)
                break

            links = self._extract_links_from_html(resp.text)
            before = len(collected)
            for raw in links:
                cleaned = _clean_url(raw)
                if cleaned and not self._is_blacklisted(cleaned) and _has_query_params(cleaned):
                    collected.append(cleaned)
            log.debug("[%s] '%s' page %d -> %d raw, %d useful",
                      engine, query, page, len(links), len(collected) - before)

            # Polite spacing already enforced by the limiter.
            if len(collected) >= per_query:
                break

        return collected[:per_query]

    @staticmethod
    def _is_blacklisted(url: str) -> bool:
        host = (urlparse(url).netloc or "").lower()
        if any(bad in host for bad in _BLACKLIST_HOSTS):
            return True
        if _ASSET_EXT_RE.search(url):
            return True
        return False

    # ------------------------------------------------------- auto dork build
    def build_queries(self) -> list[str]:
        """Return configured dorks plus freshly auto-generated ones."""
        queries = [q for q in (self.dork.get("queries") or []) if q]
        if not self.dork.get("auto_generate", True):
            return queries

        fragments = self.dork.get("auto_param_fragments") or list(self._AUTO_PARAM_FRAGMENTS)
        extensions = self.dork.get("auto_extensions") or list(self._AUTO_EXTENSIONS)
        max_auto = int(self.dork.get("max_auto_queries", 30))
        patterns = self.dork.get("auto_patterns") or list(self._AUTO_PATTERNS[:1])

        existing = set(queries)
        auto: list[str] = []
        for pattern in patterns:
            for param in fragments:
                for ext in extensions:
                    try:
                        cand = pattern.format(ext=ext, param=param)
                    except (KeyError, IndexError):
                        continue
                    if cand not in existing:
                        existing.add(cand)
                        auto.append(cand)
        random.shuffle(auto)  # rotate the mix across runs
        auto = auto[:max_auto]
        if auto:
            log.debug("auto-generated %d extra dorks", len(auto))
        return queries + auto

    # ----------------------------------------------------------------- Public
    def run_dorks(self) -> DiscoveryResult:
        """Execute every configured dork on every configured engine, concurrently."""
        result = DiscoveryResult()
        if not self.dork.get("enabled", True):
            log.info("Dork search disabled in settings")
            return result

        engines = [e.lower().strip() for e in (self.dork.get("engines") or [])]
        queries = self.build_queries()
        log.info("Dork search: %d queries x %d engines (concurrency=%d)",
                 len(queries), len(engines), self.threads)

        jobs: list[tuple[str, str]] = [(e, q) for e in engines for q in queries]
        bucket: dict[str, list[str]] = {e: [] for e in engines}

        def _job(job: tuple[str, str]) -> None:
            engine, query = job
            try:
                urls = self._dork_engine(engine, query)
                with self._lock:
                    bucket[engine].extend(urls)
            except Exception as exc:  # noqa: BLE001
                log.error("[%s] dork '%s' error: %s", engine, query, exc)

        # The per-engine rate limiter serialises requests on the wire, so the
        # thread pool mainly hides HTTP latency and keeps engines isolated.
        with ThreadPoolExecutor(max_workers=self.threads,
                                thread_name_prefix="dork") as pool:
            for fut in as_completed({pool.submit(_job, j): j for j in jobs}):
                fut.result()

        for engine in engines:
            urls = bucket.get(engine, [])
            result.stats[engine] = len(urls)
            result.extend(urls)
            if engine in self._throttled:
                result.throttled.append(engine)
                log.warning("[%s] engine was throttled/blocked during this run - "
                            "results may be incomplete", engine)
            log.info("[%s] collected %d candidate URLs", engine, len(urls))

        return result

    def run_urlscan(self) -> DiscoveryResult:
        """Query urlscan.io search API for SQLi-looking URLs."""
        result = DiscoveryResult()
        if not self.urlscan.get("enabled", True):
            log.info("urlscan.io disabled in settings")
            return result

        queries = list(self.urlscan.get("queries") or [])
        if self.urlscan.get("auto_generate", True):
            extra = self.urlscan.get("auto_queries") or [
                'page.url:".php?cid="', 'page.url:".php?pid="',
                'page.url:".aspx?id="', 'page.url:".jsp?id="',
                'page.url:".php?cat="', 'page.url:".php?item="',
                'page.url:".php?page="', 'page.url:".php?news="',
            ]
            for q in extra:
                if q not in queries:
                    queries.append(q)
        size = min(int(self.urlscan.get("size", 100)), 100)
        only_hints = bool(self.urlscan.get("scan_only_sqli_hints", True))
        api = "https://urlscan.io/api/v1/search/"

        for query in queries:
            try:
                resp = self._get(api, params={"q": query, "size": size},
                                 limiter=self.urlscan_limiter)
                data = resp.json()
            except Exception as exc:  # noqa: BLE001
                log.error("urlscan query '%s' failed: %s", query, exc)
                continue

            bucket: list[str] = []
            for entry in data.get("results", []):
                candidate = _clean_url((entry.get("page") or {}).get("url", ""))
                if not candidate or self._is_blacklisted(candidate):
                    continue
                if only_hints and not _has_query_params(candidate):
                    continue
                bucket.append(candidate)

            result.stats[f"urlscan:{query}"] = len(bucket)
            result.extend(bucket)
            log.info("urlscan '%s' -> %d candidate URLs", query, len(bucket))

        return result

    def run_wayback(self) -> DiscoveryResult:
        """Query the Wayback Machine CDX API for historical parameterised URLs.

        The CDX API is an excellent, CAPTCHA-free source of *real* endpoints:
        any URL that was ever archived and carries query parameters is a
        potential SQLi candidate.
        """
        result = DiscoveryResult()
        if not self.wayback.get("enabled", True):
            log.info("Wayback CDX disabled in settings")
            return result

        api = "https://web.archive.org/cdx/search/cdx"
        per_query = min(int(self.wayback.get("size", 100)), 500)
        match_type = self.wayback.get("match_type", "domain")
        patterns = self.wayback.get("url_patterns") or ["*"]

        def _cdx(qline: str) -> list[str]:
            params = {
                "url": qline,
                "matchType": match_type,
                "output": "json",
                "fl": "original",
                "filter": "statuscode:200",
                "collapse": "urlkey",
                "limit": str(per_query),
            }
            if self.wayback.get("from"):
                params["from"] = str(self.wayback["from"])
            if self.wayback.get("to"):
                params["to"] = str(self.wayback["to"])
            resp = self._get(api, params=params, limiter=self.wayback_limiter)
            try:
                rows = resp.json()
            except ValueError:
                log.warning("wayback returned non-JSON body (rate limit?)")
                return []
            if not rows or len(rows) < 2:
                return []
            return [row[0] for row in rows[1:] if row and row[0]]

        seeds = self.wayback.get("queries") or []
        if seeds:
            # Seed queries are either raw domain patterns (CDX syntax) or plain
            # domains - both are fed straight into the CDX `url` field.
            qtargets = list(seeds)
        else:
            # No seeds: CDX needs a target, so probe nothing rather than the
            # whole archive. The user can add domains in settings.yaml.
            qtargets = []

        for qline in qtargets:
            for pattern in patterns:
                target_q = qline if pattern == "*" else f"{pattern}{qline}"
                try:
                    urls = _cdx(target_q)
                except Exception as exc:  # noqa: BLE001
                    log.error("wayback query '%s' failed: %s", target_q, exc)
                    continue

                bucket: list[str] = []
                for raw in urls:
                    candidate = _clean_url(raw)
                    if not candidate or self._is_blacklisted(candidate):
                        continue
                    if not _has_query_params(candidate):
                        continue
                    bucket.append(candidate)

                result.stats[f"wayback:{target_q}"] = len(bucket)
                result.extend(bucket)
                log.info("wayback '%s' -> %d candidate URLs", target_q, len(bucket))

        return result

    def run_commoncrawl(self) -> DiscoveryResult:
        """Query the latest Common Crawl index for parameterised URLs (optional).

        Common Crawl indexes billions of pages; querying it with a URL pattern
        such as ``*.php?id=*`` yields high-quality candidate sinks. The index
        name is discovered automatically from collinfo.json.
        """
        result = DiscoveryResult()
        if not self.commoncrawl.get("enabled", False):
            return result

        collinfo = "https://index.commoncrawl.org/collinfo.json"
        try:
            resp = self._get(collinfo, limiter=self.cc_limiter, retries=1)
            colls = resp.json()
            index = self.commoncrawl.get("index") or colls[0]["id"]
        except Exception as exc:  # noqa: BLE001
            log.error("commoncrawl: could not resolve index: %s", exc)
            return result

        api = f"https://index.commoncrawl.org/{index}-index"
        size = min(int(self.commoncrawl.get("size", 100)), 200)
        for query in (self.commoncrawl.get("queries") or []):
            params = {"url": query, "output": "json", "limit": str(size)}
            try:
                resp = self._get(api, params=params, limiter=self.cc_limiter)
            except Exception as exc:  # noqa: BLE001
                log.error("commoncrawl query '%s' failed: %s", query, exc)
                continue

            bucket: list[str] = []
            for line in resp.text.splitlines():
                line = line.strip()
                if not line:
                    continue
                try:
                    entry = json.loads(line)
                except ValueError:
                    continue
                candidate = _clean_url(entry.get("url", ""))
                if not candidate or self._is_blacklisted(candidate):
                    continue
                if not _has_query_params(candidate):
                    continue
                bucket.append(candidate)

            result.stats[f"commoncrawl:{query}"] = len(bucket)
            result.extend(bucket)
            log.info("commoncrawl '%s' [%s] -> %d candidate URLs", query, index, len(bucket))

        return result

    # ------------------------------------------------------------ source runs
    _SOURCES = (("dork", "run_dorks"), ("urlscan", "run_urlscan"),
                ("wayback", "run_wayback"), ("commoncrawl", "run_commoncrawl"))

    def _run_source(self, name: str, method_name: str) -> DiscoveryResult:
        """Run one discovery source, fully isolated from the others."""
        result = DiscoveryResult()
        try:
            result = getattr(self, method_name)()
        except Exception as exc:  # noqa: BLE001 - one source must not kill the run
            log.error("Discovery source '%s' crashed (isolated): %s", name, exc,
                      exc_info=log.isEnabledFor(10))
            result.throttled.append(name)
        return result

    def run_all(self, parallel: bool | None = None) -> DiscoveryResult:
        """Run dork + urlscan + wayback + commoncrawl; dedupe and rank.

        Sources run concurrently by default (``general.parallel_discovery``,
        default true) - each source keeps its own rate limiter, so parallel
        sources do not stress any single upstream service harder than before.
        """
        combined = DiscoveryResult()
        if parallel is None:
            parallel = bool(self.cfg.get("general", {}).get("parallel_discovery", True))

        if parallel and len(self._SOURCES) > 1:
            with ThreadPoolExecutor(max_workers=len(self._SOURCES),
                                    thread_name_prefix="disc") as pool:
                futures = {pool.submit(self._run_source, n, m): n
                           for n, m in self._SOURCES}
                for fut in as_completed(futures):
                    src = futures[fut]
                    r = fut.result()
                    combined.extend(r.urls)
                    combined.stats.update({f"{src}:{k}": v for k, v in r.stats.items()})
                    combined.throttled.extend(f"{src}:{t}" for t in r.throttled)
        else:
            for name, method_name in self._SOURCES:
                r = self._run_source(name, method_name)
                combined.extend(r.urls)
                combined.stats.update(r.stats)
                combined.throttled.extend(r.throttled)

        # Global dedupe (exact), then smart-dedupe (host+path+param names).
        unique: list[str] = []
        for url in combined.urls:
            with self._lock:
                if url in self._seen:
                    continue
                self._seen.add(url)
            unique.append(url)

        if self.cfg.get("general", {}).get("smart_dedupe", True):
            before = len(unique)
            unique = smart_dedupe_urls(unique)
            if before != len(unique):
                log.info("smart-dedupe collapsed %d value-variant URLs -> %d",
                         before, len(unique))
        else:
            unique.sort(key=score_url, reverse=True)

        combined.urls = unique
        log.info("Discovery complete: %d unique candidate URLs (throttled engines: %s)",
                 len(unique), ",".join(combined.throttled) or "none")
        return combined