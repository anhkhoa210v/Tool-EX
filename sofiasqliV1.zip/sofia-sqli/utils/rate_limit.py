"""Rate limiting and retry helpers.

Includes:
  * ``RateLimiter``  - thread-safe token/delay based limiter.
  * ``retry``        - decorator with exponential backoff + jitter.
  * ``JitteredBackoff`` - backoff calculator used by retry.
"""

from __future__ import annotations

import functools
import random
import threading
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Iterable, TypeVar

from utils.logger import get_logger

log = get_logger("sofia-sqli.rate_limit")

T = TypeVar("T")


class RateLimiter:
    """Thread-safe rate limiter.

    Enforces a minimum delay between consecutive acquisitions of the limiter
    across all threads. Optionally enforces a maximum number of requests per
    rolling window (simple leaky-bucket approximation).
    """

    def __init__(self, min_interval: float = 0.0, max_per_window: int | None = None,
                 window: float = 60.0):
        self.min_interval = max(0.0, float(min_interval))
        self.max_per_window = max_per_window
        self.window = window
        self._last = 0.0
        self._window_start = time.monotonic()
        self._window_count = 0
        self._lock = threading.Lock()

    def acquire(self, block: bool = True) -> float:
        """Block (or not) until a slot is available. Returns the slept seconds."""
        slept = 0.0
        with self._lock:
            now = time.monotonic()

            # Rolling-window quota.
            if self.max_per_window:
                if now - self._window_start >= self.window:
                    self._window_start = now
                    self._window_count = 0
                if self._window_count >= self.max_per_window:
                    if not block:
                        return 0.0
                    wait = self.window - (now - self._window_start)
                    if wait > 0:
                        time.sleep(wait)
                        slept += wait
                    self._window_start = time.monotonic()
                    self._window_count = 0

            # Minimum spacing.
            if self.min_interval:
                elapsed = now - self._last
                wait = self.min_interval - elapsed
                if wait > 0:
                    if not block:
                        return 0.0
                    time.sleep(wait)
                    slept += wait

            self._last = time.monotonic()
            self._window_count += 1
        return slept

    def __enter__(self) -> "RateLimiter":
        self.acquire()
        return self

    def __exit__(self, *exc: Any) -> None:
        return None


@dataclass
class JitteredBackoff:
    """Exponential backoff with optional jitter.

    delay(n) = min(max_delay, base * factor**n) * random(1-jitter, 1+jitter)
    """

    base: float = 1.0
    factor: float = 2.0
    max_delay: float = 60.0
    jitter: float = 0.25

    def delay(self, attempt: int) -> float:
        raw = min(self.max_delay, self.base * (self.factor ** max(0, attempt)))
        if self.jitter > 0:
            raw *= random.uniform(1.0 - self.jitter, 1.0 + self.jitter)
        return max(0.0, raw)


def retry(
    retries: int = 3,
    exceptions: Iterable[type[BaseException]] | type[BaseException] = (Exception,),
    backoff: JitteredBackoff | None = None,
    on_retry: Callable[[int, BaseException], None] | None = None,
) -> Callable[[Callable[..., T]], Callable[..., T]]:
    """Retry decorator with exponential backoff + jitter.

    ``retries`` is the number of *additional* attempts (total = retries + 1).
    """
    backoff = backoff or JitteredBackoff()
    exc_tuple = exceptions if isinstance(exceptions, tuple) else tuple(exceptions)

    def decorator(func: Callable[..., T]) -> Callable[..., T]:
        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> T:
            last_exc: BaseException | None = None
            for attempt in range(retries + 1):
                try:
                    return func(*args, **kwargs)
                except exc_tuple as exc:  # type: ignore[misc]
                    last_exc = exc
                    if attempt >= retries:
                        break
                    wait = backoff.delay(attempt)
                    if on_retry:
                        on_retry(attempt, exc)
                    else:
                        log.warning(
                            "%s failed (attempt %d/%d): %s -> retry in %.2fs",
                            func.__name__, attempt + 1, retries + 1, exc, wait,
                        )
                    time.sleep(wait)
            assert last_exc is not None
            raise last_exc

        return wrapper

    return decorator
