"""Bộ đếm cộng dồn (thread-safe) — tiến độ quét theo 3 mốc:

  1. store   — số target đã KIỂM TRA và nhận diện là Magento hoặc WooCommerce
               (stage 2a core/fingerprint.py + stage 2a-woo core/woo_fingerprint.py)
  2. version — số target đã KIỂM TRA VERSION KHỚP cves/version_map.yaml
               (Magento, core/cve_scan.py) / cves/woo_version_map.yaml
               (Woo, core/woo_cve_scan.py) VÀ ĐÃ GHI RA FILE THÀNH CÔNG
               (output/vuln_version.txt + work/<slug>/cve_version.txt /
               woo_cve_version.txt). Target có version nhưng không khớp CVE
               nào, hay ghi file thất bại thì KHÔNG tính.
  3. nuclei  — số target đã KIỂM TRA bằng nuclei template local VÀ ĐÃ GHI FILE
               kết quả thành công (output/vuln.txt)
               (stage 3 core/cve_scan.py + stage 3-woo core/woo_cve_scan.py;
               chỉ tính khi tiến trình nuclei local kết thúc bình thường rc=0
               VÀ findings đã append vào vuln.txt thành công — bị chặn
               max_seconds (rc=124), lỗi khác hay ghi file thất bại thì
               KHÔNG tính)

Bộ đếm CỘNG DỒN trong suốt tiến trình (không reset theo CIDR). CIDR lỗi được
pipeline thử lại → target của lần thử lỗi vẫn bị đếm thêm 1 lần: bộ đếm phản
ánh KHỐI LƯỢNG công việc đã làm, không phải số target DUY NHẤT.

Mọi add_* tự log 1 dòng tổng kết (khi có cộng dồn) để theo dõi tiến độ trong
sofia.log; pipeline còn log tổng kết sau mỗi CIDR và khi kết thúc toàn bộ quét.
Thread-safe: nhánh Magento và WooCommerce chạy SONG SONG (core/pipeline.py) nên
mọi phép cộng đều qua threading.Lock.
"""
import threading

from utils.logger import info

_lock = threading.Lock()
_counters = {
    "magento": 0,            # target nhận diện là Magento
    "woocommerce": 0,        # target nhận diện là WooCommerce
    "version_checked": 0,    # target đã kiểm tra version KHỚP version_map /
                             # woo_version_map VÀ đã ghi ra file thành công
    "version_found": 0,      # trong số lượt đếm, target có version (tham khảo)
    "nuclei_local": 0,       # target đã kiểm tra bằng nuclei template local
                             # VÀ đã ghi file kết quả thành công
    "nuclei_local_runs": 0,  # số lượt nuclei local kiểm tra + ghi file (tham khảo)
}


def _summary():
    """Dòng tổng kết hiện tại (gọi khi đang GIỮ lock)."""
    return (f"[stats] Magento/Woo đã kiểm tra: "
            f"{_counters['magento'] + _counters['woocommerce']} "
            f"(Magento {_counters['magento']}, Woo {_counters['woocommerce']}) | "
            f"version khớp map + ghi file: {_counters['version_checked']} "
            f"(có version {_counters['version_found']}) | "
            f"nuclei local kiểm tra + ghi file: {_counters['nuclei_local']} "
            f"({_counters['nuclei_local_runs']} lượt)")


def snapshot():
    """Bản sao bộ đếm hiện tại (dict) — an toàn gọi từ bất kỳ thread nào."""
    with _lock:
        return dict(_counters)


def summary_line():
    """Chuỗi tổng kết hiện tại (không log) — dùng cho log tổng của pipeline."""
    with _lock:
        return _summary()


def _bump(key, delta):
    with _lock:
        _counters[key] += int(delta)


def log_summary():
    """Log 1 dòng tổng kết bộ đếm (gọi ở mốc xong CIDR / kết thúc quét)."""
    info(summary_line())


def add_store(magento=0, woocommerce=0):
    """Cộng target vừa nhận diện là Magento / WooCommerce; tự log tổng kết."""
    if magento:
        _bump("magento", magento)
    if woocommerce:
        _bump("woocommerce", woocommerce)
    if magento or woocommerce:
        log_summary()


def add_version_checked(matched=0, found=0):
    """Cộng target đã kiểm tra version khớp version_map + đã ghi file; tự log.

    CHỈ gọi sau khi ghi file kết quả thành công:
      * `matched`: số target có version được khớp offline với
        cves/version_map.yaml (Magento) / cves/woo_version_map.yaml (Woo)
        và dòng kết quả "[version] ..." đã ghi vào file thành công;
      * `found`: trong số đó, target có version (tham khảo, ngoặc).
    Target có version nhưng không khớp CVE nào, hay ghi file thất bại → KHÔNG
    cộng gì cả.
    """
    if matched:
        _bump("version_checked", matched)
    if found:
        _bump("version_found", found)
    if matched or found:
        log_summary()


def add_nuclei_local_done(targets=0, runs=0):
    """Cộng target đã kiểm tra bằng nuclei template local + đã ghi file; tự log.

    CHỈ gọi khi lượt nuclei local kết thúc bình thường (rc=0) VÀ findings đã
    được ghi ra file thành công (append vào output/vuln.txt). Lượt bị chặn
    max_seconds (rc=124), lỗi khác, hay ghi file thất bại KHÔNG được đếm.
    """
    if targets:
        _bump("nuclei_local", targets)
    if runs:
        _bump("nuclei_local_runs", runs)
    if targets or runs:
        log_summary()