"""STAGE 3: phát hiện CVE Magento — 2 lớp độc lập:

  A. OFFLINE (version match) — luôn chạy, không cần nuclei:
     version từ stage 2b → khớp cves/version_map.yaml (core/cve_map.py) →
     dòng "[version] url ver — khả năng CVE-... [severity] name (khoảng dính)".
     Không gửi request thêm; nếu URL không có version thì không có dòng này.

  B. ONLINE (nuclei) — CÓ THỂ TẮT qua cve.nuclei.enabled:
     1) template local trong cves/<CVE>.yaml qua -t; id trong template PHẢI
        khớp tên file (chống gán nhầm CVE cho kết quả) — lệch là bỏ qua;
     2) template cộng đồng qua -id (cve.community_ids).
     Một CVE vừa có template local vừa có trong community_ids → CHỈ chạy
     bản local (tránh quét trùng 2 lần cùng 1 CVE).

Cờ điều khiển mức độ ăn to (chống block/đỡ tốn băng thông) ở cve.nuclei:
  concurrency (-c), rate_limit (-rl), timeout (-timeout), retries (-retries),
  follow_redirects (trước đây code cứng "-fr" — thực chất là follow-redirects,
  KHÔNG phải "giảm false positive" như chú thích cũ), max_seconds (chặn mềm
  mỗi lượt nuclei), local_templates / community (bật tắt từng nguồn),
  severity (chỉ giữ finding mức này trở lên; rỗng = tất cả).

Kết quả: A (dòng [version]) vào output/vuln_version.txt; B (nuclei) vào
output/vuln.txt — mỗi dòng đúng 1 lần (B chỉ append phần nuclei CHƯA có ở A,
dedupe theo cặp (CVE-ID, host) thay vì so cả dòng). vuln_version.txt LUÔN
được tạo kể cả khi không có version match. Mọi lần ghi file có GHI DỰ PHÒNG:
global fail → bản tạm trong workdir (hoặc log) giữ finding — không mất dữ
liệu khi ổ cứng/quyền lỗi; _append_vul_hosts không bao giờ raise. Riêng A còn
ghi output/work/<slug>/cve_version.txt. Template cộng đồng được kiểm tra tồn
tại (nuclei -tl) trước khi chạy; timeout/template lệch được log rõ ràng. Mọi
URL dạng ip:port trong dòng finding được rewrite sang domain
(core.resolver.to_domain_url — https ưu tiên TLS SAN, http dùng PTR; giữ
nguyên URL nếu không phân giải được). Hàm nào cũng không raise (an toàn
pipeline).
"""
import os
import re
import shutil
import subprocess
import traceback
from urllib.parse import urlparse

import yaml

from core import cve_map, resolver
from utils import file_io, runner, stats
from utils.logger import debug, info, warn

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CVE_DIR = os.path.join(BASE_DIR, "cves")

# Trích URL từ dòng finding (version match + nuclei đều bắt đầu bằng URL)
# Escaped `\"` — chuỗ ra là raw string, backslash giữ → class chỉ literal `\"`
URL_RE = re.compile(r"""https?://[^\s]+[^\s.,;:)\]}'"]""", re.IGNORECASE)

# CVE-ID trong dòng finding (version: "khả năng CVE-..."; nuclei: [cve:ID] hoặc
# [CVE-...]) — dùng cho dedupe theo (CVE-ID, host) thay vì so cả dòng.
CVE_RE = re.compile(r"CVE-\d{4}-\d{4,7}", re.IGNORECASE)

# File riêng cho findings khớp version — tách khỏi vuln.txt (chỉ nuclei).
VERSION_FILENAME = "vuln_version.txt"

DEFAULT_NUCLEI_MAX_SECONDS = 7200


def version_file(global_vuln):
    """Đường dẫn output/vuln.txt → output/vuln_version.txt (cùng thư mục)."""
    return os.path.join(os.path.dirname(global_vuln) or ".", VERSION_FILENAME)


def rewrite_line(line, ptr_timeout=5, tls_timeout=10):
    """Đổi URL ip:port trong dòng finding sang domain; giữ line nếu thất bại.

    Dòng không chứa URL, hoặc URL không phân giải ra domain (PTR/TLS SAN) đều
    được trả về nguyên trạng. Không raise.
    """
    try:
        match = URL_RE.search(str(line))
        if not match:
            return line
        old_url = match.group(0)
        new_url = resolver.to_domain_url(old_url, ptr_timeout, tls_timeout)
        if new_url == old_url:
            return line
        return str(line).replace(old_url, new_url, 1)
    except (OSError, ValueError) as exc:
        # PTR/TLS phân giải thất bại là chuyện bình thường — giữ nguyên dòng;
        # chỉ bắt lỗi I/O/giá trị có thể thấy từ to_domain_url, lỗi khác phải
        # lộ ra caller thay vì bị nuốt im lặng.
        debug(f"rewrite_line giữ nguyên dòng ({exc.__class__.__name__}: {exc})")
        return line

# Cache nhận diện flag của nuclei (đọc -help 1 lần) — chống lệch version:
# chỉ truyền cờ chắc chắn nuclei bản đang chạy hỗ trợ.
_FLAG_CACHE = {"help": None}


def _nuclei_help():
    """toàn bộ -help của nuclei (cache) hoặc '' nếu đọc thất bại."""
    if _FLAG_CACHE["help"] is None:
        try:
            proc = runner.run(["nuclei", "-help"], timeout=60)
            _FLAG_CACHE["help"] = (proc.stdout or "") + "\n" + (proc.stderr or "")
        except (OSError, subprocess.SubprocessError) as exc:
            # nuclei không cài / treo → không đọc được help; log đủ stack trace
            # thay vì nuốt im lặng để debug được khi cờ bị truyền nhầm.
            warn(f"nuclei -help thất bại: {exc.__class__.__name__}: {exc} | "
                 + traceback.format_exc().rstrip())
            _FLAG_CACHE["help"] = ""
    return _FLAG_CACHE["help"]


def _nuclei_supports(*tokens):
    """True nếu nuclei -help có chứa bất kỳ token nào (vd "-follow-redirects")."""
    help_text = _nuclei_help()
    return any(re.search(re.escape(token), help_text, re.I) for token in tokens)


def nuclei_config(cfg):
    """Chuẩn hóa block cve.nuclei — điền default, trả dict an toàn."""
    nuc = (cfg.get("cve") or {}).get("nuclei") or {}
    return {
        "enabled": bool(nuc.get("enabled", True)),
        "concurrency": int(nuc.get("concurrency") or 0),
        "rate_limit": int(nuc.get("rate_limit") or 0),
        "timeout": int(nuc.get("timeout") or cfg.get("timeout") or 15),
        "retries": int(nuc.get("retries") or 2),
        "follow_redirects": bool(nuc.get("follow_redirects", False)),
        "max_seconds": int(nuc.get("max_seconds") or DEFAULT_NUCLEI_MAX_SECONDS),
        "local_templates": bool(nuc.get("local_templates", True)),
        "community": bool(nuc.get("community", True)),
        "severity": str(nuc.get("severity") or "").strip(),
    }


def _local_template_paths(cfg):
    """Đường dẫn template local cho CVE khai trong cves: (chỉ file tồn tại)."""
    out = []
    for cve in cfg.get("cves") or []:
        path = os.path.join(CVE_DIR, f"{cve}.yaml")
        if os.path.exists(path):
            out.append(path)
        else:
            warn(f"[nuclei] không tìm thấy template local {cve} → {path} (bỏ qua)")
    return out


def _template_cve_id(path):
    """id trong template local (đã normalize hoa) hoặc None nếu không đọc được.

    Chỉ chấp nhận id là CVE-ID hợp lệ — template thiếu id / id lạ bị coi là
    không thể gán kết quả → cảnh báo và loại (tránh dòng tìm thấy bị gắn
    nhầm CVE)."""
    try:
        with open(path, encoding="utf-8") as fh:
            data = yaml.safe_load(fh)
    except (yaml.YAMLError, OSError) as exc:
        warn(f"[nuclei] template {os.path.basename(path)} không đọc được: "
             f"{exc} — bỏ qua (không gán được CVE)")
        return None
    if not isinstance(data, dict):
        warn(f"[nuclei] template {os.path.basename(path)} không phải mapping — bỏ qua")
        return None
    template_id = str(data.get("id") or "").strip().upper()
    if not cve_map._valid_cve(template_id):
        warn(f"[nuclei] template {os.path.basename(path)} id={template_id!r} "
             f"không phải CVE-ID — bỏ qua (chống gán nhầm kết quả)")
        return None
    return template_id


def local_templates(cfg):
    """Template local hợp lệ → [(path, CVE-ID chuẩn)]. Kiểm tra id trùng tên file."""
    valid = []
    for path in _local_template_paths(cfg):
        filename_cve = os.path.basename(path)[:-5].upper()  # bỏ ".yaml"
        cve_id = _template_cve_id(path)
        if cve_id is None:
            continue  # đã cảnh báo trong _template_cve_id
        if cve_id != filename_cve:
            warn(f"[nuclei] template {os.path.basename(path)}: id {cve_id} "
                 f"KHÁC tên file {filename_cve} — bỏ qua (chống gán nhầm)")
            continue
        valid.append((path, cve_id))
    return valid


def community_template_ids(cfg):
    """CVE cộng đồng khai trong cve.community_ids (chưa lọc trùng local)."""
    return [cve for cve in (cfg.get("cve", {}).get("community_ids") or []) if cve]


_TL_CACHE = {"text": None}


def _nuclei_template_list():
    """Output của `nuclei -tl -silent` (cache 1 lần) — '' nếu lấy thất bại.

    Dùng để kiểm tra template cộng đồng CÓ TỒN TẠI trong bộ template nuclei
    đã cài TRƯỚC khi chạy (chưa `nuclei -update-templates` → nuclei không tìm
    thấy template, lượt chạy tốn giờ mà không ra finding nào).
    """
    if not _nuclei_supports("-template-list", "-tl"):
        return ""
    if _TL_CACHE["text"] is None:
        # runner.run không bao giờ raise (timeout → rc=124, thiếu binary →
        # rc=127) — kiểm tra returncode thay vì try/except code chết.
        proc = runner.run(["nuclei", "-tl", "-silent"], timeout=600)
        if proc.returncode != 0:
            warn(f"[nuclei] nuclei -tl exit {proc.returncode}: "
                 f"{(proc.stderr or '').strip()[-300:]} — coi như không có "
                 f"danh sách template")
            _TL_CACHE["text"] = ""
        else:
            _TL_CACHE["text"] = proc.stdout or ""
            if not _TL_CACHE["text"].strip():
                warn("[nuclei] `nuclei -tl` không trả template nào — bộ template "
                     "cộng đồng trống? Chạy `nuclei -update-templates`")
    return _TL_CACHE["text"]


def community_ids_available(ids):
    """Lọc các CVE cộng đồng CÓ template trong bộ nuclei đã cài; warn id thiếu.

    Không kiểm tra được (thiếu cờ -tl / -tl lỗi) → trả nguyên `ids` kèm cảnh
    báo (không chặn lượt chạy vì thông tin chưa chắc chắn).
    """
    ids = [str(cve).strip().upper() for cve in ids or [] if str(cve).strip()]
    if not ids:
        return []
    text = _nuclei_template_list()
    if not text.strip():
        warn("[nuclei] không kiểm tra được template cộng đồng có tồn tại — "
             "chạy nguyên trạng (nếu thiếu template, lượt nuclei sẽ không ra finding)")
        return ids
    installed = {m.group(0).upper() for m in CVE_RE.finditer(text)}
    have, missing = [], []
    for cve in ids:
        (have if cve in installed else missing).append(cve)
    for cve in missing:
        warn(f"[nuclei] template cộng đồng {cve} không có trong bộ template nuclei "
             f"— bỏ qua (chạy `nuclei -update-templates` để tải thêm)")
    return have


def extract_hosts(findings):
    """URL trong từng dòng finding → hostname (dedupe, sort) — dữ liệu cho vul.txt.

    Mỗi dòng finding (version match: `[version] <url> ...` hoặc nuclei:
    `<url> [CVE-...]`) chứa URL của cửa hàng dính lỗi. Trích part hostname
    (bỏ scheme/path) để ra "domain dính vuln" sạch, khớp kiểu t.txt.
    """
    hosts = set()
    for line in findings or []:
        match = URL_RE.search(str(line))
        if not match:
            continue
        host = urlparse(match.group(0)).hostname
        if host:
            hosts.add(host.lower())
    return sorted(hosts)


def _try_append(path, lines):
    """append_lines phiên bản không raise: True nếu ghi thành công, False nếu lỗi."""
    try:
        file_io.append_lines(path, lines)
        return True
    except OSError as exc:
        warn(f"[file] không ghi được {path}: {exc}")
        return False


def _log_lost_lines(path, lines):
    """Backup bằng log: in các dòng finding KHÔNG ghi được vào file nào ra log

    (cắt preview để log không phình to) — finding không bị mất vô trace.
    """
    preview = " | ".join(str(l) for l in lines[:3])
    if len(lines) > 3:
        preview += f" ... (+{len(lines) - 3} dòng nữa)"
    warn(f"[file] {len(lines)} dòng finding KHÔNG ghi được vào file nào "
         f"(backup qua log): {preview}")


def _append_ok(path, lines, fallback=None):
    """append_lines phiên bản không raise + GHI DỰ PHÒNG.

    Ghi `path` lỗi (OSError) → thử `fallback` (file tạm chứa cùng finding);
    fallback cũng lỗi → backup bằng log (_log_lost_lines) thay vì làm chết
    stage hay mất finding vô trace. Trả về True nếu finding đã ghi vào BẤT
    KỲ file nào (path hoặc fallback) — đây là điều kiện cộng bộ đếm
    (utils/stats.py): chỉ đếm target khi kết quả đã ghi ra file thành công.
    """
    if _try_append(path, lines):
        return True
    if fallback and fallback != path and _try_append(fallback, lines):
        warn(f"[file] đã ghi dự phòng {len(lines)} dòng finding vào {fallback} "
             f"({path} ghi thất bại)")
        return True
    _log_lost_lines(path, lines)
    return False


def ensure_version_file(global_vuln):
    """Tạo (nếu chưa có) output/vuln_version.txt — KỂ CẢ khi không có version

    match nào. Trước đây file chỉ được tạo khi có finding → người dùng tưởng
    bước quét version không chạy dù đã chạy mà không ra kết quả. Không raise.
    """
    path = version_file(global_vuln)
    try:
        if not os.path.exists(path):
            file_io.atomic_write(path, "")
    except OSError as exc:
        warn(f"[file] không tạo được {path}: {exc}")


def _urls_in_lines(lines):
    """Tập URL xuất hiện trong các dòng finding (dedupe) — dùng để đếm target."""
    urls = set()
    for line in lines or []:
        match = URL_RE.search(str(line))
        if match:
            urls.add(match.group(0))
    return urls


def _finding_key(line):
    """(CVE-ID, host) từ dòng finding — None nếu thiếu một trong hai.

    Dùng cho dedupe GIỮA version match và nuclei: trước đây so cả dòng nên
    `[version] url ver — khả năng CVE-...` không bao giờ khớp
    `<url> [cve:ID] ...` → cùng 1 lỗi xuất hiện 2 lần (vuln_version.txt +
    vuln.txt). Dedupe theo cặp (CVE-ID, host) là đủ để nhận trùng.
    """
    text = str(line)
    cve_m = CVE_RE.search(text)
    if not cve_m:
        return None
    url_m = URL_RE.search(text)
    if not url_m:
        return None
    try:
        host = (urlparse(url_m.group(0)).hostname or "").lower()
    except ValueError:
        return None
    if not host:
        return None
    return (cve_m.group(0).upper(), host)


def dedupe_against(nuclei_lines, known_lines):
    """Dedupe nuclei theo (CVE-ID, host): bỏ dòng nuclei trùng với `known_lines`

    (version match) — tức cùng 1 CVE trên cùng 1 host đã có ở bước A. Dòng
    nuclei không trích được (CVE, host) → GIỮ (không chứng minh được trùng).
    Output đã dedupe_sort (giữ nguyên hành vi cũ).
    """
    known = {key for key in (_finding_key(l) for l in known_lines or []) if key}
    out = []
    for line in file_io.dedupe_sort(nuclei_lines or []):
        key = _finding_key(line)
        if key and key in known:
            continue
        out.append(line)
    return out


def _append_vul_hosts(findings, global_vuln):
    """Ghi danh sách domain dính vuln (từ findings) vào output/vul.txt.

    KHÔNG BAO GIỜ raise (lỗi ghi chỉ là warn + backup log) — trước đây
    append_lines để trần, OSError (ổ cứng/quyền) làm sập toàn pipeline.
    """
    hosts = extract_hosts(findings)
    if not hosts:
        return
    global_vul = os.path.join(os.path.dirname(global_vuln), "vul.txt")
    if _try_append(global_vul, hosts):
        info(f"stage3: {len(hosts)} domain dính vuln → {global_vul}")
    else:
        _log_lost_lines(global_vul, hosts)


def version_candidates(urls, versions, cfg):
    """url + version → dòng '[version] ...' cho từng CVE khả năng dính lỗi.

    Mỗi dòng mang CVE, severity, tên lỗi và khoảng version dính lỗi (lý do
    khớp) để người đọc vuln.txt tự đối chiếu, không phải đoán.
    """
    if not versions:
        return []
    map_path = cfg.get("cve", {}).get("version_map")
    if map_path and not os.path.isabs(map_path):
        map_path = os.path.join(BASE_DIR, map_path)
    version_map = cve_map.load_map(map_path)
    if not version_map:
        return []

    lines = []
    for url in urls:
        version = versions.get(url)
        if not version:
            continue
        for hit in cve_map.match_detail(version, version_map):
            sev = hit["severity"].upper() if hit["severity"] != "n/a" else "n/a"
            name = f" ({hit['name']})" if hit["name"] else ""
            lines.append(
                f"[version] {url} {version} — khả năng {hit['cve']} "
                f"[{sev}]{name} — dính trong {hit['label']}"
            )
    return lines


def _nuclei_flags(ncfg):
    """cfg nuclei → cờ CLI. Chỉ thêm cờ nuclei hỗ trợ (chống crash vì lệch bản)."""
    flags = []
    if ncfg["concurrency"] > 0 and _nuclei_supports("-concurrency", " -c ", "concurrency"):
        flags += ["-c", str(ncfg["concurrency"])]
    if ncfg["rate_limit"] > 0 and _nuclei_supports("-rate-limit", "-rl"):
        flags += ["-rl", str(ncfg["rate_limit"])]
    if ncfg["retries"] > 0:
        flags += ["-retries", str(ncfg["retries"])]
    if ncfg["timeout"] > 0:
        flags += ["-timeout", str(ncfg["timeout"])]
    if ncfg["follow_redirects"] and _nuclei_supports("-follow-redirects", "-fr"):
        flags += ["-follow-redirects"]
    if ncfg["severity"] and _nuclei_supports("-severity"):
        flags += ["-severity", ncfg["severity"]]
    return flags


def _run_nuclei(targets_file, out, extra, cfg):
    """Một lượt nuclei (đã có sẵn targets_file); trả (list finding, returncode).

    Bị chặn mềm bởi cve.nuclei.max_seconds (runner báo rc=124 khi quá giờ) —
    scan dài ngày vẫn không kẹt một lượt nuclei bất tử. returncode để caller
    biết lượt chạy có TRỌN VẸN (rc=0) hay bị chặn/lỗi (rc=124/khác) — bộ đếm
    "nuclei local kiểm tra + ghi file" (utils/stats.py) chỉ cộng khi rc=0
    VÀ findings đã được ghi ra file thành công (caller kiểm tra).
    """
    ncfg = nuclei_config(cfg)
    cmd = ["nuclei", "-l", targets_file]
    cmd += extra
    cmd += ["-silent", "-nc", "-no-color", "-o", out]
    cmd += _nuclei_flags(ncfg)
    proc = runner.run(cmd, timeout=ncfg["max_seconds"])
    if proc.returncode == 124:
        # Timeout KHÔNG làm mất phần đã ghi: nuclei ghi `-o out` liên tục, file
        # chỉ chứa finding ghi TRƯỚC thời điểm kill (runner giữ output một phần).
        # Finding xuất hiện SAU đó thì mất — log rõ để người dùng tăng giờ.
        n_lines = len(file_io.read_lines(out)) if os.path.exists(out) else 0
        warn(f"[nuclei] TIMEOUT sau {ncfg['max_seconds']}s (rc=124) — bị kill: "
             f"giữ được {n_lines} finding một phần trong {out}; finding xuất "
             f"hiện sau thời điểm kill bị MẤT — tăng cve.nuclei.max_seconds "
             f"nếu cần quét trọn vẹn")
    elif proc.returncode != 0 and proc.stderr:
        warn(f"[nuclei] exit {proc.returncode}: {proc.stderr.strip()[-300:]}")
    lines = file_io.read_lines(out) if os.path.exists(out) else []
    return lines, proc.returncode


def run(urls, workdir, global_vuln, cfg, versions=None):
    """urls: list URL Magento → findings (version match + nuclei); append vuln.txt.

    Không bao giờ raise: mọi lỗi nuclei/đọc file đều thành cảnh báo. Trả list
    dòng finding (version + nuclei) cho pipeline đếm.
    """
    if not urls:
        return []
    findings = []

    # vuln_version.txt luôn được TẠO (kể cả rỗng) — không có version match
    # ≠ bước quét version không chạy.
    ensure_version_file(global_vuln)

    # A) offline version match — chạy trước, có kết quả kể cả khi thiếu nuclei.
    # Dòng [version] vào vuln_version.txt (tách khỏi vuln.txt của nuclei) và
    # được rewrite URL ip:port → domain trước khi ghi. Ghi 2 file ĐỘC LẬP:
    # global fail thì workdir (cve_version.txt) còn giữ bản — finding không mất.
    version_lines_raw = version_candidates(urls, versions or {}, cfg)
    version_lines = [rewrite_line(l) for l in version_lines_raw]
    work_version_file = os.path.join(workdir, "cve_version.txt")
    version_written = False
    if version_lines:
        ok_global = _try_append(version_file(global_vuln), version_lines)
        ok_work = _try_append(work_version_file, version_lines)
        if not ok_global and ok_work:
            warn(f"[file] findings version chỉ còn ở bản dự phòng "
                 f"{work_version_file} ({version_file(global_vuln)} ghi thất bại)")
        elif not ok_global and not ok_work:
            _log_lost_lines(version_file(global_vuln), version_lines)
        version_written = ok_global and ok_work
        findings += version_lines
        if version_written:
            # Bộ đếm cộng dồn: target đã kiểm tra version KHỚP
            # cves/version_map.yaml VÀ đã ghi kết quả ra file thành công
            # (utils/stats.py). Target có version nhưng không khớp CVE nào,
            # hoặc ghi file thất bại thì KHÔNG tính.
            stats.add_version_checked(
                matched=len(_urls_in_lines(version_lines_raw)),
                found=sum(1 for u in urls if (versions or {}).get(u)))

    ncfg = nuclei_config(cfg)
    if not ncfg["enabled"]:
        info(f"stage3: {len(findings)} findings offline "
             f"(nuclei tắt trong cve.nuclei.enabled=true — vuln.txt sẽ "
             f"KHÔNG có dòng nuclei, chỉ có findings version match)")
        _append_vul_hosts(findings, global_vuln)
        return findings
    if shutil.which("nuclei") is None:
        warn("[nuclei] không tìm thấy binary nuclei trong PATH — bỏ qua toàn bộ "
             "lượt quét nuclei; vuln.txt sẽ không có thêm dòng nào (cài nuclei "
             "hoặc bật lại để quét)")
        info(f"stage3: {len(findings)} findings offline (không có nuclei)")
        _append_vul_hosts(findings, global_vuln)
        return findings

    targets_file = os.path.join(workdir, "magento.txt")
    file_io.atomic_write(targets_file, "".join(u + "\n" for u in urls))

    # Chuẩn bị 2 nguồn + dedupe: CVE có template local → bỏ khỏi community_ids
    local = local_templates(cfg) if ncfg["local_templates"] else []
    local_cves = {cve for _, cve in local}
    configured_local = [str(c).strip().upper() for c in (cfg.get("cves") or [])
                        if str(c).strip()] if ncfg["local_templates"] else []
    skipped_local = [cve for cve in configured_local if cve not in local_cves]
    if skipped_local:
        # Log rõ: CVE bị bỏ qua (file thiếu / id lệch tên file / template hỏng)
        # sẽ KHÔNG được quét bằng nuclei → vuln.txt thiếu finding của CVE này.
        warn(f"[nuclei] {len(skipped_local)} template local bị bỏ qua: "
             f"{', '.join(skipped_local)} — các CVE này sẽ KHÔNG được quét "
             f"bằng nuclei (sửa id trong template cho khớp tên file hoặc thêm "
             f"file cves/<CVE>.yaml)")
    community_ids = [cve for cve in community_template_ids(cfg)
                     if cve and cve.upper() not in local_cves] \
        if ncfg["community"] else []
    if community_ids:
        # Kiểm tra template cộng đồng TỒN TẠI trước khi chạy (chưa
        # -update-templates → lượt nuclei tốn giờ mà không ra finding).
        community_ids = community_ids_available(community_ids)
    if not local and not community_ids:
        reason = ("template local không hợp lệ " if ncfg["local_templates"] else "tắt local") \
            if not community_ids else ""
        warn(f"[nuclei] không có nguồn nào để chạy ({reason or 'cả local và community đều tắt/trống'}) "
             f"— giữ {len(findings)} findings offline")
        _append_vul_hosts(findings, global_vuln)
        return findings

    # B1) template local đã kiểm tra id qua -t (mỗi template một -t).
    # Bộ đếm chỉ cộng SAU khi findings đã ghi ra file thành công (bên dưới).
    nuclei_lines = []
    local_done = False
    if local:
        out = os.path.join(workdir, "nuclei.txt")
        extra = []
        for path, _ in local:
            extra += ["-t", path]
        lines, rc = _run_nuclei(targets_file, out, extra, cfg)
        nuclei_lines += lines
        if rc == 0:
            # Lượt template local kiểm tra TRỌN VẸN trên toàn bộ targets_file —
            # việc cộng len(urls) target chờ điều kiện "đã ghi file".
            local_done = True
        else:
            warn(f"[nuclei] lượt template local dừng sớm (rc={rc}) — "
                 f"không tính {len(urls)} target vào bộ đếm nuclei local")

    # B2) template cộng đồng qua -id (không trùng CVE đã chạy local)
    if community_ids and os.path.isdir(CVE_DIR):
        out = os.path.join(workdir, "nuclei_community.txt")
        lines, _rc = _run_nuclei(targets_file, out, ["-id", ",".join(community_ids)], cfg)
        nuclei_lines += lines

    # Rewrite URL ip:port → domain cho findings nuclei trước khi dedupe/ghi.
    nuclei_lines = [rewrite_line(l) for l in nuclei_lines]
    findings = file_io.dedupe_sort(version_lines + nuclei_lines)
    # Append CHỈ phần nuclei chưa có ở bước A — version_lines đã append vào
    # vuln_version.txt ở bước A rồi; append cả findings sẽ ghi trùng dòng
    # [version] lần 2. Dedupe theo (CVE-ID, host) thay vì so cả dòng: trước
    # đây dòng version `[version] url ... CVE-X ...` không bao giờ trùng dòng
    # nuclei `url [cve:X] ...` → cùng 1 lỗi bị ghi 2 lần (vuln_version + vuln).
    new_lines = dedupe_against(nuclei_lines, version_lines)
    # Ghi dự phòng: global fail → bản tạm workdir/vuln_fallback.txt giữ finding.
    vuln_written = _append_ok(global_vuln, new_lines,
                              fallback=os.path.join(workdir, "vuln_fallback.txt"))
    if local_done:
        if vuln_written:
            # Bộ đếm cộng dồn: target đã kiểm tra bằng nuclei template local
            # VÀ findings đã ghi ra file thành công (utils/stats.py).
            stats.add_nuclei_local_done(targets=len(urls), runs=1)
        else:
            warn(f"[nuclei] không ghi được findings vào {global_vuln} — "
                 f"không tính {len(urls)} target vào bộ đếm nuclei local")
    _append_vul_hosts(findings, global_vuln)
    info(f"stage3: {len(findings)} findings "
         f"(offline {len(version_lines)} + nuclei mới {len(new_lines)})")
    return findings



