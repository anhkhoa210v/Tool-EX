"""LỌC TARGET RÁC: output/t.txt → output/t1.txt (NÂNG CẤP).

Mục đích: t.txt là file APPEND thô — mỗi CIDR resolver append thêm domain,
nên dần dần tích "rác": dòng rỗng, URL còn scheme/path, IP literal (fallback
khi không phân giải được), hostname không hợp lệ, domain chết (DNS không phân
giải được)… Module này đọc t.txt, LỌC SẠCH và ghi kết quả vào t1.txt để exploit
hook (`sofia/sofia.py -t t1.txt`) chỉ khai thác target sạch.

Hoạt động:
  * APPEND-ONLY: t1.txt KHÔNG BAO GIỜ bị ghi đè/xoá — chỉ append domain hợp lệ
    MỚI (chưa có trong t1.txt). Điều này giữ đúng ngữ nghĩa mốc dòng của
    exploit hook (exploit_state.json đếm dòng đã xử lý theo file): dòng cũ
    không đổi vị trí/số lượng, `min_new_lines` vẫn tính đúng số dòng mới.
  * Chuẩn hoá từng dòng t.txt: bỏ scheme (http/https), userinfo, port, path,
    query, dấu "." cuối; lowercase. Dòng ghim CVE ("domain|CVE-…") nếu lỡ lọt
    vào t.txt vẫn giữ nguyên phần CVE.
  * Loại rác cấu trúc: dòng rỗng/comment, hostname không khớp chuẩn (label
    1-63 ký tự, ký tự hợp lệ, TLD chữ ≥ 2), "*.wildcard", "localhost", tên
    không có dấu chấm, IP literal (drop_ip=true — target là domain cửa hàng,
    IP rác thường là fallback không phân giải được).
  * Loại rác DNS (check_dns=true, mặc định TẮT vì chậm): domain không phân
    giải được (A/AAAA) bị coi là target rác — KHÔNG append vào t1.txt; lần
    lọc sau vẫn thử lại (vì chưa từng được append). Dùng ThreadPoolExecutor
    riêng để không chặn pipeline.
  * Mọi lỗi CHỈ LOG — không bao giờ làm chết vòng quét.

Cấu hình (config.yaml):
    t1_filter:
      enabled: true          # false = không lọc, exploit chỉ dùng vuln.txt
      source: t.txt          # tương đối output_dir — nguồn (file thô)
      dest: t1.txt           # tương đối output_dir — file sạch cho exploit
      drop_ip: true          # loại IP literal
      check_dns: false       # true = loại domain không phân giải được
      dns_workers: 50        # số thread DNS song song
      dns_timeout: 3.0       # giây chờ mỗi lookup (socket timeout toàn cục)

CHỈ DÙNG CHO MỤC ĐÍCH KIỂM THỬ BẢO MẬT ĐƯỢC UỶ QUYỀN.
"""
import concurrent.futures
import ipaddress
import os
import re
import socket
import urllib.parse

from utils import file_io
from utils.logger import info, success, warn

# Hostname hợp lệ: 1+ label [A-Za-z0-9] (+ "-" ở giữa), cách nhau ".", TLD cuối
# là chữ cái ≥ 2 ký tự. Không chấp nhận wildcard "*", dấu "_" hay ký tự lạ.
_HOST_RE = re.compile(
    r"^(?=.{1,253}\.?$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+"
    r"[a-z]{2,63}\.?$"
)

# Tên rác hay gặp trong PTR/SAN của hosting/máy quét — không phải cửa hàng.
_JUNK_NAMES = {
    "localhost", "localhost.localdomain", "example.com", "example.org",
    "example.net", "invalid", "test", "dummy", "placeholder",
}

# Label rác phổ biến trong PTR dải IP (vd 1-2-3-4.cpe.example) — còn hợp lệ
# về cú pháp nhưng là rác: chỉ gồm số + dấu gạch hoặc quá dài vô nghĩa.
_NUMERIC_LABEL_RE = re.compile(r"^[0-9-]+$")


def _normalize(raw):
    """1 dòng t.txt → hostname (kèm phần "|CVE-…" nếu có) hoặc None nếu rác.

    Chấp nhận: "shop.example.com", "https://shop.example.com/path?x=1",
    "shop.example.com:8443", "user:pass@shop.example.com",
    "shop.example.com.|CVE-2022-24086" (dòng ghim CVE).
    """
    line = (raw or "").strip()
    if not line or line.startswith("#"):
        return None
    # Tách phần ghim CVE (nếu có) — giữ nguyên khi trả về.
    pin = ""
    if "|" in line:
        head, _, tail = line.partition("|")
        tail = tail.strip()
        if tail:
            pin = "|" + tail
        line = head.strip()
    line = line.rstrip(".")
    # Có scheme → urlparse; không có scheme → coi cả dòng là host[:port].
    if "://" in line:
        try:
            host = urllib.parse.urlparse(line).hostname or ""
        except ValueError:
            return None
    else:
        # Bỏ userinfo (user:pass@) và port (:8443) — chỉ khi không là IPv6.
        line = line.split("@", 1)[-1]
        host = line.split("/", 1)[0]
        if not (host.startswith("[") and "]" in host):
            host = host.split(":", 1)[0]
        host = host.strip("[]")
    host = host.strip().strip(".").lower()
    if not host or host in _JUNK_NAMES:
        return None
    if not _HOST_RE.match(host):
        return None
    # Label ĐẦU toàn số/gạch (PTR rác kiểu "1-2-3-4.cpe.host") → rác.
    # (chỉ label đầu: PTR dải IP hay sinh tên này; domain thật hiếm khi mở đầu
    # bằng label chỉ gồm số và dấu gạch)
    if _NUMERIC_LABEL_RE.match(host.split(".")[0]):
        return None
    return host + pin


def _is_ip_literal(host):
    try:
        ipaddress.ip_address(host)
        return True
    except ValueError:
        return False


def _resolves(host, timeout):
    """DNS lookup A/AAAA — True nếu phân giải được, False nếu chết/rác."""
    old = socket.getdefaulttimeout()
    try:
        socket.setdefaulttimeout(timeout)
        socket.getaddrinfo(host, None)
        return True
    except (socket.gaierror, socket.timeout, OSError):
        return False
    finally:
        socket.setdefaulttimeout(old)


def _dns_filter(hosts, workers, timeout):
    """Lọc giữ lại domain phân giải được (song song, lỗi DNS cá nhân = loại)."""
    keep = set()
    with concurrent.futures.ThreadPoolExecutor(max_workers=max(1, workers)) as pool:
        for host, ok in zip(hosts, pool.map(lambda h: _resolves(h, timeout), hosts)):
            if ok:
                keep.add(host)
    return keep


def _existing_hosts(dest_path):
    """Set host ĐÃ có trong t1.txt (bỏ phần ghim CVE) — để append-only dedupe."""
    existing = set()
    if not os.path.exists(dest_path):
        return existing
    for line in file_io.read_lines(dest_path, strip_comments=False):
        host = line.split("|", 1)[0].strip().rstrip(".").lower()
        if host:
            existing.add(host)
    return existing


def refresh(cfg, context=""):
    """Lọc t.txt → t1.txt (append-only). Trả về số dòng MỚI ghi vào t1.txt.

    Gọi trước MỖI lượt exploit hook để `sofia.py -t t1.txt` luôn thấy target
    sạch nhất. Không bao giờ raise với caller.
    """
    fcfg = cfg.get("t1_filter") or {}
    try:
        if not fcfg.get("enabled", True):
            return 0
    except AttributeError:
        return 0

    output_dir = cfg["paths"]["output_dir"]
    source_name = str(fcfg.get("source") or "t.txt")
    dest_name = str(fcfg.get("dest") or "t1.txt")
    src = source_name if os.path.isabs(source_name) else os.path.join(output_dir, source_name)
    dest = dest_name if os.path.isabs(dest_name) else os.path.join(output_dir, dest_name)

    try:
        drop_ip = bool(fcfg.get("drop_ip", True))
        check_dns = bool(fcfg.get("check_dns", False))
        try:
            dns_workers = max(1, int(fcfg.get("dns_workers", 50)))
        except (TypeError, ValueError):
            dns_workers = 50
        try:
            dns_timeout = max(0.5, float(fcfg.get("dns_timeout", 3.0)))
        except (TypeError, ValueError):
            dns_timeout = 3.0

        raw_lines = file_io.read_lines(src)
        if not raw_lines:
            return 0

        cleaned = []  # giữ thứ tự xuất hiện trong t.txt (append-only an toàn)
        for raw in raw_lines:
            host = _normalize(raw)
            if not host:
                continue
            bare = host.split("|", 1)[0]
            if drop_ip and _is_ip_literal(bare):
                continue
            if host not in cleaned:
                cleaned.append(host)

        existing = _existing_hosts(dest)
        new_lines = [h for h in cleaned if h.split("|", 1)[0] not in existing]
        if check_dns and new_lines:
            bare_hosts = sorted({h.split("|", 1)[0] for h in new_lines})
            alive = _dns_filter(bare_hosts, dns_workers, dns_timeout)
            dead = [h for h in bare_hosts if h not in alive]
            if dead:
                info(f"t1_filter[{context}]: loại {len(dead)} domain DNS chết "
                     f"(không phân giải được)")
            new_lines = [h for h in new_lines if h.split("|", 1)[0] in alive]

        if not new_lines:
            info(f"t1_filter[{context}]: {src} → {dest}: 0 dòng mới "
                 f"(tổng hợp lệ {len(cleaned)}, đã có {len(existing)} trong {dest})")
            return 0

        # APPEND-ONLY — không đụng phần cũ của t1.txt (mốc exploit vẫn đúng).
        file_io.append_lines(dest, new_lines)
        success(f"t1_filter[{context}]: {src} → {dest}: +{len(new_lines)} target "
                f"sạch (tổng t1.txt: {len(existing) + len(new_lines)})")
        return len(new_lines)
    except Exception as exc:  # noqa: BLE001 — lọc lỗi không được làm chết pipeline
        warn(f"t1_filter[{context}] lỗi: {exc}")
        return 0


def run_standalone(cfg):
    """Chạy lọc 1 lần rồi in thống kê (dùng cho --filter-t1 của main.py)."""
    added = refresh(cfg, context="standalone")
    dest_name = str((cfg.get("t1_filter") or {}).get("dest") or "t1.txt")
    dest = dest_name if os.path.isabs(dest_name) else os.path.join(cfg["paths"]["output_dir"], dest_name)
    total = 0
    if os.path.exists(dest):
        total = sum(1 for line in file_io.read_lines(dest) if line)
    info(f"t1_filter: t1.txt hiện có {total} target sạch (+{added} dòng mới lần này)")
    return added