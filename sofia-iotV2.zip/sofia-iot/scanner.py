"""
Giai đoạn 1: Fingerprint + detect thiết bị.

    tcp_connect(host, port)   — re-check cổng mở (kết quả zmap/masscan có thể cũ)
    http_get(host, port)      — request cơ bản, bắt banner/server header (tự TLS trên 443/8443/...)
    fingerprint(host, port)   — đoán thiết bị → chọn CVE phù hợp

Nâng cấp chống bỏ sót / chống nhận diện sai (bản nâng cấp):
  * fingerprint đa tín hiệu: server header + www-authenticate + title +
    body markers + TLS cert (CN/SAN/issuer) + banner cổng-specific +
    extra-path probes — còn ít nhất 1 tín hiệu là có device (giảm miss).
  * Confidence 0..1 theo TRỌNG SỐ từng loại tín hiệu (server header mạnh hơn
    body marker) — giảm nhận diện sai.
  * TLS (FINGERPRINT_TLS): http_get tự wrap TLS trên cổng 443/8443/10443/9443;
    đọc CN/SAN/issuer từ chứng chỉ (không validate chain — IoT hay self-signed).
  * Banner cổng-specific (FINGERPRINT_BANNER): TR-069 (7547), SIP (5060),
    telnet (23), SSH/FTP/SMTP/POP3, VNC — probe nhẹ, giữ tối đa MAX_BANNER_BYTES.
  * Extra paths (FINGERPRINT_EXTRA_PATHS: /login.asp, /web/login.html,
    /userRpm/...) probe khi body "/" chưa có marker — giảm miss trang login riêng.
  * Ghi chú WAF (evasion.waf_detect) để pipeline không kết luận nhầm
    "hết lỗ hổng" khi thực ra bị WAF chặn.
  * retry_call() — thử lại khi kết nối flaky/timeout (FINGERPRINT_RETRY).
"""

import logging
import socket
import time

from config import (
    EVASION_MODE,
    FINGERPRINT_BANNER,
    FINGERPRINT_EXTRA_PATHS,
    FINGERPRINT_RETRY,
    FINGERPRINT_TLS,
    MAX_BANNER_BYTES,
    RETRY_ATTEMPTS,
    RETRY_BACKOFF,
    TIMEOUT,
    USER_AGENT,
)
import evasion
import tlsutil

log = logging.getLogger("sofia.scanner")

MAX_BODY = 1 << 20            # 1 MB tối đa cho body
_TLS_PORTS = (443, 8443, 9443, 10443)   # cổng thử TLS cho HTTP + đọc cert

# Trọng số confidence theo loại tín hiệu (server header là tín hiệu mạnh nhất)
_SIGNAL_WEIGHTS = {
    "server": 0.80,
    "tls": 0.55,
    "title": 0.50,
    "banner": 0.45,
    "body": 0.45,
    "extra": 0.45,
    "www-auth": 0.40,
    "redirect": 0.30,
}
_CONF_DENOM = 2.0             # confidence = tổng trọng số / _CONF_DENOM (capped 1.0)

# ══ Bảng marker ───────────────────────────────────────────────────────────
# Body markers → nhận diện thiết bị/nền tảng (tín hiệu phụ khi header mơ hồ)
_BODY_MARKERS = [
    ("hikvision", ["hikvision", "webclient", "netdyn", "digicap"]),
    ("tp-link", ["tp-link", "tplink", "archer"]),
    ("omada", ["omada"]),
    ("tenda", ["tenda"]),
    ("d-link", ["d-link", "dlink", "dir-"]),
    ("zte", ["zte", "zxhn", "f609", "f670", "f663"]),
    ("dvr", ["dvr", "nvr", "xvr", "realplay", "webs"]),
    ("goahead", ["goahead", "goahead-webs"]),
    ("boa", ["boa", "webserver"]),
    ("lighttpd", ["lighttpd"]),
    ("draytek", ["draytek", "vigor"]),
    ("edimax", ["edimax", "ic-7100"]),
    ("vacron", ["vacron", "nvr"]),
    ("telesquare", ["telesquare", "sdt-cw3b1", "sdt-cw"]),
    ("sonicwall", ["sonicwall", "gms", "sma"]),
    ("struts", ["struts", "apache tomcat", "tomcat"]),
    ("huawei", ["huawei", "hg532", "hg5"]),
    ("mikrotik", ["mikrotik", "routeros", "winbox"]),
    ("dahua", ["dahua", "xvr", "smartpss"]),
    ("netgear", ["netgear", "wndr", "r6400", "r7000", "r6700"]),
    ("linksys", ["linksys", "wrt1200", "wrt1900", "wrt32x", "smart wifi"]),
    ("ubiquiti", ["ubiquiti", "unifi", "unifios", "airos", "airmax"]),
    ("asus", ["asus", "rt-ac", "rt-ax", "rt-n"]),
    ("ruijie", ["ruijie", "rg-ew", "rg-wlan"]),
    ("zyxel", ["zyxel"]),
    ("fortinet", ["fortinet", "fortios", "fortigate"]),
    ("cisco", ["cisco", "ios"]),
    ("xiongmai", ["xiongmai", "xmeye"]),
    ("grandstream", ["grandstream"]),
    ("fritz", ["fritz!box", "avm"]),
    ("openwrt", ["openwrt", "luci"]),
]

_TITLE_MARKERS = [
    ("hikvision", ["hikvision"]),
    ("telesquare", ["sdt-cw3b1", "telesquare"]),
    ("tp-link", ["tp-link", "tplink", "archer", "wr940", "wr841", "wr740"]),
    ("tenda", ["tenda", "hg9"]),
    ("d-link", ["d-link", "dlink", "dir-859", "dir-820", "dir-823"]),
    ("dvr", ["dvr", "nvr", "xvr", "camera"]),
    ("draytek", ["draytek", "vigor"]),
    ("edimax", ["edimax"]),
    ("zte", ["zte", "zxhn"]),
    ("sonicwall", ["sonicwall", "gms"]),
    ("huawei", ["huawei", "hg532"]),
    ("mikrotik", ["mikrotik", "routeros", "winbox"]),
    ("dahua", ["dahua"]),
    ("netgear", ["netgear", "wndr"]),
    ("ubiquiti", ["ubiquiti", "unifi", "airos"]),
    ("asus", ["asus"]),
    ("zyxel", ["zyxel"]),
    ("fortinet", ["fortinet", "fortios"]),
    ("cisco", ["cisco"]),
    ("fritz", ["fritz!box", "avm"]),
    ("openwrt", ["openwrt"]),
]

# Server header → vendor (thứ tự quan trọng: cụ thể trước, generic sau)
_SERVER_MARKERS = [
    ("hikvision", ["hikvision"]),
    ("goahead", ["goahead"]),
    ("boa", ["boa"]),
    ("d-link", ["d-link", "dlink"]),
    ("tp-link", ["tp-link", "t-link"]),
    ("tenda", ["tenda"]),
    ("fritz", ["fritz"]),
    ("huawei", ["huawei"]),
    ("dahua", ["dahua"]),
    ("ubiquiti", ["ubiquiti", "unifi"]),
    ("mikrotik", ["mikrotik", "routeros"]),
    ("zyxel", ["zyxel"]),
    ("draytek", ["draytek"]),
    ("sonicwall", ["sonicwall"]),
    ("mini_httpd", ["mini_httpd"]),
    ("lighttpd", ["lighttpd"]),
    ("nginx", ["nginx"]),
    ("apache", ["apache"]),
    ("openwrt", ["openwrt"]),
    ("jetty", ["jetty"]),
    ("iis", ["microsoft-iis", "iis/"]),
    ("httpd", ["httpd"]),
]

# Banner cổng-specific → vendor/nền tảng (khi HTTP im lặng)
_BANNER_MARKERS = [
    ("dropbear", ["dropbear"]),
    ("routeros", ["routeros", "mikrotik"]),
    ("draytek", ["draytek"]),
    ("huawei", ["huawei"]),
    ("fritz", ["fritz!box", "avm"]),
    ("zyxel", ["zyxel"]),
    ("tr069", ["tr-069", "tr069", "cwmp"]),
    ("sip", ["sip/2.0", "sip server"]),
    ("dahua", ["dahua"]),
    ("dvr", ["dvr", "nvr"]),
    ("openwrt", ["openwrt"]),
]

# Probe gửi khi grab banner theo cổng (b"" = chỉ đọc, server tự gửi banner)
_PORT_PROBES = {
    21: b"",        # FTP greeting
    22: b"",        # SSH greeting
    23: b"",        # telnet banner
    25: b"",        # SMTP greeting
    110: b"",       # POP3 greeting
    143: b"",       # IMAP greeting
    5060: b"\r\n",  # SIP — elicit 400 response kèm server header
    5900: b"",      # VNC RFB greeting
    7547: b"POST / HTTP/1.0\r\nHost: x\r\nContent-Length: 0\r\n\r\n",  # TR-069/SOAP
}

# Tên marker → nhãn vendor hiển thị (thêm vào report)
_VENDORS = {
    "hikvision": "Hikvision", "tp-link": "TP-Link", "omada": "TP-Link Omada",
    "tenda": "Tenda", "d-link": "D-Link", "zte": "ZTE", "huawei": "Huawei",
    "dvr": "DVR/NVR", "goahead": "GoAhead", "boa": "Boa",
    "lighttpd": "Lighttpd", "draytek": "DrayTek", "edimax": "Edimax",
    "vacron": "Vacron", "telesquare": "Telesquare", "sonicwall": "SonicWall",
    "struts": "Apache Struts", "mikrotik": "MikroTik", "dahua": "Dahua",
    "netgear": "Netgear", "linksys": "Linksys", "ubiquiti": "Ubiquiti",
    "asus": "ASUS", "ruijie": "Ruijie", "zyxel": "Zyxel",
    "fortinet": "Fortinet", "cisco": "Cisco", "xiongmai": "Xiongmai",
    "grandstream": "Grandstream", "fritz": "FRITZ!Box (AVM)",
    "openwrt": "OpenWrt", "dropbear": "Dropbear (router nhúng)",
    "sip": "SIP/VoIP", "tr069": "TR-069 (CWMP)", "mini_httpd": "mini_httpd (IPCam)",
    "apache": "Apache", "nginx": "Nginx", "iis": "IIS", "jetty": "Jetty",
}


def tcp_connect(host, port, timeout=TIMEOUT):
    """Re-check cổng mở (kết quả zmap/masscan có thể cũ)."""
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


def retry_call(fn, *args, attempts=RETRY_ATTEMPTS, backoff=RETRY_BACKOFF,
               enabled=FINGERPRINT_RETRY, **kwargs):
    """
    Gọi fn(*args, **kwargs), thử lại tối đa `attempts` lần khi lỗi
    transport (kết nối thất bại/timeout) — chống bỏ sót host flaky.
    Trả về (result, n_attempts). result=None nếu cạn lần thử.
    """
    if not enabled:
        return fn(*args, **kwargs), 1
    last = None
    for i in range(1, attempts + 1):
        try:
            res = fn(*args, **kwargs)
            if res is not None:
                return res, i
            last = res
        except (OSError, ValueError) as exc:
            last = None
            log.debug("Thử lại %s (lần %d/%d): %r", getattr(fn, "__name__", fn), i, attempts, exc)
        if i < attempts:
            time.sleep(backoff * i)
    return last, attempts


def http_get(host, port, path="/", timeout=TIMEOUT, headers=None):
    """
    Request HTTP cơ bản. Trả về (status, headers, body):
      status  — int hoặc None nếu lỗi
      headers — dict (key lowercase)
      body    — str latin-1 (không làm hỏng banner)
    Tự wrap TLS khi port ∈ _TLS_PORTS và FINGERPRINT_TLS=True (HTTPS-only device).
    Khi EVASION_MODE=True: xoay UA + header giả (WAF-bypass).
    """
    use_tls = FINGERPRINT_TLS and port in _TLS_PORTS
    raw = None
    try:
        raw = socket.create_connection((host, port), timeout=timeout)
        raw.settimeout(timeout)
        if use_tls:
            ctx = tlsutil.client_context()
            sock = ctx.wrap_socket(raw, server_hostname=host)
        else:
            sock = raw
        hdrs = headers or {}
        if EVASION_MODE:
            hdrs = evasion.evasive_headers(hdrs, host, port)
        else:
            hdrs = dict(hdrs)
            hdrs.setdefault("User-Agent", USER_AGENT)
            hdrs.setdefault("Host", "%s:%d" % (host, port))
        req = "GET %s HTTP/1.1\r\n" % path
        req += "".join("%s: %s\r\n" % (k, v) for k, v in hdrs.items())
        req += "Connection: close\r\n\r\n"
        sock.sendall(req.encode())
        resp = b""
        while len(resp) < MAX_BODY:
            chunk = sock.recv(4096)
            if not chunk:
                break
            resp += chunk
        sock.close()
    except OSError:
        if raw is not None:
            try:
                raw.close()
            except OSError:
                pass
        return None, {}, ""

    text = resp.decode("latin-1", errors="replace")
    head, sep, body = text.partition("\r\n\r\n")
    if not sep:
        # Không có phân tách HTTP => không phải HTTP/1.x hợp lệ.
        # Nếu không bắt đầu bằng HTTP/ thì coi toàn bộ là banner thuần
        # (để fingerprint nhận diện qua `banner` thay vì bỏ qua).
        head, body = text, ("" if text.lstrip().startswith("HTTP/") else text)

    status = None
    headers = {}
    lines = head.split("\r\n")
    if lines and lines[0].startswith("HTTP/"):
        try:
            status = int(lines[0].split()[1])
        except (IndexError, ValueError):
            status = None
    for line in lines[1:]:
        if ":" in line:
            k, v = line.split(":", 1)
            headers[k.strip().lower()] = v.strip()
    return status, headers, body


def _match_markers(text, markers):
    """Trả về list tên markers xuất hiện trong text (lowercase)."""
    low = text.lower()
    hits = []
    for name, kws in markers:
        if any(kw in low for kw in kws):
            hits.append(name)
    return hits


def _extract_title(body):
    """Rút <title>...</title> đầu tiên trong body (tối đa 80 ký tự)."""
    for line in body.splitlines()[:60]:
        low = line.lower()
        if "<title>" in low:
            start = low.find("<title>") + 7
            end = low.find("</title>", start)
            if end > start:
                return body[start:end].strip()[:80]
    return ""


def _signal_marker(sig):
    """Tên marker từ signal ("" nếu signal không gắn marker cụ thể)."""
    if sig.startswith("extra:"):
        parts = sig.split(":")
        return parts[2] if len(parts) >= 3 else ""
    if (sig.startswith("tls:cn=") or sig.startswith("banner:raw")
            or sig.startswith("redirect:") or sig.startswith("www-auth:")):
        return ""
    return sig.split(":", 1)[1] if ":" in sig else ""


# ══ TLS cert (CN/SAN/issuer) — parsing DER không cần thư viện ngoài ──────
def _tls_cert_info(host, port, timeout=TIMEOUT):
    """
    Bắt chứng chỉ TLS: CN/O (subject), SAN (DNS + IP), issuer organization.
    Không xác thực chain — chỉ dùng CN/SAN để fingerprint (IoT hay self-signed).
    Trả về dict hoặc None nếu không kết nối TLS được.
    """
    ctx = tlsutil.client_context()
    try:
        with socket.create_connection((host, port), timeout=timeout) as raw:
            raw.settimeout(timeout)
            with ctx.wrap_socket(raw, server_hostname=host) as tls:
                der = tls.getpeercert(binary_form=True)
        if not der:
            return None
        return _parse_cert_der(der)
    except OSError:
        return None
    except Exception:
        log.debug("Không parse được cert TLS %s:%d", host, port)
        return None


def _der_len(data, idx):
    """Đọc độ dài DER tại idx → (length, next_idx). Hỗ trợ short/long form."""
    if data[idx] < 0x80:
        return data[idx], idx + 1
    n = data[idx] & 0x7F
    if n == 0:                      # indefinite — không dùng trong cert chuẩn
        raise ValueError("indefinite length")
    length = 0
    for i in range(1, n + 1):
        length = (length << 8) | data[idx + i]
    return length, idx + 1 + n


def _skip_tlv(data, idx):
    """Bỏ qua 1 TLV (tag+len+value) → idx sau value."""
    length, nidx = _der_len(data, idx + 1)
    return nidx + length


def _parse_name(data, idx):
    """
    Parse Name (SEQUENCE OF RDN) → dict {oid_tuples: [values]}, idx sau Name.
    Thu thập CN (2.5.4.3) và O (2.5.4.10) là đủ cho fingerprint.
    """
    attrs = {}
    if data[idx] != 0x30:
        raise ValueError("Name khong phai SEQUENCE")
    length, idx = _der_len(data, idx + 1)
    end = idx + length
    _CN_OID = bytes([0x55, 0x04, 0x03])
    _O_OID = bytes([0x55, 0x04, 0x0A])
    while idx < end:
        if data[idx] != 0x31:        # SET OF
            raise ValueError("RDN khong phai SET")
        slen, sidx = _der_len(data, idx + 1)
        set_end = sidx + slen
        while sidx < set_end:
            if data[sidx] != 0x30:   # AttributeTypeAndValue SEQUENCE
                raise ValueError("ATV khong phai SEQUENCE")
            alen, aidx = _der_len(data, sidx + 1)
            a_end = aidx + alen
            if data[aidx] != 0x06:   # OID
                raise ValueError("Thieu OID")
            olen, oidx = _der_len(data, aidx + 1)
            oid = data[oidx:oidx + olen]
            aidx = oidx + olen
            tag = data[aidx]
            vlen, vidx = _der_len(data, aidx + 1)
            val = data[vidx:vidx + vlen]
            try:
                s = val.decode("utf-8" if tag in (0x0C, 0x1E) else "latin-1")
            except UnicodeDecodeError:
                s = val.decode("latin-1", errors="replace")
            if oid == _CN_OID:
                attrs["CN"] = s
            elif oid == _O_OID:
                attrs["O"] = s
            sidx = a_end
        idx = set_end
    return attrs, idx


def _parse_san(data):
    """Parse SubjectAltName (SEQUENCE OF GeneralName) → list DNS + IP."""
    names = []
    i = 0
    if data and data[0] == 0x30:
        length, i = _der_len(data, 1)
        end = i + length
    else:
        end = len(data)
    while i < end:
        tag = data[i]
        length, nidx = _der_len(data, i + 1)
        val = data[nidx:nidx + length]
        if tag == 0x82:                              # dNSName (IA5String)
            names.append(val.decode("latin-1"))
        elif tag == 0x87:                            # iPAddress
            if len(val) == 4:
                names.append(socket.inet_ntop(socket.AF_INET, val))
            elif len(val) == 16:
                names.append(socket.inet_ntop(socket.AF_INET6, val))
        i = nidx + length
    return names


def _parse_cert_der(der):
    """
    Rút {cn, o, san, issuer_o} từ chứng chỉ X.509 dạng DER.
    Cấu trúc: Certificate=SEQUENCE{ TBSCertificate, sigAlg, sig }
    TBSCertificate: version(opt [0]), serial, signature, issuer,
                    validity, subject, spki, [1]?, [2]?, [3] extensions
    """
    idx = 0
    if der[idx] != 0x30:
        raise ValueError("khong phai SEQUENCE")
    _length, idx = _der_len(der, idx + 1)
    if der[idx] != 0x30:
        raise ValueError("thieu TBSCertificate")
    tbs_len, idx = _der_len(der, idx + 1)
    tbs_end = idx + tbs_len

    if der[idx] == 0xA0:                 # version [0] EXPLICIT (optional)
        idx = _skip_tlv(der, idx)
    if der[idx] != 0x02:                 # serialNumber INTEGER
        raise ValueError("thieu serial")
    idx = _skip_tlv(der, idx)
    if der[idx] != 0x30:                 # signature AlgorithmIdentifier
        raise ValueError("thieu signature")
    idx = _skip_tlv(der, idx)
    if der[idx] != 0x30:                 # issuer Name
        raise ValueError("thieu issuer")
    iss, idx = _parse_name(der, idx)
    if der[idx] != 0x30:                 # validity SEQUENCE
        raise ValueError("thieu validity")
    idx = _skip_tlv(der, idx)
    if der[idx] != 0x30:                 # subject Name
        raise ValueError("thieu subject")
    subj, idx = _parse_name(der, idx)

    # SPKI (SEQUENCE) + optional unique IDs + extensions [3]
    if der[idx] != 0x30:                 # subjectPublicKeyInfo
        raise ValueError("thieu SPKI")
    idx = _skip_tlv(der, idx)

    san = []
    while idx < tbs_end:
        tag = der[idx]
        if tag == 0xA3:                  # [3] EXPLICIT extensions
            _plen, eidx = _der_len(der, idx + 1)
            ext_list_end = eidx + _plen
            while eidx < ext_list_end:
                if der[eidx] != 0x30:    # Extension SEQUENCE
                    break
                _elen, i2 = _der_len(der, eidx + 1)
                ext_end = i2 + _elen
                if der[i2] == 0x06:      # extnID OID
                    _olen, i3 = _der_len(der, i2 + 1)
                    oid = der[i3:i3 + _olen]
                    i3 += _olen
                    if der[i3] == 0x01:  # critical BOOLEAN (optional)
                        i3 = _skip_tlv(der, i3)
                    if der[i3] == 0x04 and oid == bytes([0x55, 0x1D, 0x11]):
                        _vlen, i4 = _der_len(der, i3 + 1)
                        san = _parse_san(der[i4:i4 + _vlen])
                eidx = ext_end
            break
        elif tag in (0x81, 0x82):        # issuer/subjectUniqueID (optional)
            idx = _skip_tlv(der, idx)
        else:
            break

    return {
        "cn": subj.get("CN", ""),
        "o": subj.get("O", ""),
        "san": san,
        "issuer_o": iss.get("O", ""),
    }


def _grab_banner(host, port, timeout=TIMEOUT, max_bytes=MAX_BANNER_BYTES):
    """
    Probe banner cổng-specific khi HTTP mờ nhạt (TR-069, SIP, telnet, SSH...).
    Gửi probe tối đa 1 lần (xem _PORT_PROBES) rồi đọc tới MAX_BANNER_BYTES.
    """
    probe = _PORT_PROBES.get(port)
    if probe is None:
        return ""
    try:
        with socket.create_connection((host, port), timeout=timeout) as raw:
            raw.settimeout(timeout)
            if probe:
                try:
                    raw.sendall(probe)
                except OSError:
                    return ""
            data = b""
            while len(data) < max_bytes:
                try:
                    chunk = raw.recv(1024)
                except socket.timeout:
                    break
                except OSError:
                    break
                if not chunk:
                    break
                data += chunk
            return data.decode("latin-1", errors="replace")
    except OSError:
        return ""


def _probe_extra_paths(host, port, timeout=TIMEOUT):
    """
    Quét FINGERPRINT_EXTRA_PATHS khi body "/" chưa có marker nào.
    Trả về list dict {path, status, title, server, markers} (chỉ path phản hồi).
    """
    def _add_marker(marks, name):
        """Thêm marker giữ thứ tự bảng (specific trước) — không trùng."""
        if name not in marks:
            marks.append(name)

    results = []
    for path in FINGERPRINT_EXTRA_PATHS:
        st, hdrs, bd = retry_call(http_get, host, port, path, timeout,
                                  attempts=2)[0]
        if st is None:
            continue
        sample = bd[:20000]
        marks = []
        for name in _match_markers(sample, _BODY_MARKERS):
            _add_marker(marks, name)
        t = _extract_title(bd)
        for name, kws in _TITLE_MARKERS:
            if any(kw in t.lower() for kw in kws):
                _add_marker(marks, name)
        srv = (hdrs.get("server") or "").lower()
        for name, kws in _SERVER_MARKERS:
            if any(kw in srv for kw in kws):
                _add_marker(marks, name)
        results.append({"path": path, "status": st, "title": t,
                        "server": srv, "markers": list(marks)})
    return results


# ══ Fingerprint chính ────────────────────────────────────────────────────
def fingerprint(host, port, timeout=TIMEOUT):
    """
    Đoán thiết bị từ đa tín hiệu → danh sách CVE ứng viên.

    Tín hiệu (gộp union, giảm miss):
      1. server header          (mạnh nhất)  5. redirect (3xx)
      2. www-authenticate       (basic)
      3. title
      4. body markers
      6. TLS cert CN/SAN/issuer (FINGERPRINT_TLS, port ∈ _TLS_PORTS)
      7. banner cổng-specific   (FINGERPRINT_BANNER, khi HTTP im lặng)
      8. extra paths           (FINGERPRINT_EXTRA_PATHS, khi body "/" trống)
    Confidence 0..1 theo trọng số tín hiệu (giảm nhận diện sai).
    Ghi chú WAF qua evasion.waf_detect (status/header/body).
    """
    status, headers, body = retry_call(http_get, host, port, "/", timeout,
                                       attempts=RETRY_ATTEMPTS)[0]
    server = (headers.get("server") or "").lower()
    www_auth = (headers.get("www-authenticate") or "").lower()
    location = (headers.get("location") or "").lower()
    title = _extract_title(body)
    body_sample = body[:20000]

    signals = []                 # tín hiệu nhận diện đã khớp (kèm loại)
    candidates = set()
    markers = set()
    http_ok = status is not None or bool(headers)   # thực sự là HTTP response

    # ── Tín hiệu 1: server header ──────────────────────────────────────
    for name, kws in _SERVER_MARKERS:
        if any(kw in server for kw in kws):
            signals.append("server:%s" % name)
            candidates.update(_name_to_cves(name))
            markers.add(name)

    # ── Tín hiệu 2: www-authenticate ───────────────────────────────────
    if "basic" in www_auth:
        signals.append("www-auth:basic")
        candidates.add("CVE-2021-36260")

    # ── Tín hiệu 3: title ──────────────────────────────────────────────
    for name, kws in _TITLE_MARKERS:
        if any(kw in title.lower() for kw in kws):
            signals.append("title:%s" % name)
            candidates.update(_name_to_cves(name))
            markers.add(name)

    # ── Tín hiệu 4: body markers (trang chính) ─────────────────────────
    for name in _match_markers(body_sample, _BODY_MARKERS):
        signals.append("body:%s" % name)
        candidates.update(_name_to_cves(name))
        markers.add(name)

    # ── Tín hiệu 5: redirect (3xx) ─────────────────────────────────────
    if status and 300 <= status < 400 and location:
        target = location.split("/")[1] if "/" in location else location
        signals.append("redirect:%s" % target)
        if "dvr" in location or "login" in location:
            candidates.update(["CVE-2024-3721", "CVE-2025-34043"])

    # ── Tín hiệu 6: TLS cert (CN/SAN) — FINGERPRINT_TLS ────────────────
    tls = None
    if FINGERPRINT_TLS and port in _TLS_PORTS:
        tls = _tls_cert_info(host, port, timeout)
        if tls:
            if tls.get("cn"):
                signals.append("tls:cn=%s" % tls["cn"][:60])
            cn_san = "%s %s" % (tls.get("cn") or "", " ".join(tls.get("san") or []))
            for name in _match_markers(cn_san, _BODY_MARKERS):
                signals.append("tls:%s" % name)
                candidates.update(_name_to_cves(name))
                markers.add(name)

    # ── Tín hiệu 7: banner cổng-specific — FINGERPRINT_BANNER ────────
    banner = ""
    if FINGERPRINT_BANNER and port not in _TLS_PORTS:
        if not http_ok:
            # không phải HTTP: body thô chính là banner; im lặng thì probe cổng
            banner = body[:MAX_BANNER_BYTES] if body else _grab_banner(host, port, timeout)
        elif port in _PORT_PROBES:
            # port quen thuộc (7547/5060/...) — body có thể là SOAP/SIP banner
            banner = body[:MAX_BANNER_BYTES]
        if banner:
            low = banner.lower()
            for name, kws in _BANNER_MARKERS:
                if any(kw in low for kw in kws):
                    signals.append("banner:%s" % name)
                    candidates.update(_name_to_cves(name))
                    markers.add(name)
            if not any(s.startswith("banner:") for s in signals):
                signals.append("banner:raw")   # có banner nhưng chưa nhận diện

    # ── Tín hiệu 8: extra paths — khi body "/" chưa có marker ──────────
    extra_paths = []
    if FINGERPRINT_EXTRA_PATHS and not markers and http_ok:
        extra_paths = _probe_extra_paths(host, port, timeout)
        for r in extra_paths:
            for m in r["markers"]:
                signals.append("extra:%s:%s" % (r["path"], m))
                candidates.update(_name_to_cves(m))
                markers.add(m)

    # ── Tổng hợp: device / vendor / confidence ────────────────────────
    device = "Unknown"
    pick = None
    for prefix in ("server", "tls", "banner", "title", "body", "extra",
                   "www-auth", "redirect"):
        pick = next((s for s in signals if s.startswith(prefix + ":")), None)
        if pick:
            break
    if pick:
        device = pick.split(":", 1)[1]
        if len(signals) > 1:
            device += " (+%d tín hiệu)" % (len(signals) - 1)

    vendor = ""
    if markers:
        strongest = next((_signal_marker(s) for s in signals if _signal_marker(s)), "")
        vendor = _VENDORS.get(strongest, strongest.title() or "Unknown")

    confidence = 0.0
    if signals:
        score = sum(_SIGNAL_WEIGHTS.get(s.split(":", 1)[0], 0.35)
                    for s in signals)
        confidence = min(1.0, score / _CONF_DENOM)

    waf_name = ""
    if status is not None:
        waf_name = evasion.waf_detect(status, headers, body_sample)[1]

    info = {
        "host": host, "port": port, "status": status,
        "server": server, "www_auth": www_auth, "title": title,
        "location": location, "device": device, "vendor": vendor,
        "confidence": round(confidence, 2), "signals": signals,
        "markers": sorted(markers), "waf": waf_name, "candidates": candidates,
        "tls": tls, "banner": banner, "extra_paths": extra_paths,
    }
    return info


def _name_to_cves(name):
    """Map tên thiết bị/nền tảng → danh sách CVE ứng viên."""
    return {
        "hikvision": ["CVE-2021-36260"],
        "tp-link": ["CVE-2023-1389", "CVE-2023-33538"],
        "tenda": ["CVE-2023-27240", "CVE-2022-30023"],
        "d-link": ["CVE-2025-29635", "CVE-2023-25280", "CVE-2019-17621"],
        "zte": ["CVE-2024-45414"],
        "dvr": ["CVE-2024-3721", "CVE-2025-34043"],
        "goahead": ["CVE-2021-36260", "CVE-2024-3721", "CVE-2025-34043"],
        "boa": ["CVE-2021-36260", "CVE-2024-3721"],
        "lighttpd": ["CVE-2017-17215", "CVE-2020-8515"],
        "draytek": ["CVE-2020-8515"],
        "edimax": ["CVE-2025-1316"],
        "vacron": ["CVE-2025-34043"],
        "telesquare": ["CVE-2021-46422"],
        "sonicwall": ["CVE-2018-9866"],
        "struts": ["CVE-2017-5638"],
        "huawei": ["CVE-2017-17215"],
        "mikrotik": ["CVE-2018-14847", "CVE-2023-30799"],
        "dahua": ["CVE-2021-33044", "CVE-2021-33045"],
        "netgear": ["CVE-2023-22945"],
        "ubiquiti": ["CVE-2021-3373"],
        "asus": ["CVE-2024-30877"],
        "ruijie": ["CVE-2021-35395"],
        "zyxel": ["CVE-2022-30525", "CVE-2020-29583"],
        "fortinet": ["CVE-2018-13379", "CVE-2022-40684"],
        "cisco": ["CVE-2018-0296"],
        "xiongmai": ["CVE-2018-9995"],
        "httpd": ["CVE-2025-29635", "CVE-2023-25280", "CVE-2019-17621"],
        "mini_httpd": ["CVE-2021-36260"],
    }.get(name, [])






