# -*- coding: utf-8 -*-
"""
Báo cáo HTML/CSV (P1 — UPGRADE_PROPOSAL mục 1.5).

Sinh `report.html` + `report.csv` từ danh sách findings (JSON list của verifier):
  - Mỗi finding được gắn severity: điểm CVSS v3 tĩnh từ config.CVE_SEVERITY
    + nhãn (Critical/High/Medium/Low/Info) theo SEVERITY_LEVELS.
  - Dedup toàn bộ theo (host, cve, port) — pipeline hiện mới dedup trong từng
    batch, nên khi gộp findings_all.json cần dedup lại ở đây.
  - Sort theo severity giảm dần → status → host để dễ review.

Chạy độc lập (tái sinh report từ kết quả cũ):
    python3 report.py [findings.json] [--out-dir results]

Hoặc dùng làm module: report.generate_report(findings, out_dir).
"""

import argparse
import csv
import html
import json
import logging
import os
import time

from config import CVE_SEVERITY, RESULTS_DIR, SEVERITY_LEVELS

log = logging.getLogger("sofia.report")

# Thứ tự hiển thị trạng thái trong HTML (ưu tiên quan trọng nhất lên đầu).
_STATUS_ORDER = {
    "RCE_CONFIRMED": 0,
    "RCE_PROBABLE": 1,
    "CONFIRMED": 2,
    "FINGERPRINT_ONLY": 3,
    "VULN_NO_EXEC": 4,
    "NO_RESPONSE": 5,
    "ERROR": 6,
}

REPORT_HTML = "report.html"
REPORT_CSV = "report.csv"


def severity_for(cve, score=None):
    """
    Trả về (cvss, label): lấy điểm từ config.CVE_SEVERITY (hoặc score nếu
    finding tự mang điểm); label theo SEVERITY_LEVELS. CVE không có bản ghi → 0.0/Info.
    """
    if score is None:
        score = CVE_SEVERITY.get(cve, 0.0)
    try:
        score = float(score or 0.0)
    except (TypeError, ValueError):
        score = 0.0
    for threshold, label in SEVERITY_LEVELS:
        if score >= threshold:
            return score, label
    return score, "Info"


def dedup_findings(findings):
    """
    Dedup danh sách findings theo (host, cve, port) — giữ bản ghi có mức kết
    luận mạnh nhất (RCE_CONFIRMED > ... > NO_RESPONSE), ổn định theo thứ tự xuất hiện.
    Trả về list mới (không sửa input).
    """
    rank = dict(_STATUS_ORDER)   # status → rank (0 = kết luận mạnh nhất)
    best = {}          # key -> (rank, index)
    out = []
    for i, f in enumerate(findings):
        key = (f.get("host", ""), f.get("cve", ""), f.get("port", f.get("port_used", "")))
        r = rank.get(f.get("status", ""), len(rank))
        if key not in best or r < best[key][0]:
            best[key] = (r, i)
    for _, i in sorted(best.values(), key=lambda kv: kv[1]):
        out.append(findings[i])
    return out


def _row(findings, idx, f):
    """Chuyển 1 finding thành dòng CSV/HTML chuẩn (kèm severity)."""
    cvss, label = severity_for(f.get("cve", ""), f.get("cvss"))
    return {
        "stt": idx + 1,
        "host": f.get("host", ""),
        "port": f.get("port", f.get("port_used", "")),
        "cve": f.get("cve", ""),
        "name": f.get("name", ""),
        "device": f.get("device", ""),
        "server": f.get("server", ""),
        "cvss": cvss,
        "severity": label,
        "status": f.get("status", ""),
        "waf": f.get("waf", ""),
        "evidence": (f.get("evidence") or "")[:500],
        "ts": f.get("ts", ""),
    }


def build_csv(findings, path):
    """Ghi report.csv (UTF-8 BOM cho Excel tiếng Việt). Trả về số dòng."""
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    fields = ["stt", "host", "port", "cve", "name", "device", "server",
              "cvss", "severity", "status", "waf", "evidence", "ts"]
    with open(path, "w", encoding="utf-8-sig", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        for idx, f in enumerate(findings):
            writer.writerow(_row(findings, idx, f))
    return len(findings)


def build_html(findings, path, title="Sofia-iot — Báo cáo quét", extra_meta=None):
    """
    Ghi report.html tự chứa (không phụ thuộc file ngoài): thống kê theo
    status + severity, bảng chi tiết sort theo severity/status, badge màu.
    Trả về dict thống kê (để main.py log).
    """
    rows = [_row(findings, i, f) for i, f in enumerate(findings)]
    rows.sort(key=lambda r: (-r["cvss"], _STATUS_ORDER.get(r["status"], 99), r["host"]))

    by_status = {}
    by_sev = {}
    for r in rows:
        by_status[r["status"]] = by_status.get(r["status"], 0) + 1
        by_sev[r["severity"]] = by_sev.get(r["severity"], 0) + 1

    sev_color = {
        "Critical": "#d0021b", "High": "#f5a623", "Medium": "#f8e71c",
        "Low": "#8b572a", "Info": "#9b9b9b",
    }

    def _badge(label):
        color = sev_color.get(label, "#9b9b9b")
        return ('<span class="badge" style="background:%s;color:#fff">%s</span>'
                % (color, html.escape(label)))

    stat_cells = "".join(
        '<div class="stat"><div class="n">%d</div><div class="k">%s</div></div>'
        % (n, html.escape(k)) for k, n in sorted(by_status.items(), key=lambda kv: (-kv[1], kv[0])))
    sev_cells = "".join(
        '<div class="stat"><div class="n">%d</div><div class="k">%s</div></div>'
        % (n, _badge(k)) for k, n in sorted(by_sev.items(), key=lambda kv: -kv[1]))

    trs = []
    for r in rows:
        trs.append(
            "<tr><td>%d</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td>"
            "<td>%s</td><td>%s</td><td>%.1f</td><td>%s</td><td>%s</td>"
            "<td>%s</td><td class='ev'>%s</td></tr>"
            % (r["stt"], html.escape(r["host"]), html.escape(str(r["port"])),
               html.escape(r["cve"]), html.escape(r["name"]), html.escape(r["device"]),
               html.escape(r["server"]), r["cvss"], _badge(r["severity"]),
               html.escape(r["status"]), html.escape(r["waf"]), html.escape(r["evidence"]))
        )
    body_rows = "\n".join(trs) if trs else \
        "<tr><td colspan='12' class='ev'>Không có finding nào.</td></tr>"

    meta = extra_meta or {}
    html_doc = """<!DOCTYPE html>
<html lang="vi"><head><meta charset="utf-8">
<title>{title}</title>
<style>
 body{{font-family:Segoe UI,Arial,sans-serif;margin:24px;color:#222}}
 h1{{font-size:20px}} h2{{font-size:15px;margin-top:28px;color:#555}}
 .meta{{color:#777;font-size:12px;margin-bottom:12px}}
 .stats{{display:flex;flex-wrap:wrap;gap:10px}}
 .stat{{border:1px solid #ddd;border-radius:6px;padding:8px 14px;min-width:90px}}
 .n{{font-size:20px;font-weight:bold}} .k{{font-size:12px;color:#666}}
 table{{border-collapse:collapse;width:100%;font-size:12px;margin-top:8px}}
 th,td{{border:1px solid #ddd;padding:5px 7px;text-align:left;vertical-align:top}}
 th{{background:#f4f4f4;position:sticky;top:0}}
 .badge{{border-radius:10px;padding:1px 8px;font-size:11px;white-space:nowrap}}
 .ev{{max-width:420px;word-break:break-word;color:#444}}
 tr:nth-child(even){{background:#fafafa}}
</style></head>
<body>
<h1>{title}</h1>
<div class="meta">Sinh lúc: {generated} · Tổng finding: {total} (sau dedup) · Nguồn: {source}
 · Mode: {mode} · Dải đã quét: {ranges}</div>
<h2>Thống kê theo trạng thái</h2><div class="stats">{stat_cells}</div>
<h2>Thống kê theo severity</h2><div class="stats">{sev_cells}</div>
<h2>Chi tiết (sort theo severity)</h2>
<table><thead><tr><th>#</th><th>Host</th><th>Port</th><th>CVE</th><th>Tên</th>
<th>Thiết bị</th><th>Server</th><th>CVSS</th><th>Severity</th><th>Status</th>
<th>WAF</th><th>Bằng chứng</th></tr></thead>
<tbody>{body_rows}</tbody></table>
</body></html>""".format(
        title=html.escape(title),
        generated=time.strftime("%Y-%m-%d %H:%M:%S %Z"),
        total=len(rows),
        source=html.escape(str(meta.get("source", "findings_all.json"))),
        mode=html.escape(str(meta.get("mode", ""))),
        ranges=html.escape(str(meta.get("ranges_done", ""))),
        stat_cells=stat_cells or "<div class='stat'>0</div>",
        sev_cells=sev_cells or "<div class='stat'>0</div>",
        body_rows=body_rows,
    )
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(html_doc)
    return {"total": len(rows), "by_status": by_status, "by_severity": by_sev}


def generate_report(findings, out_dir=RESULTS_DIR, title="Sofia-iot — Báo cáo quét",
                    extra_meta=None):
    """
    Sinh report.html + report.csv vào out_dir từ findings (đã dedup trước khi ghi).
    Trả về dict {"html": path, "csv": path, "stats": {...}}.
    """
    findings = dedup_findings(findings)
    html_path = os.path.join(out_dir, REPORT_HTML)
    csv_path = os.path.join(out_dir, REPORT_CSV)
    stats = build_html(findings, html_path, title=title, extra_meta=extra_meta)
    rows = build_csv(findings, csv_path)
    log.info("Report: %s (%d finding), %s (%d dòng)", html_path, stats["total"], csv_path, rows)
    return {"html": html_path, "csv": csv_path, "stats": stats}


def main(argv=None):
    p = argparse.ArgumentParser(description="Sinh report.html/report.csv từ findings JSON")
    p.add_argument("input", nargs="?", default="findings_all.json",
                   help="File findings JSON (mặc định findings_all.json)")
    p.add_argument("--out-dir", default=RESULTS_DIR, help="Thư mục xuất report")
    p.add_argument("--title", default="Sofia-iot — Báo cáo quét")
    args = p.parse_args(argv)

    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s | %(message)s")
    with open(args.input, "r", encoding="utf-8") as fh:
        findings = json.load(fh)
    meta = {"source": os.path.basename(args.input)}
    res = generate_report(findings, out_dir=args.out_dir, title=args.title, extra_meta=meta)
    print("HTML : %s" % res["html"])
    print("CSV  : %s" % res["csv"])
    print("Stats: %s" % json.dumps(res["stats"], ensure_ascii=False))
    return 0


if __name__ == "__main__":
    import sys
    sys.exit(main())


