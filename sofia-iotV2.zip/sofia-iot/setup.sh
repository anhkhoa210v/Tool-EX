#!/usr/bin/env bash
# setup.sh — Cài tối giản: masscan, zmap, python3-requests (Debian/Ubuntu)
# Chạy: bash setup.sh

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

log()  { echo -e "\033[1;34m[+]\033[0m $*"; }
ok()   { echo -e "\033[1;32m[OK]\033[0m $*"; }
warn() { echo -e "\033[1;33m[!]\033[0m $*"; }

# ─── 1. Cập nhật apt ─────────────────────────────────────────
log "Cập nhật apt cache..."
sudo apt-get update -qq

# ─── 2. Cài masscan ──────────────────────────────────────────
if ! command -v masscan >/dev/null 2>&1; then
    log "Cài masscan từ apt..."
    sudo apt-get install -y -qq masscan \
        || warn "apt không có masscan — thử build từ source..."
fi

if ! command -v masscan >/dev/null 2>&1; then
    log "Build masscan từ source..."
    sudo apt-get install -y -qq git make gcc libpcap-dev
    TMP="$(mktemp -d)"
    git clone --depth 1 https://github.com/robertdavidgraham/masscan.git "$TMP/masscan"
    make -C "$TMP/masscan" -j"$(nproc)"
    sudo make -C "$TMP/masscan" install
    rm -rf "$TMP"
fi

if command -v masscan >/dev/null 2>&1; then
    ok "masscan: $(command -v masscan)"
else
    warn "masscan: THIẾU"
fi

# ─── 3. Cài zmap ─────────────────────────────────────────────
if ! command -v zmap >/dev/null 2>&1; then
    log "Cài zmap từ apt..."
    sudo apt-get install -y -qq zmap \
        || warn "apt không có zmap — thử build từ source..."
fi

if ! command -v zmap >/dev/null 2>&1; then
    log "Build zmap từ source..."
    sudo apt-get install -y -qq git cmake make gcc \
        libgmp3-dev gengetopt libpcap-dev flex byacc libjson-c-dev libunistring-dev
    TMP="$(mktemp -d)"
    git clone --depth 1 https://github.com/zmap/zmap.git "$TMP/zmap"
    cmake -S "$TMP/zmap" -B "$TMP/zmap/build" -DENABLE_DEVELOPMENT=OFF
    make -C "$TMP/zmap/build" -j"$(nproc)"
    sudo make -C "$TMP/zmap/build" install
    rm -rf "$TMP"
fi

if command -v zmap >/dev/null 2>&1; then
    ok "zmap: $(command -v zmap)"
else
    warn "zmap: THIẾU"
fi

# ─── 4. Cài python3-requests ─────────────────────────────────
if python3 -c "import requests" >/dev/null 2>&1; then
    ok "python module 'requests': đã có"
else
    log "Cài python3-requests..."
    sudo apt-get install -y -qq python3-requests \
        || pip3 install requests 2>/dev/null \
        || pip3 install --break-system-packages requests
fi

if python3 -c "import requests" >/dev/null 2>&1; then
    ok "python module 'requests': OK"
else
    warn "python module 'requests': THIẾU"
fi

# ─── 5. Kiểm tra ─────────────────────────────────────────────
echo ""
log "Kiểm tra:"
MISSING=0
for b in masscan zmap; do
    command -v "$b" >/dev/null 2>&1 && ok "$b: $(command -v "$b")" || { warn "$b: THIẾU"; MISSING=1; }
done
python3 -c "import requests" >/dev/null 2>&1 && ok "requests: OK" || { warn "requests: THIẾU"; MISSING=1; }

echo ""
[ "$MISSING" -eq 0 ] && ok "✅ Xong!" || { warn "⚠ Còn thiếu — xem log trên"; exit 1; }