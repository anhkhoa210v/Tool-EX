# -*- coding: utf-8 -*-
"""
tlsutil.py — Lớp TLS dùng chung (nâng cấp OPSEC 2026-09).

Mục đích:
  * THAY THẾ các `ssl.create_default_context()` rải rác trong scanner.py và
    exploits/common.py bằng MỘT code path duy nhất → thống nhất cipher suite
    + ALPN + giới hạn phiên bản TLS cho mọi request.
  * JA3 approximation: cấu hình ClientHello theo kiểu trình duyệt hiện đại
    (cipher suite TLS 1.2 = ECDHE + GCM/CHACHA20, ưu tiên AES-128 như Chrome;
    TLS 1.3 = 3 suite chuẩn; ALPN http/1.1; không TLS compression) và XÁO
    THỨ TỰ cipher mỗi lần tạo context → vân tay JA3 thay đổi nhẹ giữa các
    kết nối, không còn cố định như context mặc định của Python/OpenSSL.
    Đây là PHƯƠNG PHÁP XẤP XỈ — JA3 thực sự ngẫu nhiên hoàn toàn cần tự
    build ClientHello (vd: patch thư viện ở tầng thấp hơn), nằm ngoài phạm vi.

Không verify chứng chỉ (IoT thường self-signed) — chỉ dùng cho fingerprint
và khai thác trong phạm vi kiểm thử được ủy quyền.
"""

import logging
import random
import ssl

from config import TLS_ALPN, TLS_CIPHERS, TLS_CIPHERSUITES, TLS_MIN_VERSION

log = logging.getLogger("sofia.tlsutil")


def client_context(ciphers=None, ciphersuites=None, randomize=True):
    """
    Tạo SSLContext chuẩn cho pipeline:
      * không verify hostname/chứng chỉ (IoT self-signed)
      * TLS >= TLS_MIN_VERSION (mặc định TLSv1_2)
      * ALPN = TLS_ALPN (mặc định ["http/1.1"]) — giống browser, tránh
        server chỉ định HTTP/2 khi ta chưa hỗ trợ (giữ code path đơn giản)
      * cipher suite browser-like (config.TLS_CIPHERS / TLS_CIPHERSUITES);
        `randomize=True` → xáo thứ tự mỗi lần (JA3 approximation).

    Trả về ssl.SSLContext sẵn sàng `ctx.wrap_socket(sock, server_hostname=...)`.
    Nếu OpenSSL của máy không chấp nhận danh sách cipher (đổi tên suite),
    fallback về mặc định của OpenSSL kèm ALPN — không làm chết request.
    """
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    try:
        ctx.minimum_version = getattr(ssl.TLSVersion, TLS_MIN_VERSION)
    except (AttributeError, ValueError):
        ctx.minimum_version = ssl.TLSVersion.TLSv1_2

    try:
        ciphers = list(ciphers if ciphers is not None else TLS_CIPHERS)
        if randomize and len(ciphers) > 1:
            random.shuffle(ciphers)      # thay đổi thứ tự → JA3 thay đổi nhẹ
        ctx.set_ciphers(":".join(ciphers))
    except ssl.SSLError as exc:
        log.debug("set_ciphers thất bại (%r) — dùng mặc định OpenSSL", exc)
    try:
        suites = list(ciphersuites if ciphersuites is not None else TLS_CIPHERSUITES)
        if randomize and len(suites) > 1:
            random.shuffle(suites)
        ctx.set_ciphersuites(":".join(suites))
    except (ssl.SSLError, AttributeError, ValueError) as exc:
        log.debug("set_ciphersuites thất bại (%r) — dùng mặc định", exc)

    try:
        if TLS_ALPN:
            ctx.set_alpn_protocols(list(TLS_ALPN))
    except (NotImplementedError, ssl.SSLError) as exc:
        log.debug("set_alpn_protocols không khả dụng: %r", exc)
    return ctx


def wrap_client_socket(sock, host):
    """Bọc socket TCP đã kết nối bằng TLS (context mới mỗi lần → UA/JA3 xoay)."""
    ctx = client_context()
    return ctx.wrap_socket(sock, server_hostname=host)


__all__ = ["client_context", "wrap_client_socket"]

