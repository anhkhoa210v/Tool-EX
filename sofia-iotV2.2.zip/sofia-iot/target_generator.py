"""
Giai đoạn 0: Discovery — sinh danh sách IP live + cổng mở từ SCAN_PORTS.

Engine chọn bằng CLI --engines (hoặc config.DISCOVER_ENGINE), mặc định "zmap":

  * zmap (mặc định): KHÔNG dùng masscan. Engine tự sinh 1 dải IPv4 /16 NGẪU
    NHIÊN (generate_random_range) rồi dùng zmap quét TẤT CẢ cổng trong
    SCAN_PORTS để tìm cổng mở. Kết quả ghi dạng "IP:Port" → zmap_scan.txt.
  * masscan: engine cũng tự sinh 1 dải IPv4 /16 NGẪU NHIÊN rồi dùng masscan
    quét SCAN_PORTS; kết quả "IP:Port" → mass_scan.txt.

Cả hai engine ưu tiên dải khai tay (--scan-range / config.SCAN_RANGES); chỉ
khi trống mới tự sinh dải /16 ngẫu nhiên. Không fallback chéo giữa 2 engine.

Luồng xử lý chung:
    _resolve_ranges() → _zmap_only()/_masscan_only() → dedupe_and_merge()
    → exclude_private_ips() + load_blacklist() → ghi file IP:Port
    → _attach_cves() → {ip: {"ports": [...], "cves": [...], "port_cves": [...]}}

Ngoài ra module còn phục vụ chế độ "nạp kết quả scan có sẵn" (main.py
--scan-file), KHÔNG quét lại:
    resolve_scan_files() → read_scan_files() → load_scan_targets()
File scan nhận dạng: "IP:Port" (zmap_scan.txt/mass_scan.txt), "IP" trần (zmap
raw) và "open tcp <port> <ip>" (masscan -oL).

Output cuối cùng là dict (tách rõ CVE khai tay vs CVE suy ra từ cổng):
    { "1.2.3.4": {"ports": [80, 8080],
                  "cves": [...khai tay, luôn giữ...],
                  "port_cves": [...suy từ cổng, xếp theo CVSS giảm dần...]}, ... }
"""

import ipaddress
import json
import logging
import os
import random
import shutil
import subprocess
import time

from config import (
    ALLOW_PRIVATE,
    AUTO_GEN_CIDR,
    AUTO_GEN_MAX_CHUNKS,
    AUTO_GEN_SEED,
    AUTO_GEN_SHUFFLE,
    AUTO_GEN_SPLIT_TO,
    BLACKLIST_FILE,
    CVE_SEVERITY,
    DISCOVER_ENGINE,
    MASSCAN_RATE,
    MASSCAN_SCAN_FILE,
    MAX_CVES_PER_HOST,
    MAX_TARGETS,
    RANDOM_RANGE_ATTEMPTS,
    RANDOM_RANGE_PREFIX,
    RANDOM_RANGE_SEED,
    RANGES_CACHE_FILE,
    SCAN_PORTS,
    SCAN_RANGES,
    ZMAP_BANDWIDTH,
    ZMAP_INTERFACE,
    ZMAP_RAW_DIR,
    ZMAP_SCAN_FILE,
)

log = logging.getLogger("sofia.target_generator")

# ── Engine discovery đang dùng (--engines / config.DISCOVER_ENGINE) ───────
ENGINE = DISCOVER_ENGINE   # "zmap" | "masscan"


# ── Bộ lọc CVE toàn cục (CLI --only-cves / --max-cves-per-host) ─────────
ONLY_CVES = None                    # None = không lọc; set(CVE) = chỉ giữ các CVE này
MAX_CVES_PER_HOST_OVERRIDE = None   # None = dùng config.MAX_CVES_PER_HOST


def set_cve_filters(only=None, max_per_host=None):
    """CLI ghi đè bộ lọc CVE — áp dụng cho cả discovery lẫn chế độ --scan-file."""
    global ONLY_CVES, MAX_CVES_PER_HOST_OVERRIDE
    if only is not None:
        ONLY_CVES = {c.strip() for c in only if c and c.strip()} or None
    if max_per_host is not None:
        MAX_CVES_PER_HOST_OVERRIDE = max(0, int(max_per_host))
    return ONLY_CVES, MAX_CVES_PER_HOST_OVERRIDE


def set_engine(name=None):
    """CLI --engines ghi đè engine discovery; name=None chỉ log engine hiện tại."""
    global ENGINE
    if name:
        if name not in ("zmap", "masscan"):
            raise ValueError("engine không hợp lệ: %r (chỉ chấp nhận zmap/masscan)" % name)
        ENGINE = name
    log.info("Discovery engine: %s", ENGINE)
    return ENGINE

# ── Map cổng → danh sách CVE thuộc cổng đó ──────────────────────────────
PORT_CVE_MAP = {
    37215: ["CVE-2017-17215"],                                   # Huawei HG532
    80: [
        "CVE-2021-36260",   # Hikvision
        "CVE-2023-1389",    # TP-Link AX21
        "CVE-2024-3721",    # TBK DVR
        "CVE-2024-45414",   # ZTE
        "CVE-2023-33538",   # TP-Link EOL
        "CVE-2025-29635",   # D-Link 823X
        "CVE-2023-25280",   # D-Link 820L
        "CVE-2023-27240",   # Tenda AX3
        "CVE-2022-30023",   # Tenda HG9
        "CVE-2021-46422",   # Telesquare
        "CVE-2019-17621",   # DIR-859
        "CVE-2020-8515",    # DrayTek keyPath
        "CVE-2025-34043",   # Vacron NVR
        "CVE-2025-1316",    # Edimax
        "CVE-2017-5638",    # Struts2
    ],
    8080: [
        "CVE-2017-5638",    # Struts2 (web app thường chạy 8080)
        "CVE-2023-1389",    # TP-Link AX21
        "CVE-2021-36260",   # Hikvision
        "CVE-2024-45414",   # ZTE
    ],
    8443: ["CVE-2018-9866"],            # SonicWall GMS (XML-RPC)
    21009: ["CVE-2018-9866"],           # Cổng XML-RPC thực tế của GMS service
    443: [                                # Web IoT qua HTTPS
        "CVE-2021-36260",   # Hikvision (HTTPS)
        "CVE-2023-1389",    # TP-Link
        "CVE-2024-45414",   # ZTE
    ],
    7547: ["CVE-2017-17215"],           # TR-069 — Huawei HG532 hay chạy ở đây
}


# Cổng web/IoT thay thế (thường chạy cùng web stack như cổng 80) → dùng
# chung bộ CVE web của cổng 80. Nhờ vậy kết quả zmap/masscan trên các cổng
# hiếm (8000, 8081, 9080, 4443...) vẫn có ứng viên CVE để khai thác.
ALT_WEB_PORTS = {
    81, 88, 443, 4443, 5000, 8000, 8008, 8081, 8088, 8089, 8090,
    8888, 9000, 9080, 9081, 9443, 34567, 37777,
}

_PORT_CVE_CACHE = None


def build_port_cve_map():
    """
    Map cổng → danh sách CVE ứng viên, gộp từ 3 nguồn:
      * PORT_CVE_MAP (khai tay, ưu tiên giữ nguyên);
      * cổng do các module trong exploits.REGISTRY tự khai báo ("ports");
      * ALT_WEB_PORTS → dùng bộ CVE web của cổng 80.
    Chỉ gộp thêm (union), KHÔNG xoá mục đã khai tay. Kết quả được cache.
    Lazy-import REGISTRY để tránh vòng import lúc nạp module.
    """
    global _PORT_CVE_CACHE
    if _PORT_CVE_CACHE is not None:
        return {p: list(c) for p, c in _PORT_CVE_CACHE.items()}

    merged = {port: list(cves) for port, cves in PORT_CVE_MAP.items()}

    try:
        from exploits import REGISTRY  # lazy — tránh vòng import
        for cve, entry in REGISTRY.items():
            # Khoá dict MỚI là CVE ID ('CVE-....'); entry['name'] chỉ là mô tả
            # tiếng người — KHÔNG được nhầm thành CVE (bug cũ gây ô nhiễm port-map).
            cve = cve or entry.get("cve")
            if not cve or not str(cve).startswith("CVE-"):
                continue
            for port in (entry.get("ports") or []):
                try:
                    port = int(port)
                except (TypeError, ValueError):
                    continue
                merged.setdefault(port, [])
                if cve not in merged[port]:
                    merged[port].append(cve)
        web_cves = list(merged.get(80, []))
        for port in ALT_WEB_PORTS:
            merged.setdefault(port, [])
            for cve in web_cves:
                if cve not in merged[port]:
                    merged[port].append(cve)
    except Exception as exc:  # noqa: BLE001 — không để discovery vỡ vì registry
        log.warning("build_port_cve_map: bỏ qua REGISTRY (%r)", exc)

    # Xếp theo CVSS giảm dần (CVE điểm cao lên đầu), rồi theo tên CVE.
    for port in merged:
        merged[port] = sorted(set(merged[port]),
                              key=lambda c: (-CVE_SEVERITY.get(c, 0.0), c))
    _PORT_CVE_CACHE = merged
    return {p: list(c) for p, c in merged.items()}


def build_port_map():
    """Map cổng → danh sách CVE thuộc cổng đó (đã gộp REGISTRY + cổng web phụ)."""
    return build_port_cve_map()


# ── Auto-generate dải IPv4 /16 (nâng cấp: zmap tự sinh dải thay vì khai tay) ──
def _range_is_ok(cidr):
    """Dải hợp lệ để quét: IPv4, không private/reserved (trừ ALLOW_PRIVATE),
    không nằm trong blacklist."""
    try:
        net = ipaddress.ip_network(cidr, strict=False)
    except ValueError:
        return False
    if net.version != 4:
        return False
    if not ALLOW_PRIVATE and _is_private(net.network_address):
        return False
    for bl in load_blacklist():
        if bl.version != 4:
            continue                    # zmap chỉ quét IPv4 — bỏ dòng IPv6 trong blacklist
        if net.subnet_of(bl) or bl.subnet_of(net):
            return False
    return True


def generate_ipv4_ranges(cidr=AUTO_GEN_CIDR, split_to=AUTO_GEN_SPLIT_TO,
                         shuffle=AUTO_GEN_SHUFFLE, seed=AUTO_GEN_SEED,
                         max_chunks=AUTO_GEN_MAX_CHUNKS,
                         use_cache=True, force=False):
    """
    TỰ ĐỘNG SINH danh sách dải IPv4 /16 để zmap/masscan quét.

    Chia `cidr` thành các chunk /`split_to` (mặc định /16 → 65536 IP/dải),
    lọc private/RFC1918 + blacklist, xáo thứ tự theo `seed`, giới hạn
    `max_chunks`. Danh sách được cache vào RANGES_CACHE_FILE để:
      * resume ổn định (chạy lại → cùng thứ tự dải, không trùng lặp)
      * `--max-chunks` chỉ ảnh hưởng lần tạo đầu; các lần sau đọc cache.

    Trả về list CIDR str (VD ["203.0.113.0/16", ...]).
    """
    os.makedirs(ZMAP_RAW_DIR, exist_ok=True)
    cache_key = {"cidr": cidr, "split_to": split_to, "shuffle": shuffle,
                 "seed": seed, "max_chunks": max_chunks}

    if use_cache and not force and os.path.isfile(RANGES_CACHE_FILE):
        try:
            with open(RANGES_CACHE_FILE, encoding="utf-8") as fh:
                cached = json.load(fh)
            if cached.get("key") == cache_key and isinstance(cached.get("ranges"), list):
                log.info("Dải /%d đọc từ cache (%d dải): %s",
                         split_to, len(cached["ranges"]), RANGES_CACHE_FILE)
                return list(cached["ranges"])
        except (ValueError, OSError) as exc:
            log.warning("Cache dải đọc lỗi (%r) — sinh lại", exc)

    try:
        net = ipaddress.ip_network(cidr, strict=False)
    except ValueError as exc:
        log.error("AUTO_GEN_CIDR không hợp lệ %r: %s", cidr, exc)
        return []
    if net.version != 4:
        log.error("AUTO_GEN_CIDR phải là IPv4: %s", cidr)
        return []
    split = int(split_to)
    if split < net.prefixlen:
        split = net.prefixlen          # không chia nhỏ hơn dải gốc
    try:
        subnets = list(net.subnets(new_prefix=split))
    except ValueError:
        subnets = [net]

    # Lọc private/RFC1918 + blacklist (trừ khi ALLOW_PRIVATE bật)
    chunks = [str(s) for s in subnets if _range_is_ok(str(s))]
    dropped = len(subnets) - len(chunks)
    if dropped:
        log.info("Đã lọc %d dải private/reserved/blacklist khỏi %d dải sinh ra",
                 dropped, len(subnets))

    # Xáo thứ tự (seed > 0 → tái lập được)
    if shuffle:
        rng = random.Random(int(seed) if int(seed) > 0 else None)
        rng.shuffle(chunks)

    limit = int(max_chunks or 0)
    if limit > 0 and len(chunks) > limit:
        chunks = chunks[:limit]

    try:
        with open(RANGES_CACHE_FILE, "w", encoding="utf-8") as fh:
            json.dump({"key": cache_key, "ranges": chunks}, fh, indent=2)
        log.info("Cache dải /%d → %s (%d dải)", split, RANGES_CACHE_FILE, len(chunks))
    except OSError as exc:
        log.warning("Không ghi được cache dải (%r)", exc)

    log.info("[ipgen] %s → %d chunk /%d (sau lọc + giới hạn) "
             "— shuffle=%s seed=%d max_chunks=%d",
             cidr, len(chunks), split, shuffle, int(seed), limit)
    return chunks


def check_zmap():
    """Kiểm tra zmap/masscan đã cài chưa (shutil.which)."""
    zmap = shutil.which("zmap")
    masscan = shutil.which("masscan")
    if not (zmap or masscan):
        log.warning("Không tìm thấy zmap lẫn masscan trong PATH. "
                    "Cài đặt: apt install zmap  /  apt install masscan")
    return {"zmap": zmap, "masscan": masscan}


def load_blacklist():
    """Đọc file loại trừ (CIDR, 1 dòng 1 dải, '#' = comment)."""
    networks = []
    if os.path.isfile(BLACKLIST_FILE):
        with open(BLACKLIST_FILE, "r", encoding="utf-8") as fh:
            for raw in fh:
                line = raw.strip()
                if not line or line.startswith("#"):
                    continue
                try:
                    networks.append(ipaddress.ip_network(line, strict=False))
                except ValueError as exc:
                    log.warning("Dòng blacklist không hợp lệ '%s': %s", line, exc)
    return networks


def _is_private(ip_obj):
    """RFC1918 / loopback / link-local / multicast / reserved."""
    return (ip_obj.is_private or ip_obj.is_loopback or ip_obj.is_link_local
            or ip_obj.is_multicast or ip_obj.is_reserved
            or ip_obj.is_unspecified)


def exclude_private_ips(ip_set):
    """Lọc RFC1918/loopback/link-local (bỏ qua nếu ALLOW_PRIVATE=True)."""
    if ALLOW_PRIVATE:
        return ip_set
    kept = {ip for ip in ip_set if not _is_private(ipaddress.ip_address(ip))}
    dropped = len(ip_set) - len(kept)
    if dropped:
        log.info("Đã lọc %d IP nội bộ/không hợp lệ (ALLOW_PRIVATE=%s)",
                 dropped, ALLOW_PRIVATE)
    return kept


def _sanitize_blacklist_for_zmap(blacklist_file):
    """zmap bản hiện tại không đọc được dòng IPv6 trong blacklist
    (lỗi `constraint: '128' is not a valid prefix length`).
    Tạo bản chỉ chứa dòng IPv4 + comment, ghi vào ZMAP_RAW_DIR, trả về path.
    """
    lines = []
    if blacklist_file and os.path.isfile(blacklist_file):
        with open(blacklist_file, encoding="utf-8") as fh:
            for raw in fh:
                line = raw.strip()
                if not line or line.startswith("#"):
                    lines.append(line)
                    continue
                try:
                    if ipaddress.ip_network(line, strict=False).version == 4:
                        lines.append(line)
                    # dòng IPv6 bị bỏ qua — zmap chỉ quét IPv4
                except ValueError:
                    lines.append(line)
    path = os.path.join(ZMAP_RAW_DIR, "blacklist_v4_tmp.conf")
    with open(path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")
    return path


def zmap_scan(port, bandwidth=ZMAP_BANDWIDTH, blacklist_file=BLACKLIST_FILE,
              out_file=None, timeout=600, subnets=None):
    """
    Chạy zmap -p <port> -B <bw> <subnets> -o <file>. Trả về đường dẫn file kết quả
    (None nếu thất bại). Mỗi dòng trong file là một IP.
    subnets: list CIDR (VD ["192.0.2.0/24"]) — bắt buộc; zmap tự sinh danh sách
    IPv4 trong các dải này. Thiếu dải → không quét (fail-closed).
    """
    if subnets is None:
        subnets = SCAN_RANGES
    if not subnets:
        log.error("zmap cổng %d: chưa khai báo dải quét (SCAN_RANGES / --scan-range) — bỏ qua", port)
        return None
    tools = check_zmap()
    if not tools["zmap"]:
        log.error("zmap chưa được cài — không thể quét cổng %d", port)
        return None

    os.makedirs(ZMAP_RAW_DIR, exist_ok=True)
    out_file = out_file or os.path.join(ZMAP_RAW_DIR, f"port_{port}.txt")
    cmd = [tools["zmap"], "-p", str(port), "-B", bandwidth, "-o", out_file]
    if blacklist_file and os.path.isfile(blacklist_file):
        blacklist_file = _sanitize_blacklist_for_zmap(blacklist_file)
        cmd += ["--blacklist-file", blacklist_file]
    if ZMAP_INTERFACE:
        cmd += ["-i", ZMAP_INTERFACE]
    cmd += list(subnets)   # zmap tự sinh IPv4 trong các dải này

    log.info("zmap: %s", " ".join(cmd))
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    except subprocess.TimeoutExpired:
        log.error("zmap cổng %d hết thời gian (%ds)", port, timeout)
        return None

    if proc.returncode != 0:
        log.error("zmap cổng %d thất bại (rc=%d): %s",
                  port, proc.returncode, proc.stderr.strip()[:500])
        return None

    count = 0
    if os.path.isfile(out_file):
        with open(out_file, "r", encoding="utf-8") as fh:
            count = sum(1 for _ in fh)
    log.info("zmap cổng %d xong: %d IP", port, count)
    return out_file


def masscan_scan(ports, rate=MASSCAN_RATE, out_file=None, timeout=600,
                 subnets=None, include_file=None):
    """
    masscan quét nhiều cổng 1 lần, output dạng list:  open tcp 80 1.2.3.4 ...

    subnets      : list CIDR → thêm --range cho từng dải (quét toàn dải).
    include_file : file 1 IP/dòng → thêm -iL (luồng hybrid: masscan chỉ quét
                   cổng trên host mà zmap đã xác nhận sống — nhanh hơn nhiều).

    Nếu include_file hợp lệ → ưu tiên dùng; subnets chỉ là fallback.
    """
    if not include_file and subnets is None:
        subnets = SCAN_RANGES
    if not include_file and not subnets:
        log.error("masscan: chưa khai dải quét (SCAN_RANGES) hoặc file -iL — bỏ qua")
        return None
    tools = check_zmap()
    if not tools["masscan"]:
        log.error("masscan chưa được cài")
        return None

    os.makedirs(ZMAP_RAW_DIR, exist_ok=True)
    out_file = out_file or os.path.join(ZMAP_RAW_DIR, "masscan_all.txt")
    cmd = [tools["masscan"], "-p", ",".join(str(p) for p in ports),
           "--rate", str(rate), "-oL", out_file]
    if include_file and os.path.isfile(include_file):
        cmd += ["-iL", include_file]
    else:
        for subnet in subnets:
            cmd += ["--range", subnet]
    if os.path.isfile(BLACKLIST_FILE):
        cmd += ["--excludefile", BLACKLIST_FILE]

    log.info("masscan: %s", " ".join(cmd))
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    except subprocess.TimeoutExpired:
        log.error("masscan hết thời gian (%ds)", timeout)
        return None
    if proc.returncode != 0:
        log.error("masscan thất bại (rc=%d): %s",
                  proc.returncode, proc.stderr.strip()[:500])
        return None
    log.info("masscan xong: %s", out_file)
    return out_file


def _read_ips(path):
    """Đọc file zmap (1 IP/dòng) hoặc masscan (-oL: 'open tcp 80 ip ...')."""
    ips = set()
    if not path or not os.path.isfile(path):
        return ips
    with open(path, "r", encoding="utf-8", errors="ignore") as fh:
        for line in fh:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if line.startswith("open "):            # masscan list format
                parts = line.split()
                if len(parts) >= 4 and parts[0] == "open":
                    ips.add(parts[3])
            elif ":" in line and " " not in line:   # "IP:Port" (đã chuẩn hoá)
                ips.add(line.rpartition(":")[0])
            else:                                   # zmap raw format
                ips.add(line)
    return ips


def _read_open_ports(path):
    """masscan -oL → {ip: set(port)} — parse cổng chính xác từ dòng 'open tcp <p> <ip>'."""
    out = {}
    if not path or not os.path.isfile(path):
        return out
    with open(path, "r", encoding="utf-8", errors="ignore") as fh:
        for line in fh:
            line = line.strip()
            if not line.startswith("open "):
                continue
            parts = line.split()
            if len(parts) >= 4 and parts[0] == "open":
                try:
                    out.setdefault(parts[3], set()).add(int(parts[2]))
                except ValueError:
                    pass
    return out


def dedupe_and_merge(port_ips):
    """
    Gộp kết quả các cổng → {ip: [cổng mở]}.
    port_ips: {port: set(ips)}
    """
    merged = {}
    for port, ips in port_ips.items():
        for ip in ips:
            merged.setdefault(ip, []).append(port)
    for ip in merged:
        merged[ip] = sorted(merged[ip])
    log.info("Gộp %d cổng → %d IP duy nhất", len(port_ips), len(merged))
    return merged


def _cve_sort(cves):
    """Sắp CVE theo CVSS giảm dần, rồi theo tên (ổn định, tái lập được)."""
    return sorted(set(cves), key=lambda c: (-CVE_SEVERITY.get(c, 0.0), c))


def _attach_cves(targets, port_map=None, forced=None, only=None, max_per_host=0):
    """
    Gắn danh sách CVE ứng viên cho từng IP theo cổng mở.

    targets      : {ip: [ports]}  (chấp nhận cả {ip: {"ports": [...]}})
    port_map     : cổng → [CVE] (mặc định build_port_cve_map())
    forced       : {ip: [CVE]} CVE khai tay — LUÔN giữ, không bị lọc/gating
    only         : iterable CVE — nếu có, chỉ giữ các CVE nằm trong danh sách
    max_per_host : 0 = không giới hạn; >0 = chỉ giữ N CVE điểm CVSS cao nhất/host

    Trả về dict tách rõ 2 nguồn để main.py phân biệt CVE khai tay (luôn khai
    thác) và CVE suy ra từ cổng (có thể bị gating với web server generic):
      {ip: {"ports": [...], "cves": [...khai tay...], "port_cves": [...theo cổng...]}}
    """
    if port_map is None:
        port_map = build_port_cve_map()
    forced = forced or {}
    only_set = set(only) if only else None

    out = {}
    for ip, val in targets.items():
        if isinstance(val, dict):
            ports = list(val.get("ports") or [])
        else:
            ports = list(val or [])
        ports = sorted({int(p) for p in ports})

        explicit = list(forced.get(ip) or [])
        derived = []
        for port in ports:
            derived.extend(port_map.get(port, []))
        derived = _cve_sort(derived)

        if only_set is not None:
            explicit = [c for c in explicit if c in only_set]
            derived = [c for c in derived if c in only_set]

        if max_per_host and max_per_host > 0:
            # Ưu tiên CVE khai tay rồi mới đến ứng viên theo cổng; giữ top-N CVSS.
            combined = _cve_sort(list(explicit) + list(derived))
            keep = set(combined[:max_per_host])
            explicit = [c for c in explicit if c in keep]
            derived = [c for c in derived if c in keep]

        out[ip] = {"ports": ports,
                   "cves": _cve_sort(explicit),
                   "port_cves": _cve_sort(derived)}
    return out


# ── Dải IPv4 /N ngẫu nhiên + chọn dải cho engine ─────────────────────

def generate_random_range(prefix=RANDOM_RANGE_PREFIX, seed=RANDOM_RANGE_SEED,
                          attempts=RANDOM_RANGE_ATTEMPTS):
    """
    Sinh 1 dải IPv4 NGẪU NHIÊN /prefix (mặc định /16) để engine tự quét khi
    không có dải khai tay. Dải phải hợp lệ qua _range_is_ok() (IPv4, không
    private/reserved, không nằm trong blacklist).

    seed > 0 → tái lập được kết quả; seed = 0 → ngẫu nhiên mỗi lần.
    Trả về CIDR str (VD "203.0.113.0/16") hoặc None nếu không sinh được dải
    hợp lệ sau `attempts` lần thử (fail-closed).
    """
    try:
        prefix = int(prefix)
    except (TypeError, ValueError):
        prefix = 16
    prefix = max(8, min(32, prefix))
    rng = random.Random(int(seed)) if int(seed) > 0 else random.Random()
    host_mask = (1 << (32 - prefix)) - 1
    check = int(attempts) if int(attempts) > 0 else 1
    for _ in range(check):
        value = rng.getrandbits(32) & ~host_mask & 0xFFFFFFFF
        cidr = "%s/%d" % (ipaddress.IPv4Address(value), prefix)
        if _range_is_ok(cidr):
            log.info("Dải ngẫu nhiên sinh được: %s (prefix /%d, seed=%s)",
                     cidr, prefix, seed)
            return cidr
    log.error("Không sinh được dải ngẫu nhiên /%d hợp lệ sau %d lần thử",
              prefix, check)
    return None


def _resolve_ranges(subnets=None):
    """
    Dải engine sẽ quét:
      * ưu tiên dải khai tay (SCAN_RANGES / --scan-range / batch /16);
      * nếu trống → tự sinh 1 dải IPv4 /N NGẪU NHIÊN (mặc định /16).
    Trả về list CIDR (rỗng = fail-closed, không quét).
    """
    if subnets is None:
        subnets = SCAN_RANGES
    if subnets:
        return list(subnets)
    rng = generate_random_range()
    if not rng:
        return []
    log.info("Không có dải khai tay — engine tự sinh dải ngẫu nhiên: %s", rng)
    return [rng]


# ── Engine zmap (mặc định) — CHỈ dùng zmap, KHÔNG dùng masscan ───────────
def _zmap_only(subnets=None):
    """
    Engine "zmap" (mặc định): quét TẤT CẢ SCAN_PORTS bằng zmap trên dải đã
    chọn (khai tay hoặc /16 ngẫu nhiên) → phát hiện cổng mở. KHÔNG dùng
    masscan (không fallback chéo). Trả về {port: set(ip)} hoặc None khi lỗi.
    """
    ranges = _resolve_ranges(subnets)
    if not ranges:
        log.error("Engine zmap: không có dải quét (fail-closed)")
        return None
    tools = check_zmap()
    if not tools["zmap"]:
        log.error("Engine zmap: chưa cài zmap — không quét (không fallback masscan)")
        return None

    log.info("Engine zmap: quét cổng %s trên %s", SCAN_PORTS, ", ".join(ranges))
    port_ips = {port: set() for port in SCAN_PORTS}
    for port in SCAN_PORTS:
        path = zmap_scan(port, subnets=ranges)
        if path:
            port_ips[port] |= _read_ips(path)
    return port_ips


# ── Engine masscan — CHỈ dùng masscan ───────────────────────────────────
def _masscan_only(subnets=None):
    """
    Engine "masscan": quét SCAN_PORTS bằng masscan trên dải đã chọn (khai tay
    hoặc /16 ngẫu nhiên) → phát hiện cổng mở. KHÔNG fallback sang zmap.
    Trả về {port: set(ip)} hoặc None khi lỗi.
    """
    ranges = _resolve_ranges(subnets)
    if not ranges:
        log.error("Engine masscan: không có dải quét (fail-closed)")
        return None
    tools = check_zmap()
    if not tools["masscan"]:
        log.error("Engine masscan: chưa cài masscan — không quét")
        return None

    log.info("Engine masscan: quét cổng %s trên %s", SCAN_PORTS, ", ".join(ranges))
    path = masscan_scan(SCAN_PORTS, subnets=ranges)
    if path is None:
        log.error("Engine masscan: quét thất bại")
        return None
    port_ips = {port: set() for port in SCAN_PORTS}
    for ip, open_ports in _read_open_ports(path).items():
        for port in open_ports:
            if port in port_ips:
                port_ips[port].add(ip)
    return port_ips


def _write_scan_file(path, merged):
    """Ghi kết quả cổng mở dạng 'IP:Port' (1 dòng/kết quả, đã sắp xếp)."""
    lines = []
    for ip in sorted(merged, key=lambda x: ipaddress.ip_address(x)):
        for port in sorted(merged[ip]):
            lines.append("%s:%d" % (ip, port))
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        if lines:
            fh.write("\n".join(lines) + "\n")
    log.info("Đã ghi %d kết quả 'IP:Port' → %s", len(lines), path)
    return path


def _valid_ipv4(ip):
    """True nếu `ip` là chuỗi IPv4 hợp lệ (loại rác trong file scan)."""
    try:
        return ipaddress.ip_address(ip).version == 4
    except ValueError:
        return False


def read_scan_file(path, default_port=None):
    """
    Đọc 1 file kết quả scan → {ip: [port,...]}. Hỗ trợ đa định dạng:
      * "IP:Port"     — định dạng chuẩn hoá của zmap_scan.txt / mass_scan.txt;
      * "open tcp <port> <ip> ..."  — masscan -oL;
      * "IP" trần     — zmap raw 1 IP/dòng (chỉ nhận khi có `default_port`).
    Bỏ qua dòng trống và chú thích bắt đầu bằng #, ; hoặc //.
    """
    out = {}
    if not path or not os.path.isfile(path):
        return out
    with open(path, "r", encoding="utf-8", errors="ignore") as fh:
        for raw in fh:
            line = raw.strip()
            if not line or line[0] in "#;" or line.startswith("//"):
                continue
            if line.startswith("open "):           # masscan -oL
                parts = line.split()
                if len(parts) >= 4 and parts[0] == "open" and _valid_ipv4(parts[3]):
                    try:
                        out.setdefault(parts[3], []).append(int(parts[2]))
                    except ValueError:
                        pass
                continue
            if ":" in line and " " not in line:     # "IP:Port"
                ip, _, port = line.rpartition(":")
                port = port.strip()
                if _valid_ipv4(ip) and port.isdigit():
                    out.setdefault(ip, []).append(int(port))
                continue
            if _valid_ipv4(line):                    # zmap raw "IP"
                out.setdefault(line, [])
                if default_port:
                    try:
                        out[line].append(int(default_port))
                    except (TypeError, ValueError):
                        pass
    for ip in out:
        out[ip] = sorted(set(out[ip]))
    return out


def read_scan_files(paths, default_port=None):
    """Gộp nhiều file scan → {ip: [port,...]} (khử trùng lặp cổng)."""
    merged = {}
    for p in paths or []:
        for ip, ports in read_scan_file(p, default_port=default_port).items():
            merged.setdefault(ip, []).extend(ports)
    for ip in merged:
        merged[ip] = sorted(set(merged[ip]))
    log.info("Đọc %d file scan → %d IP", len(paths or []), len(merged))
    return merged


def resolve_scan_files(engine=None, explicit=None):
    """
    Xác định danh sách file scan cần nạp cho chế độ --scan-file:
      * explicit = None          → chỉ file của engine hiện tại;
      * explicit = "auto"/"all"/"" → gộp MỌI file đang có (file của engine
        hiện tại ưu tiên trước), bỏ file không tồn tại hoặc rỗng;
      * explicit = "a.txt,b.txt" → danh sách file chỉ định (phân tách bằng dấu phẩy).
    Trả về list đường dẫn tồn tại & KHÔNG rỗng, theo thứ tự ưu tiên.
    """
    eng = engine or ENGINE
    primary = ZMAP_SCAN_FILE if eng == "zmap" else MASSCAN_SCAN_FILE
    other = MASSCAN_SCAN_FILE if eng == "zmap" else ZMAP_SCAN_FILE

    if isinstance(explicit, str) and explicit.strip().lower() in ("auto", "all", ""):
        want = [primary, other]
    elif isinstance(explicit, str):
        want = [p.strip() for p in explicit.split(",") if p.strip()]
    elif explicit:
        want = list(explicit)
    else:
        want = [primary]

    chosen, seen = [], set()
    for p in want:
        ap = os.path.abspath(p)
        if ap in seen or not os.path.isfile(p):
            continue
        seen.add(ap)
        try:
            if os.path.getsize(p) == 0:
                log.warning("Bỏ qua file scan rỗng: %s", p)
                continue
        except OSError:
            continue
        chosen.append(p)
    return chosen


def load_scan_targets(files, forced=None, only=None, max_per_host=0,
                      port_map=None, default_port=None):
    """
    Nạp mục tiêu từ các file scan có sẵn + chọn CVE theo cổng (KHÔNG quét lại).
    Xem _attach_cves cho định dạng `forced`/`only`/`max_per_host`.
    Trả về {ip: {"ports": [...], "cves": [...], "port_cves": [...]}}.
    """
    merged = read_scan_files(files, default_port=default_port)
    targets = _attach_cves(merged, port_map=port_map, forced=forced,
                           only=only, max_per_host=max_per_host)
    if len(targets) > MAX_TARGETS:
        log.warning("Số IP (%d) vượt MAX_TARGETS (%d) — giữ %d IP đầu tiên",
                    len(targets), MAX_TARGETS, MAX_TARGETS)
        targets = dict(sorted(targets.items())[:MAX_TARGETS])
    return targets


def generate(engine=None, subnets=None):
    """
    Điều phối Giai đoạn 0 — engine chọn bởi --engines / config.DISCOVER_ENGINE:

      * "zmap" (mặc định): CHỈ dùng zmap quét SCAN_PORTS trên dải đã chọn →
        ghi zmap_scan.txt ("IP:Port"). Xem _zmap_only.
      * "masscan": CHỈ dùng masscan quét SCAN_PORTS trên dải đã chọn →
        ghi mass_scan.txt ("IP:Port"). Xem _masscan_only.

    engine=None → dùng ENGINE hiện tại (đã set bởi config hoặc set_engine()).
    subnets=None → lấy dải từ SCAN_RANGES; nếu cả hai trống → tự sinh dải /16
    ngẫu nhiên. Gộp + lọc private/blacklist, ghi file IP:Port, giới hạn MAX_TARGETS.
    """
    if engine:
        set_engine(engine)
    os.makedirs(ZMAP_RAW_DIR, exist_ok=True)

    port_ips = _zmap_only(subnets) if ENGINE == "zmap" else _masscan_only(subnets)
    if not port_ips:
        log.info("Discovery (%s): không có kết quả cổng mở", ENGINE)
        return {}

    merged = dedupe_and_merge(port_ips)
    merged = {ip: merged[ip] for ip in exclude_private_ips(set(merged))}

    scan_file = ZMAP_SCAN_FILE if ENGINE == "zmap" else MASSCAN_SCAN_FILE
    _write_scan_file(scan_file, merged)

    max_per_host = (MAX_CVES_PER_HOST_OVERRIDE if MAX_CVES_PER_HOST_OVERRIDE is not None
                    else MAX_CVES_PER_HOST)
    targets = _attach_cves(merged, port_map=build_port_cve_map(),
                           only=ONLY_CVES, max_per_host=max_per_host)

    # Giới hạn số IP đưa vào exploit (an toàn)
    if len(targets) > MAX_TARGETS:
        log.warning("Số IP (%d) vượt MAX_TARGETS (%d) — giữ %d IP đầu tiên",
                    len(targets), MAX_TARGETS, MAX_TARGETS)
        targets = dict(sorted(targets.items())[:MAX_TARGETS])

    log.info("Discovery xong (%s): %d mục tiêu", ENGINE, len(targets))
    return targets













