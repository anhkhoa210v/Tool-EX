"""Discord webhook reporting.

Builds a Discord embed whose core line follows the requested format::

    Domain | He Quan Tri Du Lieu + phien ban | Ten 3 bang trong database | vi tri bi injection

The same information is also expanded into discrete embed fields for
readability, plus technique/OS/payload detail. Sending is retried and respects
Discord 429 ``retry_after`` responses.
"""

from __future__ import annotations

import datetime as _dt
import os
import time
from dataclasses import dataclass

import requests

from core.parser import Finding
from utils.logger import get_logger

log = get_logger("sofia-sqli.reporter")

DISCORD_MAX_FIELD = 1024
DISCORD_MAX_DESC = 4096


@dataclass
class ReportConfig:
    webhook_url: str = ""
    username: str = "Sofia SQLi"
    color: int = 15158332
    per_finding: bool = True
    retries: int = 4
    retry_backoff: float = 2.0
    mention: str = ""

    @classmethod
    def from_settings(cls, cfg: dict) -> "ReportConfig":
        d = (cfg or {}).get("discord", {}) or {}
        url = os.environ.get("SOFIA_DISCORD_WEBHOOK") or d.get("webhook_url", "")
        return cls(
            webhook_url=(url or "").strip(),
            username=d.get("username", "Sofia SQLi"),
            color=int(d.get("embed_color", 15158332)),
            per_finding=bool(d.get("per_finding", True)),
            retries=int(d.get("retries", 4)),
            retry_backoff=float(d.get("retry_backoff", 2.0)),
            mention=d.get("mention", "") or "",
        )


class DiscordReporter:
    """Send findings to a Discord webhook as rich embeds."""

    def __init__(self, cfg: dict, session: requests.Session | None = None):
        self.config = ReportConfig.from_settings(cfg)
        self.session = session or requests.Session()

    @property
    def enabled(self) -> bool:
        return bool(self.config.webhook_url)

    # ------------------------------------------------------------------ embed
    def build_embed(self, finding: Finding) -> dict:
        tables = finding.top_tables(3)
        tables_str = ", ".join(tables) if tables else "n/a"
        dbms = finding.dbms_display()
        line = finding.report_line()

        fields: list[dict] = [
            {"name": "Domain", "value": f"`{finding.domain}`", "inline": True},
            {"name": "DBMS + Version", "value": f"`{dbms}`", "inline": True},
            {"name": "Injection Point", "value": f"`{finding.injection_location()}`", "inline": True},
            {"name": "Tables", "value": f"`{tables_str}`", "inline": False},
        ]

        if finding.injection_points:
            ip = finding.injection_points[0]
            fields.append({"name": "Technique", "value": f"`{ip.technique_summary}`", "inline": True})
        if finding.web_app or finding.os:
            tech = ", ".join(x for x in (finding.os, finding.web_app) if x) or "-"
            fields.append({"name": "Stack", "value": f"`{tech}`", "inline": True})
        if finding.current_db or finding.current_user:
            cu = f"db={finding.current_db or '-'} user={finding.current_user or '-'}"
            fields.append({"name": "Context", "value": f"`{cu}`", "inline": True})
        if not tables:
            fields.append({"name": "Tables", "value": "_(not enumerated)_", "inline": False})

        if finding.payloads:
            payload_txt = "\n".join(finding.payloads[:3])
            fields.append({"name": "Payload (sample)", "value": f"```sql\n{payload_txt[:1000]}\n```"})

        if finding.note:
            fields.append({"name": "Note", "value": f"`{finding.note[:1000]}`", "inline": False})

        fields = [self._clip_field(f) for f in fields]

        return {
            "title": "SQL Injection Confirmed",
            "url": finding.target.url,
            "description": f"**{line[:DISCORD_MAX_DESC - 8]}**",
            "color": self.config.color,
            "fields": fields,
            "footer": {"text": "sofia-sqli | TranAnhKhoa x SofiaTool"},
            "timestamp": _dt.datetime.now(_dt.timezone.utc).isoformat(),
        }

    @staticmethod
    def _clip_field(field: dict) -> dict:
        if len(field.get("value", "")) > DISCORD_MAX_FIELD:
            field["value"] = field["value"][: DISCORD_MAX_FIELD - 3] + "..."
        return field

    # ------------------------------------------------------------------- send
    def send_embed(self, embed: dict, content: str | None = None) -> bool:
        if not self.enabled:
            log.debug("Discord webhook not configured - skipping send")
            return False

        payload: dict = {
            "username": self.config.username,
            "embeds": [embed],
        }
        if content or self.config.mention:
            payload["content"] = (content or "") + (self.config.mention or "")

        return self._post(payload)

    def send_finding(self, finding: Finding) -> bool:
        return self.send_embed(self.build_embed(finding))

    def send_text(self, text: str) -> bool:
        """Send a plain message (used for run summaries)."""
        if not self.enabled:
            return False
        return self._post({"username": self.config.username,
                           "content": text[:1900]})

    def send_summary(self, scanned: int, vulnerable: list[Finding],
                     started: float, ended: float) -> bool:
        dur = max(0.0, ended - started)
        lines = [
            f"**sofia-sqli run complete**",
            f"Targets scanned: `{scanned}`",
            f"Vulnerable: `{len(vulnerable)}`",
            f"Duration: `{dur:.1f}s`",
        ]
        if vulnerable:
            lines.append("**Hits:**")
            for f in vulnerable[:15]:
                lines.append(f"- {f.report_line()}")
        return self.send_text("\n".join(lines))

    # ------------------------------------------------------------------- post
    def _post(self, payload: dict) -> bool:
        url = self.config.webhook_url
        attempt = 0
        while attempt <= self.config.retries:
            try:
                resp = self.session.post(url, json=payload, timeout=20)
                if resp.status_code in (200, 204):
                    log.info("Discord report sent")
                    return True
                if resp.status_code == 429:
                    retry_after = 1.0
                    try:
                        retry_after = float(resp.json().get("retry_after", 1.0))
                    except Exception:  # noqa: BLE001
                        pass
                    log.warning("Discord rate limited; retry in %.1fs", retry_after)
                    time.sleep(min(retry_after + 0.5, 30))
                    attempt += 1
                    continue
                log.warning("Discord webhook HTTP %s: %s", resp.status_code,
                            resp.text[:200])
            except requests.RequestException as exc:
                log.warning("Discord webhook error (attempt %d): %s", attempt + 1, exc)

            attempt += 1
            if attempt <= self.config.retries:
                time.sleep(min(self.config.retry_backoff * attempt, 30))
        log.error("Discord report failed after %d attempts", self.config.retries + 1)
        return False
