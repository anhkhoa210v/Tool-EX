"""Genetic/evolutionary dork optimisation.

Each dork is a *genome*: a template plus the concrete slot values (script,
parameter, extension, vertical keyword, TLD) sampled from the dictionary.
Per run, fitness is recorded from how many candidate URLs the dork actually
harvested, then a new generation is bred:

* **Selection**  - the top ``keep_frac`` genomes survive unchanged (elitism).
* **Mutation**   - replace a random slot with a fresh dictionary sample
                   (keyword mutation, extension mutation, TLD mutation...).
* **Crossover**  - two parents swap halves of their slot dictionaries.
* **Culling**    - the bottom ``cull_frac`` genomes are removed once they
                   have enough recorded runs, so engine quota is spent on
                   dorks that actually produce results.

The population (with fitness) is persisted to ``config/dork_state.json``
and restored across runs.
"""

from __future__ import annotations

import json
import os
import random
import threading
import time
from dataclasses import dataclass, field

from core.dork_adapter import parse_tokens, to_engine
from core.dork_dict import DorkDictionary
from utils.logger import get_logger

log = get_logger("sofia-sqli.dork_evolution")


@dataclass
class Fitness:
    runs: int = 0
    urls_total: int = 0
    urls_unique: int = 0
    score_sum: int = 0
    blocked_runs: int = 0
    engines: dict[str, int] = field(default_factory=dict)

    @property
    def score(self) -> float:
        """Higher = the dork earns its engine quota."""
        if self.runs == 0:
            return -1.0                       # unproven: keep but low rank
        avg_per_run = self.urls_total / self.runs
        avg_score = (self.score_sum / self.urls_total) if self.urls_total else 0.0
        uniq_ratio = (self.urls_unique / self.urls_total) if self.urls_total else 0.0
        blocked_penalty = (self.blocked_runs / self.runs) * 2.0
        # Unique URLs matter most (they survive smart-dedupe), then volume.
        return round(self.urls_unique * 2.0 + avg_per_run * 0.5
                     + avg_score * 0.05 + uniq_ratio * 5.0 - blocked_penalty, 3)

    def to_json(self) -> dict:
        return {"runs": self.runs, "urls_total": self.urls_total,
                "urls_unique": self.urls_unique, "score_sum": self.score_sum,
                "blocked_runs": self.blocked_runs, "engines": self.engines}

    @classmethod
    def from_json(cls, d: dict) -> "Fitness":
        return cls(runs=int(d.get("runs", 0) or 0),
                   urls_total=int(d.get("urls_total", 0) or 0),
                   urls_unique=int(d.get("urls_unique", 0) or 0),
                   score_sum=int(d.get("score_sum", 0) or 0),
                   blocked_runs=int(d.get("blocked_runs", 0) or 0),
                   engines=dict(d.get("engines") or {}))


@dataclass
class DorkGenome:
    template: str
    slots: dict[str, str]
    fitness: Fitness = field(default_factory=Fitness)
    lineage: str = "seed"                 # seed | mutated | crossover
    born: str = ""

    # ---------------------------------------------------------------- render
    def render(self) -> str:
        """Render the canonical (Google-syntax) dork string."""
        try:
            return self.template.format(**{**self.slots})
        except (KeyError, IndexError):
            return self.template

    def query_for(self, engine: str) -> str:
        """Full per-engine query (canonical rendered then translated)."""
        return to_engine(self.render(), engine)

    def key(self) -> str:
        return self.render()

    def to_json(self) -> dict:
        return {"template": self.template, "slots": self.slots,
                "fitness": self.fitness.to_json(), "lineage": self.lineage,
                "born": self.born}

    @classmethod
    def from_json(cls, d: dict) -> "DorkGenome":
        return cls(template=d.get("template", ""),
                   slots=dict(d.get("slots") or {}),
                   fitness=Fitness.from_json(d.get("fitness") or {}),
                   lineage=d.get("lineage", "seed"),
                   born=d.get("born", ""))


class DorkEvolution:
    """Population of dork genomes with fitness-based evolution."""

    def __init__(self, dictionary: DorkDictionary, cfg: dict | None = None,
                 base_dir: str | None = None):
        cfg = cfg or {}
        self.cfg = cfg
        self.dictionary = dictionary
        base = base_dir or os.getcwd()
        path = cfg.get("state_file") or "config/dork_state.json"
        self.state_file = path if os.path.isabs(path) else os.path.join(base, path)

        self.enabled = bool(cfg.get("enabled", True))
        self.keep_frac = float(cfg.get("keep_frac", 0.3) or 0.3)
        self.cull_frac = float(cfg.get("cull_frac", 0.2) or 0.2)
        self.mutation_rate = float(cfg.get("mutation_rate", 0.35) or 0.35)
        self.crossover_rate = float(cfg.get("crossover_rate", 0.25) or 0.25)
        self.max_population = int(cfg.get("max_population", 40) or 40)
        self.min_runs_before_cull = int(cfg.get("min_runs_before_cull", 3) or 3)
        self.inject_new = int(cfg.get("inject_new_per_gen", 3) or 3)

        self._lock = threading.Lock()
        self.population: list[DorkGenome] = []
        self._load()

    # ------------------------------------------------------------------ io
    def _load(self) -> None:
        try:
            with open(self.state_file, "r", encoding="utf-8") as fh:
                data = json.load(fh)
        except (FileNotFoundError, ValueError, OSError):
            return
        for item in (data or {}).get("population") or []:
            try:
                g = DorkGenome.from_json(item)
                if g.template and g.slots:
                    self.population.append(g)
            except Exception:  # noqa: BLE001 - skip corrupt rows
                continue
        if self.population:
            log.info("evolution: restored %d dork genomes from %s",
                     len(self.population), self.state_file)

    def save(self) -> None:
        os.makedirs(os.path.dirname(self.state_file) or ".", exist_ok=True)
        data = {
            "saved_at": time.strftime("%Y-%m-%d %H:%M:%S"),
            "generation": self.generation() + 1,
            "population": [g.to_json() for g in self.population],
        }
        try:
            with open(self.state_file, "w", encoding="utf-8") as fh:
                json.dump(data, fh, ensure_ascii=False, indent=2)
        except OSError as exc:
            log.warning("cannot save dork evolution state: %s", exc)

    def generation(self) -> int:
        return max((g.fitness.runs for g in self.population), default=0)

    # --------------------------------------------------------------- seeding
    def seed_from_dictionary(self, size: int | None = None) -> None:
        """Create the initial population from dictionary templates."""
        size = size or self.max_population
        rng = random.Random()
        existing = {g.key() for g in self.population}
        n = 0
        while len(self.population) < size and n < size * 8:
            n += 1
            template = rng.choice(self.dictionary.templates)
            slots: dict[str, str] = {}
            for key in ("script", "ext", "param", "vertical", "tld"):
                tier = key
                e = self.dictionary._sample_entry(tier, rng, lang_bias=0.5)
                if e:
                    slots[key] = e.word
            if "tld" in slots:
                slots["tld"] = slots["tld"].lstrip(".")
            g = DorkGenome(template=template, slots=slots,
                           lineage="seed",
                           born=time.strftime("%Y-%m-%d"))
            if g.key() in existing:
                continue
            existing.add(g.key())
            self.population.append(g)
        log.info("evolution: seeded population -> %d genomes",
                 len(self.population))

    def population_or_seed(self) -> list[DorkGenome]:
        if not self.population:
            self.seed_from_dictionary()
        return self.population

    def render_all(self) -> list[str]:
        """Canonical dork strings of the whole population (deduped)."""
        out: list[str] = []
        seen: set[str] = set()
        for g in self.population_or_seed():
            q = g.render()
            if q and q not in seen:
                seen.add(q)
                out.append(q)
        return out

    # ------------------------------------------------------------- recording
    def record(self, genome: DorkGenome, engine: str, urls: list[str],
               blocked: bool = False) -> None:
        """Fold one (engine, dork) run result into the genome's fitness."""
        with self._lock:
            f = genome.fitness
            f.runs += 1
            f.urls_total += len(urls)
            uniq = len(set(urls))
            f.urls_unique += uniq
            from core.crawler import score_url  # local import avoids cycle
            f.score_sum += sum(score_url(u) for u in urls)
            if blocked:
                f.blocked_runs += 1
            f.engines[engine] = f.engines.get(engine, 0) + len(urls)

    # -------------------------------------------------------------- breeding
    def next_generation(self) -> dict:
        """Breed the next generation; returns a summary of what changed."""
        if not self.population:
            return {"kept": 0, "culled": 0, "mutated": 0, "crossed": 0, "added": 0}
        rng = random.Random()
        pop = list(self.population)
        # Rank by fitness; unproven genomes (runs == 0) get -1 so they sit at
        # the bottom but are not culled before their first real run.
        proven = [g for g in pop if g.fitness.runs >= self.min_runs_before_cull]
        young = [g for g in pop if g.fitness.runs < self.min_runs_before_cull]
        proven.sort(key=lambda g: g.fitness.score, reverse=True)

        n_proven = len(proven)
        keep_n = max(1, int(n_proven * self.keep_frac))
        cull_n = int(n_proven * self.cull_frac)
        survivors = proven[:keep_n]
        culled = proven[-cull_n:] if cull_n and n_proven > keep_n + cull_n else []
        culled_keys = {g.key() for g in culled}

        parents_pool = proven[:max(2, keep_n * 2)]
        mutated = crossed = 0
        children: list[DorkGenome] = []

        # Mutation.
        for g in parents_pool:
            if rng.random() < self.mutation_rate:
                child = self._mutate(g, rng)
                if child and child.key() not in {c.key() for c in children}:
                    children.append(child)
                    mutated += 1

        # Crossover.
        for _ in range(max(1, int(len(parents_pool) * self.crossover_rate))):
            if len(parents_pool) < 2:
                break
            a, b = rng.sample(parents_pool, 2)
            child = self._crossover(a, b, rng)
            if child and child.key() not in {c.key() for c in children}:
                children.append(child)
                crossed += 1

        # Fresh blood from the dictionary.
        fresh = self.dictionary.generate(self.inject_new, seed=rng.randrange(2**30))

        # Assemble the new population.
        new_pop = survivors + young + children
        new_pop = [g for g in new_pop if g.key() not in culled_keys]
        # De-duplicate by rendered dork.
        seen: set[str] = set()
        uniq: list[DorkGenome] = []
        for g in new_pop:
            if g.key() in seen:
                continue
            seen.add(g.key())
            uniq.append(g)
        # Trim to max_population keeping the fittest.
        if len(uniq) > self.max_population:
            uniq.sort(key=lambda g: g.fitness.score, reverse=True)
            uniq = uniq[:self.max_population]
        self.population = uniq
        self.save()
        summary = {"kept": len(survivors), "culled": len(culled_keys),
                   "mutated": mutated, "crossed": crossed,
                   "added": len(fresh)}
        log.info("evolution: generation advanced %s", summary)
        return summary

    # -------------------------------------------------------------- genetics
    _SLOT_ORDER = ("script", "ext", "param", "vertical", "tld")

    def _mutate(self, g: DorkGenome, rng: random.Random) -> DorkGenome | None:
        """Mutate one random slot (keyword / extension / TLD mutation)."""
        mutable = [k for k in self._SLOT_ORDER if k in g.slots]
        if not mutable:
            return None
        key = rng.choice(mutable)
        tier = key
        e = self.dictionary._sample_entry(tier, rng, lang_bias=0.5)
        if not e:
            return None
        new_slots = dict(g.slots)
        new_val = e.word.lstrip(".") if key == "tld" else e.word
        if new_val == g.slots.get(key):
            return None
        new_slots[key] = new_val
        child = DorkGenome(template=g.template, slots=new_slots,
                           lineage=f"mutated({key})",
                           born=time.strftime("%Y-%m-%d"))
        # Skip children identical to an existing genome.
        if any(c.key() == child.key() for c in self.population):
            return None
        return child

    def _crossover(self, a: DorkGenome, b: DorkGenome, rng: random.Random) -> DorkGenome | None:
        """Mix slot halves of two parents; child keeps parent A's template."""
        child_slots: dict[str, str] = {}
        mid = len(self._SLOT_ORDER) // 2
        for i, key in enumerate(self._SLOT_ORDER):
            if key in a.slots and key in b.slots:
                child_slots[key] = a.slots[key] if i < mid else b.slots[key]
            elif key in a.slots:
                child_slots[key] = a.slots[key]
            elif key in b.slots:
                child_slots[key] = b.slots[key]
        if not child_slots:
            return None
        child = DorkGenome(template=a.template, slots=child_slots,
                           lineage="crossover",
                           born=time.strftime("%Y-%m-%d"))
        if any(c.key() == child.key() for c in self.population):
            return None
        return child

    # ---------------------------------------------------------------- report
    def report(self, top: int = 15) -> str:
        lines = ["== Dork evolution report =="]
        ranked = sorted(self.population,
                        key=lambda g: g.fitness.score, reverse=True)
        for g in ranked[:top]:
            lines.append(
                f"  [{g.fitness.score:>7.2f}] runs={g.fitness.runs:<3} "
                f"urls={g.fitness.urls_unique:<5} {g.render()}")
        total_runs = sum(g.fitness.runs for g in self.population)
        lines.append(f"  population={len(self.population)} "
                     f"total_runs={total_runs}")
        return "\n".join(lines)