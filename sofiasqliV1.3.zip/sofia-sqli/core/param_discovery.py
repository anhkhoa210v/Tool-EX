"""Parameter discovery and request/URL normalisation.

Turns raw target strings (from targets.txt or the crawler) into structured
``Target`` objects that carry:
  * method (GET / POST)
  * the base URL
  * discovered parameter names (GET query + POST body + form fields)
  * the POST body template (if any)

Also provides a light on-page crawl to discover parameters exposed via forms
and links when a URL has none of its own.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Iterable
from urllib.parse import parse_qsl, urlencode, urlparse, urlunparse

import requests
from bs4 import BeautifulSoup

from utils.logger import get_logger

log = get_logger("sofia-sqli.param_discovery")

_POST_LINE_RE = re.compile(r"^POST\s+(?P<url>\S+)(?:\s+\[(?P<data>[^\]]*)\])?\s*$", re.IGNORECASE)
_HEADER_LINE_RE = re.compile(r"^HEADERS\s*:\s*(?P<h>.+)$", re.IGNORECASE)
_INTERESTING_PARAM_RE = re.compile(
    r"(^|[_\-])(id|pid|cid|tid|aid|bid|sid|nid|eid|uid|mid|rid|kid|xid|"
    r"cat|catid|category|prod|product|productid|item|itemid|sku|brand|"
    r"news|newsid|article|artid|post|postid|blog|page|pageid|view|content|"
    r"contentid|section|topic|thread|forum|member|profile|comment|"
    r"doc|document|file|fileid|download|attachment|media|"
    r"user|userid|account|info|detail|record|recid|event|album|photo|"
    r"gallery|video|song|game|recipe|staff|emp|empid|order|invoice|"
    r"booking|hotel|tour|property|car|vehicle|job|course|lesson|exam|"
    r"question|answer|poll|survey|vote|"
    r"search|query|q|s|text|keyword|name|title|code|ref|no|num|val|value|"
    r"key|type|status|action|task|cmd|mode|lang|year|month|week|day|date|"
    r"sort|filter|sel|select|show|get|load|read|include|dir|path|folder|"
    r"report|menu|mod|listing|shop|store)($|[_\-])",
    re.IGNORECASE,
)


@dataclass
class Target:
    """A normalised, testable target."""

    url: str
    method: str = "GET"
    data: str = ""                    # POST body template (k=v&k2=v2)
    headers: dict[str, str] = field(default_factory=dict)
    params: list[str] = field(default_factory=list)
    source: str = "file"
    note: str = ""
    score: int = 0                      # rank_targets() heuristic score

    @property
    def domain(self) -> str:
        return urlparse(self.url).netloc

    def param_pairs(self) -> list[tuple[str, str]]:
        """Return (name, value) pairs for discovered parameters."""
        pairs: list[tuple[str, str]] = []
        if self.method.upper() == "POST" and self.data:
            pairs.extend(parse_qsl(self.data, keep_blank_values=True))
        pairs.extend(parse_qsl(urlparse(self.url).query, keep_blank_values=True))
        return pairs

    def as_line(self) -> str:
        """Serialise back into the targets.txt format."""
        if self.method.upper() == "POST":
            body = f" [{self.data}]" if self.data else ""
            return f"POST {self.url}{body}"
        return self.url


def parse_target_line(line: str, source: str = "file") -> Target | None:
    """Parse a single targets.txt line into a Target (or None if blank/comment)."""
    line = line.strip()
    if not line or line.startswith("#"):
        return None

    headers: dict[str, str] = {}
    hdr_match = _HEADER_LINE_RE.match(line)
    if hdr_match:
        for piece in hdr_match.group("h").split(";"):
            if ":" in piece:
                k, v = piece.split(":", 1)
                headers[k.strip()] = v.strip()
        # Header-only lines are attached to the previous target upstream; ignore here.
        return None

    m = _POST_LINE_RE.match(line)
    if m:
        url = m.group("url").strip()
        data = (m.group("data") or "").strip()
        tgt = Target(url=url, method="POST", data=data, source=source)
        tgt.params = [k for k, _ in tgt.param_pairs()]
        return tgt

    url = _normalise_url(line)
    if not url:
        return None
    tgt = Target(url=url, method="GET", source=source)
    tgt.params = [k for k, _ in tgt.param_pairs()]
    return tgt


def _normalise_url(url: str) -> str | None:
    url = url.strip()
    if url.startswith("dork:"):
        return None
    if not url.lower().startswith(("http://", "https://")):
        url = "http://" + url
    try:
        parts = urlparse(url)
    except ValueError:
        return None
    if not parts.netloc:
        return None
    return urlunparse((parts.scheme, parts.netloc, parts.path, parts.params, parts.query, ""))


def load_targets_from_file(path: str) -> list[Target]:
    """Read targets.txt and return parsed targets (deduplicated)."""
    targets: list[Target] = []
    seen: set[str] = set()
    try:
        with open(path, "r", encoding="utf-8") as fh:
            raw_lines = fh.readlines()
    except FileNotFoundError:
        log.warning("Targets file not found: %s", path)
        return []

    pending_headers: dict[str, str] = {}
    for line in raw_lines:
        hdr_match = _HEADER_LINE_RE.match(line.strip())
        if hdr_match:
            for piece in hdr_match.group("h").split(";"):
                if ":" in piece:
                    k, v = piece.split(":", 1)
                    pending_headers[k.strip()] = v.strip()
            continue

        tgt = parse_target_line(line)
        if not tgt:
            continue
        if pending_headers:
            tgt.headers.update(pending_headers)
            pending_headers = {}

        key = f"{tgt.method}:{tgt.url}:{tgt.data}"
        if key in seen:
            continue
        seen.add(key)
        targets.append(tgt)

    log.info("Loaded %d targets from %s", len(targets), path)
    return targets


def targets_from_urls(urls: Iterable[str], source: str = "crawler") -> list[Target]:
    """Build Targets from a raw URL iterable (crawler output)."""
    out: list[Target] = []
    for url in urls:
        tgt = parse_target_line(url, source=source)
        if tgt:
            out.append(tgt)
    return out


def dedupe_targets(targets: Iterable[Target]) -> list[Target]:
    """Remove duplicate targets across sources (file wins on tie)."""
    seen: set[str] = set()
    out: list[Target] = []
    for tgt in targets:
        key = f"{tgt.method}:{tgt.url}:{tgt.data}".lower()
        if key in seen:
            continue
        seen.add(key)
        out.append(tgt)
    return out


def rank_params(params: Iterable[str],
                extra: Iterable[str] | None = None) -> list[str]:
    """Sort parameters so 'interesting' injection-prone ones are tested first.

    ``extra`` names (from ``param_discovery.extra_param_names``) are also
    treated as injection-prone, on top of the built-in regex.
    """
    extra_set = {n.lower() for n in (extra or []) if n}

    def score(name: str) -> int:
        if _INTERESTING_PARAM_RE.search(name) or name.lower() in extra_set:
            return 0
        return 1
    return sorted(set(params), key=lambda n: (score(n), n))


def discover_params_from_page(target: Target, timeout: float = 15.0,
                              session: requests.Session | None = None,
                              max_links: int = 40,
                              user_agent: str = "Mozilla/5.0") -> list[str]:
    """Light crawl: pull param names from forms/links on the target page."""
    session = session or requests.Session()
    try:
        resp = session.get(target.url, timeout=timeout,
                           headers={"User-Agent": user_agent or "Mozilla/5.0"})
    except requests.RequestException as exc:
        log.debug("param discovery fetch failed for %s: %s", target.url, exc)
        return []

    try:
        soup = BeautifulSoup(resp.text, "lxml")
    except Exception:
        soup = BeautifulSoup(resp.text, "html.parser")

    names: set[str] = set()

    # <input name=...> inside forms.
    for inp in soup.find_all(["input", "select", "textarea"]):
        name = inp.get("name")
        if name and name.lower() not in {"submit", "csrf", "token", "_token", "captcha"}:
            names.add(name)

    # Query params present in same-host links.
    base_host = urlparse(target.url).netloc
    for a in soup.find_all("a", href=True)[:max_links]:
        href = a["href"]
        if "?" not in href:
            continue
        q = urlparse(href).query
        for k, _ in parse_qsl(q, keep_blank_values=True):
            if k:
                names.add(k)

    names.discard("")
    return rank_params(names)


def enrich_target(target: Target, session: requests.Session | None = None,
                  timeout: float = 15.0,
                  cfg: dict | None = None) -> Target:
    """Ensure a target has at least one candidate parameter to test.

    ``cfg`` comes from the ``param_discovery`` section of settings.yaml:
      * ``enabled``            - allow the light page crawl (default true)
      * ``max_links``          - links scanned per page (default 40)
      * ``user_agent``         - UA for the crawl (empty = "Mozilla/5.0")
      * ``max_params``         - cap candidate params, interesting ones first
                                 (0 = unlimited)
      * ``extra_param_names``  - user param names treated as interesting
    """
    cfg = cfg or {}
    extra_names = tuple(n for n in (cfg.get("extra_param_names") or []) if n)

    if not target.params and bool(cfg.get("enabled", True)):
        extra = discover_params_from_page(
            target,
            timeout=timeout,
            session=session,
            max_links=int(cfg.get("max_links", 40) or 40),
            user_agent=str(cfg.get("user_agent") or "Mozilla/5.0"),
        )
        if extra:
            target.params = extra
            target.note = "params-from-page"
            log.debug("%s -> discovered %d params from page", target.url, len(extra))

    if target.params:
        target.params = rank_params(target.params, extra=extra_names)
        limit = int(cfg.get("max_params", 0) or 0)
        if limit > 0 and len(target.params) > limit:
            log.debug("%s -> capped params %d -> %d (max_params)",
                      target.url, len(target.params), limit)
            target.params = target.params[:limit]
    return target


def build_post_data(params: Iterable[str], existing: str = "") -> str:
    """Build a POST body from parameter names, preserving existing values."""
    values = dict(parse_qsl(existing, keep_blank_values=True)) if existing else {}
    body = {}
    for name in params:
        body[name] = values.get(name, "1")
    return urlencode(body)


# ---------------------------------------------------------------------------
# Target ranking: prioritise URLs that look the most SQLi-testable first.
# ---------------------------------------------------------------------------

_CLASSIC_SQLI_EXT_RE = re.compile(
    r"\.(?:php[2-7]?|asp|aspx|jsp|jspx|cfm|cgi|pl|py|rb|do|action)(?:$|[/?#])",
    re.IGNORECASE,
)
_NUMERIC_VALUE_RE = re.compile(r"^\d+$")


def score_target(target: Target) -> int:
    """Heuristic 0-15+ score estimating how promising a target is for SQLi.

    Signals (additive):
      * injection-prone parameter names      +2 each (cap  6)
      * numeric parameter values             +1 each (cap  3)
      * classic SQLi script extension        +3
      * POST with a body                     +1
      * 1-3 distinct parameters              +1
      * more than 8 distinct parameters      -1
      * URL longer than 300 chars            -2
    """
    pairs = target.param_pairs()
    names = [n for n, _ in pairs]
    values = [v for _, v in pairs]

    score = 0

    prone = sum(1 for n in names if _INTERESTING_PARAM_RE.search(n))
    score += min(6, prone * 2)

    numeric = sum(1 for v in values if _NUMERIC_VALUE_RE.match(v))
    score += min(3, numeric)

    path = urlparse(target.url).path
    if _CLASSIC_SQLI_EXT_RE.search(path):
        score += 3

    if target.method.upper() == "POST" and target.data:
        score += 1

    n_params = len(set(names))
    if 1 <= n_params <= 3:
        score += 1
    elif n_params > 8:
        score -= 1

    if len(target.url) > 300:
        score -= 2

    return score


def rank_targets(targets: Iterable[Target]) -> list[Target]:
    """Return targets sorted most-SQLi-promising first.

    Deterministic: equal scores are broken by URL, then method, then body.
    Each target's ``.score`` attribute is populated for reporting.
    """
    ranked: list[Target] = []
    for tgt in targets:
        tgt.score = score_target(tgt)
        ranked.append(tgt)
    ranked.sort(key=lambda t: (-t.score, t.url.lower(), t.method.upper(), t.data))
    return ranked
