"""Per-engine dork syntax adapter.

One canonical dork (Google syntax, e.g. ``inurl:"shop.php?id=" site:.vn``) is
the project's *internal* representation. This module translates it into the
syntax each target engine actually understands:

============  =========================================================
Engine        Translation
============  =========================================================
google        as-is (canonical form)
serpapi       as-is (SerpAPI proxies Google)
cse           as-is (Google CSE uses Google query syntax)
bing          keep inurl:/intitle:/site:/filetype:; only ONE inurl:
              allowed per query (extra ones become free text); intext:
              has no operator -> plain keyword
duckduckgo    keep inurl:/intitle:/site:/filetype:/intext:
ddglite       same as duckduckgo
yandex        inurl:X  -> url:"*X*"   (url: matches URL with wildcards)
              intitle: -> title:, intext: -> plain text,
              filetype:pdf -> mime:pdf, site: kept, lang: supported
mojeek        keep inurl:/intitle:/site:; drop filetype:
startpage     Google-style pass-through (proxies Google)
urlscan       DSL: inurl:T -> page.url:"*T*", site:D -> page.domain:D,
              intitle:T -> page.title:"*T*"; filetype/intext dropped
commoncrawl   CDX url pattern built from the first inurl term only
wayback       alias of commoncrawl (same CDX url field)
============  =========================================================

``to_engine()`` returns the rendered query for the engine. Engines whose
syntax cannot express a term simply *drop* that term instead of emitting a
broken query (saves quota and avoids garbage results).
"""

from __future__ import annotations

import re

# One operator token: name:value  (value optionally quoted)
_TOKEN_RE = re.compile(
    r'\b(inurl|allinurl|intitle|allintitle|intext|allintext|site|filetype|'
    r'ext|contains|language|lang|loc|location|before|after|inanchor|'
    r'cache|related|link|info|define|numrange|safesearch|source)\s*:\s*'
    r'("[^"]*"|\S+)',
    re.IGNORECASE,
)

_ENGINE_RULES: dict[str, dict] = {
    # engine: {"keep": set|None(all), "one_inurl": bool, "map": {op: fn}}
    "google": {"keep": None, "one_inurl": False, "drop": {"cache", "related", "link", "inanchor"}},
    "serpapi": {"keep": None, "one_inurl": False, "drop": {"cache", "related", "link", "inanchor"}},
    "cse": {"keep": None, "one_inurl": False, "drop": {"cache", "related", "link", "inanchor"}},
    "startpage": {"keep": None, "one_inurl": False, "drop": {"cache", "related", "link", "inanchor"}},
    "bing": {"keep": None, "one_inurl": True, "drop": {"intext", "allintext", "allinurl", "cache", "related", "link", "inanchor", "before", "after", "numrange", "define", "info", "source", "safesearch"}},
    "duckduckgo": {"keep": None, "one_inurl": False, "drop": {"cache", "related", "link", "inanchor", "numrange", "define", "info", "source", "safesearch"}},
    "ddglite": {"keep": None, "one_inurl": False, "drop": {"cache", "related", "link", "inanchor", "numrange", "define", "info", "source", "safesearch"}},
    "mojeek": {"keep": {"inurl", "intitle", "site", "intext", "allintitle"}, "one_inurl": True, "drop": {"filetype", "ext", "cache", "related", "link", "inanchor", "before", "after"}},
    "yandex": {"keep": None, "one_inurl": False, "drop": set()},
    "urlscan": {"keep": None, "one_inurl": False, "drop": set()},
    "commoncrawl": {"keep": None, "one_inurl": False, "drop": set()},
    "wayback": {"keep": None, "one_inurl": False, "drop": set()},
}

# Engines that can never express intext: as an operator (plain text instead).
_PLAINTEXT_INSTEAD = {"bing", "mojeek"}


def parse_tokens(canonical: str) -> list[tuple[str, str, str]]:
    """Split a canonical dork into (kind, op, value) tokens.

    kind = "op" for operator terms, "text" for free keywords.
    Preserves the original order (matters for readability of SERPs).
    """
    tokens: list[tuple[str, str, str]] = []
    pos = 0
    for m in _TOKEN_RE.finditer(canonical):
        if m.start() > pos:
            _add_text_tokens(canonical[pos:m.start()], tokens)
        tokens.append(("op", m.group(1).lower(), m.group(2)))
        pos = m.end()
    if pos < len(canonical):
        _add_text_tokens(canonical[pos:], tokens)
    return tokens


def _add_text_tokens(chunk: str, tokens: list[tuple[str, str, str]]) -> None:
    for w in chunk.split():
        w = w.strip()
        if w:
            tokens.append(("text", "", w))


def _strip_quotes(v: str) -> str:
    if len(v) >= 2 and v[0] == '"' and v[-1] == '"':
        return v[1:-1]
    return v


# ------------------------------------------------------------------ helpers
def _first_url_term(tokens) -> str | None:
    for kind, op, val in tokens:
        if kind == "op" and op in ("inurl", "allinurl"):
            return _strip_quotes(val)
    return None


def _first_title_term(tokens) -> str | None:
    for kind, op, val in tokens:
        if kind == "op" and op in ("intitle", "allintitle"):
            return _strip_quotes(val)
    return None


def _first_site(tokens) -> str | None:
    for kind, op, val in tokens:
        if kind == "op" and op == "site":
            return _strip_quotes(val).lstrip(".")
    return None


# ------------------------------------------------------------ translations
def _translate_generic(tokens, engine: str) -> str:
    """Operator-preserving translation for Google-family engines."""
    rule = _ENGINE_RULES[engine]
    drop = rule.get("drop") or set()
    parts: list[str] = []
    seen_inurl = 0
    for kind, op, val in tokens:
        if kind == "text":
            parts.append(val)
            continue
        if op in drop:
            continue
        if op in ("intext", "allintext") and engine in _PLAINTEXT_INSTEAD:
            parts.append(_strip_quotes(val))
            continue
        if op == "allinurl":
            op = "inurl"
        if op == "allintitle":
            op = "intitle"
        if op in ("inurl", "allinurl"):
            seen_inurl += 1
            if rule.get("one_inurl") and seen_inurl > 1:
                # Bing/mojeek: extra inurl: degrade -> keep as free text
                parts.append(_strip_quotes(val))
                continue
        parts.append(f"{op}:{val}")
    return " ".join(p for p in parts if p).strip()


def _translate_yandex(tokens) -> str:
    parts: list[str] = []
    for kind, op, val in tokens:
        if kind == "text":
            parts.append(val)
            continue
        v = _strip_quotes(val)
        if op in ("inurl", "allinurl"):
            parts.append(f'url:"*{v}*"')
        elif op in ("intitle", "allintitle"):
            parts.append(f'title:"{v}"' if " " in v else f"title:{v}")
        elif op in ("intext", "allintext"):
            parts.append(v)                    # Yandex: body search by default
        elif op == "site":
            parts.append(f"site:{v.lstrip('.')}")
        elif op == "filetype" or op == "ext":
            parts.append(f"mime:{v}")
        elif op == "language":
            parts.append(f"lang:{v}")
        elif op in ("before",):
            parts.append(f"date:<{v}")
        elif op == "after":
            parts.append(f"date:>{v}")
        # cache/related/link/inanchor/numrange/define/info: dropped
    return " ".join(p for p in parts if p).strip()


def _translate_urlscan(tokens) -> str:
    """urlscan.io search DSL (https://urlscan.io/docs/search/)."""
    parts: list[str] = []
    for kind, op, val in tokens:
        if kind == "text":
            continue                            # urlscan has no free text
        v = _strip_quotes(val)
        if op in ("inurl", "allinurl"):
            parts.append(f'page.url:"*{v}*"')
        elif op == "site":
            parts.append(f"page.domain:{v.lstrip('.')}")
        elif op in ("intitle", "allintitle"):
            parts.append(f'page.title:"*{v}*"')
        elif op in ("intext", "allintext"):
            parts.append(f'page.text:"*{v}*"')
        elif op == "filetype" or op == "ext":
            parts.append(f'page.url:"*.{v}"')
        elif op == "language":
            parts.append(f"page.language:{v}")
        # other operators unsupported -> dropped
    return " ".join(p for p in parts if p).strip()


def _translate_cdx(tokens) -> str:
    """CDX (Wayback / Common Crawl) takes a single URL pattern."""
    term = _first_url_term(tokens)
    if not term:
        # Fall back: any site restriction -> domain prefix pattern.
        site = _first_site(tokens)
        if site:
            return f"*.{site}/*"
        return ""
    # Escape nothing: CDX uses * wildcards and literal text.
    return f"*{term}*"


_TRANSLATORS = {
    "yandex": _translate_yandex,
    "urlscan": _translate_urlscan,
    "commoncrawl": _translate_cdx,
    "wayback": _translate_cdx,
}


def to_engine(canonical: str, engine: str) -> str:
    """Translate a canonical (Google-syntax) dork into engine-specific syntax.

    Returns "" when the engine cannot express anything useful from the dork
    (caller should skip the query to save quota).
    """
    engine = engine.lower().strip()
    tokens = parse_tokens(canonical)
    if not tokens:
        return ""
    fn = _TRANSLATORS.get(engine)
    if fn:
        return fn(tokens)
    rule = _ENGINE_RULES.get(engine)
    if rule is None:
        # Unknown engine: pass-through Google syntax (best effort).
        return _translate_generic(tokens, "google")
    return _translate_generic(tokens, engine)


def urlscan_query(canonical: str) -> str:
    """Convenience wrapper used by the urlscan source."""
    return _translate_urlscan(parse_tokens(canonical))


def cdx_pattern(canonical: str) -> str:
    """Convenience wrapper used by the wayback/commoncrawl sources."""
    return _translate_cdx(parse_tokens(canonical))


def supports_engine(engine: str) -> bool:
    return engine.lower().strip() in _ENGINE_RULES