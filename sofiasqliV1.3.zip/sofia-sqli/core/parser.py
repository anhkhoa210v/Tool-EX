"""Detailed parser for sqlmap console output.

Extracts structured facts the plain console hides in prose:

  * whether the target is injectable
  * DBMS name + version
  * web server OS + web app technology
  * databases, current database/user
  * tables per database (used to fill the "3 tables" report field)
  * injection points: parameter, place, technique, title, payload

Everything is regex-based against ANSI-stripped text, so it tolerates both the
``detect`` (``--dbs --banner``) and ``tables`` (``-D x --tables``) phases.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

from core.param_discovery import Target
from core.exploit import SqlmapRun
from utils.logger import get_logger

log = get_logger("sofia-sqli.parser")

_ANSI_RE = re.compile(r"\x1b\[[0-9;]*m")

_SYS_DBS = {"information_schema", "mysql", "performance_schema", "sys",
            "master", "model", "msdb", "tempdb", "postgres", "template0",
            "template1"}


def strip_ansi(text: str) -> str:
    return _ANSI_RE.sub("", text or "")


@dataclass
class InjectionPoint:
    """One identified injection point."""

    parameter: str
    place: str                 # GET | POST | ...
    technologies: list[str] = field(default_factory=list)
    titles: list[str] = field(default_factory=list)
    payloads: list[str] = field(default_factory=list)

    @property
    def technique_summary(self) -> str:
        # e.g. "boolean-based blind, time-based blind"
        cleaned = []
        for t in self.titles:
            base = t.split(" - ")[0].strip()
            if base and base not in cleaned:
                cleaned.append(base)
        return ", ".join(cleaned) or "unknown"

    def location(self) -> str:
        return f"{self.place} parameter '{self.parameter}'"


@dataclass
class Finding:
    """Structured verification result for one target."""

    target: Target
    vulnerable: bool = False
    dbms: str = ""
    dbms_version: str = ""
    dbms_full: str = ""              # "MySQL >= 5.0"
    os: str = ""
    web_app: str = ""
    current_db: str = ""
    current_user: str = ""
    databases: list[str] = field(default_factory=list)
    tables_by_db: dict[str, list[str]] = field(default_factory=dict)
    injection_points: list[InjectionPoint] = field(default_factory=list)
    payloads: list[str] = field(default_factory=list)
    evidence_files: list[str] = field(default_factory=list)
    stdout_excerpt: str = ""
    note: str = ""
    heuristic_reason: str = ""

    # -------- derived fields used by the Discord report --------
    @property
    def domain(self) -> str:
        return self.target.domain

    def non_system_databases(self) -> list[str]:
        return [d for d in self.databases if d.lower() not in _SYS_DBS]

    def top_tables(self, limit: int = 3) -> list[str]:
        """Return up to ``limit`` table names, preferring the app database."""
        ordered_dbs: list[str] = []
        if self.current_db:
            ordered_dbs.append(self.current_db)
        ordered_dbs.extend(d for d in self.non_system_databases() if d not in ordered_dbs)
        ordered_dbs.extend(d for d in self.tables_by_db if d not in ordered_dbs)

        tables: list[str] = []
        for db in ordered_dbs:
            for t in self.tables_by_db.get(db, []):
                if t not in tables:
                    tables.append(t)
                if len(tables) >= limit:
                    return tables
        # Fall back to any table we saw, regardless of database grouping.
        for tlist in self.tables_by_db.values():
            for t in tlist:
                if t not in tables:
                    tables.append(t)
                if len(tables) >= limit:
                    return tables
        return tables

    def injection_location(self) -> str:
        if not self.injection_points:
            return "unknown"
        ip = self.injection_points[0]
        loc = ip.location()
        extra = len(self.injection_points) - 1
        if extra > 0:
            loc += f" (+{extra} more)"
        return loc

    def dbms_display(self) -> str:
        """Human-facing 'DBMS + version', e.g. 'SQLite 3.9' or 'MySQL >= 5.0'."""
        base = self.dbms_full or self.dbms
        if not base:
            return "unknown"
        # Append the parsed version unless the banner string already carries it.
        if self.dbms_version and self.dbms_version not in base:
            return f"{base} {self.dbms_version}"
        return base

    def report_line(self) -> str:
        """The exact 'Domain | DBMS+version | tables | injection location' line."""
        dbms = self.dbms_display()
        tables = self.top_tables(3)
        tables_s = ", ".join(tables) if tables else "n/a"
        return f"{self.domain} | {dbms} | {tables_s} | {self.injection_location()}"


class SqlmapParser:
    """Parse a SqlmapRun (or raw text) into a Finding."""

    RE_DBMS_INFO = re.compile(r"\[INFO\] the back-end DBMS is (?P<v>.+?)\s*$", re.M | re.I)
    RE_DBMS_BANNER = re.compile(r"back-end DBMS:\s*(?P<v>.+?)\s*$", re.M | re.I)
    RE_BANNER = re.compile(r"\[INFO\] retrieved banner:\s*(?P<v>.+?)\s*$", re.M | re.I)
    RE_OS = re.compile(r"(?:web server operating system|web OS):\s*(?P<v>.+?)\s*$", re.M | re.I)
    RE_WEBAPP = re.compile(r"web application technology:\s*(?P<v>.+?)\s*$", re.M | re.I)
    RE_CURDB = re.compile(r"\[INFO\] fetching current database\s*$|current database:\s*'(?P<v>[^']+)'", re.M | re.I)
    RE_CURUSER = re.compile(r"current user:\s*'(?P<v>[^']+)'", re.M | re.I)

    RE_PARAM = re.compile(r"^\s*Parameter:\s*(?P<name>.+?)\s*\((?P<place>[^)]+)\)\s*$", re.M)
    RE_TYPE = re.compile(r"^\s*Type:\s*(?P<v>.+?)\s*$", re.M)
    RE_TITLE = re.compile(r"^\s*Title:\s*(?P<v>.+?)\s*$", re.M)
    RE_PAYLOAD = re.compile(r"^\s*Payload:\s*(?P<v>.+?)\s*$", re.M)

    RE_DBS_HEADER = re.compile(r"available databases\s*\[(?P<n>\d+)\]", re.I)
    RE_DB_ITEM = re.compile(r"^\s*\[\*\]\s*(?P<name>.+?)\s*$", re.M)

    RE_TABLE_HEADER = re.compile(r"\[(?P<n>\d+)\s+tables?\]", re.I)
    RE_TABLE_ROW = re.compile(r"^\s*\|\s*(?P<name>[^|]+?)\s*\|\s*$", re.M)

    RE_IDENTIFIED = re.compile(
        r"sqlmap identified the following injection point", re.I)
    RE_NOT_INJECTABLE = re.compile(
        r"(all tested parameters do not appear to be injectable|"
        r"does not seem to be injectable|"
        r"no parameters are injectable)", re.I)
    RE_INJECTABLE_CONFIRM = re.compile(
        r"(is vulnerable\.|appears to be injectable|the following injection point|"
        r"Parameter:.*\(|resumed the following injection point)", re.I)

    # ---------------------------------------------------------------- helpers
    @staticmethod
    def _slice_section(text: str, start_pat: re.Pattern, stop_markers: list[str],
                       max_len: int = 6000) -> str:
        m = start_pat.search(text)
        if not m:
            return ""
        chunk = text[m.start(): m.start() + max_len]
        for marker in stop_markers:
            idx = chunk.find(marker, 1)
            if idx > 0:
                chunk = chunk[:idx]
        return chunk

    # ------------------------------------------------------------------ main
    def parse_text(self, text: str, target: Target | None = None) -> Finding:
        text = strip_ansi(text)
        finding = Finding(target=target)  # type: ignore[arg-type]

        low = text.lower()
        finding.vulnerable = bool(self.RE_INJECTABLE_CONFIRM.search(text)) and not bool(
            self.RE_NOT_INJECTABLE.search(text) and not self.RE_IDENTIFIED.search(text)
        )
        # More precise: an injection block is the strongest confirmation.
        if self.RE_IDENTIFIED.search(text):
            finding.vulnerable = True
        if self.RE_NOT_INJECTABLE.search(text) and not self.RE_IDENTIFIED.search(text):
            finding.vulnerable = False

        # --- DBMS ---
        m = self.RE_DBMS_BANNER.search(text) or self.RE_DBMS_INFO.search(text)
        if m:
            finding.dbms_full = m.group("v").strip().rstrip(".")
            finding.dbms, finding.dbms_version = self._split_dbms(finding.dbms_full)
        if not finding.dbms:
            # Fallback: banner text often starts with the DBMS name.
            b = self.RE_BANNER.search(text)
            if b:
                finding.dbms_full = b.group("v").strip()
                finding.dbms, finding.dbms_version = self._split_dbms(finding.dbms_full)
        if not finding.dbms_version:
            b = self.RE_BANNER.search(text)
            if b:
                ver = re.search(r"\d+\.\d+[\w.\-]*", b.group("v"))
                if ver:
                    finding.dbms_version = ver.group(0)

        os_m = self.RE_OS.search(text)
        if os_m:
            finding.os = os_m.group("v").strip()
        web_m = self.RE_WEBAPP.search(text)
        if web_m:
            finding.web_app = web_m.group("v").strip()

        curdb = self.RE_CURDB.search(text)
        if curdb and curdb.groupdict().get("v"):
            finding.current_db = curdb.group("v").strip()
        curuser = self.RE_CURUSER.search(text)
        if curuser:
            finding.current_user = curuser.group("v").strip()

        # --- injection points ---
        finding.injection_points = self._parse_injection_points(text)
        if finding.injection_points and not finding.vulnerable:
            finding.vulnerable = True

        # Version fallback: technique titles often carry it, e.g.
        # 'SQLite > 2.0 AND time-based blind'.
        if not finding.dbms_version:
            for ip in finding.injection_points:
                for title in ip.titles:
                    ver = re.search(r"(\d+\.\d+[\w.\-]*)", title)
                    if ver:
                        finding.dbms_version = ver.group(1)
                        break
                if finding.dbms_version:
                    break

        # --- databases ---
        finding.databases = self._parse_databases(text)

        # --- tables (per database) ---
        finding.tables_by_db = self._parse_tables(text)
        if finding.tables_by_db and not finding.current_db:
            finding.current_db = next(iter(finding.tables_by_db))

        # --- payloads ---
        for ip in finding.injection_points:
            for p in ip.payloads:
                if p not in finding.payloads:
                    finding.payloads.append(p)

        if not finding.vulnerable and "not injectable" in low:
            finding.note = "sqlmap reported target not injectable"
        finding.stdout_excerpt = self._excerpt(text)
        return finding

    def parse_run(self, run: SqlmapRun, target: Target) -> Finding:
        finding = self.parse_text(run.combined(), target=target)
        if run.output_file:
            finding.evidence_files.append(run.output_file)
        if run.timed_out:
            finding.note = (finding.note + " | sqlmap timed out").strip(" |")
        return finding

    # -------------------------------------------------------------- sub-parsers
    @staticmethod
    def _split_dbms(full: str) -> tuple[str, str]:
        full = full.strip().rstrip(".")
        m = re.match(r"(?P<name>[A-Za-z][A-Za-z0-9 _\-]+?)\s*(?P<ver>[><=]?=?\s*\d[\w.\-]*)", full)
        if m:
            name = m.group("name").strip()
            ver = re.sub(r"\s+", " ", m.group("ver")).strip()
            return name, ver
        return full, ""

    def _parse_injection_points(self, text: str) -> list[InjectionPoint]:
        section = self._slice_section(
            text, self.RE_IDENTIFIED,
            stop_markers=["[INFO]", "fetched data", "available databases",
                          "[CRITICAL]", "back-end DBMS"],
            max_len=8000,
        )
        if not section:
            # Some runs only print the parameter block without the header line.
            section = text

        points: list[InjectionPoint] = []
        # Split on "Parameter:" anchors.
        matches = list(self.RE_PARAM.finditer(section))
        for i, m in enumerate(matches):
            start = m.end()
            end = matches[i + 1].start() if i + 1 < len(matches) else len(section)
            block = section[start:end]
            ip = InjectionPoint(parameter=m.group("name").strip(),
                                place=m.group("place").strip().upper())
            # technologies line (e.g. "Type: ..." and technique headers)
            for t in self.RE_TITLE.findall(block):
                ip.titles.append(t.strip())
            for p in self.RE_PAYLOAD.findall(block):
                ip.payloads.append(p.strip())
            # If no Title lines but Type lines exist, use them.
            if not ip.titles:
                for t in self.RE_TYPE.findall(block):
                    ip.titles.append(t.strip())
            points.append(ip)
        return points

    def _parse_databases(self, text: str) -> list[str]:
        if not self.RE_DBS_HEADER.search(text):
            return []
        section = self._slice_section(
            text, self.RE_DBS_HEADER,
            stop_markers=["[INFO]", "Database:", "[CRITICAL]"],
            max_len=4000,
        )
        dbs: list[str] = []
        for name in self.RE_DB_ITEM.findall(section):
            name = name.strip()
            if name and name not in dbs:
                dbs.append(name)
        return dbs

    def _parse_tables(self, text: str) -> dict[str, list[str]]:
        """Parse 'Database: X' + '[... tables]' table-list blocks."""
        result: dict[str, list[str]] = {}
        # Find every "Database: <name>" anchor with a following table listing.
        db_anchor = re.compile(r"Database:\s*(?P<db>.+?)\s*$", re.M)
        anchors = list(db_anchor.finditer(text))
        for i, m in enumerate(anchors):
            db = m.group("db").strip()
            start = m.end()
            end = anchors[i + 1].start() if i + 1 < len(anchors) else len(text)
            block = text[start:end]
            header = self.RE_TABLE_HEADER.search(block)
            if not header:
                continue
            # Only scan the region between this header and the next 'Database:'
            region = block[header.end():]
            names: list[str] = []
            for row in self.RE_TABLE_ROW.findall(region):
                name = row.strip()
                if not name or set(name) <= {"+", "-"}:
                    continue
                if name.lower() in {"table", "column", "type", "<current>"}:
                    continue
                if name not in names:
                    names.append(name)
            if names:
                result[db] = names

        # Fallback: some DBMS (notably SQLite) print '[N tables]' without a
        # preceding 'Database:' anchor line.
        if not result:
            for hm in re.finditer(r"\[(?P<n>\d+)\s+tables?\]", text, re.I):
                region = text[hm.end(): hm.end() + 3000]
                for stop in ("[INFO]", "[CRITICAL]", "fetched data"):
                    idx = region.find(stop)
                    if idx > 0:
                        region = region[:idx]
                names: list[str] = []
                for row in self.RE_TABLE_ROW.findall(region):
                    name = row.strip()
                    if not name or set(name) <= {"+", "-"}:
                        continue
                    if name.lower() in {"table", "column", "type", "<current>"}:
                        continue
                    if name not in names:
                        names.append(name)
                if names:
                    result["main"] = names
                    break
        return result

    @staticmethod
    def _excerpt(text: str, lines: int = 25) -> str:
        interesting = []
        for line in text.splitlines():
            if any(k in line for k in ("injection point", "Parameter:", "Payload:",
                                       "back-end DBMS", "available databases",
                                       "Database:", "injectable", "vulnerable",
                                       "Type:", "Title:", "tables]")):
                interesting.append(line.rstrip())
        if not interesting:
            interesting = [l.rstrip() for l in text.splitlines()[-lines:]]
        return "\n".join(interesting[:60])
