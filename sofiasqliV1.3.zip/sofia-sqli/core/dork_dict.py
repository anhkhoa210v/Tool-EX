"""Multi-tier, multi-language dork dictionary with automatic combination
generation and a self-learning feedback loop.

Design
------
The dictionary is organised in *tiers*. A generated dork picks one value per
tier and renders it through a template, so "shop" style verticals are always
combined with scripts, parameters, extensions and TLDs instead of being
searched alone:

    tier vertical : shop / store / cửa hàng / магазин / tienda ...
    tier script   : product.php / sanpham.php / item.asp ...
    tier param    : id / cat / masp / pid ...
    tier extension: php / asp / aspx / jsp ...
    tier tld      : com / vn / com.vn / ru / de ...

Learning loop (feedback)
------------------------
``observe_urls()`` parses every harvested URL, extracts script names, query
parameter names, path tokens (vertical keywords) and TLDs, then:

* bumps ``hits`` of entries already in the dictionary (auto weighting),
* collects *unknown* tokens with a frequency counter,
* promotes unknown tokens whose count >= ``min_count`` into a human-approve
  queue persisted in ``config/dork_pending.json``,
* ``approve_pending()`` moves approved entries into ``dork_learned.json``
  which is merged into the dictionary on the next run (self-learning).

Everything is persisted as JSON so the state survives across runs.
"""

from __future__ import annotations

import json
import os
import random
import re
import threading
import unicodedata
import time
from collections import Counter
from dataclasses import dataclass, field
from urllib.parse import parse_qsl, urlparse

from utils.logger import get_logger

log = get_logger("sofia-sqli.dork_dict")

# --------------------------------------------------------------------------
# Built-in multi-tier, multi-language dictionary.
# langs = language codes the entry is useful for. "en" also acts as the
# default/fallback bucket for every language.
# --------------------------------------------------------------------------
_BUILTIN: dict[str, dict[str, list[str]]] = {
    # Tier 1 - business vertical keywords (what the site *is*).
    "vertical": {
        "en": ["shop", "store", "ecommerce", "online store", "webshop",
               "market", "mall", "boutique", "catalog", "catalogue",
               "product", "products", "cart", "checkout", "order",
               "news", "blog", "forum", "portal", "cms", "classifieds",
               "directory", "booking", "hotel", "travel", "real estate",
               "auction", "wholesale", "pharmacy", "restaurant", "menu",
               "electronics", "fashion", "shoes", "jewelry", "watches",
               "cosmetics", "beauty", "furniture", "toys", "games",
               "grocery", "supermarket", "bakery", "coffee", "bar",
               "sports", "fitness", "tickets", "flights", "car rental",
               "insurance", "finance", "loans", "jobs", "courses",
               "education", "school", "university", "clinic", "dental",
               "salon", "spa", "wedding", "photography", "printing",
               "construction", "logistics", "shipping", "auto parts",
               "car dealer", "motorcycle", "bicycle", "pet shop",
               "flowers", "gifts", "books", "music", "movies", "hardware",
               "garden", "industrial", "supplier", "distributor",
               "import", "export"],
        "vi": ["cửa hàng", "shop", "bán hàng", "bán lẻ", "sản phẩm",
               "giỏ hàng", "thanh toán", "đặt hàng", "danh mục",
               "tin tức", "rao vặt", "bất động sản", "khách sạn",
               "du lịch", "đặt phòng", "siêu thị", "chợ", "thời trang",
               "điện thoại", "laptop", "máy tính", "nội thất", "mỹ phẩm",
               "thực phẩm", "nhà hàng", "quán", "dịch vụ", "công ty",
               "điện máy", "giày dép", "túi xách", "trang sức", "đồng hồ",
               "hoa", "quà tặng", "đồ chơi", "thú cưng", "thể thao",
               "xe máy", "ô tô", "xe đạp", "vé máy bay", "tour du lịch",
               "nhà đất", "mẹ và bé", "sức khỏe", "nha khoa", "phòng khám",
               "thẩm mỹ", "spa", "làm đẹp", "ẩm thực", "cà phê", "trà",
               "giải trí", "phim", "nhạc", "sách", "văn phòng phẩm",
               "xây dựng", "vận tải", "giao hàng", "bảo hiểm",
               "tài chính", "ngân hàng", "việc làm", "tuyển dụng",
               "đào tạo", "khóa học", "trường học", "đại học",
               "thiết bị", "cơ khí", "nông sản", "hải sản", "gạch",
               "sắt thép", "vật liệu", "đất nền"],
        "ru": ["магазин", "интернет магазин", "товары", "каталог",
               "корзина", "заказ", "доставка", "купить", "цена",
               "новости", "объявления", "недвижимость", "отель",
               "туризм", "аптека", "ресторан", "услуги", "компания",
               "скидки", "акции", "распродажа", "одежда", "обувь",
               "косметика", "электроника", "телефоны", "компьютеры",
               "мебель", "продукты", "авто", "запчасти",
               "стройматериалы", "спорт", "книги", "цветы", "подарки",
               "зоотовары", "детские товары", "красота", "здоровье",
               "медицина", "стоматология", "фитнес", "турфирма",
               "авиабилеты", "страхование", "финансы", "работа",
               "обучение", "курсы", "школа", "вуз", "доставка еды",
               "пиццерия", "кофейня"],
        "uk": ["інтернет-магазин", "магазин", "товари", "каталог",
               "кошик", "замовлення", "доставка", "купити", "ціна",
               "новини", "оголошення", "нерухомість", "готель",
               "туризм", "аптека", "ресторан", "послуги", "компанія",
               "знижки", "акції", "розпродаж", "одяг", "взуття",
               "косметика", "електроніка", "телефони", "комп'ютери",
               "меблі", "авто", "запчастини", "спорт", "книги",
               "квіти", "подарунки", "дитячі товари", "краса",
               "здоров'я", "медицина", "страхування", "фінанси",
               "робота", "навчання", "курси", "доставка їжі"],
        "es": ["tienda", "venta", "productos", "carrito", "comprar",
               "catálogo", "noticias", "inmobiliaria", "hotel", "viajes",
               "farmacia", "restaurante", "servicios", "empresa",
               "ofertas", "descuentos", "ropa", "zapatos", "cosméticos",
               "electrónica", "móviles", "muebles", "supermercado",
               "coches", "recambios", "deportes", "libros", "flores",
               "regalos", "mascotas", "juguetes", "belleza", "salud",
               "clínica", "dentista", "seguros", "finanzas", "empleo",
               "cursos", "vuelos", "alquiler de coches", "construcción",
               "transporte", "panadería", "cafetería"],
        "de": ["shop", "laden", "produkte", "warenkorb", "kaufen",
               "katalog", "nachrichten", "immobilien", "hotel", "reisen",
               "apotheke", "restaurant", "dienstleistungen", "firma",
               "angebote", "rabatt", "mode", "schuhe", "kosmetik",
               "elektronik", "handys", "möbel", "supermarkt", "auto",
               "autoteile", "sport", "bücher", "blumen", "geschenke",
               "haustier", "spielzeug", "schönheit", "gesundheit",
               "zahnarzt", "versicherung", "finanzen", "jobs", "kurse",
               "flüge", "mietwagen", "bau", "transport", "bäckerei",
               "café"],
        "fr": ["boutique", "magasin", "produits", "panier", "acheter",
               "catalogue", "actualités", "immobilier", "hôtel", "voyages",
               "pharmacie", "restaurant", "services", "entreprise",
               "promotions", "mode", "chaussures", "cosmétiques",
               "électronique", "téléphones", "meubles", "supermarché",
               "voitures", "pièces auto", "sport", "livres", "fleurs",
               "cadeaux", "animaux", "jouets", "beauté", "santé",
               "dentiste", "assurance", "finance", "emploi", "cours",
               "vols", "location voiture", "construction", "transport",
               "boulangerie", "café"],
        "it": ["negozio", "vendita", "prodotti", "carrello", "acquista",
               "catalogo", "notizie", "categoria", "hotel", "viaggi",
               "immobiliare", "farmacia", "ristorante", "servizi",
               "azienda", "offerte", "sconti", "moda", "scarpe",
               "gioielli", "cosmetici", "elettronica", "telefoni",
               "mobili", "supermercato", "auto", "ricambi", "sport",
               "libri", "fiori", "regali", "animali", "giocattoli",
               "bellezza", "salute", "dentista", "assicurazioni",
               "finanza", "lavoro", "corsi", "voli", "noleggio auto",
               "costruzioni", "trasporti", "pizzeria", "bar"],
        "pt": ["loja", "venda", "produtos", "carrinho", "comprar",
               "catálogo", "notícias", "imóveis", "hotel", "viagens",
               "farmácia", "restaurante", "serviços", "empresa",
               "ofertas", "moda", "sapatos", "cosméticos",
               "eletrônicos", "celulares", "móveis", "supermercado",
               "carros", "peças", "esportes", "livros", "flores",
               "presentes", "animais", "brinquedos", "beleza", "saúde",
               "dentista", "seguros", "finanças", "emprego", "cursos",
               "voos", "aluguel de carros", "construção", "transportes",
               "padaria", "café"],
        "nl": ["winkel", "producten", "winkelwagen", "kopen",
               "catalogus", "nieuws", "categorie", "hotel", "reizen",
               "vastgoed", "restaurant", "dienst", "bedrijf",
               "aanbiedingen", "mode", "schoenen", "cosmetica",
               "elektronica", "telefoons", "meubels", "supermarkt",
               "auto", "onderdelen", "sport", "boeken", "bloemen",
               "cadeaus", "huisdier", "speelgoed", "beauty",
               "gezondheid", "tandarts", "verzekering", "financiën",
               "banen", "cursussen", "vluchten", "huurauto", "bouw",
               "transport", "bakkerij", "café"],
        "pl": ["sklep", "produkty", "koszyk", "kupić", "katalog",
               "wiadomości", "kategoria", "hotel", "podróże",
               "nieruchomości", "restauracja", "usługi", "firma",
               "promocje", "moda", "buty", "kosmetyki", "elektronika",
               "telefony", "meble", "supermarket", "auto", "części",
               "sport", "książki", "kwiaty", "prezenty", "zwierzęta",
               "zabawki", "uroda", "zdrowie", "dentysta",
               "ubezpieczenie", "finanse", "praca", "kursy", "loty",
               "wypożyczalnia", "budownictwo", "transport", "piekarnia",
               "kawiarnia"],
        "cs": ["obchod", "prodej", "zboží", "košík", "koupit", "katalog",
               "zprávy", "kategorie", "hotel", "cestování",
               "nemovitosti", "lékárna", "restaurace", "služby",
               "firma", "akce", "móda", "boty", "kosmetika",
               "elektronika", "telefony", "nábytek", "auto", "díly",
               "sport", "knihy", "kytiny", "dárky", "hračky",
               "zdraví", "zubní", "pojištění", "finance", "práce",
               "kurzy", "letenky", "půjčovna", "stavebnictví",
               "doprava", "pekárna", "kavárna"],
        "ro": ["magazin", "vânzare", "produse", "coș", "cumpăra",
               "catalog", "știri", "categorie", "hotel", "călătorii",
               "imobiliare", "farmacie", "restaurant", "servicii",
               "firmă", "oferte", "modă", "încălțăminte", "cosmetice",
               "electronice", "telefoane", "mobilă", "auto", "piese",
               "sport", "cărți", "flori", "cadouri", "animale",
               "jucării", "frumusețe", "sănătate", "dentar",
               "asigurări", "finanțe", "locuri de muncă", "cursuri",
               "zboruri", "închirieri auto", "construcții",
               "transport", "brutărie", "cafenea"],
        "el": ["κατάστημα", "καταστήματα", "πωλήσεις", "προϊόντα",
               "καλάθι", "αγορά", "κατάλογος", "ειδήσεις", "κατηγορία",
               "ξενοδοχείο", "ταξίδια", "ακίνητα", "φαρμακείο",
               "εστιατόριο", "υπηρεσίες", "εταιρεία", "προσφορές",
               "μόδα", "παπούτσια", "καλλυντικά", "ηλεκτρονικά",
               "κινητά", "έπιπλα", "αυτοκίνητο", "ανταλλακτικά",
               "αθλητικά", "βιβλία", "λουλούδια", "δώρα", "κατοικίδια",
               "παιχνίδια", "ομορφιά", "υγεία", "οδοντίατρος",
               "ασφάλεια", "χρηματοδότηση", "εργασία", "σεμινάρια",
               "πτήσεις", "ενοικίαση αυτοκινήτου", "κατασκευές",
               "μεταφορές", "αρτοποιείο", "καφέ"],
        "tr": ["mağaza", "satış", "ürün", "sepet", "satın al",
               "katalog", "haber", "kategori", "otel", "seyahat",
               "gayrimenkul", "restoran", "hizmet", "firma",
               "indirim", "kampanya", "moda", "ayakkabı", "kozmetik",
               "elektronik", "telefon", "mobilya", "süpermarket",
               "otomobil", "yedek parça", "spor", "kitap", "çiçek",
               "hediyelik", "evcil hayvan", "oyuncak", "güzellik",
               "sağlık", "diş hekimi", "sigorta", "finans",
               "iş ilanları", "kurslar", "uçak bileti",
               "araç kiralama", "inşaat", "nakliye", "fırın", "kafe"],
        "ar": ["متجر", "تسوق", "منتجات", "سلة", "شراء",
               "كتالوج", "أخبار", "فئة", "فندق", "سفر",
               "عقارات", "مطعم", "خدمات", "شركة",
               "عروض", "أزياء", "أحذية", "مستحضرات تجميل",
               "إلكترونيات", "هواتف", "أثاث", "سوبر ماركت",
               "سيارات", "قطع غيار", "رياضة", "كتب", "زهور",
               "هدايا", "حيوانات", "ألعاب", "جمال", "صحة",
               "أسنان", "تأمين", "مالية", "وظائف", "دورات",
               "تذاكر طيران", "تأجير سيارات", "مقاولات", "نقل",
               "مخبز", "مقهى"],
        "he": ["חנות", "חנויות", "מוצרים", "סל", "קניות", "קטלוג",
               "חדשות", "קטגוריה", "מלון", "טיולים", "נדלן",
               "בית מרקחת", "מסעדה", "שירותים", "חברה", "מבצעים",
               "אופנה", "נעליים", "קוסמטיקה", "אלקטרוניקה",
               "טלפונים", "רהיטים", "סופרמרקט", "רכב", "חלקי חילוף",
               "ספורט", "ספרים", "פרחים", "מתנות", "חיות", "צעצועים",
               "יופי", "בריאות", "רופא שיניים", "ביטוח", "פיננסים",
               "דרושים", "קורסים", "טיסות", "השכרת רכב", "בנייה",
               "שינוע", "מאפייה", "בית קפה"],
        "fa": ["فروشگاه", "فروش", "محصولات", "سبد خرید", "خرید",
               "کاتالوگ", "اخبار", "دسته", "هتل", "سفر", "املاک",
               "داروخانه", "رستوران", "خدمات", "شرکت", "تخفیف",
               "مد", "کفش", "آرایشی", "لوازم الکترونیکی", "موبایل",
               "صنایع دستی", "خودرو", "قطعات", "ورزش", "کتاب",
               "گل", "هدیه", "حیوانات", "اسباب بازی", "زیبایی",
               "سلامت", "دندانپزشکی", "بیمه", "مالی", "استخدام",
               "دوره ها", "بلیط هواپیما", "اجاره خودرو", "ساخت",
               "حمل و نقل", "نانون", "کافه"],
        "zh": ["商店", "商城", "网店", "商品", "购物车", "购买",
               "目录", "新闻", "分类", "酒店", "旅游", "房地产",
               "药品", "餐厅", "服务", "公司", "促销", "服装", "鞋",
               "化妆品", "电子产品", "手机", "家具", "超市", "汽车",
               "配件", "体育", "图书", "鲜花", "礼品", "宠物",
               "玩具", "美容", "健康", "牙科", "保险", "金融",
               "招聘", "课程", "机票", "租车", "建筑", "物流",
               "面包店", "咖啡"],
        "ja": ["ショップ", "ストア", "商品", "カート", "購入",
               "カタログ", "ニュース", "カテゴリ", "ホテル", "旅行",
               "不動産", "レストラン", "サービス", "会社", "セール",
               "ファッション", "靴", "化粧品", "家電", "スマホ",
               "家具", "スーパー", "車", "パーツ", "スポーツ", "書籍",
               "花", "ギフト", "ペット", "おもちゃ", "美容", "健康",
               "歯科", "保険", "金融", "求人", "講座", "航空券",
               "レンタカー", "建設", "物流", "ベーカリー", "カフェ"],
        "ko": ["상점", "쇼핑몰", "상품", "장바구니", "구매",
               "카탈로그", "뉴스", "카테고리", "호텔", "여행",
               "부동산", "레스토랑", "서비스", "회사", "할인",
               "패션", "신발", "화장품", "전자제품", "휴대폰",
               "가구", "마트", "자동차", "부품", "스포츠", "도서",
               "꽃", "선물", "반려동물", "장난감", "뷰티", "건강",
               "치과", "보험", "금융", "채용", "강좌", "항공권",
               "렌터카", "건설", "물류", "베이커리", "카페"],
        "hi": ["दुकान", "बिक्री", "उत्पाद", "कार्ट", "खरीद",
               "कैटलॉग", "समाचार", "श्रेणी", "होटल", "यात्रा",
               "रियल एस्टेट", "फार्मेसी", "रेस्टोरेंट", "सेवाएं",
               "कंपनी", "छूट", "फैशन", "जूते", "कॉस्मेटिक्स",
               "इलेक्ट्रॉनिक्स", "मोबाइल", "फर्नीचर", "सुपरमार्केट",
               "कार", "पुर्जे", "खेल", "किताबें", "फूल", "उपहार",
               "पालतू", "खिलौने", "सौंदर्य", "स्वास्थ्य", "दंत",
               "बीमा", "वित्त", "नौकरियां", "कोर्स", "फ्लाइट",
               "कार किराया", "निर्माण", "परिवहन", "बेकरी", "कैफे"],
        "id": ["toko", "jual", "produk", "keranjang", "beli",
               "katalog", "berita", "kategori", "hotel", "wisata",
               "properti", "restoran", "layanan", "perusahaan",
               "diskon", "fashion", "sepatu", "kosmetik", "elektronik",
               "handphone", "furniture", "supermarket", "mobil",
               "sparepart", "olahraga", "buku", "bunga", "hadiah",
               "hewan", "mainan", "kecantikan", "kesehatan", "gigi",
               "asuransi", "keuangan", "lowongan kerja", "kursus",
               "tiket pesawat", "sewa mobil", "konstruksi", "ekspedisi",
               "kue", "kafe"],
        "ms": ["kedai", "jualan", "produk", "troli", "beli",
               "katalog", "berita", "kategori", "hotel", "percutian",
               "hartanah", "farmasi", "restoran", "perkhidmatan",
               "syarikat", "diskaun", "fesyen", "kasut", "kosmetik",
               "elektronik", "telefon", "perabot", "supermarket",
               "kereta", "alat ganti", "sukan", "buku", "bunga",
               "hadiah", "haiwan", "mainan", "kecantikan", "kesihatan",
               "gigi", "insurans", "kewangan", "kerja kosong",
               "kursus", "tiket penerbangan", "sewa kereta",
               "pembinaan", "pengangkutan", "bakery", "kafe"],
        "th": ["ร้านค้า", "สินค้า", "ตะกร้า", "ซื้อ", "แคตตาล็อก",
               "ข่าว", "หมวดหมู่", "โรงแรม", "ท่องเที่ยว", "อสังหาฯ",
               "ร้านอาหาร", "บริการ", "บริษัท", "ลดราคา", "แฟชั่น",
               "รองเท้า", "เครื่องสำอาง", "อิเล็กทรอนิกส์", "มือถือ",
               "เฟอร์นิเจอร์", "ซูเปอร์มาร์เก็ต", "รถยนต์", "อะไหล่",
               "กีฬา", "หนังสือ", "ดอกไม้", "ของขวัญ", "สัตว์เลี้ยง",
               "ของเล่น", "ความงาม", "สุขภาพ", "ทันตแพทย์", "ประกัน",
               "การเงิน", "งาน", "คอร์ส", "ตั๋วเครื่องบิน", "เช่ารถ",
               "ก่อสร้าง", "ขนส่ง", "เบเกอรี่", "คาเฟ่"],
        "sv": ["butik", "affär", "produkter", "varukorg", "köpa",
               "katalog", "nyheter", "kategori", "hotell", "resor",
               "fastigheter", "apotek", "restaurang", "tjänster",
               "företag", "erbjudanden", "mode", "skor", "kosmetika",
               "elektronik", "telefoner", "möbler", "supermarket",
               "bil", "reservdelar", "sport", "böcker", "blommor",
               "presenter", "husdjur", "leksaker", "skönhet",
               "hälsa", "tandläkare", "försäkring", "finansiering",
               "jobb", "kurser", "flyg", "hyrbil", "byggnad",
               "transport", "bageri", "kafé"],
    },
    # Tier 2 - script / page names (URL path tokens). Many e-commerce stacks
    # use localised script names, so per-language entries matter here.
    "script": {
        "en": ["product", "products", "item", "detail", "details", "view",
               "show", "display", "article", "news", "post", "page",
               "category", "cat", "shop", "store", "listing", "search",
               "index", "main", "default", "info", "content", "download",
               "file", "gallery", "photo", "video", "user", "profile",
               "member", "order", "cart", "basket", "checkout", "buy",
               "brand", "brandlist", "collection", "sale", "promo",
               "review", "comment", "faq", "contact", "about",
               "prodlist", "productlist", "newsdetail", "newslist",
               "catlist", "categorylist", "shopdetail", "itemdetail",
               "viewproduct", "showproduct", "viewitem", "showitem",
               "goodsdetail", "boardlist", "shopinfo", "cataloglist"],
        "vi": ["sanpham", "chitietsanpham", "danhmuc", "chitiet", "xem",
               "hienthi", "tintuc", "chitiettintuc", "baiviet", "trang",
               "giohang", "thanhtoan", "muahang", "datmua", "datphong",
               "lienhe", "gioithieu", "timkiem", "thuonghieu", "khuyenmai",
               "donhang", "hoadon", "tailieu", "hinhanh", "video",
               "thanhvien", "taikhoan", "dangnhap", "dangky", "binhluan",
               "danhsach", "chitiettin", "xemchitiet", "sanphammoi",
               "tuyendung", "hoidap", "datlich", "hoso", "diendan",
               "thuvienanh", "dichvu", "tuyensinh", "tracuu"],
        "ru": ["tovar", "produkty", "katalog", "kategorija", "novosti",
               "statja", "stranitsa", "korzina", "zakaz", "pokupka",
               "poisk", "kontakt", "kompanija", "akcija", "skidka",
               "dokument", "fajl", "galereja", "polzovatel", "profil",
               "tovary", "dostavka", "oplata", "otzyvy", "spisok",
               "razdel", "uslugi", "magazin", "brend", "skidki",
               "kupon", "podrobnee", "vakansii",
               "obuchenie"],
        "uk": ["tovar", "katalog", "korystuvach", "storinka", "novyny",
               "stattia", "koshyk", "zamovlennya", "kupyty", "poshuk",
               "kontakty", "kompaniya", "aktsiya", "znyzhky", "posluhy",
               "dokument", "fail", "halereya", "profil", "spysok",
               "rozdil", "mahazyn", "brend", "oplata", "dostavka",
               "vidhuky"],
        "es": ["producto", "articulo", "detalle", "ver", "categoria",
               "noticia", "pagina", "carrito", "comprar", "busqueda",
               "contacto", "empresa", "descarga", "galeria", "usuario",
               "ofertas", "novedades", "listado", "ficha", "pedidos",
               "factura", "registro", "nosotros", "empleo", "cursos",
               "reservas", "eventos", "foro", "blog", "secciones"],
        "de": ["produkt", "artikel", "detail", "ansicht", "kategorie",
               "nachricht", "seite", "warenkorb", "kaufen", "suche",
               "kontakt", "unternehmen", "download", "galerie",
               "benutzer", "angebote", "neuheiten", "liste",
               "bestellung", "rechnung", "registrierung", "ueberuns",
               "jobs", "kurse", "buchung", "veranstaltungen", "forum",
               "blog", "warengruppen"],
        "fr": ["produit", "article", "detail", "voir", "categorie",
               "actualite", "page", "panier", "acheter", "recherche",
               "contact", "societe", "telechargement", "galerie",
               "utilisateur", "promotions", "nouveautes", "liste",
               "commande", "facture", "inscription", "apropos",
               "emplois", "cours", "reservation", "evenements", "forum",
               "blog", "rayons"],
        "it": ["prodotto", "dettaglio", "visualizza", "categoria",
               "notizia", "articolo", "pagina", "carrello", "acquista",
               "ricerca", "contatti", "azienda", "download", "galleria",
               "utente", "offerte", "novita", "elenco", "ordine",
               "fattura", "registrazione", "chisiamo", "lavoro",
               "corsi", "prenotazione", "eventi", "forum", "blog",
               "reparti"],
        "pt": ["produto", "detalhe", "ver", "categoria", "noticia",
               "artigo", "pagina", "carrinho", "comprar", "busca",
               "contato", "empresa", "download", "galeria", "usuario",
               "ofertas", "novidades", "lista", "pedido", "fatura",
               "cadastro", "sobre", "vagas", "cursos", "reserva",
               "eventos", "forum", "blog", "departamentos"],
        "nl": ["product", "detail", "bekijk", "categorie", "nieuws",
               "artikel", "pagina", "winkelwagen", "kopen", "zoeken",
               "contact", "bedrijf", "download", "galerie", "gebruiker",
               "aanbiedingen", "lijst", "bestelling", "factuur",
               "registreren", "overons", "vacatures", "cursussen",
               "reserveren", "evenementen", "forum", "blog",
               "afdelingen"],
        "pl": ["produkt", "szczegoly", "widok", "kategoria", "wiadomosci",
               "artykul", "strona", "koszyk", "kup", "szukaj", "kontakt",
               "firma", "pobierz", "galeria", "uzytkownik", "promocje",
               "nowosci", "lista", "zamowienie", "faktura", "rejestracja",
               "onas", "praca", "kursy", "rezerwacja", "wydarzenia",
               "forum", "blog", "dzialy"],
        "cs": ["produkt", "detail", "zobrazit", "kategorie", "clanek",
               "zprava", "stranka", "kosik", "nakup", "hledat",
               "kontakt", "firma", "stahnout", "galerie", "uzivatel",
               "akce", "nabidka", "seznam", "objednavka", "faktura",
               "registrace", "onas", "sluzby", "prace", "kurzy",
               "rezervace", "forum", "blog", "oddeleni"],
        "ro": ["produs", "detaliu", "vizualizare", "categorie", "stire",
               "articol", "pagina", "cos", "cumpara", "cauta", "contact",
               "firma", "descarcare", "galerie", "utilizator", "oferte",
               "noutati", "lista", "comanda", "factura", "inregistrare",
               "despre", "angajari", "cursuri", "rezervare",
               "evenimente", "forum", "blog", "departamente"],
        "el": ["proion", "leptomereies", "provoli", "katigoria",
               "eidisi", "arthro", "selida", "kalathi", "agora",
               "anazitisi", "epikoinonia", "etaireia", "xristis",
               "lista", "paraggelia", "timi", "prosfores", "nea",
               "eggrafi", "ypiresies", "ergasia", "mathimata",
               "kratisi", "ekdiloseis", "gallery", "blog", "forum"],
        "tr": ["urun", "detay", "kategori", "haber", "goruntule",
               "sepet", "satin-al", "ara", "bilgi", "magaza", "makale",
               "iletisim", "hakkimizda", "urunler", "urundetay",
               "kampanya", "sepetim", "siparis", "siparistakip",
               "uyelik", "giris", "kayit", "hizmetler", "galeri",
               "blog", "forum", "iletisimform"],
        "ar": ["matjar", "muntaj", "tafasil", "fea", "akhbar", "maqal",
               "safha", "salla", "shira", "bahth", "ittisal", "sharika",
               "khadamat", "tanzil", "talab", "taqid", "ailanat", "wathaiq", "sowar"],
        "he": ["chanut", "mutzar", "mutzarim", "katalog", "kategoriot",
               "chedshot", "maamar", "daf", "sal", "kniya", "chipus",
               "kesher", "chevra", "sharutim", "machzor", "tashlum",
               "rishum", "taaruch"],
        "fa": ["forushgah", "mahsul", "mahsulat", "tafsil", "dasteh",
               "khabar", "maqale", "safhe", "sabad", "kharid", "jostoju",
               "tamas", "darkhast", "pardakht", "sabtnam", "khadamat",
               "galeri", "blog"],
        "zh": ["product", "goods", "item", "category", "news", "view",
               "detail", "shop", "cart", "buy", "order", "search",
               "show", "list", "info", "about", "contact",
               "goodsdetail", "newsdetail", "productlist", "newslist",
               "categorylist", "shopinfo", "member", "reg", "photo",
               "pic", "down", "soft", "job", "hr", "bbs", "help",
               "guestbook"],
        "ja": ["item", "detail", "category", "products", "news",
               "view", "cart", "buy", "search", "info", "list", "shop",
               "itemdetail", "itemlist", "newsdetail", "newslist",
               "categorylist", "shopdetail", "member", "entry", "photo",
               "download", "job", "recruit", "faq", "support", "goods",
               "sale", "event"],
        "ko": ["product", "item", "view", "detail", "category", "news",
               "cart", "order", "search", "info", "shop", "goods",
               "productdetail", "productlist", "newsdetail", "newslist",
               "categorylist", "shopdetail", "member", "join", "photo",
               "download", "job", "recruit", "faq", "support", "goods",
               "sale", "event"],
        "hi": ["dukaan", "utpad", "vivaran", "shreni", "samachar",
               "lekh", "panna", "kharid", "khoj", "sampark",
               "parichay", "seva", "gallery", "booking", "blog",
               "forum", "bhugtan", "sadasya"],
        "id": ["produk", "detail", "kategori", "berita", "lihat",
               "keranjang", "beli", "cari", "info", "toko", "artikel",
               "detailproduk", "daftarproduk", "daftar", "beritadetail",
               "halaman", "belanja", "pencarian", "kontak", "tentang",
               "pengguna", "galeri", "unduhan", "pesanan", "pemesanan",
               "promo", "blog"],
        "ms": ["produk", "butiran", "lihat", "kategori", "berita",
               "artikel", "halaman", "troli", "beli", "cari", "hubungi",
               "tentang", "pengguna", "galeri", "muat-turun", "tempahan",
               "pesanan", "promo", "blog"],
        "th": ["product", "detail", "category", "news", "view",
               "cart", "buy", "search", "info", "shop", "article",
               "products", "shopdetail", "newsdetail", "promotion",
               "bestseller", "contactus", "aboutus", "productdetail",
               "categorylist", "webboard", "gallery", "download",
               "member", "register", "booking"],
        "sv": ["produkt", "detalj", "visa", "kategori", "nyhet",
               "artikel", "sida", "varukorg", "kop", "sok", "kontakt",
               "foretag", "hamta", "galleri", "anvandare",
               "erbjudande", "lista", "bestallning", "faktura",
               "registrera", "omoss", "tjanster", "jobb", "kurser",
               "bokning", "evenemang", "forum", "blogg",
               "avdelningar"],
    },
    # Tier 3 - query parameter names (classic SQLi sinks first).
    "param": {
        "en": ["id", "pid", "cid", "tid", "aid", "bid", "sid", "nid", "eid",
               "uid", "mid", "rid", "kid", "xid", "catid", "categoryid",
               "prod", "product", "productid", "prodid", "item", "itemid",
               "sku", "brand", "brandid", "shop", "store", "listing",
               "news", "newsid", "article", "artid", "post", "postid",
               "blog", "page", "pageid", "pg", "p", "view", "content",
               "contentid", "section", "sec", "topic", "topicid", "thread",
               "forum", "member", "memberid", "profile", "comment",
               "doc", "document", "docid", "file", "fileid", "download",
               "attachment", "media", "user", "userid", "user_id",
               "info", "detail", "details", "record", "recid", "event",
               "eventid", "album", "photo", "photoid", "gallery", "video",
               "videoid", "song", "game", "recipe", "staff", "emp",
               "empid", "order", "orderid", "invoice", "booking", "hotel",
               "hotelid", "tour", "tourid", "property", "estate", "car",
               "vehicle", "job", "jobid", "course", "courseid", "lesson",
               "exam", "question", "answer", "poll", "survey", "vote",
               "lang", "year", "month", "week", "day", "date", "keyword",
               "search", "query", "q", "s", "text", "name", "title",
               "code", "ref", "no", "num", "val", "value", "key", "type",
               "status", "action", "task", "cmd", "mode", "do", "go",
               "show", "get", "load", "read", "mod", "module", "act",
               "op", "option", "func", "fn", "wp", "id_num",
               "product_id", "category_id", "item_id", "news_id",
               "art_id", "cat_id", "page_id", "prod_id", "fid", "gid",
               "lid", "did", "hid", "vid", "imgid", "imageid", "albumid",
               "menuid", "deptid", "subid", "viewid", "shopid",
               "storeid", "galleryid", "downloadid", "file_id", "doc_id",
               "post_id", "threadid", "forumid", "model", "partno",
               "partnumber", "asin", "isbn", "ean"],
        "vi": ["masp", "idsp", "msp", "maloai", "idloai", "madm", "idcha",
               "matin", "idtin", "mabaiviet", "makh", "idkh", "madh",
               "iddh", "mahh", "idhh", "matl", "idtl", "manhasx",
               "idnsx", "matv", "idtv", "matintuc", "idsanpham",
               "iddanhmuc", "idbaiviet", "idgiohang", "idhoadon",
               "id_sp", "id_tin", "id_dm", "id_bv", "id_kh", "id_dh",
               "id_anh", "id_tag", "ma_loai", "ma_sp", "ma_tin", "ma_bv",
               "manv", "idnv", "id_phong", "id_chuyenmuc", "idtheloai",
               "id_theloai", "makhuyenmai", "makm"],
        "ru": ["id_tovar", "id_prod", "id_kat", "id_nov", "id_stat",
               "id_polz", "id_zakaz", "id_str", "id_foto", "id_file",
               "id_mag", "id_usl", "id_otz", "id_avto", "id_kursa",
               "kod_tov", "artikul"],
        "uk": ["id_tov", "id_kat", "id_nov", "id_stat", "id_zam",
               "id_kor", "id_mag", "id_posl", "kod_tov", "artikul"],
        "es": ["idprod", "idart", "idcat", "idnot", "idpag", "idusu",
               "idped", "idemp", "idcli", "idsubcat", "idprov", "idmar",
               "idtienda", "idoferta", "codprod"],
        "de": ["artikelid", "kategorieid", "newsid", "seitenid",
               "benutzerid", "bestellungid", "kundeid", "artikelnr",
               "herstid", "markid", "ukatid", "shopid", "anbid"],
        "fr": ["idprod", "idart", "idcat", "idnews", "idpage",
               "iduser", "idcmd", "idclient", "idsouscat", "idfourn",
               "idmar", "idboutique", "idoffre", "refprod"],
        "it": ["idprod", "idart", "idcat", "idnot", "idpag", "idute",
               "idord", "idcli", "idneg", "idsottocat", "idforn",
               "idmar", "idofferta", "codprod"],
        "pt": ["idprod", "idart", "idcat", "idnot", "idpag", "idusu",
               "idped", "idcli", "idsubcat", "idforn", "idmar", "idloja",
               "idoferta", "codprod"],
        "nl": ["productid", "artikelid", "categorieid", "nieuwsid",
               "paginaid", "gebruikerid", "bestellingid", "idsubcat",
               "idlev", "idmerk", "idwinkel", "idaanb", "artikelnr"],
        "pl": ["idprod", "idart", "idkat", "idnews", "idstr",
               "iduser", "idzam", "idkli", "idpodkat", "iddost",
               "idmar", "idskl", "idprom", "kprod"],
        "cs": ["idprod", "idclan", "idkat", "idzpr", "idstr", "iduziv",
               "idobj", "idpodkat", "iddod", "idzn", "idobch",
               "idakce", "kodzbo"],
        "ro": ["idprod", "idart", "idcat", "idstire", "idpag", "idusr",
               "idcmd", "idcli", "idsubcat", "idfurn", "idmar",
               "idmag", "idoferta", "codprod"],
        "el": ["idproion", "idkat", "ideid", "idsel", "idxristi",
               "idypokat", "idprosfora"],
        "tr": ["urunid", "kategoriid", "haberid", "kullaniciid",
               "siparisid", "sayfaid", "altkatid", "markaid", "tedid",
               "magazaid", "kampid", "urunkod"],
        "ar": ["pid", "cid", "nid", "uid", "oid", "idsub", "idmarka",
               "idmatjar", "idakhbar", "idkhadama"],
        "he": ["idmutzar", "idkategor", "idchanut", "idmaamar",
               "idchedsha"],
        "fa": ["idkala", "iddasteh", "idmahsul", "idkhabar",
               "idsefaresh", "idfroshgah"],
        "zh": ["pid", "gid", "cid", "nid", "uid", "oid", "typeid",
               "classid", "infoid", "sortid", "brandid", "areaid",
               "goodid", "bookid", "picid", "shopid"],
        "ja": ["pid", "gid", "cid", "nid", "uid", "oid", "tid",
               "goodsid", "shopid", "brandid", "classid", "areaid",
               "itemcd"],
        "ko": ["pid", "gid", "cid", "nid", "uid", "oid", "tid",
               "goodsid", "shopid", "brandid", "classid", "areaid",
               "cateidx"],
        "hi": ["idutpad", "idkhabar", "idshreni", "idseva", "iddukaan",
               "idsamachar"],
        "id": ["idbrg", "idktg", "idbrt", "idusr", "idpsn", "idproduk",
               "idkategori", "idberita", "idartikel", "idpesanan",
               "idpengguna", "idtoko", "idtransaksi"],
        "ms": ["idproduk", "idkat", "idberita", "idartikel", "idtempah",
               "idpesanan", "idpengguna", "idkedai"],
        "th": ["pid", "cid", "nid", "uid", "oid", "productid",
               "categoryid", "newsid", "shopid", "brandid"],
        "sv": ["idprod", "idart", "idkat", "idnyhet", "idsida", "idanv",
               "idbest", "idbutik"],
    },
}

# Tier 4/5 - language independent lists.
_EXTENSIONS = ("php", "asp", "aspx", "jsp", "cfm", "cgi", "pl", "py",
               "do", "action", "shtml", "shtm", "stm", "php3", "php4",
               "php5", "php7", "phtml", "jspx")

_TLDS = ("com", "net", "org", "info", "biz", "io", "co", "eu", "vn",
         "com.vn", "net.vn", "edu.vn", "gov.vn", "ru", "su", "рф",
         "de", "uk", "co.uk", "fr", "es", "it", "nl", "pl", "cz", "ro",
         "tr", "com.tr", "cn", "jp", "co.jp", "kr", "co.kr", "id",
         "co.id", "com.id", "th", "co.th", "my", "com.my", "sg",
         "com.sg", "in", "co.in", "pk", "com.pk", "bd", "ir", "il",
         "sa", "com.sa", "ae", "eg", "com.eg", "br", "com.br", "mx",
         "com.mx", "ar", "com.ar", "cl", "pe", "com.pe", "us", "ca",
         "au", "com.au", "nz", "za", "co.za", "ua", "com.ua", "kz",
         "by", "uz", "az", "ge", "am", "md", "rs", "bg", "gr", "hu",
         "sk", "si", "hr", "ba", "mk", "al", "lt", "lv", "ee", "fi",
         "se", "no", "dk", "ie", "pt", "be", "at", "ch", "li", "lu",
         "tw", "hk", "ph", "com.ph", "asia", "me", "tv", "cc", "xyz",
         "top", "online", "site", "shop", "store", "website")

# Dork templates. {slot} placeholders are filled from the tiers above.
# The rendered result is a *canonical* (Google-syntax) dork which the engine
# adapter translates per engine.
_TEMPLATES: tuple[str, ...] = (
    # script + param (strongest classic pattern)
    'inurl:"{script}.{ext}?{param}="',
    # extension + param + vertical keyword (finds niche regional shops)
    'inurl:"{ext}?{param}=" {vertical}',
    # script + param + vertical
    'inurl:"{script}.{ext}?{param}=" {vertical}',
    # script + param scoped to a TLD
    'inurl:"{script}.{ext}?{param}=" site:{tld}',
    # extension + param scoped to a TLD
    'inurl:"{ext}?{param}=" site:{tld}',
    # vertical + generic numeric param
    '{vertical} inurl:"{ext}?id="',
    # vertical + script (finds whole store apps)
    '{vertical} inurl:"{script}.{ext}?"',
    # title leak variant
    'intitle:"{script}.{ext}?{param}="',
    # path-style script token (frameworks without extensions)
    'inurl:"/{script}/" {vertical} inurl:"?id="',
    # index-style sink
    'inurl:"index.{ext}?{param}=" {vertical}',
)

_SLOT_KEYS = ("script", "ext", "param", "vertical", "tld")


@dataclass
class DictEntry:
    """One dictionary entry with learning metadata."""
    word: str
    tier: str
    langs: tuple[str, ...] = ("en",)
    hits: int = 0
    weight: float = 1.0
    source: str = "builtin"          # builtin | learned
    added: str = ""                  # ISO date for learned entries

    def to_json(self) -> dict:
        return {"word": self.word, "langs": list(self.langs),
                "hits": self.hits, "weight": self.weight,
                "source": self.source, "added": self.added}

    @classmethod
    def from_json(cls, tier: str, data: dict) -> "DictEntry":
        return cls(word=str(data.get("word", "")).strip(),
                   tier=tier,
                   langs=tuple(data.get("langs") or ("en",)),
                   hits=int(data.get("hits", 0) or 0),
                   weight=float(data.get("weight", 1.0) or 1.0),
                   source=str(data.get("source", "learned")),
                   added=str(data.get("added", "")))


# Path/query tokens that are never useful learning candidates.
_JUNK_TOKEN_RE = re.compile(
    r"^(?:utm_[a-z0-9_]*|gclid|fbclid|yclid|_ga|_gl|mc_[ce][a-z0-9_]*|"
    r"msclkid|igshid|ref_?src|spm|track[a-z0-9_]*|trk[a-z0-9_]*|"
    r"pk_[a-z0-9_]*|mtm_[a-z0-9_]*|hsa_[a-z0-9_]*|phpsessid|jsessionid|"
    r"aspsessionid[a-z0-9_]*|sid|session|sessionid|csrf|token|_token|"
    r"lang|locale|page|p|per_?page|sort|order|dir|limit|offset|start|"
    r"from|to|callback|jsonp|format|output|view|mobile|amp)$",
    re.IGNORECASE,
)

# Unicode-aware: split on anything that is not a letter/digit (any script),
# treating '-' and '_' as separators too.
# LUU Y: re \w KHONG khop combining marks (category M*), nen Devanagari /
# Thai / niqqud / harakat bi tach vong neu chi dung regex. Dung
# _split_tokens() de giu dau ket hop dinh vao chu goc.
_TOKEN_SPLIT_RE = re.compile(r"[\W_]+", re.UNICODE)


def _split_tokens(text: str) -> list[str]:
    """Tach token theo ranh gioi tu, ho tro moi script Unicode.

    Khac voi _TOKEN_SPLIT_RE: ky tu ket hop (category M* - matra Devanagari,
    vowel Thai, niqqud Hebrew, harakat Arabic...) duoc giu dinh vao chu goc
    thay vi bi coi la ky tu phan cach.
    """
    toks: list[str] = []
    cur = ""
    for ch in text:
        if ch == "_" or (
            not ch.isalnum() and not unicodedata.category(ch).startswith("M")
        ):
            if cur:
                toks.append(cur)
                cur = ""
        else:
            cur += ch
    if cur:
        toks.append(cur)
    return toks
_MIN_TOKEN_LEN = 2
_MAX_TOKEN_LEN = 32


class DorkDictionary:
    """Multi-tier dictionary + combination generator + self-learning state."""

    LEARNABLE_TIERS = ("vertical", "script", "param")

    def __init__(self, cfg: dict | None = None, base_dir: str | None = None):
        cfg = cfg or {}
        self.cfg = cfg
        self.base_dir = base_dir or os.getcwd()
        self.languages: list[str] = [
            str(x).lower() for x in (cfg.get("languages") or ["en", "vi"])]
        # "en" is always available as fallback.
        if "en" not in self.languages:
            self.languages.insert(0, "en")
        self.pending_file = self._path(cfg.get("pending_file")
                                       or "config/dork_pending.json")
        self.learned_file = self._path(cfg.get("learned_file")
                                       or "config/dork_learned.json")
        self.state_file = self._path(cfg.get("state_file")
                                     or "config/dork_dict_state.json")
        self.min_count = int(cfg.get("min_count", 5) or 5)
        self.max_learned = int(cfg.get("max_learned_per_tier", 200) or 200)

        self._lock = threading.Lock()
        self.tiers: dict[str, list[DictEntry]] = {}
        self._index: dict[str, dict[str, DictEntry]] = {}
        self._load_builtin()
        self._load_learned()
        self._load_hits()
        self._pending: dict[str, list[dict]] = {}
        self._load_pending()

    # ------------------------------------------------------------------ paths
    def _path(self, p: str) -> str:
        if os.path.isabs(p):
            return p
        return os.path.join(self.base_dir, p)

    # ------------------------------------------------------------------ loads
    def _load_builtin(self) -> None:
        for tier, by_lang in _BUILTIN.items():
            entries: list[DictEntry] = []
            seen: set[str] = set()
            for lang, words in by_lang.items():
                for w in words:
                    w = w.strip().lower()
                    if not w or w in seen:
                        continue
                    seen.add(w)
                    entries.append(DictEntry(word=w, tier=tier, langs=(lang,)))
            # Merge langs of duplicate words across languages (already deduped,
            # but keep entries from enabled languages first for sampling).
            self.tiers[tier] = entries
        for ext in _EXTENSIONS:
            self.tiers.setdefault("ext", []).append(
                DictEntry(word=ext, tier="ext"))
        for tld in _TLDS:
            self.tiers.setdefault("tld", []).append(
                DictEntry(word=tld, tier="tld"))
        self._reindex()

    def _reindex(self) -> None:
        self._index = {}
        for tier, entries in self.tiers.items():
            idx: dict[str, DictEntry] = {}
            for e in entries:
                idx[e.word] = e
            self._index[tier] = idx

    def _load_learned(self) -> None:
        try:
            with open(self.learned_file, "r", encoding="utf-8") as fh:
                data = json.load(fh)
        except FileNotFoundError:
            return
        except (ValueError, OSError) as exc:
            log.warning("learned dict unreadable (%s): %s", self.learned_file, exc)
            return
        n = 0
        for tier, items in (data or {}).items():
            if tier not in self.LEARNABLE_TIERS and tier not in ("ext", "tld"):
                continue
            for item in items or []:
                if not isinstance(item, dict):
                    continue
                e = DictEntry.from_json(tier, item)
                if not e.word:
                    continue
                if e.word in self._index.get(tier, {}):
                    continue
                self.tiers.setdefault(tier, []).append(e)
                n += 1
        if n:
            log.info("dictionary: merged %d learned entries from %s",
                     n, self.learned_file)
            self._reindex()

    def _load_hits(self) -> None:
        """Restore hit counts/weights from the previous run's state."""
        try:
            with open(self.state_file, "r", encoding="utf-8") as fh:
                state = json.load(fh)
        except (FileNotFoundError, ValueError, OSError):
            return
        for tier, entries in self.tiers.items():
            saved = (state or {}).get(tier) or {}
            for e in entries:
                if e.word in saved:
                    e.hits = int(saved[e.word].get("hits", 0) or 0)
                    e.weight = float(saved[e.word].get("weight", 1.0) or 1.0)

    def _load_pending(self) -> None:
        try:
            with open(self.pending_file, "r", encoding="utf-8") as fh:
                self._pending = json.load(fh) or {}
        except (FileNotFoundError, ValueError, OSError):
            self._pending = {}
        # Sanitise structure.
        clean: dict[str, list[dict]] = {}
        for tier, items in self._pending.items():
            if tier not in self.LEARNABLE_TIERS:
                continue
            clean[tier] = [i for i in (items or []) if isinstance(i, dict)
                           and i.get("word")]
        self._pending = clean

    # ------------------------------------------------------------------ saves
    def save_state(self) -> None:
        os.makedirs(os.path.dirname(self.state_file) or ".", exist_ok=True)
        state = {tier: {e.word: e.to_json() for e in entries}
                 for tier, entries in self.tiers.items()}
        try:
            with open(self.state_file, "w", encoding="utf-8") as fh:
                json.dump(state, fh, ensure_ascii=False, indent=2)
        except OSError as exc:
            log.warning("cannot save dictionary state: %s", exc)

    def _save_pending(self) -> None:
        os.makedirs(os.path.dirname(self.pending_file) or ".", exist_ok=True)
        try:
            with open(self.pending_file, "w", encoding="utf-8") as fh:
                json.dump(self._pending, fh, ensure_ascii=False, indent=2)
        except OSError as exc:
            log.warning("cannot save pending queue: %s", exc)

    def _save_learned(self) -> None:
        os.makedirs(os.path.dirname(self.learned_file) or ".", exist_ok=True)
        data: dict[str, list[dict]] = {}
        for tier, entries in self.tiers.items():
            learned = [e.to_json() for e in entries if e.source == "learned"]
            if learned:
                data[tier] = learned
        try:
            with open(self.learned_file, "w", encoding="utf-8") as fh:
                json.dump(data, fh, ensure_ascii=False, indent=2)
        except OSError as exc:
            log.warning("cannot save learned dict: %s", exc)

    # ------------------------------------------------------------ sampling
    def _sample_entry(self, tier: str, rng: random.Random,
                      lang_bias: float = 0.0) -> DictEntry | None:
        """Weighted sample of one entry from a tier.

        Language-aware: entries matching the enabled languages are preferred
        (``lang_bias`` in [0,1] raises that preference further).
        """
        entries = self.tiers.get(tier) or []
        if not entries:
            return None
        langs = set(self.languages)
        weights: list[float] = []
        for e in entries:
            w = max(0.05, e.weight)
            hit_boost = 1.0 + min(1.0, e.hits / 50.0)
            w *= hit_boost
            if set(e.langs) & langs:
                w *= 1.0 + 2.0 * max(0.25, lang_bias)
            else:
                w *= 0.35          # entries for other languages still reachable
            weights.append(w)
        return rng.choices(entries, weights=weights, k=1)[0]

    def render(self, template: str, rng: random.Random,
               lang_bias: float = 0.0) -> str:
        """Fill one template with sampled slot values -> canonical dork."""
        slots: dict[str, str] = {}
        for key in _SLOT_KEYS:
            tier = {"ext": "ext"}.get(key, key)
            e = self._sample_entry(tier, rng, lang_bias)
            slots[key] = e.word if e else "id"
        if slots["tld"]:
            slots["tld"] = slots["tld"].lstrip(".")
        try:
            out = template.format(**slots)
        except (KeyError, IndexError):
            out = template
        return re.sub(r"\s+", " ", out).strip()

    def generate(self, n: int, seed: int | None = None) -> list[str]:
        """Generate ``n`` unique canonical dorks from template x tier combos."""
        rng = random.Random(seed)
        seen: set[str] = set()
        out: list[str] = []
        attempts = 0
        while len(out) < n and attempts < n * 12:
            attempts += 1
            tpl = rng.choice(_TEMPLATES)
            q = self.render(tpl, rng)
            if q in seen:
                continue
            seen.add(q)
            out.append(q)
        return out

    @property
    def templates(self) -> tuple[str, ...]:
        return _TEMPLATES

    def template_slots(self, template: str) -> dict[str, str]:
        """Re-extract slot values from a rendered canonical dork (for mutation)."""
        slots: dict[str, str] = {}
        m = re.search(r'inurl:"([a-z0-9_\-]+)\.([a-z0-9]+)\?([a-z0-9_\-]+)="',
                      template, re.IGNORECASE)
        if m:
            slots["script"], slots["ext"], slots["param"] = \
                m.group(1).lower(), m.group(2).lower(), m.group(3).lower()
        m2 = re.search(r"site:(\S+)", template, re.IGNORECASE)
        if m2:
            slots["tld"] = m2.group(1).lstrip(".")
        # Remaining free words that are not operators are the vertical.
        stripped = re.sub(
            r'(inurl|intitle|intext|site|filetype):"[^"]*"|\S+:\S+', "",
            template)
        free = [w.strip('"') for w in stripped.split()
                if len(w.strip('"')) >= 2]
        if free:
            slots.setdefault("vertical", free[-1].lower())
        return slots

    # ------------------------------------------------------------ feedback
    def observe_urls(self, urls: list[str], *, learn: bool = True) -> dict:
        """Feed harvested URLs into the learning loop.

        Returns a summary dict: ``{"bumped": n, "new_candidates": n,
        "promoted": n}``. Unknown tokens reaching ``min_count`` are moved to
        the pending (human-approve) queue.
        """
        counters: dict[str, Counter] = {t: Counter() for t in self.LEARNABLE_TIERS}
        examples: dict[str, dict[str, list[str]]] = \
            {t: {} for t in self.LEARNABLE_TIERS}
        bumped = 0

        for raw in urls:
            try:
                p = urlparse(raw)
            except ValueError:
                continue
            host = (p.netloc or "").lower()
            path = p.path or "/"
            params = [k for k, _ in parse_qsl(p.query, keep_blank_values=True)]

            # --- bump hits for known entries present in the URL.
            path_l = path.lower()
            for tier in self.LEARNABLE_TIERS:
                for e in self.tiers.get(tier, []):
                    tok = e.word
                    hit = False
                    if tier == "param":
                        hit = tok in params
                    elif tier == "script":
                        base = os.path.basename(path_l)
                        stem = re.sub(r"\.[a-z0-9]+$", "", base)
                        hit = tok in (stem, base) or f"/{tok}/" in path_l
                    else:  # vertical tokens appear in path or host
                        hit = (tok in path_l.replace("%20", " ")
                               or tok in host.replace("-", " ")
                               or tok in host.replace("-", ""))
                    if hit:
                        e.hits += 1
                        # weight grows sub-linearly, capped
                        e.weight = min(3.0, 1.0 + e.hits / 100.0)
                        bumped += 1

            if not learn:
                continue

            # --- collect unknown candidates.
            for pname in params:
                if self._learnable_token(pname):
                    counters["param"][pname.lower()] += 1
                    examples["param"].setdefault(pname.lower(), []).append(raw)

            base = os.path.basename(path_l)
            stem = re.sub(r"\.[a-z0-9]{1,5}$", "", base)
            for tok in {stem} | set(_split_tokens(path_l)):
                tok = tok.strip("-_")
                if self._learnable_token(tok):
                    counters["script"][tok] += 1
                    examples["script"].setdefault(tok, []).append(raw)

            if host:
                for tok in _split_tokens(host.replace("-", " ")):
                    tok = tok.strip()
                    if self._learnable_token(tok):
                        counters["vertical"][tok] += 1
                        examples["vertical"].setdefault(tok, []).append(raw)

        # --- promote frequent unknown tokens to the pending queue.
        promoted = 0
        added_new = 0
        with self._lock:
            for tier, cnt in counters.items():
                known = self._index.get(tier, {})
                for word, c in cnt.items():
                    if word in known:
                        continue
                    pend = self._pending.setdefault(tier, [])
                    existing = next((i for i in pend if i.get("word") == word),
                                    None)
                    if existing:
                        existing["count"] = max(int(existing.get("count", 0)), c)
                        exs = set(existing.get("examples") or []) | \
                              set(examples[tier].get(word, [])[:2])
                        existing["examples"] = list(exs)[:4]
                    else:
                        pend.append({
                            "word": word,
                            "count": c,
                            "first_seen": time.strftime("%Y-%m-%d %H:%M:%S"),
                            "examples": examples[tier].get(word, [])[:4],
                        })
                        added_new += 1
                    if c >= self.min_count:
                        promoted += 1
            self._save_pending()

        summary = {"bumped": bumped, "new_candidates": added_new,
                   "promoted": promoted}
        if learn and (added_new or bumped):
            log.debug("dictionary feedback: %s", summary)
        return summary

    @staticmethod
    def _learnable_token(tok: str) -> bool:
        if not tok or not _MIN_TOKEN_LEN <= len(tok) <= _MAX_TOKEN_LEN:
            return False
        if _JUNK_TOKEN_RE.match(tok):
            return False
        if tok.isdigit():
            return False
        # Any alphabetic character in any script (latin, cyrillic, greek,
        # hebrew, arabic, devanagari, cjk, ...) makes the token learnable.
        if not any(ch.isalpha() for ch in tok):
            return False
        return True

    # ------------------------------------------------------------ approval
    def pending(self) -> dict[str, list[dict]]:
        return {t: list(items) for t, items in self._pending.items()}

    def pending_total(self) -> int:
        return sum(len(v) for v in self._pending.values())

    def approve(self, indices: list[int] | None = None,
                tier: str | None = None, all_pending: bool = False) -> int:
        """Approve pending candidates -> move into the learned dictionary.

        ``indices`` indexes into the *flat* listing produced by
        ``pending_flat()``. ``all_pending=True`` approves everything.
        """
        flat = self.pending_flat(tier)
        chosen: list[tuple[str, dict]] = []
        if all_pending:
            chosen = [(t, i) for t, items in self._pending.items()
                      for i in items]
        elif indices:
            for idx in indices:
                if 0 <= idx < len(flat):
                    chosen.append(flat[idx])
        if not chosen:
            return 0
        n = 0
        with self._lock:
            for t, item in chosen:
                word = str(item.get("word", "")).strip().lower()
                if not word or t not in self.LEARNABLE_TIERS:
                    continue
                if word in self._index.get(t, {}):
                    pass  # already known, just drop from queue
                else:
                    entry = DictEntry(word=word, tier=t,
                                      langs=tuple(self.languages),
                                      hits=int(item.get("count", 0) or 0),
                                      weight=1.25,     # learned start boosted
                                      source="learned",
                                      added=time.strftime("%Y-%m-%d"))
                    # cap learned entries per tier
                    learned_n = sum(1 for e in self.tiers.get(t, [])
                                    if e.source == "learned")
                    if learned_n >= self.max_learned:
                        log.warning("learned tier '%s' full (%d) - not adding %s",
                                    t, learned_n, word)
                        continue
                    self.tiers.setdefault(t, []).append(entry)
                    self._index.setdefault(t, {})[word] = entry
                    self._pending[t] = [i for i in self._pending[t]
                                        if i.get("word") != word]
                n += 1
            # remove fully approved items from queue even when already known
            if all_pending:
                self._pending = {t: [] for t in self._pending}
            else:
                approved_words = {(t, i.get("word")) for t, i in chosen}
                for t in list(self._pending):
                    self._pending[t] = [i for i in self._pending[t]
                                        if (t, i.get("word")) not in approved_words]
            self._save_pending()
            self._save_learned()
        log.info("dictionary: approved %d learned entr%s", n,
                 "y" if n == 1 else "ies")
        return n

    def reject(self, indices: list[int] | None = None,
               tier: str | None = None, all_pending: bool = False) -> int:
        """Remove pending candidates without learning them."""
        flat = self.pending_flat(tier)
        drop: set[str] = set()
        if all_pending:
            self._pending = {t: [] for t in self._pending}
            self._save_pending()
            return len(flat)
        if not indices:
            return 0
        for idx in indices:
            if 0 <= idx < len(flat):
                drop.add(flat[idx][1].get("word", ""))
        n = 0
        with self._lock:
            for t in list(self._pending):
                keep = []
                for i in self._pending[t]:
                    if i.get("word") in drop:
                        n += 1
                        continue
                    keep.append(i)
                self._pending[t] = keep
            self._save_pending()
        return n

    def pending_flat(self, tier: str | None = None) -> list[tuple[str, dict]]:
        """Flat, stable ordering of the pending queue for CLI display."""
        out: list[tuple[str, dict]] = []
        for t in sorted(self._pending):
            if tier and t != tier:
                continue
            for i in sorted(self._pending[t], key=lambda x: x.get("word", "")):
                out.append((t, i))
        return out

    def stats(self) -> dict:
        out: dict[str, dict] = {}
        for tier, entries in self.tiers.items():
            out[tier] = {
                "total": len(entries),
                "learned": sum(1 for e in entries if e.source == "learned"),
                "hot": sorted(entries, key=lambda e: -e.hits)[:5],
            }
        return out