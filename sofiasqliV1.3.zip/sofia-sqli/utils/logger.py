"""Colored, thread-safe logger for sofia-sqli.

Provides a single configured logger used across every module. Supports
optional ANSI colors (auto disabled when the output is not a TTY) and a
compact format that is friendly to both console and file output.
"""

from __future__ import annotations

import logging
import os
import sys
import threading

_LOCK = threading.Lock()
_CONFIGURED = False

_COLORS = {
    "DEBUG": "\033[36m",     # cyan
    "INFO": "\033[32m",      # green
    "WARNING": "\033[33m",   # yellow
    "ERROR": "\033[31m",     # red
    "CRITICAL": "\033[1;41m",
    "RESET": "\033[0m",
}

# Windows / dumb terminals: enable ANSI on modern Windows consoles.
if os.name == "nt":  # pragma: no cover
    os.system("")


class _ColorFormatter(logging.Formatter):
    """Formatter that injects an ANSI color per log level."""

    def __init__(self, fmt: str, datefmt: str | None = None, use_color: bool = True):
        super().__init__(fmt, datefmt)
        self.use_color = use_color

    def format(self, record: logging.LogRecord) -> str:  # noqa: D102
        msg = super().format(record)
        if not self.use_color:
            return msg
        color = _COLORS.get(record.levelname, "")
        if not color:
            return msg
        return f"{color}{msg}{_COLORS['RESET']}"


def setup_logger(
    name: str = "sofia-sqli",
    level: str | int = "INFO",
    log_file: str | None = None,
    use_color: bool | None = None,
) -> logging.Logger:
    """Return a configured logger.

    Idempotent: repeated calls return the same logger without duplicating
    handlers.
    """
    global _CONFIGURED

    logger = logging.getLogger(name)

    if isinstance(level, str):
        level = getattr(logging, level.upper(), logging.INFO)
    logger.setLevel(level)

    if _CONFIGURED and logger.handlers:
        return logger

    with _LOCK:
        if _CONFIGURED and logger.handlers:
            return logger

        if use_color is None:
            use_color = sys.stderr.isatty()

        fmt = "%(asctime)s | %(levelname)-8s | %(threadName)-12s | %(name)s | %(message)s"
        datefmt = "%H:%M:%S"

        console = logging.StreamHandler(sys.stderr)
        console.setFormatter(_ColorFormatter(fmt, datefmt, use_color=use_color))
        logger.addHandler(console)

        if log_file:
            os.makedirs(os.path.dirname(os.path.abspath(log_file)), exist_ok=True)
            file_handler = logging.FileHandler(log_file, encoding="utf-8")
            file_handler.setFormatter(logging.Formatter(fmt, datefmt))
            logger.addHandler(file_handler)

        logger.propagate = False
        _CONFIGURED = True

    return logger


def get_logger(name: str = "sofia-sqli") -> logging.Logger:
    """Fetch (or lazily create) a child logger sharing the base config."""
    base = logging.getLogger("sofia-sqli")
    if not base.handlers:
        return setup_logger(name)
    if name == "sofia-sqli":
        return base
    return base.getChild(name.split("sofia-sqli.", 1)[-1])
