#!/usr/bin/env bash
# ============================================================================
# sofia-sqli — setup.sh
# Tự cài đặt mọi thứ cần thiết để chạy pipeline:
#   - Python 3 + venv + pip
#   - Thư viện Python (requirements.txt): requests, PyYAML, beautifulsoup4, lxml
#   - sqlmap (pip -> apt -> git clone, tự chọn phương án khả dụng)
#   - git, curl, pytest (chạy test suite)
#
# Cách dùng:
#   ./setup.sh              # cài vào venv .venv/ (khuyến nghị)
#   SOFIA_SYSTEM=1 ./setup.sh   # cài thẳng vào Python hệ thống
#
# Sau khi cài xong, kích hoạt môi trường:
#   source .venv/bin/activate && python3 main.py --help
#
# Nếu sqlmap được cài bằng git clone, script sẽ in ra dòng export
# SOFIA_SQLMAP_PATH cần set trước khi chạy pipeline.
# ============================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VENV_DIR="${SCRIPT_DIR}/.venv"
SQLMAP_CLONE_DIR="${SCRIPT_DIR}/sqlmap"

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
log()  { echo -e "\033[1;34m[setup]\033[0m $*"; }
ok()   { echo -e "\033[1;32m[ ok ]\033[0m $*"; }
warn() { echo -e "\033[1;33m[warn]\033[0m $*"; }
die()  { echo -e "\033[1;31m[fail]\033[0m $*" >&2; exit 1; }

# Chạy lệnh với sudo nếu cần và có sudo, không thì chạy trực tiếp
maybe_sudo() {
    if [ "$(id -u)" -eq 0 ]; then
        "$@"
    elif command -v sudo >/dev/null 2>&1; then
        sudo -n "$@" 2>/dev/null || sudo "$@"
    else
        "$@"
    fi
}

# ---------------------------------------------------------------------------
# 1) Kiểm tra hệ điều hành / package manager
# ---------------------------------------------------------------------------
PKG=""
if command -v apt-get >/dev/null 2>&1; then
    PKG="apt"
elif command -v dnf >/dev/null 2>&1; then
    PKG="dnf"
elif command -v yum >/dev/null 2>&1; then
    PKG="yum"
elif command -v pacman >/dev/null 2>&1; then
    PKG="pacman"
else
    warn "Không nhận diện được package manager — sẽ bỏ qua bước cài gói hệ thống."
fi

install_system_packages() {
    log "Cài gói hệ thống (python3, pip, venv, git, curl, sqlmap)..."
    case "${PKG}" in
        apt)
            maybe_sudo apt-get update -y
            # sqlmap có thể không có trong một số repo — cài riêng, không fail cả cụm
            maybe_sudo apt-get install -y python3 python3-pip python3-venv git curl \
                || die "apt-get install python3/git/curl thất bại"
            maybe_sudo apt-get install -y sqlmap \
                || warn "apt không cài được sqlmap — sẽ cài bằng pip/git ở bước sau."
            ;;
        dnf)
            maybe_sudo dnf install -y python3 python3-pip git curl sqlmap \
                || warn "dnf install lỗi (có thể thiếu sqlmap) — sẽ thử pip/git."
            ;;
        yum)
            maybe_sudo yum install -y python3 python3-pip git curl \
                || warn "yum install lỗi — sẽ thử pip/git."
            ;;
        pacman)
            maybe_sudo pacman -Sy --noconfirm --needed python python-pip git curl sqlmap \
                || warn "pacman install lỗi — sẽ thử pip/git."
            ;;
        *)
            warn "Bỏ qua cài gói hệ thống."
            ;;
    esac
}

# ---------------------------------------------------------------------------
# 2) Python
# ---------------------------------------------------------------------------
command -v python3 >/dev/null 2>&1 || die "python3 không tồn tại và không tự cài được. Hãy cài Python 3.9+ trước."
PYV="$(python3 -c 'import sys; print("%d.%d" % sys.version_info[:2])')"
log "Python ${PYV} tại: $(command -v python3)"

# ---------------------------------------------------------------------------
# 3) Môi trường cài pip: venv (mặc định) hoặc system
# ---------------------------------------------------------------------------
if [ "${SOFIA_SYSTEM:-0}" = "1" ]; then
    log "SOFIA_SYSTEM=1 -> cài vào Python hệ thống."
    PIP_FLAGS=(--break-system-packages)
    PY_RUN() { python3 "$@"; }
else
    log "Cài vào virtualenv: ${VENV_DIR} (dùng SOFIA_SYSTEM=1 để cài system-wide)."
    if [ ! -x "${VENV_DIR}/bin/python" ]; then
        # Đảm bảo module venv có sẵn (trên Debian/Ubuntu nằm trong python3-venv)
        python3 -m venv "${VENV_DIR}" 2>/dev/null \
            || { install_system_packages; python3 -m venv "${VENV_DIR}" || die "Không tạo được venv (thiếu python3-venv?)."; }
    fi
    # shellcheck disable=SC1091
    source "${VENV_DIR}/bin/activate"
    PIP_FLAGS=()
    PY_RUN() { "${VENV_DIR}/bin/python" "$@"; }
fi
ok "Môi trường Python sẵn sàng."

# ---------------------------------------------------------------------------
# 4) Thư viện Python
# ---------------------------------------------------------------------------
log "Cài dependencies từ requirements.txt..."
python3 -m pip install --upgrade pip ${PIP_FLAGS[*]+"${PIP_FLAGS[@]}"} >/dev/null 2>&1 || \
    warn "Không upgrade được pip (bỏ qua, không ảnh hưởng)."
python3 -m pip install ${PIP_FLAGS[*]+"${PIP_FLAGS[@]}"} -r "${SCRIPT_DIR}/requirements.txt" \
    || die "pip install -r requirements.txt thất bại"

# pytest cho test suite (không bắt buộc để chạy pipeline)
python3 -m pip install ${PIP_FLAGS[*]+"${PIP_FLAGS[@]}"} pytest >/dev/null 2>&1 \
    && ok "pytest đã cài (chạy test: python3 -m pytest tests/ -v)" \
    || warn "Không cài được pytest — bỏ qua nếu không cần chạy test."
ok "requirements.txt đã cài xong."

# ---------------------------------------------------------------------------
# 5) sqlmap — thử theo thứ tự: đã có sẵn -> pip -> git clone
# ---------------------------------------------------------------------------
sqlmap_available() {
    command -v sqlmap >/dev/null 2>&1 && return 0
    # pip sqlmap có thể chỉ expose module
    python3 -m sqlmap --version >/dev/null 2>&1 && return 0
    # bản git clone
    [ -f "${SQLMAP_CLONE_DIR}/sqlmap.py" ] && return 0
    return 1
}

if command -v sqlmap >/dev/null 2>&1; then
    ok "sqlmap đã có sẵn: $(command -v sqlmap) ($({ sqlmap --version || true; } 2>/dev/null | head -n1))"
elif python3 -m sqlmap --version >/dev/null 2>&1; then
    ok "sqlmap có sẵn qua module (python3 -m sqlmap)."
else
    log "sqlmap chưa có — đang cài..."
    # 5a) pip (bản mới nhất, đi kèm môi trường venv nếu đang dùng)
    if python3 -m pip install ${PIP_FLAGS[*]+"${PIP_FLAGS[@]}"} sqlmap >/dev/null 2>&1 \
        && { command -v sqlmap >/dev/null 2>&1 || python3 -m sqlmap --version >/dev/null 2>&1; }; then
        ok "sqlmap cài qua pip thành công."
    else
        # 5b) apt/dnf/pacman nếu chưa thử ở bước hệ thống
        if [ -n "${PKG}" ] && ! command -v sqlmap >/dev/null 2>&1; then
            case "${PKG}" in
                apt)    maybe_sudo apt-get install -y sqlmap >/dev/null 2>&1 || true ;;
                dnf)    maybe_sudo dnf install -y sqlmap >/dev/null 2>&1 || true ;;
                yum)    maybe_sudo yum install -y sqlmap >/dev/null 2>&1 || true ;;
                pacman) maybe_sudo pacman -Sy --noconfirm --needed sqlmap >/dev/null 2>&1 || true ;;
            esac
        fi
        # 5c) git clone — luôn hoạt động, không cần quyền root
        if ! command -v sqlmap >/dev/null 2>&1; then
            log "pip/apt không dùng được — git clone sqlmap vào ${SQLMAP_CLONE_DIR}..."
            if [ -d "${SQLMAP_CLONE_DIR}/.git" ]; then
                git -C "${SQLMAP_CLONE_DIR}" pull --ff-only >/dev/null 2>&1 || true
            else
                rm -rf "${SQLMAP_CLONE_DIR}"
                git clone --depth 1 https://github.com/sqlmapproject/sqlmap.git "${SQLMAP_CLONE_DIR}" \
                    || die "git clone sqlmap thất bại — kiểm tra kết nối mạng."
            fi
            chmod +x "${SQLMAP_CLONE_DIR}/sqlmap.py" 2>/dev/null || true
            # symlink vào PATH của venv / ~/.local/bin để gọi `sqlmap` trực tiếp
            LINK_DIR="$(dirname "$(command -v python3)")"
            ln -sf "${SQLMAP_CLONE_DIR}/sqlmap.py" "${LINK_DIR}/sqlmap" 2>/dev/null || true
            mkdir -p "${HOME}/.local/bin"
            ln -sf "${SQLMAP_CLONE_DIR}/sqlmap.py" "${HOME}/.local/bin/sqlmap" 2>/dev/null || true
        fi
    fi
fi

# Kiểm tra cuối và xuất SOFIA_SQLMAP_PATH nếu cần
FINAL_HINT=""
if command -v sqlmap >/dev/null 2>&1; then
    ok "sqlmap OK: $(command -v sqlmap)"
elif python3 -m sqlmap --version >/dev/null 2>&1; then
    ok "sqlmap OK (module). Pipeline tự dùng được, hoặc set SOFIA_SQLMAP_PATH='python3 -m sqlmap' wrapper."
    FINAL_HINT="export SOFIA_SQLMAP_PATH=\"$(command -v python3) -m sqlmap\"  # nếu pipeline cần đường dẫn trực tiếp"
elif [ -f "${SQLMAP_CLONE_DIR}/sqlmap.py" ]; then
    ok "sqlmap OK (git clone): ${SQLMAP_CLONE_DIR}/sqlmap.py"
    FINAL_HINT="export SOFIA_SQLMAP_PATH=\"${SQLMAP_CLONE_DIR}/sqlmap.py\""
else
    die "sqlmap vẫn chưa cài được. Cài thủ công: pip install sqlmap / apt install sqlmap / git clone https://github.com/sqlmapproject/sqlmap"
fi

# ---------------------------------------------------------------------------
# 6) Tạo .env gợi ý (nếu sqlmap dùng bản clone)
# ---------------------------------------------------------------------------
if [ -n "${FINAL_HINT}" ]; then
    grep -q "SOFIA_SQLMAP_PATH" "${SCRIPT_DIR}/.env" 2>/dev/null || \
        echo "${FINAL_HINT}" >> "${SCRIPT_DIR}/.env"
    log "Đã ghi ${FINAL_HINT} vào ${SCRIPT_DIR}/.env (source .env trước khi chạy)."
fi

# ---------------------------------------------------------------------------
# 7) Kiểm tra tổng thể
# ---------------------------------------------------------------------------
log "Kiểm tra tổng thể..."
python3 - <<'EOF'
import importlib, sys
missing = []
for mod in ("requests", "yaml", "bs4", "lxml"):
    try:
        importlib.import_module(mod)
    except ImportError:
        missing.append(mod)
if missing:
    print("THIEU MODULE:", ", ".join(missing)); sys.exit(1)
print("Tat ca module Python OK:", ", ".join(("requests", "PyYAML", "beautifulsoup4", "lxml")))
EOF

ok "=============================================="
ok "sofia-sqli setup HOAN TAT"
ok "=============================================="
echo ""
if [ "${SOFIA_SYSTEM:-0}" != "1" ]; then
    echo "  Chạy pipeline:"
    echo "    source ${VENV_DIR}/bin/activate"
    [ -n "${FINAL_HINT}" ] && echo "    source ${SCRIPT_DIR}/.env"
    echo "    python3 main.py --help"
else
    [ -n "${FINAL_HINT}" ] && echo "  ${FINAL_HINT}"
    echo "  Chạy pipeline: python3 main.py --help"
fi
echo "  Test suite:   python3 -m pytest tests/ -v"
echo ""
