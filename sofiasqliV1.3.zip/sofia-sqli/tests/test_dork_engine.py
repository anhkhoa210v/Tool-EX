"""Offline tests for DorkCrawler engine dispatch, parse helpers and filters.

Regression target: ``_dork_engine`` must ALWAYS return a list (never None),
for every engine key including unknown ones.
"""

from __future__ import annotations

import time

from core.crawler import (_clean_url, _has_query_params, _looks_blocked,
                          DorkCrawler)
from tests.conftest import FakeResp, make_cfg, make_crawler

SERP_HTML = """
<html><body>
<a href="http://target.example/view.php?id=3">result 1</a>
<a href="https://shop.example/product.php?id=42&ref=spam">result 2</a>
</body></html>
"""


# ----------------------------------------------------------- dispatch/None bug
def test_dork_engine_never_returns_none_html(monkeypatch):
    c = make_crawler()
    monkeypatch.setattr(c, "_get", lambda url, **kw: FakeResp(text=SERP_HTML))
    for engine in ("google", "bing", "duckduckgo", "ddglite", "mojeek",
                   "startpage", "yandex"):
        out = c._dork_engine(engine, 'inurl:".php?id="')
        assert isinstance(out, list), engine
        assert all(u.startswith("http") for u in out)


def test_dork_engine_never_returns_none_serpapi(monkeypatch):
    c = make_crawler()
    body = {"organic_results": [{"link": "http://target.example/a.php?id=1"}]}
    monkeypatch.setattr(c, "_get", lambda url, **kw: FakeResp(json_data=body))
    out = c._dork_engine("serpapi", 'inurl:".php?id="')
    assert isinstance(out, list) and out


def test_dork_engine_never_returns_none_cse(monkeypatch):
    c = make_crawler()
    body = {"items": [{"link": "http://target.example/a.php?id=1"}]}
    monkeypatch.setattr(c, "_get", lambda url, **kw: FakeResp(json_data=body))
    out = c._dork_engine("cse", 'inurl:".php?id="')
    assert isinstance(out, list) and out


def test_dork_engine_unknown_engine_returns_empty_list():
    c = make_crawler()
    out = c._dork_engine("no-such-engine", 'inurl:".php?id="')
    assert out == []


def test_dork_engine_normalises_engine_name(monkeypatch):
    c = make_crawler()
    monkeypatch.setattr(c, "_get", lambda url, **kw: FakeResp(text=SERP_HTML))
    assert c._dork_engine("  GOOGLE ", 'inurl:".php?id="') == \
        c._dork_engine("google", 'inurl:".php?id="')


# -------------------------------------------------- cooldown honoured by API engines
def test_serpapi_skips_while_in_cooldown(monkeypatch):
    c = make_crawler()

    def _boom(*a, **kw):
        raise AssertionError("network hit during cooldown")

    monkeypatch.setattr(c, "_get", _boom)
    c._engine_cooldown["serpapi"] = time.monotonic() + 60
    assert c._dork_serpapi("q") == []


def test_cse_skips_while_in_cooldown(monkeypatch):
    c = make_crawler()

    def _boom(*a, **kw):
        raise AssertionError("network hit during cooldown")

    monkeypatch.setattr(c, "_get", _boom)
    c._engine_cooldown["cse"] = time.monotonic() + 60
    assert c._dork_cse("q") == []


# -------------------------------------------------- API-level rate-limit errors
def test_cse_api_rate_limit_error_marks_engine_blocked(monkeypatch):
    c = make_crawler()
    body = {"error": {"code": 429,
                      "message": "Quota exceeded, HTTP 429 rate limited"}}
    monkeypatch.setattr(c, "_get", lambda url, **kw: FakeResp(json_data=body))
    out = c._dork_cse("q")
    assert out == []
    assert "cse" in c._throttled
    assert c._engine_mult.get("cse", 1.0) > 1.0


def test_serpapi_api_rate_limit_error_marks_engine_blocked(monkeypatch):
    c = make_crawler()
    body = {"error": "429 Too Many Requests"}
    monkeypatch.setattr(c, "_get", lambda url, **kw: FakeResp(json_data=body))
    out = c._dork_serpapi("q")
    assert out == []
    assert "serpapi" in c._throttled


def test_cse_plain_api_error_does_not_mark_blocked(monkeypatch):
    c = make_crawler()
    body = {"error": {"code": 400, "message": "bad request"}}
    monkeypatch.setattr(c, "_get", lambda url, **kw: FakeResp(json_data=body))
    assert c._dork_cse("q") == []
    assert "cse" not in c._throttled


# ----------------------------------------------------------- SERP parse helpers
def test_looks_blocked_detects_captcha_and_normal_serp():
    assert _looks_blocked("unusual traffic from your computer network")
    assert _looks_blocked("Please complete the reCAPTCHA to continue")
    assert not _looks_blocked(SERP_HTML)
    assert not _looks_blocked("")


def test_clean_url_strips_tracking_junk():
    assert _clean_url("https://t.example/p.php?id=1&utm_source=x") == \
        "https://t.example/p.php?id=1"
    assert _clean_url("https://t.example/p.php?utm_term=x") is None
    assert _clean_url("not a url") is None


def test_has_query_params():
    assert _has_query_params("http://a.b/x.php?id=1")
    assert _has_query_params("http://a.b/x.php?id=")
    assert not _has_query_params("http://a.b/x.php")


def test_xlsx_asset_is_blacklisted():
    # Regression: the extension regex used to contain a broken "xls x?" token
    # so .xlsx URLs slipped through the static-asset filter.
    c = make_crawler()
    assert c._is_blacklisted("https://files.example/report.xlsx")
    assert c._is_blacklisted("https://files.example/doc.xls")
    assert not c._is_blacklisted("https://shop.example/product.php?id=2")


def test_html_engine_extracts_and_cleans(monkeypatch):
    c = make_crawler()
    monkeypatch.setattr(c, "_get", lambda url, **kw: FakeResp(text=SERP_HTML))
    out = c._dork_html("google", 'inurl:".php?id="')
    assert "http://target.example/view.php?id=3" in out
    # Tracking junk (utm_*) never survives cleaning, even inside SERP
    # extraction. Plain `ref` is kept on purpose: it is listed in
    # _INTERESTING_PARAM_RE as a potential SQLi sink parameter.
    assert not any("utm_" in u for u in out)
    assert any("ref=spam" in u for u in out)


def test_per_query_cap(monkeypatch):
    cfg = make_cfg(max_results_per_query=5)
    c = make_crawler(cfg)
    links = "".join(f'<a href="http://t{i}.example/p.php?id={i}">x</a>'
                    for i in range(12))
    monkeypatch.setattr(c, "_get", lambda url, **kw: FakeResp(text=links))
    assert len(c._dork_html("google", "q")) == 5