"""Offline integration tests for ``DorkCrawler._get``.

Covers the whole request path in one place: UA/Accept-Language rotation,
proxy pool injection, throttled status handling (429/503 + retry) and the
SERP disk cache working on top of the real ``_get`` (no monkeypatch of
``_get`` itself - only the transport layer is faked).
"""

from __future__ import annotations

import pytest
import requests

from core.crawler import _ACCEPT_LANGS, _UA_POOL, DorkCrawler
from tests.conftest import FakeResp, make_cfg
from utils.rate_limit import JitteredBackoff


class RecordingSession:
    """Stand-in for requests.Session that records every .get() call."""

    def __init__(self, responses):
        self.calls: list[dict] = []
        self._responses = list(responses)
        self.headers: dict[str, str] = {}

    def get(self, url, **kwargs):
        self.calls.append({"url": url, **kwargs})
        if len(self._responses) > 1:
            return self._responses.pop(0)
        return self._responses[0]


def _crawler(session, **dork_over):
    dork_over.setdefault("min_interval", 0.0)
    cfg = make_cfg(**dork_over)
    return DorkCrawler(cfg, session=session)


# ------------------------------------------------------------------- headers
def test_get_injects_rotated_user_agent_and_accept_language():
    s = RecordingSession([FakeResp(text="ok")])
    c = _crawler(s)                     # rotate_user_agent=True mặc định
    c._get("http://t.example/search")
    assert len(s.calls) == 1
    headers = s.calls[0]["headers"]
    assert headers["User-Agent"] in set(_UA_POOL) | {"TestUA/1.0"}
    assert headers["Accept-Language"] in _ACCEPT_LANGS


def test_get_rotation_off_pins_user_agent():
    s = RecordingSession([FakeResp(text="ok")])
    cfg = make_cfg(rotate_user_agent=False, min_interval=0.0)
    cfg["general"]["user_agent"] = "PinnedUA/2.0"
    c = DorkCrawler(cfg, session=s)
    for _ in range(5):
        c._get("http://t.example/search")
    assert {call["headers"]["User-Agent"] for call in s.calls} == {"PinnedUA/2.0"}


def test_get_explicit_headers_win_over_rotation_defaults():
    s = RecordingSession([FakeResp(text="ok")])
    c = _crawler(s)
    c._get("http://t.example/search",
           headers={"User-Agent": "Explicit/1.0", "X-Custom": "v"})
    headers = s.calls[0]["headers"]
    assert headers["User-Agent"] == "Explicit/1.0"     # setdefault không ghi đè
    assert headers["X-Custom"] == "v"
    assert "Accept-Language" in headers                 # vẫn xoay Accept-Language


# ------------------------------------------------------------------- proxies
def test_get_passes_proxy_from_pool(monkeypatch):
    monkeypatch.delenv("SOFIA_PROXIES", raising=False)
    s = RecordingSession([FakeResp(text="ok")])
    c = _crawler(s, proxies=["10.0.0.9:3128"])
    assert c._proxy_pool == [{"http": "http://10.0.0.9:3128",
                              "https": "http://10.0.0.9:3128"}]
    c._get("http://t.example/search")
    assert s.calls[0]["proxies"] == {"http": "http://10.0.0.9:3128",
                                     "https": "http://10.0.0.9:3128"}


def test_get_without_proxy_pool_omits_proxies_kwarg():
    s = RecordingSession([FakeResp(text="ok")])
    c = _crawler(s)                     # proxies: []
    c._get("http://t.example/search")
    assert "proxies" not in s.calls[0]


# ----------------------------------------------------------------- 429 / 503
def test_get_raises_throttled_on_429_single_attempt():
    s = RecordingSession([FakeResp(text="", status_code=429)])
    c = _crawler(s)                     # retries=0
    with pytest.raises(requests.RequestException, match="429"):
        c._get("http://t.example/search")
    assert len(s.calls) == 1            # retries=0 -> đúng 1 lần gọi


def test_get_raises_throttled_on_503_single_attempt():
    s = RecordingSession([FakeResp(text="", status_code=503)])
    c = _crawler(s)
    with pytest.raises(requests.RequestException, match="503"):
        c._get("http://t.example/search")
    assert len(s.calls) == 1


def test_get_retries_on_503_then_succeeds(monkeypatch):
    monkeypatch.setattr("utils.rate_limit.time.sleep", lambda _s: None)
    s = RecordingSession([FakeResp(text="", status_code=503),
                          FakeResp(text="ok")])
    cfg = make_cfg(min_interval=0.0)
    cfg["general"]["retries"] = 1       # tổng 2 attempt
    c = DorkCrawler(cfg, session=s)
    c.backoff = JitteredBackoff(base=0.001, jitter=0.0)
    resp = c._get("http://t.example/search")
    assert resp.text == "ok"
    assert len(s.calls) == 2            # 1 lần fail + 1 lần retry thành công


def test_get_429_marks_engine_blocked_through_dork_html():
    """429 ở tầng _get -> engine bị đánh dấu block (cooldown + mult x2)."""
    s = RecordingSession([FakeResp(text="", status_code=429)])
    c = _crawler(s)
    out = c._dork_html("google", "q")
    assert out == []
    assert "google" in c._throttled
    assert c._engine_mult["google"] == pytest.approx(2.0)


# ------------------------------------------------- cache tích hợp qua _get
def test_cache_roundtrip_uses_real_get(tmp_path):
    """Chạy 1: qua _get thật và ghi cache. Chạy 2: session không bị gọi."""
    path = str(tmp_path / "c.json")
    serp = '<a href="http://target.example/p.php?id=1">x</a>'

    s1 = RecordingSession([FakeResp(text=serp)])
    c1 = _crawler(s1, cache_enabled=True, cache_file=path,
                  max_results_per_query=5)
    first = c1._dork_html("google", "q")
    # extract có thể trả URL 2 lần (anchor + raw-text), nên so sánh theo set
    assert set(first) == {"http://target.example/p.php?id=1"}
    c1._cache_save()
    assert len(s1.calls) == 1

    s2 = RecordingSession([FakeResp(text=serp)])
    c2 = _crawler(s2, cache_enabled=True, cache_ttl=600, cache_file=path,
                  max_results_per_query=5)
    second = c2._dork_html("google", "q")
    assert sorted(second) == sorted(first)
    assert len(s2.calls) == 0           # cache hit -> không chạm transport