"""Shared fixtures for the offline test suite.

All tests run WITHOUT network access: ``DorkCrawler._get`` is monkeypatched
to return canned responses, and the SERP disk cache is redirected into
pytest's tmp_path.
"""

from __future__ import annotations

import os
import sys

import pytest
import requests

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

from core.crawler import DorkCrawler  # noqa: E402


def make_cfg(**dork_over: object) -> dict:
    """Minimal settings dict exercising the anti-block / cache features."""
    dork: dict = {
        "enabled": True,
        "engines": ["google", "bing"],
        "queries": ['inurl:".php?id="'],
        "auto_generate": False,
        "min_interval": 0.0,
        "max_per_window": None,
        "window": 60.0,
        "jitter": 0.25,
        "block_cooldown": 60.0,
        "max_interval_mult": 8.0,
        "failover": True,
        "rotate_user_agent": True,
        "proxies": [],
        "cache_enabled": False,
        "cache_ttl": 21600,
        "cache_file": ".serp_cache.json",
        "dictionary": {"enabled": False},
        "evolution": {"enabled": False},
        "generator": {"enabled": False},
        "max_results_per_query": 20,
        "serpapi": {"api_key": "fake-key", "engine": "google"},
        "cse": {"api_key": "fake-key", "cx": "fake-cx"},
    }
    dork.update(dork_over)
    return {
        "general": {
            "timeout": 5,
            "retries": 0,
            "threads": 2,
            "discovery_threads": 2,
            "user_agent": "TestUA/1.0",
            "parallel_discovery": False,
            "smart_dedupe": False,
        },
        "dork": dork,
        "urlscan": {"enabled": False},
        "wayback": {"enabled": False},
        "commoncrawl": {"enabled": False},
    }


class FakeResp:
    """Minimal stand-in for requests.Response."""

    def __init__(self, text: str = "", json_data: object = None,
                 status_code: int = 200):
        self.text = text
        self._json = json_data
        self.status_code = status_code

    def raise_for_status(self) -> None:
        return None

    def json(self) -> object:
        if self._json is None:
            raise ValueError("no json body")
        return self._json


def make_crawler(cfg: dict | None = None,
                 session: requests.Session | None = None) -> DorkCrawler:
    return DorkCrawler(cfg or make_cfg(), session=session or requests.Session())


@pytest.fixture()
def crawler(tmp_path) -> DorkCrawler:
    cfg = make_cfg(cache_enabled=True,
                   cache_file=str(tmp_path / ".serp_cache.json"))
    return make_crawler(cfg)