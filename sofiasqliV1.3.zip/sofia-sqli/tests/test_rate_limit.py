"""Offline tests for utils.rate_limit (RateLimiter + JitteredBackoff + retry)."""

from __future__ import annotations

import time

import pytest

from utils.rate_limit import JitteredBackoff, RateLimiter, retry


def test_min_interval_enforced():
    lim = RateLimiter(min_interval=0.1)
    t0 = time.monotonic()
    lim.acquire()
    slept = lim.acquire()
    elapsed = time.monotonic() - t0
    assert slept > 0
    assert elapsed >= 0.09


def test_jitter_varies_the_wait():
    sleeps = []
    for _ in range(20):
        lim = RateLimiter(min_interval=0.05, jitter=0.5)
        lim.acquire()
        sleeps.append(lim.acquire())
    # jitter 0.5 -> wait in [0.025, 0.075]; the 20 samples must not be constant
    assert max(sleeps) - min(sleeps) > 0.005
    for s in sleeps:
        assert 0.02 <= s <= 0.08


def test_nonblocking_acquire_returns_zero_when_busy():
    lim = RateLimiter(min_interval=10.0)
    lim.acquire()
    t0 = time.monotonic()
    assert lim.acquire(block=False) == 0.0
    assert time.monotonic() - t0 < 0.5


def test_max_per_window_quota():
    lim = RateLimiter(min_interval=0.0, max_per_window=2, window=0.2)
    lim.acquire()
    lim.acquire()
    t0 = time.monotonic()
    lim.acquire()                      # must block ~window before slot opens
    assert time.monotonic() - t0 >= 0.15


def test_backoff_bounds_and_cap():
    b = JitteredBackoff(base=1.0, factor=2.0, max_delay=3.0, jitter=0.0)
    assert b.delay(0) == pytest.approx(1.0)
    assert b.delay(1) == pytest.approx(2.0)
    assert b.delay(10) == pytest.approx(3.0)      # capped at max_delay

    bj = JitteredBackoff(base=1.0, factor=1.0, max_delay=10.0, jitter=0.25)
    for _ in range(10):
        assert 0.75 <= bj.delay(0) <= 1.25


def test_retry_decorator_retries_then_raises():
    calls = {"n": 0}

    @retry(retries=2, exceptions=(ValueError,),
           backoff=JitteredBackoff(base=0.01, jitter=0.0))
    def flaky() -> int:
        calls["n"] += 1
        if calls["n"] < 3:
            raise ValueError("boom")
        return 7

    assert flaky() == 7
    assert calls["n"] == 3

    @retry(retries=1, exceptions=(ValueError,),
           backoff=JitteredBackoff(base=0.01, jitter=0.0))
    def always_bad() -> None:
        raise ValueError("nope")

    with pytest.raises(ValueError):
        always_bad()

# ----------------------------------------------------- jitter / validation
def test_jitter_fraction_is_clamped():
    lim = RateLimiter(min_interval=1.0, jitter=5.0)
    assert lim.jitter == pytest.approx(0.9)          # capped at 0.9
    lim2 = RateLimiter(min_interval=1.0, jitter=-1.0)
    assert lim2.jitter == pytest.approx(0.0)


def test_backoff_negative_attempt_uses_base():
    b = JitteredBackoff(base=2.0, factor=3.0, jitter=0.0)
    assert b.delay(-5) == pytest.approx(b.delay(0))


def test_backoff_zero_delay_when_base_zero():
    b = JitteredBackoff(base=0.0, jitter=0.5)
    assert b.delay(4) == 0.0


# ------------------------------------------------------------- retry decorator
def test_retry_calls_on_retry_callback():
    seen: list[tuple[int, str]] = []

    @retry(retries=2, exceptions=(ValueError,),
           backoff=JitteredBackoff(base=0.001, jitter=0.0),
           on_retry=lambda attempt, exc: seen.append((attempt, str(exc))))
    def flaky() -> None:
        raise ValueError("boom")

    with pytest.raises(ValueError):
        flaky()
    assert [a for a, _ in seen] == [0, 1]
    assert all("boom" in e for _, e in seen)


def test_retry_does_not_retry_unlisted_exceptions():
    calls = {"n": 0}

    @retry(retries=3, exceptions=(ValueError,),
           backoff=JitteredBackoff(base=0.001, jitter=0.0))
    def bad_type() -> None:
        calls["n"] += 1
        raise TypeError("not retried")

    with pytest.raises(TypeError):
        bad_type()
    assert calls["n"] == 1


def test_retry_sleeps_between_attempts(monkeypatch):
    sleeps: list[float] = []
    monkeypatch.setattr("utils.rate_limit.time.sleep", lambda s: sleeps.append(s))

    @retry(retries=3, exceptions=(ValueError,),
           backoff=JitteredBackoff(base=0.5, factor=2.0, jitter=0.0))
    def always_bad() -> None:
        raise ValueError("x")

    with pytest.raises(ValueError):
        always_bad()
    assert sleeps == [pytest.approx(0.5), pytest.approx(1.0), pytest.approx(2.0)]


def test_retry_zero_retries_is_single_attempt():
    calls = {"n": 0}

    @retry(retries=0, exceptions=(ValueError,),
           backoff=JitteredBackoff(base=0.001, jitter=0.0))
    def f() -> None:
        calls["n"] += 1
        raise ValueError("x")

    with pytest.raises(ValueError):
        f()
    assert calls["n"] == 1


def test_retry_accepts_single_exception_class():
    calls = {"n": 0}

    @retry(retries=1, exceptions=ValueError,
           backoff=JitteredBackoff(base=0.001, jitter=0.0))
    def f() -> str:
        calls["n"] += 1
        if calls["n"] == 1:
            raise ValueError("x")
        return "ok"

    assert f() == "ok"
    assert calls["n"] == 2


def test_retry_original_exception_instance_raised():
    sentinel = ValueError("original")

    @retry(retries=2, exceptions=(ValueError,),
           backoff=JitteredBackoff(base=0.001, jitter=0.0))
    def f() -> None:
        raise sentinel

    with pytest.raises(ValueError) as ei:
        f()
    assert ei.value is sentinel


# ------------------------------------------------------------- thread safety
def test_limiter_thread_safety_spreads_acquisitions():
    import threading

    lim = RateLimiter(min_interval=0.05)
    done: list[float] = []
    lock = threading.Lock()

    def worker() -> None:
        lim.acquire()
        with lock:
            done.append(time.monotonic())

    t0 = time.monotonic()
    threads = [threading.Thread(target=worker) for _ in range(4)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    # 4 lan acquire cach nhau it nhat 0.05s -> tong thoi gian >= 3 * 0.05
    assert time.monotonic() - t0 >= 0.14
    assert sorted(done) == done


def test_limiter_context_manager():
    lim = RateLimiter(min_interval=0.05)
    with lim as got:
        assert got is lim
    t0 = time.monotonic()
    lim.acquire()
    assert time.monotonic() - t0 >= 0.045


# ------------------------------------------------------- bổ sung: retry API
def test_retry_accepts_exception_list():
    calls = {"n": 0}

    @retry(retries=1, exceptions=[ValueError, KeyError],
           backoff=JitteredBackoff(base=0.001, jitter=0.0))
    def f() -> str:
        calls["n"] += 1
        if calls["n"] == 1:
            raise KeyError("x")
        return "ok"

    assert f() == "ok"
    assert calls["n"] == 2


def test_retry_default_backoff_and_exceptions():
    """Không truyền backoff/exceptions: dùng mặc định, vẫn retry được."""
    calls = {"n": 0}

    @retry(retries=1)
    def f() -> str:
        calls["n"] += 1
        if calls["n"] == 1:
            raise RuntimeError("transient")
        return "ok"

    assert f() == "ok"
    assert calls["n"] == 2


def test_retry_preserves_function_metadata():
    @retry(retries=0, exceptions=(ValueError,),
           backoff=JitteredBackoff(base=0.001, jitter=0.0))
    def documented() -> None:
        """Docstring gốc."""

    assert documented.__name__ == "documented"
    assert "Docstring gốc" in (documented.__doc__ or "")


def test_on_retry_receives_attempt_index_and_exception():
    seen: list[tuple[int, BaseException]] = []

    @retry(retries=2, exceptions=(ValueError,),
           backoff=JitteredBackoff(base=0.001, jitter=0.0),
           on_retry=lambda a, e: seen.append((a, e)))
    def always_bad() -> None:
        raise ValueError("boom")

    with pytest.raises(ValueError):
        always_bad()
    # attempt bắt đầu từ 0, mỗi lần retry nhận đúng exception vừa gặp
    assert [a for a, _ in seen] == [0, 1]
    assert all(isinstance(e, ValueError) for _, e in seen)


def test_on_retry_replaces_default_warning_log(caplog):
    """Khi có on_retry, không phát log warning mặc định nữa."""

    @retry(retries=1, exceptions=(ValueError,),
           backoff=JitteredBackoff(base=0.001, jitter=0.0),
           on_retry=lambda a, e: None)
    def always_bad() -> None:
        raise ValueError("boom")

    with caplog.at_level("WARNING", logger="sofia-sqli.rate_limit"):
        with pytest.raises(ValueError):
            always_bad()
    assert not any("failed (attempt" in r.getMessage() for r in caplog.records)


# ------------------------------------------------- bổ sung: window / threads
def test_limiter_window_count_resets_after_window():
    lim = RateLimiter(min_interval=0.0, max_per_window=1, window=0.15)
    lim.acquire()
    t0 = time.monotonic()
    lim.acquire()                       # chờ hết window cũ rồi được phép lại
    assert time.monotonic() - t0 >= 0.1


def test_limiter_thread_safety_never_exceeds_window_quota():
    """N thread chen chân cùng limiter: quota cửa sổ vẫn được tôn trọng."""
    import threading

    lim = RateLimiter(min_interval=0.0, max_per_window=2, window=0.25)
    ok: list[float] = []
    lock = threading.Lock()

    def worker() -> None:
        lim.acquire()                   # block=True: chờ tới lượt
        with lock:
            ok.append(time.monotonic())

    threads = [threading.Thread(target=worker) for _ in range(6)]
    t0 = time.monotonic()
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    # 6 slot / 2-per-0.25s window -> cần tối thiểu 2 lần chờ window
    assert time.monotonic() - t0 >= 0.4
    assert len(ok) == 6
    assert sorted(ok) == ok
