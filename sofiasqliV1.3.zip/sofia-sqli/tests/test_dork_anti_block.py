"""Offline tests for the adaptive anti-block layer:
per-engine rate limiters + jitter, block cooldown, interval escalation and
failover to a healthy engine.
"""

from __future__ import annotations

import time

import pytest
import requests

from core.crawler import DorkCrawler
from tests.conftest import make_cfg, make_crawler


# ------------------------------------------------------------ per-engine limiter
def test_per_engine_limiters_are_independent():
    c = make_crawler()
    g = c._engine_limiter("google")
    b = c._engine_limiter("bing")
    assert g is not b
    assert g is c._engine_limiter("google")        # lazily cached
    assert g.min_interval == pytest.approx(0.0)
    assert g.jitter == pytest.approx(0.25)


def test_limiter_picks_up_min_interval_and_window():
    cfg = make_cfg(min_interval=1.5, max_per_window=30, window=90.0)
    c = make_crawler(cfg)
    lim = c._engine_limiter("google")
    assert lim.min_interval == pytest.approx(1.5)
    assert lim.max_per_window == 30
    assert lim.window == pytest.approx(90.0)


# ------------------------------------------------------------ adaptive backoff
def test_block_doubles_interval_and_sets_cooldown():
    cfg = make_cfg(min_interval=2.0, block_cooldown=300, max_interval_mult=8.0)
    c = make_crawler(cfg)
    lim = c._engine_limiter("google")

    c._mark_engine_blocked("google")
    assert "google" in c._throttled
    assert c._engine_mult["google"] == pytest.approx(2.0)
    assert lim.min_interval == pytest.approx(4.0)
    assert not c._engine_available("google")

    c._mark_engine_blocked("google")
    assert c._engine_mult["google"] == pytest.approx(4.0)
    assert lim.min_interval == pytest.approx(8.0)

    for _ in range(10):                            # capped at max_interval_mult
        c._mark_engine_blocked("google")
    assert c._engine_mult["google"] == pytest.approx(8.0)
    assert lim.min_interval == pytest.approx(16.0)


def test_success_halves_interval_back_to_baseline():
    cfg = make_cfg(min_interval=2.0)
    c = make_crawler(cfg)
    lim = c._engine_limiter("bing")
    c._mark_engine_blocked("bing")
    c._mark_engine_blocked("bing")                 # mult=4, interval=8
    c._engine_success("bing")
    assert c._engine_mult["bing"] == pytest.approx(2.0)
    assert lim.min_interval == pytest.approx(4.0)
    c._engine_success("bing")
    c._engine_success("bing")                      # floors at 1.0
    assert c._engine_mult.get("bing", 1.0) == pytest.approx(1.0)
    assert lim.min_interval == pytest.approx(2.0)


def test_engine_recovers_after_cooldown_expires():
    cfg = make_cfg(min_interval=2.0, block_cooldown=0.2)
    c = make_crawler(cfg)
    lim = c._engine_limiter("google")
    c._mark_engine_blocked("google")
    assert not c._engine_available("google")
    time.sleep(0.25)
    assert c._engine_available("google")           # recovery path
    assert c._engine_mult.get("google", 1.0) == pytest.approx(1.0)
    assert lim.min_interval == pytest.approx(2.0)


def test_zero_cooldown_never_blocks_engine():
    cfg = make_cfg(block_cooldown=0.0)
    c = make_crawler(cfg)
    c._mark_engine_blocked("google")
    assert c._engine_available("google")           # interval still escalated
    assert c._engine_mult["google"] == pytest.approx(2.0)


# ------------------------------------------------------------------- failover
def test_failover_reroutes_blocked_engine_dorks(monkeypatch, caplog):
    """Google bi block -> dork duoc thu lai tren bing (healthy engine).

    run_dorks khong dedupe (dedupe nam o run_all): bing co the tra cung URL
    tu ca job rieng va lenh failover, nen assert theo tung phan tu va log.
    """
    c = make_crawler()                             # engines: google, bing
    good = ["http://target.example/a.php?id=7"]

    def fake_html(engine, query):
        if engine == "google":
            c._mark_engine_blocked("google")
            raise requests.RequestException("HTTP 429 (throttled)")
        return list(good)

    monkeypatch.setattr(c, "_dork_html", fake_html)
    with caplog.at_level("INFO", logger="sofia-sqli.crawler"):
        res = c.run_dorks()
    assert res.stats.get("google", 0) == 0
    assert "google" in res.throttled
    assert res.stats.get("bing", 0) >= 1
    assert good[0] in res.urls
    # Nhanh failover thuc su chay: dork bi chuyen tu google sang bing.
    assert any("failover" in r.getMessage() and "'google' sang 'bing'" in r.getMessage()
               for r in caplog.records)


def test_failover_disabled_leaves_results_empty(monkeypatch):
    c = make_crawler(make_cfg(failover=False))

    def fake_html(engine, query):
        if engine == "google":
            c._mark_engine_blocked("google")
            raise requests.RequestException("HTTP 429 (throttled)")
        return ["http://target.example/a.php?id=7"]

    monkeypatch.setattr(c, "_dork_html", fake_html)
    res = c.run_dorks()
    assert res.stats.get("google", 0) == 0
    # bing still runs its own job independently of google's failure
    assert res.stats.get("bing") == 1


def test_html_engine_marks_blocked_on_captcha_page(monkeypatch):
    c = make_crawler()

    class R:
        text = "unusual traffic from your computer network"

        @staticmethod
        def raise_for_status():
            return None

    monkeypatch.setattr(c, "_get", lambda url, **kw: R())
    out = c._dork_html("google", "q")
    assert out == []
    assert "google" in c._throttled

# --------------------------------------------------- throttle detection helpers
SERP_PAGE = '<a href="http://target.example/a.php?id=1">r</a>'
CAPTCHA_PAGE = "unusual traffic from your computer network"


def test_looks_throttled_exc_variants():
    m = DorkCrawler._looks_throttled_exc
    assert m(Exception("HTTP 429 (throttled)"))
    assert m(Exception("HTTP 503 Service Unavailable"))
    assert m(Exception("429 Too Many Requests"))
    assert m(Exception("server THROTTLING"))
    assert not m(Exception("connection reset by peer"))
    assert not m(Exception("name resolution failure"))


def test_dork_html_stops_pagination_when_engine_gets_blocked(monkeypatch):
    """Page 0 binh thuong, page 1 tra CAPTCHA -> dung pagination + cooldown."""
    c = make_crawler()                 # max_results_per_query=20 -> 2 pages
    pages = [SERP_PAGE, CAPTCHA_PAGE]

    class R:
        def __init__(self, text):
            self.text = text

        def raise_for_status(self):
            return None

    monkeypatch.setattr(c, "_get", lambda url, **kw: R(pages.pop(0)))
    out = c._dork_html("google", "q")
    assert "http://target.example/a.php?id=1" in out
    assert "google" in c._throttled
    assert c._engine_mult["google"] == pytest.approx(2.0)


def test_failover_skips_engines_in_cooldown(monkeypatch):
    """Ca 2 engine bi block -> khong con alt healthy -> khong co failover."""
    import threading

    c = make_crawler()                 # engines: google, bing
    bing_calls: list[str] = []
    lock = threading.Lock()

    def fake_html(engine, query):
        if engine == "google":
            c._mark_engine_blocked("google")
            raise requests.RequestException("HTTP 429 (throttled)")
        with lock:
            bing_calls.append(query)
        return []

    monkeypatch.setattr(c, "_dork_html", fake_html)
    c._mark_engine_blocked("bing")     # bing trong cooldown truoc khi chay
    res = c.run_dorks()
    assert res.urls == []
    assert "google" in res.throttled and "bing" in res.throttled
    # bing chi duoc goi dung 1 lan (job rieng) - failover khong the dung no
    assert len(bing_calls) == 1


def test_dork_pool_without_expressible_dork_yields_no_jobs(monkeypatch):
    """Dork chi gom toan op bi engine drop -> job bi loai, khong request."""
    cfg = make_cfg(queries=["cache:somepage"])
    c = make_crawler(cfg)

    def _boom(engine, query):
        raise AssertionError("no job should run for an inexpressible dork")

    monkeypatch.setattr(c, "_dork_html", _boom)
    res = c.run_dorks()
    assert res.urls == []
    assert set(res.stats.values()) == {0}
    assert res.throttled == []


def test_api_engines_without_credentials_are_skipped(monkeypatch):
    cfg = make_cfg(engines=["google", "serpapi", "cse"])
    cfg["dork"]["serpapi"]["api_key"] = ""
    cfg["dork"]["cse"]["api_key"] = ""
    cfg["dork"]["cse"]["cx"] = ""
    monkeypatch.delenv("SOFIA_SERPAPI_KEY", raising=False)
    monkeypatch.delenv("SOFIA_CSE_KEY", raising=False)
    monkeypatch.delenv("SOFIA_CSE_CX", raising=False)
    c = make_crawler(cfg)
    called: list[str] = []

    def fake_html(engine, query):
        called.append(engine)
        return []

    monkeypatch.setattr(c, "_dork_html", fake_html)
    res = c.run_dorks()
    assert called == ["google"]
    assert set(res.stats) == {"google"}


# ------------------------------------------- bổ sung: throttle + cooldown/failover
def test_looks_throttled_exc_with_real_requests_exceptions():
    m = DorkCrawler._looks_throttled_exc
    assert m(requests.HTTPError("429 Client Error: Too Many Requests"))
    assert m(requests.HTTPError("503 Server Error: Service Unavailable"))
    assert m(requests.RequestException("HTTP 429 (throttled)"))
    # lỗi mạng thuần không phải throttle
    assert not m(requests.ConnectionError("Connection aborted"))
    assert not m(requests.Timeout("timed out"))


def test_cooldown_is_per_engine_and_does_not_leak(monkeypatch):
    """Google bị block không ảnh hưởng bing: limiter/mult/cooldown tách bạch."""
    cfg = make_cfg(min_interval=2.0, block_cooldown=60.0)
    c = make_crawler(cfg)
    g = c._engine_limiter("google")                 # limiter phai ton tai truoc
    b = c._engine_limiter("bing")                   # khi _apply_interval_mult chay
    c._mark_engine_blocked("google")
    assert g.min_interval == pytest.approx(4.0)
    assert b.min_interval == pytest.approx(2.0)
    assert c._engine_available("bing")
    assert not c._engine_available("google")
    assert c._engine_mult.get("bing", 1.0) == pytest.approx(1.0)


def test_mark_engine_blocked_is_thread_safe():
    """Nhiều thread đồng loạt mark block: mult tăng gấp đôi an toàn, có cap."""
    import threading

    cfg = make_cfg(min_interval=2.0, max_interval_mult=8.0)
    c = make_crawler(cfg)
    c._engine_limiter("google")                     # tao limiter truoc khi block

    def worker() -> None:
        for _ in range(5):
            c._mark_engine_blocked("google")

    threads = [threading.Thread(target=worker) for _ in range(8)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    # mult chỉ được nhân 2, không bao giờ vượt max_interval_mult
    assert c._engine_mult["google"] == pytest.approx(8.0)
    assert c._engine_limiter("google").min_interval == pytest.approx(16.0)


def test_failover_does_not_reuse_engine_already_throttled_mid_run(monkeypatch):
    """Google block trước, failover phải chọn engine healthy (không phải google)."""
    c = make_crawler()                     # engines: google, bing
    hits: list[str] = []

    def fake_html(engine, query):
        hits.append(engine)
        if engine == "google":
            c._mark_engine_blocked("google")
            raise requests.RequestException("HTTP 429 (throttled)")
        return ["http://target.example/a.php?id=9"]

    monkeypatch.setattr(c, "_dork_html", fake_html)
    res = c.run_dorks()
    # chỉ google bị throttle, bing vẫn healthy
    assert res.throttled == ["google"]
    assert "http://target.example/a.php?id=9" in res.urls
    # failover đúng nghĩa: sau lần lỗi đầu, engine xử lý dork tiếp theo là bing
    assert hits.count("bing") >= 1
