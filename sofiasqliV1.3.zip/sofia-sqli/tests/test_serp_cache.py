"""Offline tests for the SERP disk cache (TTL, persistence, disable)."""

from __future__ import annotations

import json
import os
import time

from tests.conftest import make_cfg, make_crawler


def test_cache_roundtrip_in_memory(crawler):
    key = crawler._cache_key("google", "q", 0)
    assert crawler._cache_get(key) is None          # cold
    crawler._cache_put(key, ["http://a.example/x.php?id=1"])
    assert crawler._cache_get(key) == ["http://a.example/x.php?id=1"]


def test_cache_key_distinguishes_engine_query_page(crawler):
    a = crawler._cache_key("google", "q", 0)
    b = crawler._cache_key("bing", "q", 0)
    d = crawler._cache_key("google", "q2", 0)
    assert len({a, b, d}) == 3
    assert a == crawler._cache_key("google", "q", 0)


def test_cache_ttl_expiry(tmp_path):
    cfg = make_cfg(cache_enabled=True, cache_ttl=0.05,
                   cache_file=str(tmp_path / "c.json"))
    c = make_crawler(cfg)
    key = c._cache_key("google", "q", 0)
    c._cache_put(key, ["http://a.example/x.php?id=1"])
    import time
    time.sleep(0.08)
    assert c._cache_get(key) is None                # expired


def test_cache_save_and_reload(tmp_path):
    path = str(tmp_path / "c.json")
    cfg = make_cfg(cache_enabled=True, cache_file=path)
    c = make_crawler(cfg)
    key = c._cache_key("bing", "inurl:", 1)
    c._cache_put(key, ["http://a.example/y.php?id=2"])
    c._cache_save()

    on_disk = json.load(open(path, encoding="utf-8"))
    assert key in on_disk

    c2 = make_crawler(make_cfg(cache_enabled=True, cache_file=path))
    assert c2._cache_get(key) == ["http://a.example/y.php?id=2"]


def test_cache_disabled_behaves_as_noop(tmp_path):
    cfg = make_cfg(cache_enabled=False, cache_file=str(tmp_path / "c.json"))
    c = make_crawler(cfg)
    key = c._cache_key("google", "q", 0)
    c._cache_put(key, ["http://a.example/x.php?id=1"])
    assert c._cache_get(key) is None
    c._cache_save()
    assert not os.path.exists(tmp_path / "c.json")


def test_stale_entries_dropped_on_load(tmp_path):
    import time
    path = str(tmp_path / "c.json")
    old = {"k": {"t": time.time() - 99999, "urls": ["http://a.example/"]}}
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(old, fh)
    c = make_crawler(make_cfg(cache_enabled=True, cache_ttl=60,
                              cache_file=path))
    assert c._cache == {}                           # stale entry filtered

def test_cache_hit_skips_network(tmp_path, monkeypatch):
    """Cache hit o page 0 -> khong co bat ky HTTP call nao xay ra."""
    cfg = make_cfg(cache_enabled=True, cache_ttl=600,
                   cache_file=str(tmp_path / "c.json"),
                   max_results_per_query=5)          # 1 page duy nhat
    c = make_crawler(cfg)
    query = 'inurl:".php?id="'
    c._cache_put(c._cache_key("google", query, 0),
                 ["http://target.example/a.php?id=1"])

    def _boom(url, **kw):
        raise AssertionError("network hit despite cache hit")

    monkeypatch.setattr(c, "_get", _boom)
    assert c._dork_html("google", query) == \
        ["http://target.example/a.php?id=1"]


def test_cache_save_prunes_expired_entries(tmp_path):
    path = str(tmp_path / "c.json")
    c = make_crawler(make_cfg(cache_enabled=True, cache_ttl=60, cache_file=path))
    fresh_key = c._cache_key("google", "q1", 0)
    old_key = c._cache_key("bing", "q2", 0)
    c._cache_put(fresh_key, ["http://a.example/x.php?id=1"])
    c._cache_put(old_key, ["http://a.example/y.php?id=2"])
    c._cache[old_key]["t"] = time.time() - 9999    # het han ngay lap tuc
    c._cache_save()
    on_disk = json.load(open(path, encoding="utf-8"))
    assert fresh_key in on_disk
    assert old_key not in on_disk


def test_cache_load_corrupt_file_is_tolerated(tmp_path):
    path = tmp_path / "c.json"
    path.write_text("{not json!!", encoding="utf-8")
    c = make_crawler(make_cfg(cache_enabled=True, cache_file=str(path)))
    assert c._cache == {}                          # fallback an toan


def test_cache_put_snapshots_the_url_list(crawler):
    original = ["http://a.example/x.php?id=1"]
    key = crawler._cache_key("google", "q", 0)
    crawler._cache_put(key, original)
    original.append("MUTATED")                     # dung sau put phai an toan
    assert crawler._cache_get(key) == ["http://a.example/x.php?id=1"]


def test_cache_roundtrip_through_dork_html(tmp_path, monkeypatch):
    """2 lan chay lien tiep: lan 2 doc het ket qua tu disk cache."""
    path = str(tmp_path / "c.json")
    cfg = make_cfg(cache_enabled=True, cache_file=path,
                   max_results_per_query=5)

    c1 = make_crawler(cfg)
    monkeypatch.setattr(c1, "_get", lambda url, **kw: FakeResp(text=SERP_HTML))
    first = c1._dork_html("google", "q")
    c1._cache_save()

    c2 = make_crawler(make_cfg(cache_enabled=True, cache_ttl=600,
                               cache_file=path, max_results_per_query=5))
    monkeypatch.setattr(c2, "_get", lambda url, **kw: FakeResp(text=SERP_HTML))
    second = c2._dork_html("google", "q")
    assert first == second
