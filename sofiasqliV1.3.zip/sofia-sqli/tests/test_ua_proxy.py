"""Offline tests for User-Agent/header rotation and the proxy pool."""

from __future__ import annotations

from core.crawler import _ACCEPT_LANGS, _UA_POOL
from tests.conftest import make_cfg, make_crawler


def test_ua_rotation_uses_pool(monkeypatch):
    c = make_crawler()                              # rotate_user_agent=True
    seen = {c._next_user_agent() for _ in range(60)}
    # TestUA/1.0 (from general.user_agent) prepended + the built-in pool
    assert "TestUA/1.0" in seen
    assert len(seen) >= 3
    assert seen <= set(_UA_POOL) | {"TestUA/1.0"}


def test_ua_rotation_off_pins_single_agent():
    cfg = make_cfg(rotate_user_agent=False)
    cfg["general"]["user_agent"] = "PinnedUA/2.0"
    c = make_crawler(cfg)
    assert c._ua_pool == ("PinnedUA/2.0",)
    assert c._next_user_agent() == "PinnedUA/2.0"


def test_accept_language_pool_nonempty():
    assert _ACCEPT_LANGS and all("q=" in l for l in _ACCEPT_LANGS)


def test_proxy_pool_from_settings_and_env(monkeypatch):
    monkeypatch.setenv("SOFIA_PROXIES",
                       "socks5://1.2.3.4:1080, http://5.6.7.8:8080")
    cfg = make_cfg(proxies=["10.0.0.1:3128", "http://10.0.0.1:3128"])
    c = make_crawler(cfg)
    # "10.0.0.1:3128" auto-prefixed and deduped with its explicit twin
    assert len(c._proxy_pool) == 3
    schemes = sorted(p["http"].split("://")[0] for p in c._proxy_pool)
    assert schemes == ["http", "http", "socks5"]
    for p in c._proxy_pool:
        assert p["http"] == p["https"]


def test_next_proxy_none_without_pool():
    c = make_crawler()                              # proxies: []
    assert c._next_proxy() is None


def test_next_proxy_picks_from_pool(monkeypatch):
    monkeypatch.setenv("SOFIA_PROXIES", "http://a:1,http://b:2")
    c = make_crawler(make_cfg())
    got = {c._next_proxy()["http"] for _ in range(40)}
    assert got == {"http://a:1", "http://b:2"}